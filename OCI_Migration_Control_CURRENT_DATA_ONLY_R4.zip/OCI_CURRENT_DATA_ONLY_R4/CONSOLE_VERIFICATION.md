# Console verification

35/35 Python tests pass: the original 21 tests plus 14 new HTTP wrapper tests. These exercise actual planning/discovery calls, no-write dry-run, fake-OCI execution and journal output, missing approvals, invalid plan identity, Host/Origin/token refusal, path traversal and absence of live cloud execution routes.

Browser QA verified overview rendering from real sample data, inventory navigation and filtering (12 rows to 2), wave detail inspection, named review recording and workspace reset. JavaScript syntax was checked with node --check. Responsive behavior is implemented in CSS; a separate mobile-device browser run was not performed.

Original engine Monte Carlo results remain historical to the unchanged Python core. All 18 originally tested Python source hashes match examples/evidence.json. This is not a fresh 175-trial run of the new wrapper, and it is not live OCI verification.

The hosted site is a static interactive preview. The downloadable local launcher connects the UI to the actual Python engine. Both avoid live cloud mutation through the browser.
