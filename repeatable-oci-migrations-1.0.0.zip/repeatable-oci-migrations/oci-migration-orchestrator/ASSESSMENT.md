# Innovation Assessment

*Repeatable OCI Migrations (`ocio`, version 1.0.0) · J.C. Glover · glover.jwg@gmail.com · 21 October 2026*

*Assessment against the White-Space "Innovation Assessment and Elevation Pass", in its required structure. Evidence
tiers follow the project's rule: **measured** (our code, counted or timed in a 2-CPU cloud container),
**simulated** (an in-memory OCI with injected faults, or synthetic estates with known truth), **modeled**
(reasoning, no run). Nothing here has run against a live tenancy.*

## Letter Grade

**B** for the innovation as it stands: strong, well-tested engineering of a mostly known pattern, with no live
validation and modest distinctiveness.

## Executive Assessment

- **What it is.** A migration control layer that sits on top of Oracle Cloud Migrations (OCM). It turns a VM
  inventory and observed network flows into reviewed application groups, applies versioned target blueprints,
  orders waves by dependency, and executes each wave in one of two ways:
  - by writing the wave's settings into an OCM migration plan (`ocm-wave`);
  - by building target resources directly (`run`).
- **The problem.** Large migrations are run as one-off projects. Each wave is hand-assembled, exceptions are
  invisible, and a crash halfway through a wave leaves people guessing what exists.
- **Who benefits.** Cloud migration teams and the architects who own the target standard.
- **What its novelty depends on.** Not any single component. It depends on one binding rule applied end to end:
  every action is tied to a reviewed plan id. Every deviation from the standard is a named, journalled,
  human-owned exception. Resume is decided by content checked against the cloud, not by the record alone.
- **Type.** A control architecture and method, delivered as software (a Python package with a CLI and a local
  console).
- **Current evidence:**
  - 344 tests pass, measured.
  - Planted-defect (mutation) testing: 206 of 206 caught on the delivered code (one full run caught 204 of 207; two gaps got tests, one equivalent mutant was removed), measured.
  - A Monte Carlo of 14 scenarios × 500 trials with independent oracles: every safety check held in 500 of 500, plus the whole suite in 20 of 20 shuffled runs, simulated.
  - Planning timed to 51,779 synthetic VMs, measured.
  - Discovery accuracy on synthetic estates with known truth, simulated.
- **Still hypothetical.**
  - Behaviour against a live tenancy and a real OCM plan.
  - Operator time saved.
  - Whether teams adopt the review discipline.

**Grade reasons (five):**
1. The problem is real and expensive, and the target (OCM's documented gaps) is specific.
2. The engineering is unusually well verified for its stage: tests written first, mutation testing, Monte Carlo
   with independent oracles, and four independent reviews whose reproduced defects (about 45) were all fixed.
3. Most components are known practice: dependency mapping from flows, infrastructure templates, idempotency
   tokens, hash-chained logs, change approvals.
4. There is no live run yet, so every OCI-facing claim rests on SDK documentation and stand-ins.
5. It is a single-author project with no adoption evidence.

## Novelty Kernel

> The potentially distinctive invention is a **plan-bound exception ledger for migration waves**. One content hash
> (the plan id) binds every input that reaches a cloud API. Every deviation from a standard blueprint, every
> dropped dependency, every external-address acknowledgement and every readiness claim must be a named,
> journalled human decision against that hash. A wave may proceed only when the live cloud agrees with the
> ledger.

- **Potentially novel operating principle.** The plan id as the single unit of authorization:
  - approval, admission evidence (fresh, plan- and wave-bound, named observers) and every `--apply` must quote
    it;
  - a changed input yields a new id and stops the run;
  - combined with resume-by-content verified against OCI.
- **Known or conventional components:**
  - flow-based dependency discovery;
  - blueprint/template catalogs;
  - DAG wave ordering;
  - retry tokens;
  - If-Match etags;
  - a hash-chained journal;
  - quota preflight;
  - AIMD pacing;
  - least-privilege NSGs from observed traffic.
- **Optional enhancements:**
  - the local console;
  - the agent proposer;
  - OCI Generative AI request building.
- **Speculative future features:**
  - learning blueprints from completed waves;
  - cross-tenancy portfolio planning.

## White-Space Analysis

| Category | What it already does | What it does not appear to do | Functional difference | Meaningful? |
|---|---|---|---|---|
| Oracle Cloud Migrations | Discovers VMs, recommends shapes, builds migration plans, replicates and launches | Per Oracle's published material: grouping VMs into apps from traffic, a template library, wave orchestration with dependency gates, rollback beyond terminate-and-rerun | ocio drives OCM plans wave by wave: it excludes out-of-wave assets first, writes the blueprint settings, re-reads to verify, and records a before-state it can restore | Meaningful as an integration layer. *Hypothesis requiring validation:* OCM's own roadmap may close part of this gap |
| Dependency-mapping tools (cloud vendors' discovery services, CMDB/APM products) | Dependency maps from agents or flow data | Usually stop at the map; not bound to an approval-gated execution | Findings carry confidence and evidence; unreviewed dependencies are kept (they can only delay a wave); dropping one needs a named reviewer | Partly. Mapping itself is known; *the review-gated, conservative default is claim territory to investigate* |
| Infrastructure as code (Terraform, OCI Resource Manager) | Declarative state, plan/apply, drift detection | No notion of app waves, migration readiness or per-wave evidence; state is the record, not the live check | Plan-id binding across all inputs; admission evidence that expires; resume verified VM by VM against OCI | Meaningful for migration, less so for general provisioning |
| Change-management and approval systems | Tickets, CAB approvals | Not bound to the exact content of an execution | Approval is journalled against the wave hash and plan id; a changed plan invalidates it | Meaningful in effect. *Subject to prior-art analysis:* signed change bundles exist in deployment tooling |
| AI-assisted migration planning | Model-generated sizing or plans | Usually advisory, or loosely constrained | The model may only propose one VM's blueprint and fields; deterministic code accepts or rejects; approvals and a change cap stay human | Meaningful as a safety pattern. *Claim territory to investigate;* guarded-proposal patterns are emerging broadly |

No claim of legal novelty, patentability, freedom to operate or market exclusivity is made.

## Scorecard

| Dimension | Score | Reason |
|---|---:|---|
| Problem importance | 4/5 | Migration programmes are large and failure-prone; OCM leaves orchestration to the team |
| Novelty potential | 2/5 | Mostly a disciplined combination of known practices; the binding rule is the candidate |
| Functional distinctiveness | 3/5 | The plan-bound exception ledger and the resume rule change outcomes (0 duplicates under crash, simulated) |
| Mechanistic plausibility | 4/5 | Every mechanism is ordinary engineering; OCM-side behaviour is unconfirmed live |
| Testability | 5/5 | Fully testable offline and in a sandbox tenancy; endpoints are countable |
| Technical feasibility | 4/5 | Built and tested; live API details (limits service name, OCM read-back timing) remain |
| Safety and risk manageability | 4/5 | Unknown means stop; dry run by default; restore path; journal; residual risk in OCM behaviour |
| Adoption probability | 2/5 | One author, no pilot, needs a migration team to accept a review discipline |
| Regulatory feasibility | 4/5 | No regulated claims; improves auditability; tenancy security review still required |
| Economic viability | 3/5 | Value if it saves operator time per wave; not yet measured |
| Scalability | 4/5 | Planning measured to 51,779 VMs in 0.55 s; live re-runs cost one read per finished VM |
| Defensibility | 2/5 | Code is easy to reimplement; the advantage would be execution and data, not exclusivity |

- **Total:** 41/60.
- **Confidence:**
  - moderate on the engineering scores, which rest on measured and simulated evidence;
  - low on adoption, economics and defensibility, which are modeled.
- **Three largest uncertainties:** see below.
- **Recommendation:** **test.** Run the minimum decisive experiment in a sandbox tenancy before any wider claim.

## Principal Strengths

- **Unknown means stop.** No quota, image, blueprint, reviewer or evidence is ever filled in by default. 25
  distinct refusals exit with code 2 before any change.
- **Crash safety is demonstrated, not asserted.** Retry tokens, `create_unconfirmed` handling within the 24-hour
  token life, and resume by content checked against OCI give 0 duplicate resources across the crash and
  throttling scenarios (simulated).
- **The verification depth is uncommon:**
  - tests are written first;
  - mutation testing guards each fix with a planted defect;
  - the Monte Carlo oracles are written independently of the modules;
  - four independent reviews were reproduced and closed.
- **It is honest about evidence.** Every figure names its instrument and tier; limits are stated next to
  capabilities.
- **It sits on top of OCM, not beside it.** OCM does replication and cutover, and ocio governs what goes into
  each wave.

## Structural Weaknesses

| Weakness | Class | What would resolve it |
|---|---|---|
| No live tenancy or OCM run | **Major** | `live_smoke.py --apply` in a sandbox, then one `ocm-wave --apply` on a sandbox plan, with the read-back timing recorded |
| Novelty asserted on a combination of known parts | **Major** | Frame the kernel narrowly (plan-bound exception ledger plus live-verified resume) and compare against the strongest alternative in the experiment below |
| No measured operator benefit | **Major** | Time and error counts against a conventional runbook in the experiment below |
| Synthetic estates follow patterns the author chose | Moderate | Discovery on one real (anonymised) flow export |
| OCM target-asset matching by source name, and `created_resource_id` read as "migrated" | Moderate | Confirm on a real plan; a mapping file is the fallback today |
| Windows launcher and lock untested | Minor | One run on a Windows host |
| The console adds surface area to a tool whose core is the CLI | Minor | Keep the console optional; the CLI remains the contract |

## Assumption Register

| Assumption | Why it matters | Existing support | Test needed | Failure consequence |
|---|---|---|---|---|
| OCM applies a target-asset update and reflects it on re-read within the backoff window | `ocm-wave` verifies before anyone executes the plan | SDK docs; stateful stand-in (simulated) | Sandbox OCM plan, timed | The wave refuses (safe), and the backoff needs tuning |
| `opc-retry-token` holds for 24 h on create and update | Duplicate prevention after a lost reply | Oracle documentation (known fact) | Live smoke with a forced resend | Possible duplicate; mitigated by tags and the 23-hour cut-off |
| `used + available` from the Limits API is the effective limit | Quota headroom is a share of it | SDK model docstrings (reasonable inference) | One read in a tenancy with a quota policy | Headroom too large or too small; preflight still refuses unknowns |
| Flow exports capture enough of real dependencies | Wave order | Synthetic accuracy 97.9–100% (simulated) | One real export | Missed dependency; the default keeps unreviewed dependencies, and a reviewer must act |
| Teams will accept a named-reviewer discipline | Adoption | None (unverified assumption) | Pilot interviews | Tool used without review, which reduces its value to a wrapper |
| Operator time per wave falls | Economic case | None (speculative claim) | Experiment below | No business case beyond safety |

## Three Largest Uncertainties

1. Real OCM behaviour: update application, read-back timing, asset matching.
2. Whether the review discipline reduces incidents and rework enough to be worth its cost.
3. Discovery quality on a real, messy estate.

## Initial Decision

**Test.** The engineering is ready for a sandbox; the claims are not ready for anything wider.

# Elevated Innovation

## Executive Thesis

**Repeatable OCI Migrations** is a method and control layer that uses **one content-hashed plan id to bind every
input, approval, readiness proof and exception of a migration wave** to produce **zero-duplicate, fully
attributable wave execution on top of Oracle Cloud Migrations**. Its distinctive operating principle is that
**no wave proceeds unless the live cloud, the reviewed plan and the exception ledger agree**.

- **Primary invention.** The plan-bound exception ledger with live-verified resume.
- **Minimum viable embodiment:**
  - `discover` → review → `plan` → `ocm-wave` (dry run, then apply with the plan id) on one OCM plan;
  - the journal, admission evidence and approvals.
- **Optional embodiments:**
  - the `run` rebuild path;
  - `netpolicy` NSGs;
  - the local console.
- **Removed or deferred:**
  - a live language model in the loop, until the guard is exercised with a real model;
  - resource types beyond VCN, subnet, instance and NSG.
- **Boundary.** Data replication and cutover stay with OCM. ocio governs what enters a wave and proves what
  happened.

## Unmet Need

- **Current workflow.** OCM discovers and replicates. People decide app groups, waves, target sizes and
  readiness in spreadsheets and tickets, then edit migration plans in the console.
- **The gap.** Nothing binds those human decisions to the exact plan that executes. A changed subnet, an extra
  included asset, or stale readiness evidence slips through unnoticed.
- **Why it stays open.** Tools that map dependencies stop at the map. Infrastructure-as-code tools have no notion
  of waves or readiness. Change systems approve descriptions, not content hashes.
- **The consequence.** Assets launched in the wrong wave, duplicate resources after a crash, and audits that
  cannot say who accepted which deviation.
- **Why this principle fits.** A content hash makes "what was approved" and "what runs" the same object, and a
  live check makes "what the record says" and "what exists" the same object.

## Core Invention

- **Inputs:** inventory, flows, listeners, VIPs, reviewed decisions, blueprints, overrides, settings, image map,
  OCM plan, subnet map and admission policy.
- **Plan id:** a hash over all of them.
- **Ledger:** append-only, hash-chained and bound to one target (compartment, environment, landing network).
  It records:
  - every approval, with the wave hash and approver;
  - every admission decision, with the evidence hash and phase;
  - every exception: an override, a rejected dependency, an `external_ok`, or a downsizing;
  - every create, with its retry token, and every before-state.
- **Gate:** a wave executes only if:
  - the plan id matches;
  - admission evidence is fresh and bound to this plan and wave;
  - required approvals exist;
  - quota fits with headroom of the limit;
  - every existing resource is confirmed in OCI.

## What Is Known, New, Optional, and Speculative

| Element | Status |
|---|---|
| Flow-based dependency discovery, DAG waves, templates, retry tokens, etags, hash chains, AIMD pacing | Known |
| Plan id covering every API-reaching input, invalidating approvals and evidence on change | Potentially distinctive (claim territory to investigate) |
| Conservative discovery default: unreviewed dependencies kept, any drop or `external_ok` needs a named reviewer | Potentially distinctive in combination |
| Resume by content verified against OCI, with token-age cut-off for unconfirmed creates | Known parts, distinctive application |
| Guarded agent proposals (one VM, factory's blueprint, customizable fields only, never below source) | Optional |
| Console, NSG generation, OCI Generative AI request | Optional |
| Learning blueprints from wave outcomes | Speculative |

## Operating Architecture

```
Inventory + flows + listeners + VIPs
  ↓
Baseline: discover (findings with confidence and evidence; unknown private addresses must be placed)
  ↓
Review: decisions file (accept / reject / regroup / external_ok, named reviewer)
  ↓
Plan: blueprints, waves, policy gates → plan id (dry run; nothing sent)
  ↓
Evidence: admission documents bound to plan id + wave, fresh, named observers
  ↓
Gate: plan id match · admission · approvals · quota (headroom of limit) · live check of existing resources
  ↓
Execute wave: exclude out-of-wave assets → write wave settings → re-read and verify  (or run: create → wait)
  ↓
Continue / stop (refusal, exit 2) / restore (ocm-restore from journalled before-state) / teardown (run path)
  ↓
Verify: journal chain, status, read-back; next wave only after dependencies show migrated
```

- **Entry conditions.** A target bound to its own journal; a reviewed inventory with no open unresolved private
  addresses.
- **Exit conditions.** All waves SUCCEEDED, or a refusal naming the step and the remedy.

## Decision and Safety Logic

- **Inputs:** the files above, plus live reads: limits, shapes, ADs, OCM assets and etags, resource states.
- **State variables:** per-step journal status, the live view of what exists, the plan id, wave hash, evidence
  age, and quota remaining against the total.
- **Decision rules:** a wave runs only when every gate in Core Invention passes. Any unknown is a stop.
- **Outputs:** a dry-run plan with its id; or an applied wave with a journal; or a refusal with exit 2 and a
  remedy.
- **Safety hierarchy (overrides everything):**
  1. A journal that is torn, broken or busy.
  2. A target mismatch.
  3. A 412 etag mismatch.
  4. An asset in FAILED, NEEDS_ATTENTION or DELETED.
  5. An unconfirmed create older than 23 hours.
  6. Any unknown quota or image.
- **Human authority:**
  - reviewers own the discovery decisions;
  - approvers own production, subnet moves, growth beyond 2× and shrinking below the source;
  - observers own the admission evidence;
  - the agent only proposes.

| Evidence state | Interpretation | Default action | Safety override |
|---|---|---|---|
| Plan id differs from the one quoted | Inputs changed since review | Refuse, exit 2 | — |
| Admission evidence stale, future, wrong wave, or a recorded failure | Readiness not established | BLOCKED_ADMISSION (journalled) | — |
| Quota unknown or within headroom of the limit | Capacity not established | BLOCKED_QUOTA | — |
| Journal says it exists; OCI says gone | Deleted by hand | Create again, once | Unexpected state → BLOCKED_STATE |
| Create sent, reply lost, token older than 23 h | Possible orphan | Stop; find by `ocio_run` / `ocio_step` tags | Always |
| OCM read-back disagrees after update | Plan not as intended | Refuse; do not execute the plan | Always |

## Conflicting-Evidence Rules

- **Journal versus OCI:** OCI wins for existence; the journal wins for provenance. A disagreement in state stops
  the wave.
- **Discovery versus tags:** tags win (confidence 1.0). An invalid tier tag is inferred, but capped at 0.5 for
  review.
- **Two evidence documents for one wave:** both are refused.
- **A reviewer decision versus a finding:** the decision applies only with a named reviewer. Unreviewed
  dependencies are kept.

## Minimum Decisive Experiment

- **Objective.** Does the plan-bound ledger with live-verified resume reduce wrong-wave launches, duplicates and
  unattributed deviations, compared with a conventional OCM runbook, at no more than equal operator time?
- **Model.** One sandbox tenancy and one OCM migration plan with about 20 small test VMs in 5 apps and 3 waves.
  The dependencies are known, and two are deliberately missing from the tags.
- **Arms:**
  1. Conventional runbook: console edits, a spreadsheet and a checklist.
  2. The same, with Terraform for target settings (a fixed-tooling control).
  3. ocio with the review discipline (the proposed protocol).
  4. ocio with the gates disabled except the dry run (a component control: tooling without the ledger).
- **Sequence.** Each arm migrates the same waves. Injected events, at fixed points:
  - the process killed mid-wave;
  - a console edit between read and write;
  - stale readiness evidence;
  - a quota near the limit.
- **Blinding and randomization.** The order of arms is randomised across two operators. Outcomes are counted from
  tenancy audit logs by a third person who does not know the arm.
- **Primary endpoint.** Safety errors per wave: wrong-wave launches, duplicate resources, and deviations without
  a named owner.
- **Secondary and safety endpoints:**
  - operator minutes per wave;
  - time to a safe state after an injected failure;
  - refusals that were false alarms;
  - restore success.
- **Replication.** Two operators, then a second sandbox plan.
- **Analysis.** Support means arm 3 has fewer safety errors than arms 1 and 2, with operator time no worse than
  20% above arm 1. If arm 4 matches arm 3, the ledger adds nothing beyond tooling.

## Endpoints

- **Primary.** Safety errors per wave. Target: 0 for ocio, against an observed baseline.
- **Secondary.** Operator minutes per wave; time to recover; false-refusal rate.
- **Mechanistic.**
  - every applied wave traces to one plan id and named owners in the journal;
  - the read-back matches the plan.
- **Durability.** The same results on the second plan and with the second operator.
- **Thresholds.** Set after the arm-1 baseline is measured; none is invented here.

## Advance, Redesign, and Stop Criteria

- **Advance when:**
  - zero duplicates and zero wrong-wave launches in arm 3 across both replications;
  - fewer safety errors than arms 1 and 2;
  - operator time within 20% of arm 1.
- **Redesign when:**
  - safety errors fall but operator time rises sharply (simplify the review);
  - the OCM read-back regularly exceeds the backoff (tune it, or move to work-request polling only).
- **Stop when:**
  - arm 4 equals arm 3, so the ledger adds nothing;
  - OCM rejects or silently ignores target-asset updates in ways that cannot be verified.
- **Simplicity test.** If ocio does not beat a conventional runbook with Terraform, do not advance the added
  complexity.

## Development Portfolio

| Path | Purpose | Minimum product or experiment | Readiness | Largest dependency | Go/no-go | Connection to core |
|---|---|---|---|---|---|---|
| **Primary** | Plan-bound OCM wave control | The experiment above | Built, offline-verified | Sandbox OCM plan | Advance criteria above | It is the core |
| **Lower-risk** | Report-only planning: discovery, deviation report, wave plan; nothing created | One real estate export | Ready now | A customer's flow export | Reviewers accept 80% or more of high-confidence findings | Feeds the core; useful alone |
| **Frontier** | Model-proposed blueprints under the guard; learning from outcomes | Guard fuzzing with a real model | Request built, never called | Model access and evaluation data | 0 unsafe accepted over a large hostile set, with a real model | Kept separate; must not define the minimum product |

## Defensibility and Prior-Art Investigation

| Claim family to investigate | Potentially distinctive element | Likely prior-art threat | Evidence needed | Narrower fallback |
|---|---|---|---|---|
| Method: plan-bound authorization of migration waves | One hash over every API-reaching input invalidates approvals and evidence on change | Signed deployment bundles, change-management hashes | Comparison against such systems; experiment data | Limited to OCM target-asset updates with exclude-first ordering and read-back |
| Control logic: conservative dependency review | Unreviewed dependencies kept; drops and external acknowledgements need a named reviewer | Dependency-mapping products | Search of their review workflows | Combined with plan-id binding |
| Safety and recovery: live-verified resume | Journal provenance plus OCI existence checks plus the token-age cut-off | Idempotent workflow engines | Analysis of their resume semantics | Specific to retry-token lifetime handling |
| Workflow: guarded AI proposals | Only the factory's blueprint and customizable fields, never below the source | Policy-as-code over model output | Survey of emerging guard patterns | Combined with change caps and approvals |

> Legal novelty, non-obviousness, patent eligibility, enablement, freedom to operate, and claim scope require
> professional analysis and cannot be established by conceptual assessment alone.

## Adoption and Implementation

- **Who decides:** the migration programme lead and the cloud architect who owns the target standard.
- **Who pays:** the migration programme.
- **Who bears the risk:** the application owners whose waves move.
- **Workflow fit:** it runs beside OCM, from a laptop or a bastion, using existing IAM policies (listed verbatim
  in the RUNBOOK).
- **Training:** the review file, plan ids, and reading refusals. About half a day.
- **Evidence each stakeholder needs:** the experiment's safety counts (programme), the audit trail (security),
  operator time (delivery).
- **Barriers even if it works:**
  - single-author support;
  - preference for vendor tools;
  - review fatigue.

## Risk Register

| Risk | Probability | Impact | Early warning signal | Mitigation | Decision consequence |
|---|---:|---:|---|---|---|
| OCM behaves differently from the SDK documentation | Medium | High | Read-back mismatch in the sandbox | Verify-before-execute; mapping file; restore | Redesign the OCM path |
| Review fatigue: reviewers rubber-stamp | Medium | Medium | Near-zero rejection rate | Show confidence and evidence; cap customizations | Simplify the review |
| Discovery misses real dependencies | Medium | High | Late-found dependencies during a pilot | Keep unreviewed dependencies; per-wave gate on dependencies migrated | Require more evidence sources |
| Single maintainer | High | Medium | Unanswered issues | Documented code, test suite, mutation harness | Partner or hand over |
| Live API details (limits service name) | Medium | Low | Unknown quota → refusal | Fail closed; one-time confirmation | Configuration only |
| Console misuse on a shared host | Low | Medium | — | Token only via a private launch file; host check | — |

## Revised Scorecard

| Dimension | Score | Change |
|---|---:|---|
| Problem importance | 4/5 | — |
| Novelty potential | 3/5 | +1: the kernel is stated narrowly and comparably |
| Functional distinctiveness | 3/5 | — (until the experiment) |
| Mechanistic plausibility | 4/5 | — |
| Testability | 5/5 | — |
| Technical feasibility | 4/5 | — |
| Safety and risk manageability | 4/5 | — |
| Adoption probability | 3/5 | +1: the lower-risk report-only path needs no write access |
| Regulatory feasibility | 4/5 | — |
| Economic viability | 3/5 | — |
| Scalability | 4/5 | — |
| Defensibility | 2/5 | — |

**Total 43/60** (conceptual; nothing new has been measured).

## Immediate Next Steps

1. Run `scripts/live_smoke.py --apply` in a sandbox compartment and record the results.
2. Run one `ocm-wave` dry run, then apply it on a sandbox OCM plan; time the read-back.
3. Run report-only discovery on one real, anonymised flow export.
4. Run the minimum decisive experiment with two operators.

## Final Formulation

Repeatable OCI Migrations is a control layer over Oracle Cloud Migrations. It turns migration decisions into a
plan-bound exception ledger: one hash covers every input that can reach the cloud. Every deviation, dropped
dependency and readiness claim must be a named, journalled human decision against that hash. A wave runs only
when the live cloud agrees with the record. It is built and verified offline:
- 344 tests;
- 206 of 206 planted defects caught;
- a 500-trial Monte Carlo with independent oracles;
- four independent reviews closed.

Its next proof is a sandbox experiment against a conventional runbook. It advances only if it removes
wrong-wave launches and duplicates without costing materially more operator time.

# Improvement Delta

| Area | Original version | Elevated version | Why it is stronger |
|---|---|---|---|
| Novelty statement | "Standardize by default, customize by exception" | Plan-bound exception ledger with live-verified resume | Names a mechanism that can be compared and tested |
| Scope | Five parts presented equally | One primary invention; the console, agent and NSGs are optional | Smaller minimum product; the frontier path cannot define it |
| Evidence | Offline tests and simulations | The same, plus a predefined sandbox experiment with a fixed-tooling control | Tests the principle, not only the components |
| Success | Implicit | Primary endpoint (safety errors per wave) with advance, redesign and stop rules | Falsifiable |
| Adoption | Full pipeline adoption | Report-only discovery as an entry path | Value with no write access |

- **Original letter grade:** B.
- **Elevated conceptual grade:** B+. Higher only with live evidence.
- **Remaining barrier to an A+:** measured live results showing fewer safety errors than a conventional runbook
  at comparable operator time, replicated, plus one real-estate discovery run.
- **Single most important next experiment:** the four-arm sandbox experiment above (start with
  `live_smoke.py --apply`).
- **Single most important nontechnical action:** secure one OCI sandbox plan and one migration team willing to
  run the report-only path on a real estate.
