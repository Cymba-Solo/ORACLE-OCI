# OCI Migration Orchestrator (version 2, ocio 1.0.0)

**ocio** = **OCI O**rchestrator, short for OCI Migration Orchestrator: the Python package and its `ocio` command. The browser console is **OCI Migration Control** (double-click `Launch`).

Read `BRIEF.md` for the design and results, and `RUNBOOK.md` for how to use it. Everything here runs
locally with no OCI account. The live paths are `scripts/live_smoke.py` (dry run unless `--apply`) and
`scripts/migrate.py ocm-wave` (dry run unless `--apply`).

Quick start: double-click `Launch.command` (macOS) or `Launch.bat` (Windows), or run `./launch.sh`, for the
console. On the command line:

```
pip install oci                         # only for live runs and the SDK/OCM adapter tests (tested with 2.189.0)
pip install .                           # optional: installs the `ocio` command (python -m ocio works without it)
python -B -m unittest                   # 344 tests
python -B mutate.py                     # 206 planted defects; the suite must catch every one
python -B scripts/montecarlo.py --trials 500 --out mc.json   # randomised scenarios with independent oracles
python -B demo.py                       # v1 demo: factory + engine with injected faults
python -B demo_v2.py                    # all five parts: discovery -> agent -> waves -> crash/fail -> re-run
python -B scripts/scale_test.py out.json    # planning/discovery timings; fixed pools vs adaptive pacing
python -B scripts/evidence.py out.json      # discovery accuracy, renamed hosts, guard fuzz
python -m ocio --help                   # discover | plan | run | ocm-wave | ocm-restore | netpolicy | status |
                                        # teardown | resolve | ui
```

`ASSESSMENT.md` grades the work against the White-Space innovation framework. `TUNEUP_LOG.md` records every
tune-up: the defect, the fix and the test that failed before it.

## Layout

| Path | What it holds |
|---|---|
| `ocio/discovery.py` | Part 1: app groups, tiers and dependencies from assets, flows, listeners and VIPs, with confidence and evidence |
| `ocio/factory.py`, `ocio/catalog.py` | Part 2: blueprints, overrides, Flex shape limits, deviation report, target network. Part 3: the wave planner (mutual groups, caps) |
| `ocio/capacity.py` | Part 3: quota preflight (Oracle's documented compute limit names) and the adaptive pacing limiter |
| `ocio/ocm.py` | Part 4, migration path: blueprint placements as Oracle Cloud Migrations target-asset updates; before-state and restore |
| `ocio/admission.py` | Readiness evidence: fresh, plan- and wave-bound, named observers |
| `ocio/netpolicy.py` | Least-privilege NSGs per app tier from observed traffic |
| `ocio/cli.py`, `ocio/auth.py`, `ocio/errors.py` | The `ocio` command, the four authentication modes, OCI error hints |
| `ocio/ui/` | OCI Migration Control: the local console (the provisioned wrapper page with ocio's data) and its launcher |
| `ocio/engine.py`, `ocio/journal.py`, `ocio/policy.py`, `ocio/spec.py` | Part 4, rebuild path: gates, dry run, retries, idempotent creates, waits, rollback, teardown, resume, hash-chained journal |
| `ocio/agent.py` | Part 5: proposal format, guard, approvals, change cap; rule-based, adversarial and LLM proposers; OCI Generative AI request |
| `ocio/pipeline.py` | All parts wired together: blocked apps, plan id, resume by content |
| `ocio/providers.py` | Simulated OCI (faults, throttling, crashes) and the real OCI SDK adapter |
| `ocio/synth.py` | Synthetic estates with known ground truth, for discovery accuracy and scale tests |
| `scripts/` | `migrate.py` (same CLI), `live_smoke.py`, `montecarlo.py`, `scale_test.py`, `evidence.py`, `release.py`, `make_example_estate.py` |
| `tests/` | `test_all.py` (v1 guarantees), `test_v2.py` (v2 parts, review rounds, determinism, CLI), `test_tuneup.py` (one class per tune-up) |
| `examples/` | Inventory, overrides, a 54-VM discovery estate (`estate/`), and saved outputs: `demo_output.txt`, `demo_v2_output.txt`, `scale_results.json`, `evidence.json`, `mutate_results.txt`, `montecarlo_results.json`; admission policy and evidence templates |
