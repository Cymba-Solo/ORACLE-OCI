"""Tests. Run from a cleared cache:  python -B -m unittest -v"""
import copy
import os
import random
import tempfile
import unittest

from ocio import factory as F
from ocio import policy
from ocio.catalog import BLUEPRINTS, E5
from ocio.engine import Engine, RetryPolicy, retry_token
from ocio.journal import Journal
from ocio.providers import Crash, FakeOCI, OCISDKProvider, ProviderError
from ocio.spec import SpecError, Step, Workflow, load, resolve, waves

COMP = "ocid1.compartment.oc1..test"
TAGS = {"cost_center": "cc-100", "owner": "platform"}


def lz(env="prod"):
    return F.landing_zone("acme", env, COMP, TAGS, "10.0.0.0/16",
                          {"web": "10.0.1.0/24", "app": "10.0.2.0/24", "db": "10.0.3.0/24"})


class Clock:
    def __init__(self):
        self.t = 0.0
    def __call__(self):
        return self.t
    def sleep(self, s):
        self.t += s


def engine(fake, path, **kw):
    c = Clock()
    return Engine(fake, Journal(path), sleep=c.sleep, clock=c, rng=random.Random(1), **kw), c


class Tmp(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.jp = os.path.join(self.d, "journal.jsonl")


# ------------------------------------------------------------------ spec


class SpecTests(unittest.TestCase):
    def doc(self, steps):
        return {"name": "t", "environment": "dev", "compartment_id": COMP, "steps": steps, "tags": TAGS}

    def test_waves_group_independent_steps(self):
        wf = lz()
        self.assertEqual(waves(wf), [["vcn"], ["subnet_app", "subnet_db", "subnet_web"]])

    def test_cycle_rejected(self):
        with self.assertRaises(SpecError):
            load(self.doc([{"id": "a", "kind": "vcn", "depends_on": ["b"]}, {"id": "b", "kind": "vcn", "depends_on": ["a"]}]))

    def test_reference_without_dependency_rejected(self):
        with self.assertRaises(SpecError):
            load(self.doc([{"id": "v", "kind": "vcn", "params": {"cidr_block": "10.0.0.0/16"}},
                           {"id": "s", "kind": "subnet", "params": {"vcn_id": "${v.id}"}}]))

    def test_unknown_kind_and_missing_dep_rejected(self):
        for steps in ([{"id": "a", "kind": "database"}], [{"id": "a", "kind": "vcn", "depends_on": ["zz"]}]):
            with self.subTest(steps=steps), self.assertRaises(SpecError):
                load(self.doc(steps))

    def test_unresolved_reference_is_error_not_blank(self):
        with self.assertRaises(SpecError):
            resolve({"x": "${v.id}"}, {})


# ------------------------------------------------------------------ policy


class PolicyTests(unittest.TestCase):
    def test_landing_zone_passes_prod_gates(self):
        self.assertEqual(policy.evaluate(lz("prod")), [])

    def test_public_subnet_in_prod_blocked(self):
        wf = lz("prod")
        steps = tuple(Step(s.id, s.kind, dict(s.params, prohibit_public_ip_on_vnic=False), s.depends_on)
                      if s.id == "subnet_web" else s for s in wf.steps)
        v = policy.evaluate(Workflow(wf.name, "prod", COMP, steps, TAGS))
        self.assertTrue(any("subnet_web" in x for x in v))

    def test_overlapping_and_outside_cidrs_blocked(self):
        wf = F.landing_zone("x", "dev", COMP, TAGS, "10.0.0.0/16", {"web": "10.0.1.0/24", "app": "10.0.1.128/25"})
        self.assertTrue(any("overlapping" in x for x in policy.evaluate(wf)))
        wf = F.landing_zone("x", "dev", COMP, TAGS, "10.0.0.0/16", {"web": "10.9.0.0/24"})
        self.assertTrue(any("not inside" in x for x in policy.evaluate(wf)))

    def test_missing_tags_blocked(self):
        wf = lz(); wf2 = Workflow(wf.name, wf.environment, COMP, wf.steps, {})
        self.assertTrue(any("required tag" in x for x in policy.evaluate(wf2)))


# ------------------------------------------------------------------ factory (the cookie cutter)


def W(name, app, tier="app", os="Red Hat Enterprise Linux 8 (64-bit)", vcpus=4, mem=16, deps=()):
    return F.Workload(name, app, tier, os, vcpus, mem, tuple(deps))


class FactoryTests(unittest.TestCase):
    def test_standard_placement_and_sizing(self):
        p = F.place(W("vm1", "crm", vcpus=6, mem=24), BLUEPRINTS, {})
        self.assertEqual(p.blueprint.id(), "app-linux@v1")
        self.assertEqual((p.params["ocpus"], p.params["memory_gbs"], p.params["shape"]), (3, 24, E5))
        self.assertTrue(p.standard)

    def test_odd_vcpus_round_up_never_shrink(self):
        self.assertEqual(F.size(W("v", "a", vcpus=3)), {"ocpus": 2, "memory_gbs": 16})
        self.assertEqual(F.size(W("v", "a", vcpus=1)), {"ocpus": 1, "memory_gbs": 16})

    def test_allowed_override_is_applied_and_reported(self):
        p = F.place(W("vm1", "crm"), BLUEPRINTS, {"memory_gbs": 64})
        self.assertEqual(p.params["memory_gbs"], 64)
        self.assertFalse(p.standard)
        rep = F.deviation_report([p, F.place(W("vm2", "crm"), BLUEPRINTS, {})])
        self.assertEqual((rep["standard"], rep["customized"], rep["standard_pct"]), (1, 1, 50.0))
        self.assertEqual(rep["customizations"][0]["overrides"], {"memory_gbs": 64})

    def test_locked_field_override_refused_with_field_named(self):
        with self.assertRaises(F.FactoryError) as cm:
            F.place(W("web1", "shop", tier="web"), BLUEPRINTS, {"assign_public_ip": True})
        self.assertIn("assign_public_ip", str(cm.exception))

    def test_no_blueprint_refused_not_defaulted(self):
        for w in (W("x", "a", tier="db", os="Windows Server 2019"), W("y", "a", os="FreeBSD 13")):
            with self.subTest(w=w.name), self.assertRaises(F.FactoryError):
                F.place(w, BLUEPRINTS, {})

    def test_os_family_detection(self):
        self.assertEqual(F.os_family("Microsoft Windows Server 2022 (64-bit)"), "windows")
        self.assertEqual(F.os_family("Oracle Linux 8"), "linux")
        self.assertEqual(F.os_family("CentOS 7"), "linux")
        self.assertEqual(F.os_family("Solaris 11"), "unknown")

    def test_waves_respect_app_dependencies(self):
        ws = [W("a1", "crm", deps=["db-core"]), W("d1", "db-core", tier="db"), W("p1", "portal", deps=["crm"]),
              W("h1", "hr")]
        self.assertEqual(F.plan_waves(ws), [["db-core", "hr"], ["crm"], ["portal"]])

    def test_wave_size_cap(self):
        ws = [W(f"v{i}", f"app{i}") for i in range(5)]
        self.assertEqual([len(w) for w in F.plan_waves(ws, max_apps_per_wave=2)], [2, 2, 1])

    def test_mutual_dependency_moves_together_and_unknown_app_refused(self):
        # v2 behaviour change: discovery finds mutual dependencies in real estates (A calls B, B calls A).
        # Neither can move first, so they move in the same wave and are reported, instead of failing.
        ws = [W("a", "x", deps=["y"]), W("b", "y", deps=["x"]), W("c", "z", deps=["x"]), W("d", "core")]
        self.assertEqual(F.plan_waves(ws), [["core", "x", "y"], ["z"]])
        self.assertEqual(F.mutual_groups(ws), [["x", "y"]])
        with self.assertRaises(F.FactoryError):
            F.plan_waves([W("a", "x", deps=["ghost"])])

    def test_wave_workflow_uses_landing_subnets_and_custom_subnet(self):
        outs = {"subnet_app": {"id": "ocid.app"}, "subnet_db": {"id": "ocid.db"}, "subnet_web": {"id": "ocid.web"}}
        p1 = F.place(W("db1", "core", tier="db"), BLUEPRINTS, {"subnet": "subnet_app"})
        p2 = F.place(W("db2", "core", tier="db"), BLUEPRINTS, {})
        wf = F.wave_workflow(1, ["core"], [p1, p2], outs, "prod", COMP, TAGS)
        ids = {s.id: s.params["subnet_id"] for s in wf.steps}
        self.assertEqual(ids, {"db1": "ocid.app", "db2": "ocid.db"})
        self.assertIn("subnet", p1.params)          # placement not mutated by building the workflow
        self.assertEqual(wf.tags["migration_wave"], "1")


# ------------------------------------------------------------------ engine


class EngineTests(Tmp):
    def test_dry_run_plan_makes_no_calls(self):
        fake = FakeOCI(); e, _ = engine(fake, self.jp)
        plan = e.plan(lz())
        self.assertEqual(plan["violations"], [])
        self.assertEqual(fake.calls, [])

    def test_blocked_by_policy_makes_no_calls(self):
        fake = FakeOCI(); e, _ = engine(fake, self.jp)
        wf = lz(); bad = Workflow(wf.name, "prod", COMP, wf.steps, {})
        r = e.apply(bad)
        self.assertEqual(r.status, "BLOCKED"); self.assertEqual(fake.calls, [])

    def test_happy_path_creates_and_waits_for_ready(self):
        fake = FakeOCI(); e, _ = engine(fake, self.jp)
        r = e.apply(lz())
        self.assertEqual(r.status, "SUCCEEDED", r.error)
        self.assertEqual(len(fake.live()), 4)
        self.assertTrue(all(o["state"] == "AVAILABLE" for o in r.outputs.values()))
        self.assertTrue(e.j.verify())

    def test_throttling_is_retried_with_backoff(self):
        fake = FakeOCI(faults={("create", "subnet"): [429, 503, 0, 0, 0]}); e, clock = engine(fake, self.jp)
        r = e.apply(lz())
        self.assertEqual(r.status, "SUCCEEDED", r.error)
        self.assertGreater(clock.t, 0)                       # backoff actually slept
        self.assertEqual(len(fake.live()), 4)                 # retries created no duplicates

    def test_retry_gives_up_after_max_attempts_and_rolls_back(self):
        fake = FakeOCI(faults={("create", "subnet"): [429] * 50})
        e, _ = engine(fake, self.jp, retry=RetryPolicy(max_attempts=3))
        r = e.apply(lz())
        self.assertEqual(r.status, "FAILED_ROLLED_BACK")
        self.assertIn("3 attempt", r.error)
        self.assertEqual(fake.live(), {})

    def test_client_error_is_not_retried(self):
        fake = FakeOCI(faults={("create", "vcn"): [400]}); e, _ = engine(fake, self.jp)
        r = e.apply(lz())
        self.assertEqual(r.status, "FAILED_ROLLED_BACK")
        self.assertEqual(sum(1 for c in fake.calls if c[0] == "create"), 1)

    def test_failed_provision_rolls_back_in_reverse_order(self):
        fake = FakeOCI(fail_provision={"acme-db"}); e, _ = engine(fake, self.jp)
        r = e.apply(lz())
        self.assertEqual(r.status, "FAILED_ROLLED_BACK")
        self.assertEqual(r.rolled_back[-1], "vcn")            # VCN last: subnets deleted first
        self.assertEqual(fake.live(), {})

    def test_rollback_failure_reports_orphans_by_ocid(self):
        fake = FakeOCI(fail_provision={"acme-db"}, faults={("delete", "vcn"): [400]}); e, _ = engine(fake, self.jp)
        r = e.apply(lz())
        self.assertEqual(r.status, "FAILED_ROLLBACK_INCOMPLETE")
        self.assertEqual([o["step"] for o in r.orphans], ["vcn"])
        self.assertTrue(r.orphans[0]["id"].startswith("ocid1.vcn"))

    def test_wait_timeout(self):
        fake = FakeOCI(provision_polls=10_000); e, _ = engine(fake, self.jp, wait_timeout=60, poll_seconds=5)
        r = e.apply(lz())
        self.assertEqual(r.status, "FAILED_ROLLED_BACK"); self.assertIn("within 60", r.error)

    def test_crash_then_resume_creates_no_duplicates(self):
        fake = FakeOCI(crash_after_create={"acme-app"}); e, _ = engine(fake, self.jp)
        wf = lz()
        with self.assertRaises(Crash):
            e.apply(wf)
        run_id = Journal(self.jp).entries[0]["run_id"]
        e2, _ = engine(fake, self.jp)                         # new process, same journal
        r = e2.apply(wf, run_id=run_id)
        self.assertEqual(r.status, "SUCCEEDED", r.error)
        self.assertEqual(len(fake.live()), 4)                 # the app subnet was not created twice
        self.assertEqual(sum(1 for c in fake.calls if c == ("create", "vcn", "acme-vcn")), 1)

    def test_resume_refuses_a_changed_workflow(self):
        fake = FakeOCI(crash_after_create={"acme-app"}); e, _ = engine(fake, self.jp)
        with self.assertRaises(Crash):
            e.apply(lz())
        run_id = Journal(self.jp).entries[0]["run_id"]
        other = F.landing_zone("acme", "prod", COMP, TAGS, "10.0.0.0/16", {"web": "10.0.1.0/24"})
        with self.assertRaises(SpecError):
            engine(fake, self.jp)[0].apply(other, run_id=run_id)

    def test_resume_after_rollback_gets_new_resources(self):
        fake = FakeOCI(fail_provision={"acme-db"}); e, _ = engine(fake, self.jp)
        r = e.apply(lz()); self.assertEqual(r.status, "FAILED_ROLLED_BACK")
        fake.fail_provision.clear()
        r2 = engine(fake, self.jp)[0].apply(lz(), run_id=r.run_id)
        self.assertEqual(r2.status, "SUCCEEDED", r2.error)
        self.assertEqual(len(fake.live()), 4)

    def test_retry_token_stable_and_generation_scoped(self):
        self.assertEqual(retry_token("r", "s"), retry_token("r", "s"))
        self.assertNotEqual(retry_token("r", "s", 0), retry_token("r", "s", 1))

    def test_journal_tamper_detected(self):
        fake = FakeOCI(); e, _ = engine(fake, self.jp); e.apply(lz())
        with open(self.jp) as f:
            lines = f.read().splitlines()
        lines[2] = lines[2].replace("created", "creatEd")
        with open(self.jp, "w") as f:
            f.write("\n".join(lines) + "\n")
        self.assertFalse(Journal(self.jp).verify())


# ------------------------------------------------------------------ end to end: factory -> engine


class EndToEnd(Tmp):
    def test_two_waves_one_fails_and_only_that_wave_rolls_back(self):
        ws = [W("db1", "core", tier="db"), W("app1", "crm", deps=["core"]), W("app2", "crm", deps=["core"])]
        pl = [F.place(w, BLUEPRINTS, {}) for w in ws]
        fake = FakeOCI(fail_provision={"app2"}); e, _ = engine(fake, self.jp)
        z = e.apply(lz()); self.assertEqual(z.status, "SUCCEEDED")
        results = [e.apply(F.wave_workflow(i, apps, pl, z.outputs, "prod", COMP, TAGS))
                   for i, apps in enumerate(F.plan_waves(ws), start=1)]
        self.assertEqual([r.status for r in results], ["SUCCEEDED", "FAILED_ROLLED_BACK"])
        names = {r["params"]["display_name"] for r in fake.live().values()}
        self.assertIn("db1", names); self.assertNotIn("app1", names); self.assertNotIn("app2", names)


# ------------------------------------------------------------------ real SDK adapter (offline)


class SDKAdapterOffline(unittest.TestCase):
    """Builds real oci.core.models request objects. No network, no credentials."""

    def setUp(self):
        self.p = OCISDKProvider.__new__(OCISDKProvider)
        import oci
        self.p.oci, self.p.ad, self.p.image_id = oci, "AD-1", "ocid1.image.oc1..x"

    def test_models_build_with_expected_fields(self):
        v = self.p.build("vcn", COMP, {"display_name": "v", "cidr_block": "10.0.0.0/16"}, TAGS)
        self.assertEqual((v.cidr_blocks, v.compartment_id, v.freeform_tags), (["10.0.0.0/16"], COMP, TAGS))
        s = self.p.build("subnet", COMP, {"display_name": "s", "cidr_block": "10.0.1.0/24", "vcn_id": "ocid.v",
                                           "prohibit_public_ip_on_vnic": True}, TAGS)
        self.assertTrue(s.prohibit_public_ip_on_vnic)
        i = self.p.build("instance", COMP, {"display_name": "i", "shape": E5, "subnet_id": "ocid.s", "ocpus": 2,
                                             "memory_gbs": 16}, TAGS)
        self.assertEqual((i.shape, i.shape_config.ocpus, i.create_vnic_details.assign_public_ip,
                          i.source_details.image_id), (E5, 2, False, "ocid1.image.oc1..x"))

    def test_service_error_maps_to_transient(self):
        import oci
        def boom(*a, **k):
            raise oci.exceptions.ServiceError(429, "TooManyRequests", {}, "slow down")
        with self.assertRaises(ProviderError) as cm:
            self.p._call(boom)
        self.assertTrue(cm.exception.transient)


if __name__ == "__main__":
    unittest.main()
