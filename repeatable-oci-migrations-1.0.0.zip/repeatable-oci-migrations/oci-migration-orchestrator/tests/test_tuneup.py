"""Tune-up iterations. Each test was written first, seen to fail against the code before the change, and
then passes; TUNEUP_LOG.md records the finding, the change and the evidence for each one."""
import io
import json
import os
import random
import sys
import tempfile
import unittest
from types import SimpleNamespace as NS
from unittest import mock

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "scripts"))

from ocio import capacity as C, factory as F, ocm as O, pipeline as P, synth   # noqa: E402
from ocio.catalog import BLUEPRINTS                                            # noqa: E402
from ocio.engine import Engine                                                 # noqa: E402
from ocio.journal import Journal                                               # noqa: E402
from ocio.providers import FakeOCI                                             # noqa: E402

COMP = "ocid1.compartment.oc1..tune"
TAGS = {"cost_center": "cc", "owner": "o"}
QUOTA = C.StaticQuota({n: 1e9 for pair in C.SHAPE_LIMITS.values() for n in pair})
L8 = "Oracle Linux 8"
WIN = "Microsoft Windows Server 2022 (64-bit)"


def W(name, app, tier="app", os_=L8, vcpus=4, mem=16, deps=()):
    return F.Workload(name, app, tier, os_, vcpus, mem, tuple(deps))


def settings(env="dev", **kw):
    return P.Settings(env, COMP, TAGS, "t", "10.0.0.0/16",
                      {"web": "10.0.1.0/24", "app": "10.0.2.0/24", "db": "10.0.3.0/24"}, **kw)


def _write(path, text):
    with open(path, "w") as f:
        f.write(text)


def _inv(d, rows):
    _write(f"{d}/inv.csv", "name,app,tier,os,vcpus,memory_gb,depends_on_apps\n" +
           "".join(f"{n},{a},{t},{o},4,16,{dp}\n" for n, a, t, o, dp in rows))
    return f"{d}/inv.csv"


class Iteration01EngineClock(unittest.TestCase):
    def test_clock_is_resolved_when_the_engine_is_built_not_at_import(self):
        calls = []
        with mock.patch("time.sleep", lambda s: calls.append(s)):
            e = Engine(FakeOCI(), Journal(os.path.join(tempfile.mkdtemp(), "j")))
            e.sleep(1.5)
        self.assertEqual(calls, [1.5])


class Iteration02NothingToExecute(unittest.TestCase):
    def test_plan_with_no_waves_stops_before_any_api_call(self):
        wls = [W("w1", "shop", tier="web", os_=WIN)]                 # no blueprint: the only app is blocked
        rep = P.run(wls, BLUEPRINTS, settings(), lambda: self.fail("no engine may be built"), quota=QUOTA)
        self.assertEqual(rep.waves, [])
        self.assertTrue(any("nothing to execute" in x for x in rep.run_blocked), rep.run_blocked)
        self.assertEqual(rep.wave_results, [])

    def test_cli_run_apply_with_no_waves_exits_2_and_creates_nothing(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        inv = _inv(d, [("w1", "shop", "web", WIN, "")])
        base = ["run", "--inventory", inv, "--env", "dev", "--compartment", COMP, "--availability-domain", "AD-1",
                "--tag", "cost_center=a", "--tag", "owner=b", "--journal", f"{d}/j.jsonl"]
        self.assertEqual(M.main(base, out=out.append), 2)
        fake = FakeOCI()
        pid = json.loads(out[-2] if out[-1].startswith("DRY") else out[-1])["plan_id"]
        self.assertEqual(M.main(base + ["--apply", "--plan-id", pid], out=out.append,
                                provider_factory=lambda: fake, quota=QUOTA), 2)
        self.assertEqual(fake.calls, [])
        self.assertIn("nothing to execute", out[-1])


class Iteration03OcmWaveRange(unittest.TestCase):
    def test_wave_out_of_range_names_the_waves_that_exist(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        inv = _inv(d, [("a1", "a", "app", L8, ""), ("b1", "b", "app", L8, "a")])
        _write(f"{d}/sub.json", json.dumps({"subnet_app": "ocid1.subnet.oc1.phx.app"}))
        with self.assertRaises(SystemExit) as cm:
            M.main(["ocm-wave", "--inventory", inv, "--env", "dev", "--compartment", COMP,
                    "--availability-domain", "AD-1", "--tag", "cost_center=a", "--tag", "owner=b", "--wave", "7",
                    "--migration-plan", "ocid1.ocmmigrationplan.oc1.phx.plan1", "--subnet-map", f"{d}/sub.json"], out=out.append,
                   ocm_client=mock.Mock())
        self.assertIn("2 waves", str(cm.exception))
        self.assertIn("['a']", str(cm.exception))


class Iteration04OcmPartialFailureSemantics(unittest.TestCase):
    def test_a_failed_exclusion_leaves_earlier_inclusions_and_never_adds_new_ones(self):
        import oci
        m = oci.cloud_migrations.models
        assets = {"ta-in": NS(id="ta-in", migration_asset=NS(display_name="in"), is_excluded_from_execution=True,
                              user_spec=None, recommended_spec=None, created_resource_id=None),
                  "ta-out": NS(id="ta-out", migration_asset=NS(display_name="out"), is_excluded_from_execution=False,
                               user_spec=None, recommended_spec=None, created_resource_id=None)}

        class Client:
            def list_target_assets(self, migration_plan_id, page=None):
                return NS(data=NS(items=list(assets.values())), next_page=None)

            def get_target_asset(self, tid):
                return NS(data=assets[tid])

            def update_target_asset(self, tid, details):
                raise oci.exceptions.ServiceError(400, "Bad", {}, "rejected")
        p = F.place(W("in", "a"), BLUEPRINTS, {})
        with self.assertRaisesRegex(O.OCMError, "do not execute"):
            O.OCMDriver(Client(), "ocid1.ocmmigrationplan.oc1.phx.plan1", m, sleep=lambda s: None).apply_wave([p], {"subnet_app": "s"}, COMP, "AD-1")
        self.assertFalse(assets["ta-out"].is_excluded_from_execution)     # was included before; still is
        self.assertTrue(assets["ta-in"].is_excluded_from_execution)       # nothing newly included


class Iteration05ApprovalWithoutATerminal(unittest.TestCase):
    def test_no_stdin_means_not_approved_not_a_crash(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        inv = _inv(d, [("a1", "a", "app", L8, "")])
        base = ["run", "--inventory", inv, "--env", "prod", "--compartment", COMP, "--availability-domain", "AD-1",
                "--tag", "cost_center=a", "--tag", "owner=b", "--journal", f"{d}/j.jsonl"]
        M.main(base, out=out.append)
        pid = json.loads(out[-2])["plan_id"]
        fake = FakeOCI()
        with mock.patch("builtins.input", side_effect=EOFError), mock.patch("time.sleep", lambda s: None):
            rc = M.main(base + ["--apply", "--plan-id", pid], out=out.append, provider_factory=lambda: fake, quota=QUOTA)
        self.assertEqual(rc, 1)
        self.assertIn("BLOCKED_APPROVAL", out[-1])
        self.assertFalse(any(x["kind"] == "instance" for x in fake.live().values()))


class Iteration06WaveCapsMustBePositive(unittest.TestCase):
    def test_zero_or_negative_caps_are_refused_not_reinterpreted(self):
        wls = [W("a1", "a"), W("b1", "b")]
        for kw in ({"max_apps_per_wave": 0}, {"max_apps_per_wave": -1}, {"max_vms_per_wave": 0}):
            with self.subTest(kw=kw), self.assertRaises(F.FactoryError):
                F.plan_waves(wls, **kw)


class Iteration07OverCapAppsAreReported(unittest.TestCase):
    def test_an_app_bigger_than_the_vm_cap_is_named_in_the_plan(self):
        wls = [W(f"b{i}", "big") for i in range(5)] + [W("s1", "small")]
        rep = P.run(wls, BLUEPRINTS, settings(max_vms_per_wave=3), None, execute=False)
        self.assertEqual(rep.over_cap, {"big": "5 VMs, above the cap of 3 per wave; it moves alone in one wave"})
        self.assertIn("over_cap", rep.summary())


class Iteration08CliNumbersAreValidated(unittest.TestCase):
    def test_out_of_range_numbers_are_rejected_by_the_parser(self):
        import migrate as M
        base = ["plan", "--inventory", "x.csv"]
        for extra in (["--max-apps-per-wave", "0"], ["--max-vms-per-wave", "0"], ["--quota-headroom", "1.5"],
                      ["--quota-headroom", "-0.1"], ["--max-customized-share", "2"]):
            with self.subTest(extra=extra), self.assertRaises(SystemExit), \
                    mock.patch("sys.stderr", io.StringIO()):
                M.parser().parse_args(base + extra)
        with self.assertRaises(SystemExit), mock.patch("sys.stderr", io.StringIO()):
            M.parser().parse_args(["run", "--inventory", "x.csv", "--max-in-flight", "0"])


if __name__ == "__main__":
    unittest.main()


class Iteration09To12JournalScales(unittest.TestCase):
    """Re-runs re-read and re-scanned the whole journal once per wave and once per step: quadratic.
    Measured before: 2,388 VMs, a no-op re-run took 4.3 s with 31 full loads and 65 full scans."""

    def _journal(self, n):
        jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        j = Journal(jp)
        for r in range(n):
            j.append(run_id=f"r{r}", event="run_started", workflow=f"w{r % 7}", workflow_hash="h", steps=[f"s{r}"])
            j.append(run_id=f"r{r}", step=f"s{r}", event="creating", params_hash="p", kind="instance")
            j.append(run_id=f"r{r}", step=f"s{r}", event="created", outputs={"id": f"id{r}"})
            j.append(run_id=f"r{r}", step=f"s{r}", event="ready", outputs={"id": f"id{r}"})
            if r % 3:
                j.append(run_id=f"r{r}", event="run_succeeded")
        return jp

    def test_09_reopening_an_unchanged_journal_does_not_reparse_it(self):
        jp = self._journal(300)
        Journal(jp)
        with mock.patch("json.loads", side_effect=AssertionError("re-parsed")):
            j = Journal(jp)
        self.assertEqual(len(j.entries), 300 * 4 + 200)
        self.assertTrue(j.verify())

    def test_10_an_outside_edit_forces_a_full_reload_and_is_detected(self):
        jp = self._journal(5)
        Journal(jp)
        with open(jp) as f:
            lines = f.read().splitlines()
        lines[2] = lines[2].replace("created", "creatEd")
        with open(jp, "w") as f:
            f.write("\n".join(lines) + "\n")
        self.assertFalse(Journal(jp).verify())

    def test_11_views_come_from_indexes_not_full_scans(self):
        jp = self._journal(2000)
        j = Journal(jp)

        class Counting(list):
            reads = 0

            def __iter__(self):
                Counting.reads += 1
                return super().__iter__()
        with mock.patch.object(j._s, "entries", Counting(j._s.entries)):
            P.existing_steps(j); P.unfinished_runs(j); P._runs(j, "w3"); j.state("r5")
            j.step_entries("r5", "s5"); j.run_entries("r5")
        self.assertEqual(Counting.reads, 0)

    def test_12_views_match_a_full_scan(self):
        jp = self._journal(50)
        j = Journal(jp)
        j.append(run_id="r4", step="s4", event="rolled_back", outputs={"id": "id4"})
        j.append(run_id="r7", step="s7", event="rollback_failed", outputs={"id": "id7"})
        live = P.existing_steps(j)
        self.assertNotIn("s4", live)
        self.assertTrue(live["s7"]["uncertain"])
        self.assertEqual(len(live), 49)
        self.assertEqual(sorted(r for r, *_ in P.unfinished_runs(j)), sorted(f"r{r}" for r in range(50) if r % 3 == 0))
        self.assertEqual(j.state("r4")["s4"]["status"], "rolled_back")
        j2 = Journal(jp)                                          # a second handle sees the same, appended state
        self.assertNotIn("s4", P.existing_steps(j2))


# ---------------------------------------------------------------- OCI production detail (13-27)
# Each fact below was checked against the oci SDK 2.189.0 model documentation or Oracle's pages; the
# source is named in the code next to it.

def _sdk_provider(**kw):
    from ocio.providers import OCISDKProvider
    import oci
    with mock.patch.object(oci.core, "VirtualNetworkClient"), mock.patch.object(oci.core, "ComputeClient"):
        return OCISDKProvider(config={"region": "us-phoenix-1"}, availability_domain="Uocm:PHX-AD-1", **kw)


def _network_and_wave(fake, wls):
    e = Engine(fake, Journal(os.path.join(tempfile.mkdtemp(), "j")), sleep=lambda s: None, poll_seconds=0)
    net = e.apply(F.target_network("t", "dev", COMP, TAGS, "10.0.0.0/16", {"app": "10.0.2.0/24"}))
    assert net.status == "SUCCEEDED", net.error
    return e, F.wave_workflow(1, sorted({w.app for w in wls}), [F.place(w, BLUEPRINTS, {}) for w in wls],
                              net.outputs, "dev", COMP, TAGS)


class Iteration13FaultDomainSpread(unittest.TestCase):
    def test_vms_of_one_app_tier_are_spread_over_the_three_fault_domains(self):
        pl = [F.place(W(f"web{i}", "shop", tier="web"), BLUEPRINTS, {}) for i in range(4)] + \
             [F.place(W("db1", "shop", tier="db"), BLUEPRINTS, {})]
        wf = F.wave_workflow(1, ["shop"], pl, {k: {"id": f"ocid1.subnet.oc1..{k}"} for k in F.TIER_SUBNETS.values()},
                             "dev", COMP, TAGS)
        fd = {s.id: s.params["fault_domain"] for s in wf.steps}
        self.assertEqual([fd[f"web{i}"] for i in range(4)], ["FAULT-DOMAIN-1", "FAULT-DOMAIN-2", "FAULT-DOMAIN-3", "FAULT-DOMAIN-1"])
        self.assertEqual(fd["db1"], "FAULT-DOMAIN-1")
        d = _sdk_provider().build("instance", COMP, dict(wf.step("web1").params, image_id="ocid1.image.oc1..x"), TAGS)
        self.assertEqual(d.fault_domain, "FAULT-DOMAIN-2")

    def test_ocm_user_spec_carries_the_fault_domain(self):
        import oci
        pl = [F.place(W(f"app{i}", "crm"), BLUEPRINTS, {}) for i in range(2)]
        fds = F.fault_domains(pl)
        self.assertEqual(fds, {"app0": "FAULT-DOMAIN-1", "app1": "FAULT-DOMAIN-2"})
        u = O.user_spec(oci.cloud_migrations.models, pl[1], {"subnet_app": "s"}, COMP, "AD-1", fds["app1"])
        self.assertEqual(u.fault_domain, "FAULT-DOMAIN-2")

    def test_spread_can_be_turned_off_and_that_changes_the_plan_id(self):
        wls = [W("a1", "a"), W("a2", "a")]
        on = P.run(wls, BLUEPRINTS, settings(), None, execute=False).plan_id
        off = P.run(wls, BLUEPRINTS, settings(spread_fault_domains=False), None, execute=False).plan_id
        self.assertNotEqual(on, off)


class Iteration14ArmSizing(unittest.TestCase):
    """Oracle Compute Shapes page: 1 OCPU on x86 = 2 vCPUs; 1 OCPU on Arm A1 = 1 vCPU.
    VM.Standard.A1.Flex: up to 76 OCPUs, 64 GB per OCPU up to 472 GB."""
    A1 = "VM.Standard.A1.Flex"

    def test_a1_ocpus_match_source_vcpus_not_half(self):
        self.assertEqual(F.size(W("a", "a", vcpus=4), "VM.Standard.E5.Flex")["ocpus"], 2)
        self.assertEqual(F.size(W("a", "a", vcpus=4), self.A1)["ocpus"], 4)

    def test_a_shape_override_to_a1_resizes_instead_of_halving_the_vm(self):
        p = F.place(W("a1", "a", vcpus=8, mem=32), BLUEPRINTS, {"shape": self.A1})
        self.assertEqual((p.params["shape"], p.params["ocpus"]), (self.A1, 8))

    def test_a1_limits_and_quota_names(self):
        self.assertTrue(F.shape_problems(self.A1, 77, 77))
        self.assertTrue(F.shape_problems(self.A1, 8, 473))
        self.assertEqual(F.shape_problems(self.A1, 8, 64), [])
        self.assertEqual(C.SHAPE_LIMITS[self.A1], ("standard-a1-core-count", "standard-a1-memory-count"))

    def test_guard_never_below_source_uses_the_final_shape(self):
        from ocio import agent as A
        wls = [W("a1", "a", vcpus=8, mem=32)]
        g = A.Guard(wls, BLUEPRINTS, A.Bounds(shapes=frozenset({"VM.Standard.E5.Flex", self.A1})))
        d = g.check({"workload": "a1", "blueprint": "app-linux@v1", "overrides": {"shape": self.A1, "ocpus": 4},
                     "rationale": "arm"}, "a1")
        self.assertFalse(d.accepted)                                       # 4 A1 OCPUs = 4 vCPUs < 8
        self.assertTrue(any("source size" in r for r in d.reasons), d.reasons)


class Iteration15HostCapacity(unittest.TestCase):
    def test_out_of_host_capacity_is_recognised_and_not_retried_blindly(self):
        import oci
        from ocio.providers import ProviderError
        prov = _sdk_provider()
        err = oci.exceptions.ServiceError(500, "InternalError", {"opc-request-id": "req-1"}, "Out of host capacity.")
        with self.assertRaises(ProviderError) as cm:
            prov._call(mock.Mock(side_effect=err))
        self.assertTrue(cm.exception.capacity)
        fake = FakeOCI(faults={("create", "instance"): ["capacity"] * 10})
        e, wf = _network_and_wave(fake, [W("a1", "a")])
        before = e.calls
        r = e.apply(wf)
        self.assertEqual(r.status, "FAILED_ROLLED_BACK")
        self.assertIn("Out of host capacity", r.error)
        self.assertIn("capacity reservation", r.error)
        self.assertFalse(any(x["kind"] == "instance" for x in fake.res.values()))   # refused each time, never created
        self.assertLessEqual(e.calls - before, 2)                                  # not 6 blind retries


class Iteration16LaunchFailureReason(unittest.TestCase):
    def test_a_failed_launch_reports_the_work_request_error(self):
        fake = FakeOCI(fail_provision={"a1"})
        e, wf = _network_and_wave(fake, [W("a1", "a")])
        r = e.apply(wf)
        self.assertIn("simulated launch failure", r.error)

    def test_sdk_provider_reads_the_work_request_errors(self):
        prov = _sdk_provider(image_map={"IMAGE_OL8": "ocid1.image.oc1..x"})
        prov.compute.launch_instance.return_value = NS(data=NS(id="ocid1.instance.oc1..i"),
                                                      headers={"opc-work-request-id": "ocid1.workrequest.oc1..w"})
        prov.wr = mock.Mock()
        prov.wr.list_work_request_errors.return_value = NS(data=[NS(code="InternalError", message="Out of host capacity.")])
        p = F.place(W("a1", "a"), BLUEPRINTS, {}).params
        rid = prov.create("instance", COMP, dict(p, subnet_id="s"), TAGS, "tok")
        self.assertIn("Out of host capacity", prov.failure_reason("instance", rid))
        prov.wr.list_work_request_errors.assert_called_with("ocid1.workrequest.oc1..w")


class Iteration17AvailabilityDomainCheck(unittest.TestCase):
    def test_unknown_ad_names_are_refused_with_the_tenancy_list(self):
        from ocio import tenancy as T
        ident = mock.Mock()
        ident.list_availability_domains.return_value = NS(data=[NS(name="Uocm:PHX-AD-1"), NS(name="Uocm:PHX-AD-2")])
        T.check_availability_domain(ident, "ocid1.tenancy.oc1..t", "Uocm:PHX-AD-2")
        with self.assertRaisesRegex(ValueError, "Uocm:PHX-AD-1"):
            T.check_availability_domain(ident, "ocid1.tenancy.oc1..t", "AD-1")


class Iteration18OcidValidation(unittest.TestCase):
    def test_ocid_structure_and_type(self):
        from ocio.ocid import problem
        self.assertIsNone(problem("ocid1.tenancy.oc1..aaaaaaaaba3pv6wkcr4jqae5f44n2b2m2yt2j6rx32uzr4h25vqstifsfdsq", ("tenancy", "compartment")))
        self.assertIsNone(problem("ocid1.subnet.oc1.phx.aaaa", ("subnet",)))
        self.assertIsNone(problem("ocid1.instance.oc19.ap-dcc-x-1.aaaa", ("instance",)))      # newer realms
        self.assertIn("type", problem("ocid1.vcn.oc1.phx.aaaa", ("subnet",)))
        for bad in ("", "subnet123", "ocid2.subnet.oc1..a", "ocid1.subnet.xx1..a", "ocid1.subnet.oc1.", "ocid1..oc1..a"):
            with self.subTest(bad=bad):
                self.assertIsNotNone(problem(bad))

    def test_cli_refuses_a_malformed_compartment_and_subnet_map(self):
        import migrate as M
        d = tempfile.mkdtemp()
        inv = _inv(d, [("a1", "a", "app", L8, "")])
        with self.assertRaisesRegex(SystemExit, "compartment"):
            M.main(["run", "--inventory", inv, "--compartment", "my-compartment", "--availability-domain", "AD-1",
                    "--tag", "cost_center=a", "--tag", "owner=b"], out=lambda *_: None)
        _write(f"{d}/sub.json", json.dumps({"subnet_app": "ocid1.vcn.oc1.phx.x"}))
        with self.assertRaisesRegex(SystemExit, "subnet"):
            M.main(["ocm-wave", "--inventory", inv, "--compartment", COMP, "--availability-domain", "AD-1",
                    "--tag", "cost_center=a", "--tag", "owner=b", "--wave", "1", "--migration-plan", "ocid1.ocmmigrationplan.oc1.phx.p",
                    "--subnet-map", f"{d}/sub.json"], out=lambda *_: None, ocm_client=mock.Mock())


class Iteration19AuthModes(unittest.TestCase):
    def test_each_auth_mode_builds_the_right_signer(self):
        from ocio import auth
        import oci
        with mock.patch.object(oci.auth.signers, "InstancePrincipalsSecurityTokenSigner") as ip:
            ip.return_value = NS(region="us-ashburn-1", tenancy_id="ocid1.tenancy.oc1..t")
            cfg, signer = auth.make("instance_principal")
            self.assertEqual((cfg["region"], cfg["tenancy"]), ("us-ashburn-1", "ocid1.tenancy.oc1..t"))
        with mock.patch.object(oci.auth.signers, "get_resource_principals_signer") as rp:
            rp.return_value = NS(region="eu-frankfurt-1", tenancy_id="ocid1.tenancy.oc1..t")
            self.assertIs(auth.make("resource_principal")[1], rp.return_value)
        d = tempfile.mkdtemp()
        _write(f"{d}/token", "TOKEN")
        with mock.patch.object(oci.config, "from_file", return_value={"security_token_file": f"{d}/token", "key_file": f"{d}/key",
                                                                     "region": "us-phoenix-1", "tenancy": "ocid1.tenancy.oc1..t"}), \
                mock.patch.object(oci.signer, "load_private_key_from_file", return_value="KEY"), \
                mock.patch.object(oci.auth.signers, "SecurityTokenSigner") as st:
            cfg, signer = auth.make("security_token", profile="P", config_file="~/.oci/config")
            st.assert_called_with("TOKEN", "KEY")
        with mock.patch.object(oci.config, "from_file", return_value={"region": "r"}):
            self.assertIsNone(auth.make("api_key")[1])
        with self.assertRaises(ValueError):
            auth.make("password")


class Iteration20DefinedTags(unittest.TestCase):
    def test_defined_tags_reach_every_create_and_the_plan_id(self):
        from ocio import auth  # noqa: F401  (module must exist for the CLI parser)
        import migrate as M
        self.assertEqual(M._defined_tags(["Ops.CostCenter=42", "Ops.Owner=jc", "Sec.Tier=1"]),
                         {"Ops": {"CostCenter": "42", "Owner": "jc"}, "Sec": {"Tier": "1"}})
        with self.assertRaises(SystemExit):
            M._defined_tags(["NoNamespace=1"])
        net = F.target_network("t", "dev", COMP, TAGS, "10.0.0.0/16", {"app": "10.0.2.0/24"}, defined_tags={"Ops": {"A": "1"}})
        prov = _sdk_provider()
        self.assertEqual(prov.build("vcn", COMP, net.step("vcn").params, TAGS).defined_tags, {"Ops": {"A": "1"}})
        a = P.run([W("a1", "a")], BLUEPRINTS, settings(), None, execute=False).plan_id
        b = P.run([W("a1", "a")], BLUEPRINTS, settings(defined_tags={"Ops": {"A": "1"}}), None, execute=False).plan_id
        self.assertNotEqual(a, b)


class Iteration21ImageResolution(unittest.TestCase):
    def test_newest_available_compatible_image_is_chosen_and_incompatible_ones_skipped(self):
        from ocio import images as I
        compute = mock.Mock()
        compute.list_images.__name__ = "list_images"          # real client methods have one; the SDK pager reads it
        import oci
        compute.list_images.return_value = oci.response.Response(
            200, {}, [NS(id="ocid1.image.oc1.phx.new", display_name="OL8-2026.09"),
                      NS(id="ocid1.image.oc1.phx.old", display_name="OL8-2026.01")], None)
        compute.get_image_shape_compatibility_entry.side_effect = [oci.exceptions.ServiceError(404, "NotFound", {}, "x"), NS(data=NS())]
        got = I.resolve(compute, COMP, {"IMAGE_OL8": {"operating_system": "Oracle Linux", "operating_system_version": "8"}},
                        "VM.Standard.E5.Flex")
        self.assertEqual(got, {"IMAGE_OL8": "ocid1.image.oc1.phx.old"})
        kw = compute.list_images.call_args.kwargs
        self.assertEqual((kw["sort_by"], kw["sort_order"], kw["lifecycle_state"], kw["shape"]),
                         ("TIMECREATED", "DESC", "AVAILABLE", "VM.Standard.E5.Flex"))
        compute.get_image_shape_compatibility_entry.side_effect = oci.exceptions.ServiceError(404, "NotFound", {}, "x")
        with self.assertRaisesRegex(ValueError, "no AVAILABLE image"):
            I.resolve(compute, COMP, {"IMAGE_OL8": {"operating_system": "Oracle Linux", "operating_system_version": "8"}},
                      "VM.Standard.E5.Flex")


class Iteration22CapacityReservation(unittest.TestCase):
    def test_capacity_reservation_reaches_the_launch_and_the_ocm_spec(self):
        import oci
        pl = [F.place(W("a1", "a"), BLUEPRINTS, {})]
        wf = F.wave_workflow(1, ["a"], pl, {"subnet_app": {"id": "s"}}, "dev", COMP, TAGS,
                             capacity_reservation_id="ocid1.capacityreservation.oc1.phx.r")
        d = _sdk_provider().build("instance", COMP, dict(wf.step("a1").params, image_id="ocid1.image.oc1..x"), TAGS)
        self.assertEqual(d.capacity_reservation_id, "ocid1.capacityreservation.oc1.phx.r")
        u = O.user_spec(oci.cloud_migrations.models, pl[0], {"subnet_app": "s"}, COMP, "AD-1",
                        capacity_reservation_id="ocid1.capacityreservation.oc1.phx.r")
        self.assertEqual(u.capacity_reservation_id, "ocid1.capacityreservation.oc1.phx.r")


class Iteration23BootVolume(unittest.TestCase):
    """SDK: boot volume 50 GB to 32,768 GB; VPUs per GB 10 (Balanced), 20 (Higher), 30-120 (Ultra High)."""

    def _bp(self, **d):
        return (F.Blueprint("app-linux", 9, "app", "linux", dict({"shape": "VM.Standard.E5.Flex", "assign_public_ip": False,
                                                                  "image_id": "IMAGE_OL8"}, **d), frozenset()),)

    def test_boot_volume_settings_are_validated_and_sent(self):
        p = F.place(W("a1", "a"), self._bp(boot_volume_size_in_gbs=100, boot_volume_vpus_per_gb=20), {})
        d = _sdk_provider().build("instance", COMP, dict(p.params, subnet_id="s", image_id="ocid1.image.oc1..x"), TAGS)
        self.assertEqual((d.source_details.boot_volume_size_in_gbs, d.source_details.boot_volume_vpus_per_gb), (100, 20))
        for bad in ({"boot_volume_size_in_gbs": 49}, {"boot_volume_size_in_gbs": 32769}, {"boot_volume_vpus_per_gb": 15},
                    {"boot_volume_vpus_per_gb": 121}):
            with self.subTest(bad=bad), self.assertRaises(F.FactoryError):
                F.place(W("a1", "a"), self._bp(**bad), {})


class Iteration24SdkTimeouts(unittest.TestCase):
    def test_clients_get_explicit_timeouts(self):
        from ocio.providers import OCISDKProvider
        import oci
        with mock.patch.object(oci.core, "VirtualNetworkClient") as net, mock.patch.object(oci.core, "ComputeClient") as comp:
            OCISDKProvider(config={"region": "r"}, timeout=(5, 30))
        self.assertEqual(net.call_args.kwargs["timeout"], (5, 30))
        self.assertEqual(comp.call_args.kwargs["timeout"], (5, 30))
        import migrate as M
        self.assertEqual(M.parser().parse_args(["run", "--inventory", "x", "--sdk-timeout", "7,45"]).sdk_timeout, (7.0, 45.0))


class Iteration25HostnamesAndSubnetDns(unittest.TestCase):
    def test_subnets_get_dns_labels_and_vms_valid_unique_hostnames(self):
        net = F.target_network("t", "dev", COMP, TAGS, "10.0.0.0/16", {"web": "10.0.1.0/24", "app": "10.0.2.0/24"})
        self.assertEqual({s.id: s.params.get("dns_label") for s in net.steps if s.kind == "subnet"},
                         {"subnet_web": "web", "subnet_app": "app"})
        pl = [F.place(W(n, "a"), BLUEPRINTS, {}) for n in ("App_Server.01", "app-server-01", "9lives", "x" * 80)]
        wf = F.wave_workflow(1, ["a"], pl, {"subnet_app": {"id": "s"}}, "dev", COMP, TAGS)
        hosts = [s.params["hostname_label"] for s in wf.steps]
        self.assertEqual(len(set(hosts)), 4)
        import re
        for h in hosts:
            self.assertRegex(h, r"^[a-z][a-z0-9-]{0,61}[a-z0-9]$")
        d = _sdk_provider().build("instance", COMP, dict(wf.steps[0].params, image_id="ocid1.image.oc1..x"), TAGS)
        self.assertEqual(d.create_vnic_details.hostname_label, hosts[0])


class Iteration26RequestIdInErrors(unittest.TestCase):
    def test_opc_request_id_is_kept_for_oracle_support(self):
        import oci
        from ocio.providers import ProviderError
        prov = _sdk_provider()
        err = oci.exceptions.ServiceError(400, "InvalidParameter", {"opc-request-id": "ABC123/XYZ"}, "bad cidr")
        with self.assertRaises(ProviderError) as cm:
            prov._call(mock.Mock(side_effect=err))
        self.assertIn("ABC123/XYZ", str(cm.exception))
        self.assertIn("bad cidr", str(cm.exception))
        c = mock.Mock()
        c.list_target_assets.side_effect = err
        with self.assertRaisesRegex(O.OCMError, "ABC123/XYZ"):
            O.OCMDriver(c, "ocid1.ocmmigrationplan.oc1.phx.plan1", oci.cloud_migrations.models, sleep=lambda s: None).summaries()


class Iteration27BurstableInstances(unittest.TestCase):
    """SDK: baseline_ocpu_utilization BASELINE_1_8, BASELINE_1_2 or BASELINE_1_1 (not burstable)."""

    def test_baseline_is_validated_sent_and_kept_out_of_prod(self):
        bp = (F.Blueprint("app-linux", 9, "app", "linux", {"shape": "VM.Standard.E5.Flex", "assign_public_ip": False,
                                                           "image_id": "IMAGE_OL8"}, frozenset({"baseline_ocpu_utilization"})),)
        p = F.place(W("a1", "a"), bp, {"baseline_ocpu_utilization": "BASELINE_1_2"})
        d = _sdk_provider().build("instance", COMP, dict(p.params, subnet_id="s", image_id="ocid1.image.oc1..x"), TAGS)
        self.assertEqual(d.shape_config.baseline_ocpu_utilization, "BASELINE_1_2")
        with self.assertRaises(F.FactoryError):
            F.place(W("a1", "a"), bp, {"baseline_ocpu_utilization": "BASELINE_1_4"})
        rep = P.run([W("a1", "a")], bp, settings("prod"), None, execute=False,
                    overrides={"a1": {"baseline_ocpu_utilization": "BASELINE_1_8"}})
        self.assertTrue(any("burstable" in v for v in rep.policy_violations), rep.policy_violations)


# ---------------------------------------------------------------- white space: flow-derived network policy

def _asset(name, ip, tags=None):
    from ocio.discovery import Asset
    return Asset(name, ip, L8, 4, 16, dict(tags or {}))


class Iteration28FlowDerivedNsgPlan(unittest.TestCase):
    def setUp(self):
        self.assets = [_asset("shop-web-01", "10.0.0.1"), _asset("shop-web-02", "10.0.0.2"),
                       _asset("shop-app-01", "10.0.0.3"), _asset("shop-db-01", "10.0.0.4"),
                       _asset("pay-app-01", "10.0.0.5")]
        self.flows = [("10.0.0.1", "10.0.0.3", 8080, 900), ("10.0.0.2", "10.0.0.3", 8080, 800),
                      ("10.0.0.3", "10.0.0.4", 1521, 500), ("10.0.0.3", "10.0.0.5", 8443, 40),
                      ("10.0.0.9", "10.0.0.3", 22, 5), ("203.0.113.7", "10.0.0.1", 443, 9000)]
        self.wls = [W("shop-web-01", "shop", "web"), W("shop-web-02", "shop", "web"), W("shop-app-01", "shop"),
                    W("shop-db-01", "shop", "db"), W("pay-app-01", "pay")]
        self.pl = [F.place(w, BLUEPRINTS, {}) for w in self.wls]

    def test_one_nsg_per_app_tier_and_one_stateful_rule_per_observed_path(self):
        from ocio import netpolicy as N
        fl = N.observed_flows(self.assets, self.flows)
        self.assertNotIn(22, [f[2] for f in fl])                       # infrastructure traffic is not policy
        plan = N.build(self.pl, fl)
        self.assertEqual(sorted(plan.members), ["pay-app", "shop-app", "shop-db", "shop-web"])
        self.assertEqual(sorted(r.key() for r in plan.rules),
                         [("pay-app", "shop-app", 8443), ("shop-app", "shop-web", 8080), ("shop-db", "shop-app", 1521)])
        self.assertEqual(N.default_list_blocks(self.pl, fl), {"flows_between_placed_vms": 4, "denied_by_default_security_list": 4})

    def test_cutover_check_finds_blockers_and_hybrid_flows(self):
        from ocio import netpolicy as N
        fl = N.observed_flows(self.assets, self.flows)
        plan = N.build(self.pl, fl)
        shop = [w.name for w in self.wls if w.app == "shop"]
        # Without NSGs created yet (empty map), every in-OCI flow of the wave is a cutover blocker.
        r = N.check(plan, self.pl, fl, wave_vms=shop, nsg_map={})
        self.assertEqual(sorted((b["from"], b["to"], b["tcp_port"]) for b in r["blocked"]),
                         [("shop-app-01", "shop-db-01", 1521), ("shop-web-01", "shop-app-01", 8080),
                          ("shop-web-02", "shop-app-01", 8080)])
        self.assertEqual(r["hybrid"], [{"from": "shop-app-01", "to": "pay-app-01", "tcp_port": 8443, "connections": 40,
                                        "direction": "OCI -> source site"}])
        names = {n: f"ocid1.networksecuritygroup.oc1.phx.{n}" for n in plan.members}
        self.assertEqual(N.check(plan, self.pl, fl, wave_vms=shop, nsg_map=names)["blocked"], [])

    def test_apply_is_idempotent_and_batches_rules_by_25(self):
        from ocio import netpolicy as N
        import oci
        m = oci.core.models
        many = [W(f"c{i:02d}", f"client{i:02d}") for i in range(30)] + [W("db1", "core", "db")]
        pl = [F.place(w, BLUEPRINTS, {}) for w in many]
        fl = [(f"c{i:02d}", "db1", 1521, 10) for i in range(30)]
        plan = N.build(pl, fl)

        class Net:
            def __init__(self):
                self.nsgs, self.rules, self.tokens, self.add_calls = {}, {}, {}, []

            def create_network_security_group(self, d, opc_retry_token=None):
                if opc_retry_token not in self.tokens:
                    self.tokens[opc_retry_token] = f"ocid1.networksecuritygroup.oc1.phx.{d.display_name}"
                    self.nsgs[self.tokens[opc_retry_token]] = d
                return NS(data=NS(id=self.tokens[opc_retry_token]))

            def list_network_security_group_security_rules(self, nsg_id, **kw):
                return NS(data=list(self.rules.get(nsg_id, [])))

            def list_network_security_groups(self, **kw):       # the real SDK call, listed before creating
                return NS(data=[], next_page=None)

            def add_network_security_group_security_rules(self, nsg_id, details):
                self.add_calls.append(len(details.security_rules))
                self.rules.setdefault(nsg_id, []).extend(details.security_rules)
        net = Net()
        ids = N.apply(net, m, plan, COMP, "ocid1.vcn.oc1.phx.v")
        self.assertEqual(len(ids), 31)
        self.assertEqual(net.add_calls, [25, 5])                          # documented limit: 25 per call
        r = net.rules[ids["core-db"]][0]
        self.assertEqual((r.direction, r.protocol, r.source_type, r.is_stateless, r.tcp_options.destination_port_range.min),
                         ("INGRESS", "6", "NETWORK_SECURITY_GROUP", False, 1521))
        N.apply(net, m, plan, COMP, "ocid1.vcn.oc1.phx.v")                # re-run: nothing duplicated
        self.assertEqual(net.add_calls, [25, 5])
        self.assertEqual(len(net.nsgs), 31)


class Iteration29NsgMembership(unittest.TestCase):
    def test_vnics_join_their_app_tier_nsg_on_both_paths(self):
        import oci
        pl = [F.place(W("a1", "shop"), BLUEPRINTS, {})]
        nsg = {"shop-app": "ocid1.networksecuritygroup.oc1.phx.sa"}
        wf = F.wave_workflow(1, ["shop"], pl, {"subnet_app": {"id": "s"}}, "dev", COMP, TAGS, nsg_map=nsg)
        self.assertEqual(wf.step("a1").params["nsg_ids"], ["ocid1.networksecuritygroup.oc1.phx.sa"])
        d = _sdk_provider().build("instance", COMP, dict(wf.step("a1").params, image_id="ocid1.image.oc1..x"), TAGS)
        self.assertEqual(d.create_vnic_details.nsg_ids, ["ocid1.networksecuritygroup.oc1.phx.sa"])
        u = O.user_spec(oci.cloud_migrations.models, pl[0], {"subnet_app": "s"}, COMP, "AD-1", nsg_ids=["x"])
        self.assertEqual(u.create_vnic_details.nsg_ids, ["x"])


class Iteration30CutoverGate(unittest.TestCase):
    def _estate(self, d):
        _write(f"{d}/assets.csv", "name,ip,os,vcpus,memory_gb,tags\nshop-app-01,10.0.0.3,Oracle Linux 8,4,16,app=shop;tier=app\n"
                                  "shop-db-01,10.0.0.4,Oracle Linux 8,4,16,app=shop;tier=db\n")
        _write(f"{d}/flows.csv", "src_ip,dst_ip,dst_port,connections\n10.0.0.3,10.0.0.4,1521,500\n")
        return _inv(d, [("shop-app-01", "shop", "app", L8, ""), ("shop-db-01", "shop", "db", L8, "")])

    @mock.patch("time.sleep", lambda s: None)        # FakeOCI needs polls; no real waiting in tests
    def test_run_refuses_a_wave_whose_flows_would_be_blocked_and_proceeds_with_the_nsgs(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        inv = self._estate(d)
        base = ["run", "--inventory", inv, "--env", "dev", "--compartment", COMP, "--availability-domain", "AD-1",
                "--tag", "cost_center=a", "--tag", "owner=b", "--journal", f"{d}/j.jsonl",
                "--assets", f"{d}/assets.csv", "--flows", f"{d}/flows.csv"]
        self.assertEqual(M.main(base, out=out.append), 2)                   # dry run already says so
        self.assertIn("shop-db-01", out[-1])
        self.assertIn("1521", out[-1])
        _write(f"{d}/nsg.json", json.dumps({"shop-app": "ocid1.networksecuritygroup.oc1.phx.a",
                                            "shop-db": "ocid1.networksecuritygroup.oc1.phx.d"}))
        out = []
        self.assertEqual(M.main(base + ["--nsg-map", f"{d}/nsg.json"], out=out.append), 0, out[-1])
        pid = json.loads(out[-2])["plan_id"]
        fake = FakeOCI()
        rc = M.main(base + ["--nsg-map", f"{d}/nsg.json", "--apply", "--plan-id", pid], out=out.append,
                    provider_factory=lambda: fake, quota=QUOTA)
        self.assertEqual(rc, 0, out[-1])
        nsgs = {x["params"]["display_name"]: x["params"].get("nsg_ids") for x in fake.res.values() if x["kind"] == "instance"}
        self.assertEqual(nsgs, {"shop-app-01": ["ocid1.networksecuritygroup.oc1.phx.a"],
                                "shop-db-01": ["ocid1.networksecuritygroup.oc1.phx.d"]})

    def test_netpolicy_command_reports_rules_blockers_and_hybrid_flows(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        inv = self._estate(d)
        rc = M.main(["netpolicy", "--inventory", inv, "--assets", f"{d}/assets.csv", "--flows", f"{d}/flows.csv",
                     "--compartment", COMP, "--tag", "cost_center=a", "--tag", "owner=b"], out=out.append)
        self.assertEqual(rc, 0, out)
        r = json.loads(out[-1])
        self.assertEqual(r["rules"], [{"nsg": "shop-db", "allow_from_nsg": "shop-app", "tcp_port": 1521}])
        self.assertEqual(r["default_security_list"], {"flows_between_placed_vms": 1, "denied_by_default_security_list": 1})
        self.assertIn("waves", r)


class Iteration31NetpolicyApplyIsBoundAndIdempotent(unittest.TestCase):
    def test_apply_needs_the_reviewed_policy_and_converges(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        inv = Iteration30CutoverGate()._estate(d)
        base = ["netpolicy", "--inventory", inv, "--assets", f"{d}/assets.csv", "--flows", f"{d}/flows.csv",
                "--compartment", COMP, "--tag", "cost_center=a", "--tag", "owner=b", "--journal", f"{d}/n.jsonl",
                "--nsg-map-out", f"{d}/nsg.json"]
        M.main(base, out=out.append)
        pid = json.loads(out[-1])["policy_id"]
        net = mock.Mock()
        net.create_network_security_group.side_effect = lambda d_, opc_retry_token=None: NS(
            data=NS(id=f"ocid1.networksecuritygroup.oc1.phx.{d_.display_name}"))
        net.list_network_security_group_security_rules.return_value = NS(data=[])
        net.list_network_security_groups.return_value = NS(data=[], next_page=None)
        with self.assertRaises(SystemExit):
            M.main(base + ["--apply", "--policy-id", "000000000000", "--vcn", "ocid1.vcn.oc1.phx.v"], out=out.append,
                   net_client=net)
        net.create_network_security_group.assert_not_called()
        self.assertEqual(M.main(base + ["--apply", "--policy-id", pid, "--vcn", "ocid1.vcn.oc1.phx.v"], out=out.append,
                                net_client=net), 0)
        self.assertEqual(json.load(open(f"{d}/nsg.json")), {"shop-app": "ocid1.networksecuritygroup.oc1.phx.shop-app",
                                                            "shop-db": "ocid1.networksecuritygroup.oc1.phx.shop-db"})
        self.assertEqual(net.create_network_security_group.call_count, 2)
        M.main(base + ["--apply", "--policy-id", pid, "--vcn", "ocid1.vcn.oc1.phx.v"], out=out.append, net_client=net)
        self.assertEqual(net.create_network_security_group.call_count, 2)    # re-run reuses the map: none created
        self.assertTrue(Journal(f"{d}/n.jsonl").verify())


# ------------------------------------------------------------------ 32-37: OCM hardening (merged design)

class FakeOCM2:
    """MigrationClient stand-in with the parts of the real API the hardened driver relies on: an etag per
    target asset (changes on every update; If-Match enforced with 412), an opc-retry-token cache, an
    asynchronous work request per update (status scripted by `wr_status`), lifecycle_state, and paging."""

    def __init__(self, assets, wr_status="SUCCEEDED", page_size=None, repeat_token=False):
        import oci
        self.oci = oci
        self.assets = {k: NS(id=k, migration_asset=NS(display_name=n), is_excluded_from_execution=x,
                             recommended_spec=None, user_spec=None, created_resource_id=None,
                             lifecycle_state=st)
                       for k, (n, x, st) in assets.items()}
        self.etag = {k: "e0" for k in assets}
        self.updates, self.tokens, self.wr, self.wr_status = [], {}, {}, wr_status
        self.page_size, self.repeat_token = page_size, repeat_token

    def _err(self, status, code, msg):
        return self.oci.exceptions.ServiceError(status, code, {"opc-request-id": "req-1"}, msg)

    SUMMARY_FIELDS = ("compartment_id", "compatibility_messages", "created_resource_id", "display_name",
                      "estimated_cost", "id", "is_excluded_from_execution", "lifecycle_details", "lifecycle_state",
                      "migration_asset", "migration_plan_id", "time_assessed", "time_created", "time_updated", "type")

    def list_target_assets(self, migration_plan_id, page=None):
        # A listing returns TargetAssetSummary, which has no user_spec or recommended_spec (oci 2.189.0): only the
        # summary's fields are copied, so code that needs the spec must GET the asset, as with the real service.
        items = [NS(**{k: getattr(a, k) for k in self.SUMMARY_FIELDS if hasattr(a, k)}) for a in self.assets.values()]
        if not self.page_size:
            return NS(data=NS(items=items), next_page=None, headers={})
        start = int(page or 0)
        nxt = start + self.page_size
        token = None if nxt >= len(items) else ("0" if self.repeat_token else str(nxt))
        return NS(data=NS(items=items[start:nxt]), next_page=token, headers={})

    def get_target_asset(self, target_asset_id):
        return NS(data=self.assets[target_asset_id], headers={"etag": self.etag[target_asset_id]})

    def update_target_asset(self, target_asset_id, details, if_match=None, opc_retry_token=None):
        import copy
        if opc_retry_token in self.tokens:                       # an idempotent retry: same answer, no change
            return self.tokens[opc_retry_token]
        if if_match is not None and if_match != self.etag[target_asset_id]:
            raise self._err(412, "PreconditionFailed", "etag mismatch")
        a = self.assets[target_asset_id]
        if details.is_excluded_from_execution is not None:
            a.is_excluded_from_execution = details.is_excluded_from_execution
        if details.user_spec is not None:
            a.user_spec = copy.deepcopy(details.user_spec)
        self.etag[target_asset_id] = f"e{len(self.updates) + 1}"
        self.updates.append((target_asset_id, details, if_match, opc_retry_token))
        wid = f"wr-{len(self.updates)}"
        self.wr[wid] = self.wr_status
        resp = NS(data=None, headers={"opc-work-request-id": wid})
        if opc_retry_token:
            self.tokens[opc_retry_token] = resp
        return resp

    def get_work_request(self, work_request_id):
        return NS(data=NS(status=self.wr[work_request_id]), headers={})

    def list_work_request_errors(self, work_request_id, page=None):
        return NS(data=NS(items=[NS(code="InvalidParameter", message="subnet is in another AD")]), next_page=None,
                  headers={})


def _ocm_place():
    return F.place(W("crm-app-01", "crm", vcpus=8, mem=32), BLUEPRINTS, {"memory_gbs": 48})


def _ocm_driver(c, **kw):
    import oci
    return O.OCMDriver(c, "ocid1.ocmmigrationplan.oc1.phx.plan1", oci.cloud_migrations.models,
                       sleep=lambda s: None, **kw)


SUBNETS = {"subnet_app": "ocid1.subnet.oc1.phx.app", "subnet_db": "ocid1.subnet.oc1.phx.db",
           "subnet_web": "ocid1.subnet.oc1.phx.web"}


class Iteration32OcmWaitsForWorkRequests(unittest.TestCase):
    def test_a_failed_update_work_request_stops_with_oracles_reason(self):
        c = FakeOCM2({"ta-crm": ("crm-app-01", True, "ACTIVE")}, wr_status="FAILED")
        with self.assertRaisesRegex(O.OCMError, "FAILED.*subnet is in another AD"):
            _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1")

    def test_successful_work_requests_are_reported(self):
        c = FakeOCM2({"ta-crm": ("crm-app-01", True, "ACTIVE"), "ta-x": ("x-01", False, "ACTIVE")})
        res = _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1")
        self.assertEqual(sorted(res["work_requests"]), ["wr-1", "wr-2"])


class Iteration33OcmOptimisticConcurrency(unittest.TestCase):
    def test_updates_carry_the_etag_read_just_before(self):
        c = FakeOCM2({"ta-crm": ("crm-app-01", True, "ACTIVE")})
        _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1")
        self.assertEqual(c.updates[0][2], "e0")

    def test_a_concurrent_edit_is_not_overwritten(self):
        class Racing(FakeOCM2):
            def get_target_asset(self, target_asset_id):
                r = super().get_target_asset(target_asset_id)
                self.etag[target_asset_id] += "+edit"                     # someone edits right after each GET
                return r
        c = Racing({"ta-crm": ("crm-app-01", True, "ACTIVE")})
        with self.assertRaisesRegex(O.OCMError, "changed by someone else"):
            _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1")
        self.assertEqual(c.updates, [])


class Iteration34OcmRetryTokens(unittest.TestCase):
    def test_a_lost_response_is_retried_with_the_same_token_and_applied_once(self):
        class LostResponse(FakeOCM2):
            lost = False

            def update_target_asset(self, *a, **kw):
                r = super().update_target_asset(*a, **kw)
                if not self.lost:
                    self.lost = True
                    raise self._err(503, "ServiceUnavailable", "response lost after the change was made")
                return r
        c = LostResponse({"ta-crm": ("crm-app-01", True, "ACTIVE")})
        _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1")
        self.assertEqual(len(c.updates), 1)                                 # the retry did not apply it twice
        self.assertEqual(len(c.updates[0][3]), 64)


class Iteration35OcmAssetStateGate(unittest.TestCase):
    def test_an_asset_needing_attention_is_not_included(self):
        c = FakeOCM2({"ta-crm": ("crm-app-01", True, "NEEDS_ATTENTION"), "ta-x": ("x-01", False, "ACTIVE")})
        with self.assertRaisesRegex(O.OCMError, "NEEDS_ATTENTION"):
            _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1")
        self.assertTrue(c.assets["ta-crm"].is_excluded_from_execution)        # never included
        self.assertEqual(c.updates, [])                                      # checked before any change


class Iteration36OcmBeforeStateIsRecordedFirst(unittest.TestCase):
    def test_before_state_reaches_the_callback_before_the_first_update(self):
        c = FakeOCM2({"ta-crm": ("crm-app-01", True, "ACTIVE"), "ta-x": ("x-01", False, "ACTIVE")})
        seen = []
        _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1",
                                  on_before=lambda b: seen.append((len(c.updates), b)))
        self.assertEqual(seen[0][0], 0)
        self.assertEqual(seen[0][1]["ta-x"], {"is_excluded_from_execution": False, "user_spec": None})
        self.assertIn("ta-crm", seen[0][1])

    def test_cli_journals_the_before_state(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        _write(f"{d}/sub.json", json.dumps(SUBNETS))
        _inv(d, [("crm-app-01", "crm", "app", L8, "")])
        args = ["ocm-wave", "--inventory", f"{d}/inv.csv", "--wave", "1", "--env", "dev",
                "--migration-plan", "ocid1.ocmmigrationplan.oc1.phx.plan1", "--subnet-map", f"{d}/sub.json",
                "--compartment", COMP, "--availability-domain", "AD-1", "--tag", "cost_center=a", "--tag", "owner=b",
                "--journal", f"{d}/ocm.jsonl"]
        M.main(args, out=out.append, ocm_client=mock.Mock())
        pid = json.loads(out[-1])["plan_id"]
        c = FakeOCM2({"ta-crm": ("crm-app-01", True, "ACTIVE")})
        self.assertEqual(M.main(args + ["--apply", "--plan-id", pid], out=out.append, ocm_client=c, quota=QUOTA), 0,
                         out[-1])
        ev = [e["event"] for e in Journal(f"{d}/ocm.jsonl").entries]
        self.assertEqual(ev, ["ocm_before_state", "ocm_wave_applied"])


class Iteration37OcmPagingGuard(unittest.TestCase):
    def test_all_pages_are_read(self):
        c = FakeOCM2({f"ta-{i}": (f"v{i}", True, "ACTIVE") for i in range(5)}, page_size=2)
        self.assertEqual(len(_ocm_driver(c).summaries()), 5)

    def test_a_repeated_page_token_stops_instead_of_looping(self):
        c = FakeOCM2({f"ta-{i}": (f"v{i}", True, "ACTIVE") for i in range(5)}, page_size=2, repeat_token=True)
        with self.assertRaisesRegex(O.OCMError, "repeated"):
            _ocm_driver(c).summaries()


def _shape(name, cpu=(1, 94), mem=(1, 1049.6), per=(1, 64), fixed=None):
    if fixed:
        return NS(shape=name, ocpus=fixed[0], memory_in_gbs=fixed[1], ocpu_options=None, memory_options=None,
                  is_flexible=False)
    return NS(shape=name, ocpus=None, memory_in_gbs=None, is_flexible=True,
              ocpu_options=NS(min=cpu[0], max=cpu[1]),
              memory_options=NS(min_in_g_bs=mem[0], max_in_g_bs=mem[1], min_per_ocpu_in_gbs=per[0],
                                max_per_ocpu_in_gbs=per[1]))


class _Compute:
    def __init__(self, shapes):
        self.shapes, self.calls = shapes, []

    def list_shapes(self, compartment_id, **kw):
        self.calls.append((compartment_id, kw))
        return NS(data=self.shapes, next_page=None, headers={}, has_next_page=False)


class Iteration38LiveShapeLimits(unittest.TestCase):
    def setUp(self):
        from ocio import shapes as S
        self.S = S
        self.p = F.place(W("crm-app-01", "crm", vcpus=8, mem=32), BLUEPRINTS, {"memory_gbs": 48})

    def test_offered_shape_within_limits_passes(self):
        c = _Compute([_shape(self.p.params["shape"])])
        self.assertEqual(self.S.check(c, COMP, "AD-1", [self.p]), [])
        self.assertEqual(c.calls[0], (COMP, {"availability_domain": "AD-1"}))

    def test_shape_not_offered_in_the_ad_is_named(self):
        probs = self.S.check(_Compute([_shape("VM.Standard3.Flex")]), COMP, "AD-1", [self.p])
        self.assertTrue(any("not offered" in x and self.p.params["shape"] in x for x in probs), probs)

    def test_tenancy_limits_tighter_than_the_static_table_are_caught(self):
        tight = _Compute([_shape(self.p.params["shape"], cpu=(1, 2), per=(1, 8))])
        probs = self.S.check(tight, COMP, "AD-1", [self.p])
        self.assertTrue(any("OCPUs" in x for x in probs), probs)
        self.assertTrue(any("GB per OCPU" in x for x in probs), probs)

    def test_cli_run_apply_stops_before_creating_anything(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        inv = _inv(d, [("crm-app-01", "crm", "app", L8, "")])
        base = ["run", "--inventory", inv, "--env", "dev", "--compartment", COMP, "--availability-domain", "AD-1",
                "--tag", "cost_center=a", "--tag", "owner=b", "--journal", f"{d}/j.jsonl"]
        M.main(base, out=out.append)
        pid = json.loads(out[-2])["plan_id"]
        fake = FakeOCI()
        rc = M.main(base + ["--apply", "--plan-id", pid], out=out.append, provider_factory=lambda: fake, quota=QUOTA,
                    shape_compute=_Compute([_shape("VM.Standard3.Flex")]))
        self.assertEqual(rc, 2)
        self.assertIn("not offered", out[-1])
        self.assertEqual(fake.calls, [])


POLICY = {"required_checks": ["capacity", "application_health", "rollback_rehearsal"], "max_age_seconds": 900}


def _evidence(pid, wave, at, **over):
    checks = [{"name": n, "passed": True, "observer": "ops on-call", "source_ref": f"ticket/{n}"}
              for n in POLICY["required_checks"]]
    doc = {"plan_id": pid, "wave": wave, "observed_at": at, "checks": checks}
    doc.update(over)
    return doc


class Iteration39AdmissionEvidence(unittest.TestCase):
    def setUp(self):
        from ocio import admission as AD
        self.AD = AD

    def test_fresh_bound_complete_evidence_admits(self):
        r = self.AD.evaluate("p1", 2, [_evidence("p1", 2, 1000)], POLICY, now=1100)
        self.assertTrue(r["allowed"], r)
        self.assertEqual(len(r["evidence_hash"]), 64)

    def test_every_refusal_reason(self):
        cases = {
            "not bound": [_evidence("other", 2, 1000)],
            "stale": [_evidence("p1", 2, 1000)],
            "missing": [_evidence("p1", 2, 1900, checks=[])],
            "did not pass": [_evidence("p1", 2, 1900, checks=[dict(c, passed="yes") for c in _evidence("p1", 2, 0)["checks"]])],
            "observer": [_evidence("p1", 2, 1900, checks=[dict(c, observer=" ") for c in _evidence("p1", 2, 0)["checks"]])],
            "conflicting": [_evidence("p1", 2, 1900, checks=_evidence("p1", 2, 0)["checks"] * 2)],
            "future": [_evidence("p1", 2, 9999)],
            "more than one": [_evidence("p1", 2, 1900), _evidence("p1", 2, 1901)],
        }
        for why, docs in cases.items():
            with self.subTest(why):
                r = self.AD.evaluate("p1", 2, docs, POLICY, now=2000)
                self.assertFalse(r["allowed"])
                self.assertTrue(any(why in x for x in r["reasons"]), r["reasons"])

    def test_iso_timestamps_need_a_timezone(self):
        ok = self.AD.evaluate("p1", 1, [_evidence("p1", 1, "1970-01-01T00:16:40Z")], POLICY, now=1100)
        self.assertTrue(ok["allowed"], ok)
        naive = self.AD.evaluate("p1", 1, [_evidence("p1", 1, "1970-01-01T00:16:40")], POLICY, now=1100)
        self.assertFalse(naive["allowed"])

    def test_bad_policy_is_refused(self):
        for bad in ({}, {"required_checks": [], "max_age_seconds": 9}, {"required_checks": ["a", "a"], "max_age_seconds": 9},
                    {"required_checks": ["a"], "max_age_seconds": 0}, {"required_checks": ["a"], "max_age_seconds": True}):
            with self.subTest(bad), self.assertRaises(ValueError):
                self.AD.check_policy(bad)

    def test_pipeline_stops_a_wave_without_evidence_and_journals_the_decision(self):
        jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        fake = FakeOCI()
        seen = []

        def admit(i, pid):
            seen.append(i)
            return {"allowed": i == 1, "reasons": [] if i == 1 else ["missing or conflicting check: capacity"],
                    "evidence_hash": "h"}
        wls = [W("a1", "a"), W("b1", "b", deps=["a"])]
        rep = P.run(wls, BLUEPRINTS, settings(), lambda: Engine(fake, Journal(jp), sleep=lambda s: None), quota=QUOTA,
                    admit=admit)
        self.assertEqual([w["status"] for w in rep.wave_results], ["SUCCEEDED", "BLOCKED_ADMISSION"])
        self.assertEqual(seen, [1, 1, 2])                # wave 1 once before the network, then per wave
        self.assertNotIn("b1", {x["params"].get("display_name") for x in fake.res.values()})
        ev = [e for e in Journal(jp).entries if e["event"] == "admission"]
        self.assertEqual([(e["phase"], e["wave"], e["allowed"]) for e in ev],      # every decision on record (100)
                         [("before_network", 1, True), ("wave", 1, True), ("wave", 2, False)])

    @mock.patch("time.sleep", lambda s: None)        # FakeOCI needs polls; no real waiting in tests
    def test_cli_policy_is_part_of_the_plan_and_evidence_is_required(self):
        import migrate as M
        import time as _t
        d, out = tempfile.mkdtemp(), []
        inv = _inv(d, [("crm-app-01", "crm", "app", L8, "")])
        _write(f"{d}/pol.json", json.dumps(POLICY))
        base = ["run", "--inventory", inv, "--env", "dev", "--compartment", COMP, "--availability-domain", "AD-1",
                "--tag", "cost_center=a", "--tag", "owner=b", "--journal", f"{d}/j.jsonl"]
        M.main(base, out=out.append)
        plain = json.loads(out[-2])["plan_id"]
        M.main(base + ["--admission-policy", f"{d}/pol.json"], out=out.append)
        pid = json.loads(out[-2])["plan_id"]
        self.assertNotEqual(plain, pid)                                   # the policy is part of what was reviewed
        fake = FakeOCI()
        apply = base + ["--admission-policy", f"{d}/pol.json", "--apply", "--plan-id", pid]
        self.assertEqual(M.main(apply, out=out.append, provider_factory=lambda: fake, quota=QUOTA), 2)
        self.assertEqual(fake.calls, [])
        _write(f"{d}/ev.json", json.dumps([_evidence(pid, 1, _t.time() - 5)]))
        self.assertEqual(M.main(apply + ["--admission", f"{d}/ev.json"], out=out.append,
                                provider_factory=lambda: fake, quota=QUOTA), 0, out[-1])


class Iteration39bAdmissionGatesTheNetwork(unittest.TestCase):
    def test_unadmitted_first_wave_creates_nothing_at_all(self):
        fake = FakeOCI()
        rep = P.run([W("a1", "a")], BLUEPRINTS, settings(), lambda: Engine(fake, Journal(os.path.join(tempfile.mkdtemp(), "j"))),
                    quota=QUOTA, admit=lambda i, pid: {"allowed": False, "reasons": ["stale"]})
        self.assertTrue(any("not admitted" in x for x in rep.run_blocked), rep.run_blocked)
        self.assertEqual(fake.calls, [])


class Iteration41OneWriterPerJournal(unittest.TestCase):
    def test_a_second_writer_is_refused_while_the_first_holds_the_journal(self):
        from ocio.journal import exclusive, JournalBusy
        jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        with exclusive(jp):
            with self.assertRaisesRegex(JournalBusy, str(os.getpid())):
                with exclusive(jp):
                    pass
        with exclusive(jp):                                     # released on exit
            pass

    def test_cli_apply_is_refused_while_another_process_holds_the_journal(self):
        import migrate as M
        from ocio.journal import exclusive
        d, out = tempfile.mkdtemp(), []
        inv = _inv(d, [("crm-app-01", "crm", "app", L8, "")])
        base = ["run", "--inventory", inv, "--env", "dev", "--compartment", COMP, "--availability-domain", "AD-1",
                "--tag", "cost_center=a", "--tag", "owner=b", "--journal", f"{d}/j.jsonl"]
        M.main(base, out=out.append)
        pid = json.loads(out[-2])["plan_id"]
        fake = FakeOCI()
        with exclusive(f"{d}/j.jsonl"):
            with self.assertRaisesRegex(SystemExit, "in use"):
                M.main(base + ["--apply", "--plan-id", pid], out=out.append, provider_factory=lambda: fake, quota=QUOTA)
        self.assertEqual(fake.calls, [])


class Iteration42TornJournalLine(unittest.TestCase):
    def test_a_torn_last_line_is_refused_with_its_line_number(self):
        from ocio.journal import JournalError
        jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        Journal(jp).append(event="a")
        with open(jp, "a") as f:
            f.write('{"event": "creat')                         # the process died mid-write
        with self.assertRaisesRegex(JournalError, "line 2"):
            Journal(jp)


class Iteration43RegionIsBound(unittest.TestCase):
    def _base(self, d):
        inv = _inv(d, [("crm-app-01", "crm", "app", L8, "")])
        return ["run", "--inventory", inv, "--env", "dev", "--compartment", COMP, "--availability-domain", "AD-1",
                "--tag", "cost_center=a", "--tag", "owner=b", "--journal", f"{d}/j.jsonl"]

    def test_region_is_part_of_the_plan_id(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        M.main(self._base(d), out=out.append)
        a = json.loads(out[-2])["plan_id"]
        M.main(self._base(d) + ["--region", "us-phoenix-1"], out=out.append)
        b = json.loads(out[-2])["plan_id"]
        M.main(self._base(d) + ["--region", "us-ashburn-1"], out=out.append)
        self.assertEqual(len({a, b, json.loads(out[-2])["plan_id"]}), 3)

    def test_session_in_another_region_is_refused_before_any_call(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        args = self._base(d) + ["--region", "us-phoenix-1"]
        M.main(args, out=out.append)
        pid = json.loads(out[-2])["plan_id"]
        ident = mock.Mock()
        with mock.patch("ocio.auth.make", return_value=({"region": "us-ashburn-1", "tenancy": "t"}, None)):
            with self.assertRaisesRegex(SystemExit, "us-ashburn-1.*us-phoenix-1|us-phoenix-1.*us-ashburn-1"):
                M.main(args + ["--apply", "--plan-id", pid], out=out.append, quota=QUOTA, identity=ident)
        ident.list_availability_domains.assert_not_called()


class Iteration44Packaging(unittest.TestCase):
    def test_python_dash_m_ocio_and_version(self):
        import subprocess
        r = subprocess.run([sys.executable, "-m", "ocio", "--version"], cwd=HERE, capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        from ocio import __version__
        self.assertIn(__version__, r.stdout)

    def test_pyproject_declares_the_console_script_and_pins_the_sdk(self):
        import tomllib
        with open(os.path.join(HERE, "pyproject.toml"), "rb") as f:
            proj = tomllib.load(f)["project"]
        self.assertEqual(proj["scripts"]["ocio"], "ocio.cli:main")
        self.assertIn("oci==2.189.0", proj["optional-dependencies"]["oci"])

    def test_the_old_script_path_still_works(self):
        import subprocess
        r = subprocess.run([sys.executable, os.path.join(HERE, "scripts", "migrate.py"), "--version"],
                           capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)


class Iteration45OneTargetAssetPerVm(unittest.TestCase):
    def test_two_vms_mapped_to_one_target_asset_are_refused(self):
        sums = [NS(id="ta-1", migration_asset=NS(display_name="a")), NS(id="ta-2", migration_asset=NS(display_name="b"))]
        with self.assertRaisesRegex(ValueError, "same target asset"):
            O.match_target_assets(sums, ["a", "b"], mapping={"b": "ta-1"})        # b mapped onto a's asset


class Iteration46OcmKeepsFieldsItDoesNotOwn(unittest.TestCase):
    def test_existing_user_spec_fields_survive_and_ours_are_applied(self):
        import oci
        m = oci.cloud_migrations.models
        c = FakeOCM2({"ta-crm": ("crm-app-01", True, "ACTIVE")})
        c.assets["ta-crm"].user_spec = m.LaunchInstanceDetails(
            shape="VM.Standard2.1", is_pv_encryption_in_transit_enabled=True,
            freeform_tags={"cost_center": "keep-me"},
            source_details=m.InstanceSourceViaBootVolumeDetails(boot_volume_id="ocid1.bootvolume.oc1.phx.rep"),
            create_vnic_details=m.CreateVnicDetails(subnet_id=SUBNETS["subnet_app"], private_ip="10.0.2.17", skip_source_dest_check=True))
        _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1")
        u = c.assets["ta-crm"].user_spec
        self.assertEqual(u.shape, _ocm_place().params["shape"])                       # ours
        self.assertEqual(u.create_vnic_details.subnet_id, SUBNETS["subnet_app"])        # ours
        self.assertTrue(u.is_pv_encryption_in_transit_enabled)                           # kept
        self.assertEqual(u.source_details.boot_volume_id, "ocid1.bootvolume.oc1.phx.rep")  # kept
        self.assertEqual(u.create_vnic_details.private_ip, "10.0.2.17")                  # kept
        self.assertTrue(u.create_vnic_details.skip_source_dest_check)                    # kept
        self.assertEqual(u.freeform_tags["cost_center"], "keep-me")
        self.assertEqual(u.freeform_tags["ocio_blueprint"], _ocm_place().blueprint.id())

    def test_without_a_user_spec_ocms_recommendation_is_the_base(self):
        import oci
        m = oci.cloud_migrations.models
        c = FakeOCM2({"ta-crm": ("crm-app-01", True, "ACTIVE")})
        c.assets["ta-crm"].recommended_spec = m.LaunchInstanceDetails(
            shape="VM.Standard2.1", agent_config=m.LaunchInstanceAgentConfigDetails(is_monitoring_disabled=False))
        _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1")
        u = c.assets["ta-crm"].user_spec
        self.assertEqual(u.shape, _ocm_place().params["shape"])
        self.assertIsNotNone(u.agent_config)


class Iteration47NamedReviewerForRejections(unittest.TestCase):
    def _findings(self):
        from ocio import discovery as D
        assets = [D.Asset("a-app-01", "10.0.0.1", "Oracle Linux 8", 4, 16, {"app": "a"}),
                  D.Asset("b-db-01", "10.0.0.2", "Oracle Linux 8", 4, 16, {"app": "b"})]
        return D.discover(assets, [("10.0.0.1", "10.0.0.2", 1521, 50)])

    def test_rejecting_a_discovered_dependency_needs_a_reviewer(self):
        f = self._findings()
        key = f.deps[0].key
        with self.assertRaisesRegex(ValueError, "reviewed_by"):
            f.to_workloads({"dependencies": {key: "reject"}})
        wls, summary = f.to_workloads({"dependencies": {key: "reject"}, "reviewed_by": "J. Doe"})
        self.assertEqual(summary["reviewed_by"], "J. Doe")
        f.to_workloads({"dependencies": {key: "accept"}})                        # accepting needs no name


class Iteration48OcmRestore(unittest.TestCase):
    def test_model_round_trip_keeps_nested_and_polymorphic_fields(self):
        import oci
        m = oci.cloud_migrations.models
        u = m.LaunchInstanceDetails(
            shape="X", source_details=m.InstanceSourceViaBootVolumeDetails(boot_volume_id="b"),
            create_vnic_details=m.CreateVnicDetails(subnet_id="s", nsg_ids=["n"], private_ip="10.0.0.9"),
            shape_config=m.LaunchInstanceShapeConfigDetails(ocpus=2, memory_in_gbs=16), freeform_tags={"a": "b"})
        back = O.from_dict(m.LaunchInstanceDetails, oci.util.to_dict(u), m)
        self.assertEqual(oci.util.to_dict(back), oci.util.to_dict(u))
        self.assertIsInstance(back.source_details, m.InstanceSourceViaBootVolumeDetails)
        with self.assertRaisesRegex(ValueError, "unknown field"):
            O.from_dict(m.LaunchInstanceDetails, {"shapez": "X"}, m)

    def test_restore_puts_back_the_journalled_before_state(self):
        import oci
        import migrate as M
        m = oci.cloud_migrations.models
        d, out = tempfile.mkdtemp(), []
        c = FakeOCM2({"ta-crm": ("crm-app-01", True, "ACTIVE"), "ta-x": ("x-01", False, "ACTIVE")})
        c.assets["ta-crm"].user_spec = m.LaunchInstanceDetails(
            shape="VM.Standard2.1", create_vnic_details=m.CreateVnicDetails(subnet_id=SUBNETS["subnet_app"], private_ip="10.0.2.17"))
        orig = oci.util.to_dict(c.assets["ta-crm"].user_spec)
        j = Journal(f"{d}/ocm.jsonl")
        _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1", on_before=lambda snap: j.append(
            event="ocm_before_state", migration_plan="ocid1.ocmmigrationplan.oc1.phx.plan1", wave=1, plan_id="p",
            assets=snap))
        self.assertNotEqual(oci.util.to_dict(c.assets["ta-crm"].user_spec), orig)
        args = ["ocm-restore", "--journal", f"{d}/ocm.jsonl", "--migration-plan", "ocid1.ocmmigrationplan.oc1.phx.plan1"]
        n = len(c.updates)
        self.assertEqual(M.main(args, out=out.append, ocm_client=c), 0)                    # dry run
        self.assertEqual(len(c.updates), n)
        self.assertIn("ta-crm", out[-1])
        rid = json.loads(out[-1])["restore_id"]
        with self.assertRaises(SystemExit):
            M.main(args + ["--apply"], out=out.append, ocm_client=c)                       # not reviewed
        self.assertEqual(len(c.updates), n)
        self.assertEqual(M.main(args + ["--apply", "--restore-id", rid], out=out.append, ocm_client=c), 0, out[-1])
        self.assertEqual(oci.util.to_dict(c.assets["ta-crm"].user_spec), orig)
        self.assertTrue(c.assets["ta-crm"].is_excluded_from_execution)
        self.assertFalse(c.assets["ta-x"].is_excluded_from_execution)
        self.assertEqual(Journal(f"{d}/ocm.jsonl").entries[-1]["event"], "ocm_restored")


class Iteration49PollBackoff(unittest.TestCase):
    def test_state_polls_back_off_to_30_seconds_like_the_sdk_waiter(self):
        states = iter(["PROVISIONING"] * 7 + ["RUNNING"])
        prov = NS(state=lambda kind, rid: next(states))
        slept = []
        e = Engine(prov, Journal(os.path.join(tempfile.mkdtemp(), "j")), sleep=slept.append, clock=lambda: 0.0)
        e._wait("instance", "i1", "RUNNING")
        self.assertEqual(slept, [5.0, 10.0, 20.0, 30.0, 30.0, 30.0, 30.0])

    def test_last_sleep_never_runs_past_the_deadline(self):
        t = [0.0]
        prov = NS(state=lambda kind, rid: "PROVISIONING")
        e = Engine(prov, Journal(os.path.join(tempfile.mkdtemp(), "j")), wait_timeout=40.0,
                   sleep=lambda s: t.__setitem__(0, t[0] + s), clock=lambda: t[0])
        from ocio.engine import StepFailed
        with self.assertRaises(StepFailed):
            e._wait("instance", "i1", "RUNNING")
        self.assertLessEqual(t[0], 40.0)


class Iteration50ErrorHints(unittest.TestCase):
    def _provider_error(self, status, code, msg):
        import oci
        p = _sdk_provider()
        def boom(*a, **kw):
            raise oci.exceptions.ServiceError(status, code, {"opc-request-id": "r1"}, msg)
        from ocio.providers import ProviderError
        with self.assertRaises(ProviderError) as cm:
            p._call(boom)
        return str(cm.exception)

    def test_limit_quota_and_authorization_errors_say_what_to_do(self):
        self.assertIn("limit increase", self._provider_error(400, "LimitExceeded", "x"))
        self.assertIn("compartment quota", self._provider_error(400, "QuotaExceeded", "x"))
        m = self._provider_error(404, "NotAuthorizedOrNotFound", "x")
        self.assertIn("IAM policy", m)
        self.assertIn("r1", m)                                         # the request id is still there
        self.assertIn("API key", self._provider_error(401, "NotAuthenticated", "x"))

    def test_ocm_errors_get_the_same_hints(self):
        import oci
        c = FakeOCM2({"ta-crm": ("crm-app-01", True, "ACTIVE")})
        def denied(*a, **kw):
            raise oci.exceptions.ServiceError(404, "NotAuthorizedOrNotFound", {"opc-request-id": "r2"}, "x")
        c.update_target_asset = denied
        with self.assertRaisesRegex(O.OCMError, "IAM policy"):
            _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1")


class Iteration51ReleaseManifest(unittest.TestCase):
    def _tree(self):
        d = tempfile.mkdtemp()
        os.makedirs(f"{d}/ocio/__pycache__")
        _write(f"{d}/ocio/a.py", "x = 1\n")
        _write(f"{d}/ocio/__pycache__/a.pyc", "junk")
        _write(f"{d}/README.md", "hi\n")
        _write(f"{d}/j.jsonl.lock", "123")
        return d

    def test_manifest_is_sha256sum_compatible_and_skips_caches(self):
        import subprocess
        import release as R
        d = self._tree()
        R.write(d)
        text = open(f"{d}/SHA256SUMS").read()
        self.assertIn("  ocio/a.py\n", text)
        self.assertNotIn("pyc", text)
        self.assertNotIn(".lock", text)
        r = subprocess.run(["sha256sum", "-c", "--quiet", "SHA256SUMS"], cwd=d, capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertEqual(R.verify(d), [])

    def test_changed_missing_and_unlisted_files_are_reported(self):
        import release as R
        d = self._tree()
        R.write(d)
        _write(f"{d}/ocio/a.py", "x = 2\n")
        os.remove(f"{d}/README.md")
        _write(f"{d}/extra.py", "")
        problems = R.verify(d)
        self.assertTrue(any("changed: ocio/a.py" in p for p in problems), problems)
        self.assertTrue(any("missing: README.md" in p for p in problems), problems)
        self.assertTrue(any("not listed: extra.py" in p for p in problems), problems)


class Iteration52WhereTheChainBreaks(unittest.TestCase):
    def test_first_bad_entry_is_named(self):
        jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        j = Journal(jp)
        for i in range(4):
            j.append(event="e", n=i)
        self.assertEqual(Journal(jp).verify_detail(), None)
        lines = open(jp).read().splitlines()
        lines[2] = lines[2].replace('"n": 2', '"n": 9')
        _write(jp, "\n".join(lines) + "\n")
        detail = Journal(jp).verify_detail()
        self.assertEqual(detail["line"], 3)
        self.assertIn("hash", detail["problem"])
        self.assertFalse(Journal(jp).verify())

    def test_a_removed_entry_is_located_and_called_a_removal(self):
        jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        j = Journal(jp)
        for i in range(4):
            j.append(event="e", n=i)
        lines = open(jp).read().splitlines()
        del lines[1]                                              # entry 2 removed; 3 now follows 1
        _write(jp, "\n".join(lines) + "\n")
        detail = Journal(jp).verify_detail()
        self.assertEqual(detail["line"], 2)
        self.assertIn("removed", detail["problem"])


class Iteration53StatusCommand(unittest.TestCase):
    def test_status_summarises_runs_resources_and_integrity(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        fake = FakeOCI(crash_after_create={"crm-app-01"})
        jp = f"{d}/j.jsonl"
        from ocio.providers import Crash
        with self.assertRaises(Crash):
            P.run([W("crm-app-01", "crm")], BLUEPRINTS, settings(), lambda: Engine(fake, Journal(jp), sleep=lambda s: None),
                  quota=QUOTA)
        self.assertEqual(M.main(["status", "--journal", jp], out=out.append), 0)
        s = json.loads(out[-1])
        self.assertTrue(s["chain_intact"])
        self.assertEqual(len(s["head"]), 64)
        self.assertGreaterEqual(s["runs"]["open"], 1)                       # the crashed wave never ended
        self.assertGreaterEqual(s["resources_existing"], 1)
        self.assertIn("events", s)


class Iteration54InventoryLoader(unittest.TestCase):
    H = "name,app,tier,os,vcpus,memory_gb,depends_on_apps\n"

    def _load(self, text, bom=False):
        from ocio.catalog import load_inventory
        p = os.path.join(tempfile.mkdtemp(), "inv.csv")
        with open(p, "w", encoding="utf-8-sig" if bom else "utf-8") as f:
            f.write(text)
        return load_inventory(p)

    def test_excel_utf8_bom_is_read(self):
        self.assertEqual(self._load(self.H + f"v1,a,app,{L8},4,16,\n", bom=True)[0].name, "v1")

    def test_fractional_memory_and_spaced_dependencies(self):
        w = self._load(self.H + f"v1,a,app,{L8},4,15.5,b; c\nv2,b,app,{L8},4,16,\nv3,c,app,{L8},4,16,\n")[0]
        self.assertEqual(w.memory_gb, 15.5)
        self.assertEqual(w.depends_on_apps, ("b", "c"))

    def test_bad_values_are_refused_with_the_line(self):
        for row, why in ((f"v1,a,App,{L8},4,16,", "tier"), (f"v1,a,app,{L8},0,16,", "vcpus"),
                         (f"v1,a,app,{L8},4,-1,", "memory_gb"), (f",a,app,{L8},4,16,", "name"),
                         (f"v1,,app,{L8},4,16,", "app"), (f"v1,a,app,{L8},four,16,", "vcpus")):
            with self.subTest(row), self.assertRaisesRegex(ValueError, f"line 2.*{why}"):
                self._load(self.H + row + "\n")

    def test_missing_columns_and_duplicates_are_named(self):
        with self.assertRaisesRegex(ValueError, "missing columns.*memory_gb"):
            self._load("name,app,tier,os,vcpus\nv1,a,app,x,4\n")
        with self.assertRaisesRegex(ValueError, "duplicate.*v1"):
            self._load(self.H + f"v1,a,app,{L8},4,16,\nv1,a,app,{L8},4,16,\n")

    def test_discovery_csvs_accept_a_bom_too(self):
        from ocio import discovery as D
        p = os.path.join(tempfile.mkdtemp(), "assets.csv")
        with open(p, "w", encoding="utf-8-sig") as f:
            f.write("name,ip,os,vcpus,memory_gb,tags\nv1,10.0.0.1,Oracle Linux 8,4,16,\n")
        self.assertEqual(D.load_assets(p)[0].name, "v1")

    def test_fractional_memory_rounds_up_never_down(self):
        self.assertEqual(F.size(W("v", "a", mem=15.5))["memory_gbs"], 16)

    def test_discovery_assets_take_fractional_memory_and_refuse_zero(self):
        from ocio import discovery as D
        p = os.path.join(tempfile.mkdtemp(), "assets.csv")
        _write(p, "name,ip,os,vcpus,memory_gb,tags\nv1,10.0.0.1,Oracle Linux 8,4,15.5,\n")
        self.assertEqual(D.load_assets(p)[0].memory_gb, 15.5)
        _write(p, "name,ip,os,vcpus,memory_gb,tags\nv1,10.0.0.1,Oracle Linux 8,0,16,\n")
        with self.assertRaisesRegex(ValueError, "line 2"):
            D.load_assets(p)


class Iteration55NamesMustMeanSomething(unittest.TestCase):
    def test_blank_approver_is_refused(self):
        import migrate as M
        for flag in ("--approve-by", "--dependencies-done-by"):
            with self.subTest(flag), self.assertRaises(SystemExit):
                M.parser().parse_args(["ocm-wave", "--inventory", "x", "--wave", "1", "--migration-plan", "p",
                                       "--subnet-map", "s", flag, "   "])
        with self.assertRaises(SystemExit):
            M.parser().parse_args(["run", "--inventory", "x", "--approve-by", ""])

    def test_solo_app_not_in_the_inventory_is_refused(self):
        rep = P.run([W("v1", "a"), W("v2", "b")], BLUEPRINTS, settings(solo_apps=("nosuch",)), None, execute=False)
        self.assertTrue(any("nosuch" in x for x in rep.run_blocked), rep.run_blocked)


class Iteration56LiveSmokeLikeTheCli(unittest.TestCase):
    def _args(self, d, *extra):
        return ["--compartment", COMP, "--availability-domain", "AD-1", "--journal", os.path.join(d, "s.jsonl"), *extra]

    def test_ocids_are_checked_before_anything(self):
        import live_smoke as L
        d = tempfile.mkdtemp()
        with self.assertRaisesRegex(SystemExit, "compartment"):
            L.main(["--compartment", "my-compartment", "--availability-domain", "AD-1"], out=lambda s: None)
        with self.assertRaisesRegex(SystemExit, "image"):
            L.main(self._args(d, "--with-instance", "--image-ocid", "ocid1.subnet.oc1.phx.x"), out=lambda s: None)

    def test_unknown_availability_domain_is_refused_before_creating(self):
        import live_smoke as L
        d = tempfile.mkdtemp()
        ident = mock.Mock()
        ident.list_availability_domains.return_value = NS(data=[NS(name="Uocm:PHX-AD-1")])
        fake = FakeOCI()
        with self.assertRaisesRegex(SystemExit, "AD-1"):
            L.main(self._args(d, "--apply"), provider_factory=lambda: fake, identity=ident, tenancy="t",
                   out=lambda s: None)
        self.assertEqual(fake.calls, [])

    def test_auth_modes_timeout_and_region_flags_exist(self):
        import live_smoke as L
        a = L.parser().parse_args(self._args("/tmp", "--auth", "instance_principal", "--sdk-timeout", "5,30",
                                             "--region", "us-phoenix-1"))
        self.assertEqual((a.auth, a.sdk_timeout, a.region), ("instance_principal", (5.0, 30.0), "us-phoenix-1"))

    def test_apply_holds_the_journal(self):
        import live_smoke as L
        from ocio.journal import exclusive
        d = tempfile.mkdtemp()
        with exclusive(os.path.join(d, "s.jsonl")), self.assertRaisesRegex(SystemExit, "in use"):
            L.main(self._args(d, "--apply"), provider_factory=lambda: FakeOCI(), out=lambda s: None)


class Iteration59OneClickConsole(unittest.TestCase):
    """The radio-button launch console: one schema, built and checked on the server."""

    def setUp(self):
        from ocio.ui import launch as LA
        self.LA = LA
        self.d = tempfile.mkdtemp()
        os.makedirs(f"{self.d}/examples")
        _write(f"{self.d}/examples/inventory.csv", open(os.path.join(HERE, "examples", "inventory.csv")).read())

    def cfg(self, command="plan", radios=None, **fields):
        base = {"inventory": "examples/inventory.csv", "cost_center": "cc", "owner": "o"}
        return {"command": command, "radios": radios or {}, "fields": dict(base, **fields)}

    def test_radios_map_to_the_real_flags(self):
        argv, probs = self.LA.build_argv(self.cfg("run", {"mode": "apply", "env": "prod", "auth": "instance_principal",
                                                          "fd": "oci"}, compartment=COMP, ad="AD-1", plan_id="abc123",
                                                  approve_by="J. Doe"), self.d)
        self.assertEqual(probs, [])
        for flag in ("--apply", "--no-fault-domain-spread", "--plan-id", "--approve-by"):
            self.assertIn(flag, argv)
        self.assertEqual(argv[argv.index("--env") + 1], "prod")
        self.assertEqual(argv[argv.index("--auth") + 1], "instance_principal")
        import ocio.cli as CLI
        a = CLI.parser().parse_args(argv)                          # every built argv parses with the real CLI
        self.assertTrue(a.apply and a.no_fault_domain_spread and a.approve_by == "J. Doe")

    def test_every_command_with_defaults_parses_with_the_real_parser(self):
        import ocio.cli as CLI
        _write(f"{self.d}/a.csv", "x"); _write(f"{self.d}/f.csv", "x"); _write(f"{self.d}/s.json", "{}")
        _write(f"{self.d}/j.jsonl", "")
        extra = {"discover": {"assets": "a.csv", "flows": "f.csv"}, "netpolicy": {"assets": "a.csv", "flows": "f.csv"},
                 "ocm-wave": {"migration_plan": "ocid1.ocmmigrationplan.oc1.phx.p", "subnet_map": "s.json"},
                 "status": {"status_journal": "j.jsonl"}}
        for cmd, *_ in self.LA.COMMANDS:
            with self.subTest(cmd):
                argv, probs = self.LA.build_argv(self.cfg(cmd, **extra.get(cmd, {})), self.d)
                self.assertEqual(probs, [], cmd)
                CLI.parser().parse_args(argv)

    def test_apply_needs_the_reviewed_id_and_fields_cannot_smuggle_flags(self):
        _, probs = self.LA.build_argv(self.cfg("run", {"mode": "apply"}, compartment=COMP, ad="AD-1"), self.d)
        self.assertIn("Reviewed plan id is required", probs)
        _, probs = self.LA.build_argv(self.cfg(owner="--apply"), self.d)
        self.assertTrue(any("may not start with '-'" in p for p in probs), probs)
        _, probs = self.LA.build_argv(self.cfg(radios={"env": "prod; rm -rf ~"}), self.d)
        self.assertTrue(any("not an option" in p for p in probs), probs)
        _, probs = self.LA.build_argv(self.cfg(inventory="nope.csv"), self.d)
        self.assertTrue(any("no such file" in p for p in probs), probs)
        _, probs = self.LA.build_argv(self.cfg("run", compartment="ocid1.vcn.oc1.phx.x", ad="AD-1"), self.d)
        self.assertTrue(any("expected compartment" in p for p in probs), probs)

    def test_console_runs_one_command_at_a_time_and_carries_the_plan_id(self):
        calls = []
        c = self.LA.Console(self.d, token="t", runner=lambda argv: (calls.append(argv), (0, '{"plan_id": "0123456789ab"}'))[1])
        status, out = c.handle("run", self.cfg())
        self.assertEqual((status, out["returncode"], out["plan_id"]), (200, 0, "0123456789ab"))
        c.lock.acquire()
        self.assertEqual(c.handle("run", self.cfg())[0], 409)
        c.lock.release()
        self.assertEqual(c.handle("preview", {"command": "nope"})[0], 400)
        self.assertEqual(len(calls), 1)

    def test_token_and_host_are_both_required(self):
        c = self.LA.Console(self.d, token="secret")
        ok = {"X-Console-Token": "secret", "Host": "127.0.0.1:5000"}
        self.assertTrue(c.authorized(ok, 5000))
        self.assertTrue(c.authorized(dict(ok, Host="localhost:5000"), 5000))
        self.assertFalse(c.authorized(dict(ok, **{"X-Console-Token": "guess"}), 5000))
        self.assertFalse(c.authorized(dict(ok, Host="attacker.example:5000"), 5000))   # DNS rebinding
        self.assertFalse(c.authorized({"Host": "127.0.0.1:5000"}, 5000))

    def test_real_subprocess_run_of_a_plan(self):
        c = self.LA.Console(self.d, token="t")
        status, out = c.handle("run", self.cfg())
        self.assertEqual((status, out["returncode"]), (200, 0), out.get("output"))
        self.assertEqual(len(out["plan_id"]), 12)

    def test_launchers_exist_and_start_the_console(self):
        for f in ("launch.sh", "Launch.bat"):
            self.assertIn("-m ocio ui", open(os.path.join(HERE, f)).read(), f)
        self.assertIn("exec ./launch.sh", open(os.path.join(HERE, "Launch.command")).read())
        for f in ("Launch.command", "launch.sh"):
            self.assertTrue(os.access(os.path.join(HERE, f), os.X_OK), f)


class Iteration60WrapperOnEveryPage(unittest.TestCase):
    def test_console_and_guide_use_the_shell_and_load_nothing_remote(self):
        from ocio.ui import guide, launch as LA
        pages = {"console": LA.console_html(), "console-live": LA.console_html("tok", "/w"), "guide": guide.html()}
        for name, page in pages.items():
            with self.subTest(name):
                self.assertIn('class="sidebar"', page)
                self.assertIn("data-sparkle-anchor", page)
                self.assertIn("metadataTooltip", page)
                self.assertNotRegex(page, r'(src|href)="https?://')
                self.assertNotIn("@import", page)
                self.assertNotIn("fonts.googleapis", page)
                self.assertIn("not an Oracle product", page)

    def test_document_css_is_scoped_and_dark_blocks_dropped(self):
        from ocio.ui.guide import scope_css
        out = scope_css(":root{--a:1}body{margin:0}th,td{padding:1px}@media (prefers-color-scheme:dark){:root{--a:2}}"
                        ":root[data-theme=\"dark\"]{--a:3}@media (max-width:700px){h1{font-size:2px}}@keyframes k{from{opacity:0}}")
        self.assertIn(".doc{--a:1}", out)
        self.assertIn(".doc{margin:0}", out)
        self.assertIn(".doc th,.doc td{padding:1px}", out)
        self.assertNotIn("--a:2", out)
        self.assertNotIn("--a:3", out)
        self.assertIn("@media (max-width:700px){.doc h1{font-size:2px}}", out)
        self.assertIn("@keyframes k{from{opacity:0}}", out)


class Iteration61NoSilentlyIgnoredOptions(unittest.TestCase):
    def _ocm_args(self, d):
        _write(f"{d}/sub.json", json.dumps(SUBNETS))
        _inv(d, [("crm-app-01", "crm", "app", L8, "")])
        _write(f"{d}/pol.json", json.dumps(POLICY))
        return ["ocm-wave", "--inventory", f"{d}/inv.csv", "--wave", "1", "--env", "dev",
                "--migration-plan", "ocid1.ocmmigrationplan.oc1.phx.plan1", "--subnet-map", f"{d}/sub.json",
                "--compartment", COMP, "--availability-domain", "AD-1", "--tag", "cost_center=a", "--tag", "owner=b",
                "--journal", f"{d}/ocm.jsonl", "--admission-policy", f"{d}/pol.json"]

    def test_ocm_wave_evaluates_admission_evidence(self):
        import migrate as M
        import time as _t
        d, out = tempfile.mkdtemp(), []
        args = self._ocm_args(d)
        M.main(args, out=out.append, ocm_client=mock.Mock())
        pid = json.loads(out[-1])["plan_id"]
        c = FakeOCM2({"ta-crm": ("crm-app-01", True, "ACTIVE")})
        self.assertEqual(M.main(args + ["--apply", "--plan-id", pid], out=out.append, ocm_client=c, quota=QUOTA), 2)
        self.assertIn("admission", out[-1])
        self.assertEqual(c.updates, [])
        _write(f"{d}/ev.json", json.dumps([_evidence(pid, 1, _t.time() - 5)]))
        self.assertEqual(M.main(args + ["--apply", "--plan-id", pid, "--admission", f"{d}/ev.json"], out=out.append,
                                ocm_client=c, quota=QUOTA), 0, out[-1])
        ev = [e for e in Journal(f"{d}/ocm.jsonl").entries if e["event"] == "admission"]
        self.assertEqual([e["allowed"] for e in ev], [False, True])

    def test_plan_runs_the_cutover_check_it_is_given(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        inv = Iteration30CutoverGate()._estate(d)
        rc = M.main(["plan", "--inventory", inv, "--env", "dev", "--tag", "cost_center=a", "--tag", "owner=b",
                     "--assets", f"{d}/assets.csv", "--flows", f"{d}/flows.csv"], out=out.append)
        self.assertEqual(rc, 2)
        self.assertIn("1521", out[-1])

    def test_plan_does_not_accept_evidence(self):
        import migrate as M
        with self.assertRaises(SystemExit):
            M.parser().parse_args(["plan", "--inventory", "x", "--admission", "e.json"])

    def test_no_option_abbreviations(self):
        import migrate as M
        with self.assertRaises(SystemExit):
            M.parser().parse_args(["run", "--inventory", "x", "--appr", "J. Doe"])

    def test_every_option_of_every_command_is_read_somewhere(self):
        """Static audit: each option a command accepts is read (a.<dest>) by its handler or a helper it calls.
        An accepted option nobody reads reports success while doing nothing."""
        import argparse
        import re
        import ocio.cli as CLI
        src = open(CLI.__file__).read()
        funcs = dict(re.findall(r"\ndef (\w+)\(.*?\):\n(.*?)(?=\ndef |\Z)", src, flags=re.S))
        calls = {n: set(re.findall(r"\b(_\w+|cmd_\w+)\(", b)) for n, b in funcs.items()}

        def reach(fn, seen):
            if fn in funcs and fn not in seen:
                seen.add(fn)
                for c in calls[fn]:
                    reach(c, seen)
            return seen
        sub = next(x for x in CLI.parser()._actions if isinstance(x, argparse._SubParsersAction))
        for cmd, sp in sub.choices.items():
            handler = "cmd_" + cmd.replace("-", "_")
            if cmd == "ui":
                continue                                          # dispatched inline in _dispatch
            body = "".join(funcs[f] for f in reach(handler, set()))
            read = set(re.findall(r"\ba\.(\w+)", body)) | set(re.findall(r'getattr\(a, "(\w+)"', body))
            unread = [x.dest for x in sp._actions if x.dest != "help" and x.dest not in read]
            with self.subTest(cmd):
                self.assertEqual(unread, [], f"{cmd} accepts options it never reads")


class Iteration62EveryPublicPieceIsExplained(unittest.TestCase):
    def test_module_level_public_functions_classes_and_methods_have_docstrings(self):
        import ast
        missing = []
        for root in ("ocio", "scripts"):
            for dp, _, fs in os.walk(os.path.join(HERE, root)):
                for f in sorted(fs):
                    if not f.endswith(".py"):
                        continue
                    p = os.path.join(dp, f)
                    t = ast.parse(open(p).read())
                    if not ast.get_docstring(t):
                        missing.append(f"{p}: module")
                    for n in t.body:
                        items = [n] + ([m for m in n.body if isinstance(m, ast.FunctionDef)] if isinstance(n, ast.ClassDef) else [])
                        for x in items:
                            if isinstance(x, (ast.FunctionDef, ast.ClassDef)) and not x.name.startswith("_") \
                                    and not ast.get_docstring(x):
                                missing.append(f"{os.path.relpath(p, HERE)}:{x.lineno} {x.name}")
        self.assertEqual(missing, [])


class Iteration65ArmEndToEnd(unittest.TestCase):
    def test_default_policy_allows_every_shape_with_verified_limits(self):
        from ocio import policy
        p = F.place(W("a1-app-01", "a1", vcpus=8, mem=32), BLUEPRINTS, {"shape": "VM.Standard.A1.Flex"})
        wf = F.wave_workflow(1, ["a1"], [p], {k: {"id": "x"} for k in F.TIER_SUBNETS.values()}, "dev", COMP, TAGS)
        self.assertEqual([v for v in policy.evaluate(wf) if "shape" in v], [])
        bad = F.wave_workflow(1, ["a1"], [p], {k: {"id": "x"} for k in F.TIER_SUBNETS.values()}, "dev", COMP, TAGS)
        object.__setattr__(bad.steps[0], "params", dict(bad.steps[0].params, shape="VM.Unknown.Flex"))
        self.assertTrue([v for v in policy.evaluate(bad) if "shape" in v])

    def test_arm_shape_never_gets_the_x86_image(self):
        from ocio.providers import ProviderError
        p = _sdk_provider(image_map={"IMAGE_OL8": "ocid1.image.oc1.phx.x86"})
        with self.assertRaisesRegex(ProviderError, "Arm"):
            p._image({"image_id": "IMAGE_OL8", "shape": "VM.Standard.A1.Flex"})
        p = _sdk_provider(image_map={"IMAGE_OL8": "ocid1.image.oc1.phx.x86", "IMAGE_OL8@VM.Standard.A1.Flex": "ocid1.image.oc1.phx.arm"})
        self.assertEqual(p._image({"image_id": "IMAGE_OL8", "shape": "VM.Standard.A1.Flex"}), "ocid1.image.oc1.phx.arm")
        self.assertEqual(p._image({"image_id": "IMAGE_OL8", "shape": "VM.Standard.E5.Flex"}), "ocid1.image.oc1.phx.x86")

    def test_missing_images_stop_run_apply_before_any_change(self):
        problems = F.image_problems([F.place(W("v", "a", vcpus=4), BLUEPRINTS, {"shape": "VM.Standard.A1.Flex"})],
                                    {"IMAGE_OL8": "ocid1.image.oc1.phx.x86"})
        self.assertTrue(problems and "@VM.Standard.A1.Flex" in problems[0], problems)
        self.assertEqual(F.image_problems([F.place(W("v", "a"), BLUEPRINTS, {})], {"IMAGE_OL8": "ocid1.image.oc1.phx.x"}), [])

    def test_agent_may_not_change_cpu_architecture(self):
        from ocio.agent import Bounds
        self.assertNotIn("VM.Standard.A1.Flex", Bounds().shapes)

    def test_cli_run_apply_on_the_tenancy_path_stops_for_a_missing_arm_image(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        inv = _inv(d, [("crm-app-01", "crm", "app", L8, "")])
        _write(f"{d}/ov.json", json.dumps({"crm-app-01": {"shape": "VM.Standard.A1.Flex"}}))
        _write(f"{d}/img.json", json.dumps({"IMAGE_OL8": "ocid1.image.oc1.phx.x86"}))
        base = ["run", "--inventory", inv, "--overrides", f"{d}/ov.json", "--env", "dev", "--compartment", COMP,
                "--availability-domain", "AD-1", "--tag", "cost_center=a", "--tag", "owner=b",
                "--journal", f"{d}/j.jsonl", "--image-map", f"{d}/img.json"]
        M.main(base, out=out.append)
        pid = json.loads(out[-2])["plan_id"]
        ident = mock.Mock()
        ident.list_availability_domains.return_value = NS(data=[NS(name="AD-1")])
        made = []
        sess = ({"region": "us-phoenix-1", "tenancy": "t"}, None, lambda cls: made.append(cls) or mock.Mock())
        with mock.patch("ocio.cli._oci_session", return_value=sess):
            rc = M.main(base + ["--apply", "--plan-id", pid], out=out.append, quota=QUOTA, identity=ident,
                        shape_compute=_Compute([_shape("VM.Standard.A1.Flex", cpu=(1, 76), mem=(1, 472))]))
        self.assertEqual(rc, 2)
        self.assertIn("IMAGE_OL8@VM.Standard.A1.Flex", out[-1])
        self.assertFalse(os.path.exists(f"{d}/j.jsonl") and Journal(f"{d}/j.jsonl").entries)   # nothing started


class Iteration66DecisionsMustNameRealThings(unittest.TestCase):
    def _f(self):
        from ocio import discovery as D
        assets = [D.Asset("a-app-01", "10.0.0.1", L8, 4, 16, {"app": "a"}), D.Asset("b-db-01", "10.0.0.2", L8, 4, 16, {"app": "b"})]
        return D.discover(assets, [("10.0.0.1", "10.0.0.2", 1521, 50)])

    def test_unknown_vm_in_apps_or_tiers_is_refused(self):
        for dec in ({"apps": {"a-app-1": "z"}, "reviewed_by": "t"}, {"tiers": {"ghost": "db"}, "reviewed_by": "t"}):
            with self.subTest(dec), self.assertRaisesRegex(ValueError, "not in the assets"):
                self._f().to_workloads(dec)

    def test_unknown_top_level_key_is_refused(self):
        with self.assertRaisesRegex(ValueError, "dependancies"):
            self._f().to_workloads({"dependancies": {}})
        self._f().to_workloads({"_note": "comments with a leading underscore are fine", "reviewed_by": ""})


class Iteration67AdCheckWithoutTenancy(unittest.TestCase):
    def test_compartment_is_used_when_the_signer_gives_no_tenancy(self):
        import ocio.cli as M
        ident = mock.Mock()
        ident.list_availability_domains.return_value = NS(data=[NS(name="AD-1")])
        M._check_ad(ident, None, "AD-1", compartment=COMP)
        ident.list_availability_domains.assert_called_once()
        ca = ident.list_availability_domains.call_args
        self.assertEqual(ca.kwargs.get("compartment_id", ca.args[0] if ca.args else None), COMP)
        with self.assertRaisesRegex(SystemExit, "tenancy"):
            M._check_ad(ident, None, "AD-1")


class Iteration68ProvisionedWrapperWithOcioData(unittest.TestCase):
    def setUp(self):
        from ocio.ui import launch as LA, wrapper as WR
        self.LA, self.WR = LA, WR
        self.state = LA.wrapper_state(HERE)

    def test_the_template_is_the_provisioned_file_and_every_patch_applies_once(self):
        import hashlib
        raw = open(os.path.join(HERE, "ocio", "ui", "assets", "wrapper.html"), encoding="utf-8").read()
        self.assertEqual(hashlib.sha256(raw.encode()).hexdigest(), self.WR.PROVISIONED_SHA256)
        for reason, old, new in self.WR.PATCHES:
            self.assertEqual(raw.count(old), 1, reason)
        page = self.LA.wrapper_page(self.state)                  # the page as served: ocio's data and documents
        self.assertNotIn('aria-label="Oracle"', page)
        self.assertNotIn("Oracle-themed", page)
        self.assertNotIn("oci_orchestrator", page)                 # nothing of the other package's text remains

    def test_embedded_plan_is_ocios_plan(self):
        from ocio import pipeline as P
        from ocio.catalog import BLUEPRINTS, load_inventory
        ws = self.WR.workspace(self.state["inventory"], self.state["settings"])
        wls = load_inventory(self.state["inventory"])
        rep = P.run(wls, BLUEPRINTS, self.state["settings"], None, execute=False)
        self.assertEqual(ws["plan"]["plan_id"], rep.plan_id)
        self.assertEqual([w["apps"] for w in ws["plan"]["waves"]], rep.waves)
        self.assertEqual([w["index"] for w in ws["plan"]["waves"]], list(range(len(rep.waves))))
        self.assertEqual(set(ws["plan"]["placements"]), {p.workload.name for p in rep.placements})
        self.assertEqual(ws["plan"]["blocked"], rep.blocked_apps)

    def test_api_answers_with_ocios_engine(self):
        st = self.state
        status, plan = self.WR.handle_api("plan", {}, st)
        self.assertEqual(status, 200)
        self.assertEqual(self.WR.handle_api("validate", {"plan": {"plan_id": "0" * 12}}, st)[0], 400)
        self.assertEqual(self.WR.handle_api("dry-run", {"plan": plan}, st)[1]["plan_id"], plan["plan_id"])
        status, sim = self.WR.handle_api("simulate", {"plan": plan, "approvals": []}, st)
        self.assertEqual(status, 200)
        self.assertIn("run_started", [r["event"] for r in sim["journal"]])
        self.assertIn("no tenancy", sim["provider"])
        status, disc = self.WR.handle_api("discover", {}, st)
        self.assertEqual(status, 200)
        self.assertTrue(disc["dependencies"])
        self.assertEqual(self.WR.handle_api("nope", {}, st)[0], 404)

    def test_prod_simulation_needs_the_named_reviews(self):
        st = dict(self.state, settings=self.WR.default_settings("prod"))
        plan = self.WR.handle_api("plan", {}, st)[1]
        sim = self.WR.handle_api("simulate", {"plan": plan, "approvals": []}, st)[1]
        self.assertIn("BLOCKED_APPROVAL", [w["status"] for w in sim["waves"]])
        appr = [{"plan_id": plan["plan_id"], "wave": w["index"], "approver": "J. Doe"} for w in plan["waves"]]
        sim = self.WR.handle_api("simulate", {"plan": plan, "approvals": appr}, st)[1]
        self.assertNotIn("BLOCKED_APPROVAL", [w["status"] for w in sim["waves"]])

    def test_offline_and_served_pages(self):
        offline = self.LA.wrapper_page(self.state)
        served = self.LA.wrapper_page(self.state, served=True)
        self.assertIn("window.OCIO_LIVE=null", offline)
        self.assertIn("sessionStorage.getItem('ocio-token')", served)     # token from the private launch file only
        for page in (offline, served):
            self.assertIn("window.OCIO_LAUNCH=", page)
            self.assertNotRegex(page, r'(src|href)="https?://')
            self.assertIn("not an Oracle product", page)


class Iteration70ChainBreakReportsTheRealFileLine(unittest.TestCase):
    def test_blank_lines_do_not_shift_the_reported_line(self):
        jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        j = Journal(jp)
        for i in range(4):
            j.append(event="e", n=i)
        lines = open(jp).read().splitlines()
        lines[3] = lines[3].replace('"n": 3', '"n": 7')                   # entry 4 edited ...
        _write(jp, lines[0] + "\n\n\n" + "\n".join(lines[1:]) + "\n")     # ... and two blank lines after entry 1
        self.assertEqual(Journal(jp).verify_detail()["line"], 6)           # entry 4 is on file line 6

    def test_appends_after_trailing_blank_lines_are_numbered_correctly(self):
        jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        Journal(jp).append(event="a")
        with open(jp, "a") as f:
            f.write("\n\n")                                         # entry on line 1, blank lines 2-3
        j = Journal(jp)
        j.append(event="b")                                         # lands on line 4
        lines = open(jp).read().split("\n")
        self.assertIn('"event": "b"', lines[3])
        self.assertEqual(j._s.line_of, [1, 4])


class Iteration71InfrastructureOnlyVmsAreFlagged(unittest.TestCase):
    def test_a_vm_seen_only_on_admin_ports_is_reported_for_review(self):
        from ocio import discovery as D
        assets = [D.Asset("a-app-01", "10.0.0.1", L8, 4, 16, {"app": "a"}), D.Asset("b-db-01", "10.0.0.2", L8, 4, 16, {"app": "b"}),
                  D.Asset("jump-01", "10.0.0.3", L8, 2, 4, {"app": "ops"})]
        r = D.discover(assets, [("10.0.0.1", "10.0.0.2", 1521, 50), ("10.0.0.3", "10.0.0.1", 22, 9),
                                ("10.0.0.3", "10.0.0.53", 53, 40)])
        rep = r.report()
        self.assertEqual(rep["infrastructure_only_vms"], ["jump-01"])
        self.assertNotIn("jump-01", rep["silent_vms"])
        self.assertNotIn("a-app-01", rep["infrastructure_only_vms"])


class Iteration72EvidenceScriptHygiene(unittest.TestCase):
    def test_guard_fuzz_counts_rounds_from_any_iterable(self):
        import evidence as E
        out = E.guard_fuzz(iter([0, 1]))
        self.assertEqual(out["rounds"], 2)


class Iteration73ConsoleTokenNeverServedInAPage(unittest.TestCase):
    def setUp(self):
        from ocio.ui import launch as LA
        self.LA = LA

    def test_pages_carry_no_token(self):
        st = self.LA.wrapper_state(HERE)
        tok = "SeCrEt-token-123"
        for page in (self.LA.wrapper_page(st, served=True), self.LA.console_html(served=True, workdir="/w")):
            self.assertNotIn(tok, page)
            self.assertIn("sessionStorage", page)                # the token comes from the private launch file

    def test_private_launch_file(self):
        import stat
        path = self.LA.write_launch_file("http://127.0.0.1:5000/", "tok-abc")
        mode = stat.S_IMODE(os.stat(path).st_mode)
        dmode = stat.S_IMODE(os.stat(os.path.dirname(path)).st_mode)
        self.assertEqual((mode, dmode), (0o600, 0o700))
        self.assertIn("http://127.0.0.1:5000/#k=tok-abc", open(path).read())

    def test_served_page_reads_the_token_from_the_fragment_then_drops_it(self):
        import subprocess, socket, time, urllib.request
        st = self.LA.wrapper_state(HERE)
        page = self.LA.wrapper_page(st, served=True)
        self.assertIn("#k=", page)                                 # the bootstrap reads it ...
        self.assertIn("history.replaceState", page)                # ... and removes it from the address bar


class Iteration74EnvironmentIsOneOfThree(unittest.TestCase):
    def test_cli_refuses_other_spellings_everywhere(self):
        import ocio.cli as CLI
        for cmd in ("plan", "run", "ocm-wave", "netpolicy", "ui"):
            for bad in ("production", "PROD", "Prod", ""):
                with self.subTest(cmd=cmd, env=bad), self.assertRaises(SystemExit):
                    extra = ["--wave", "1", "--migration-plan", "p", "--subnet-map", "s"] if cmd == "ocm-wave" else []
                    CLI.parser().parse_args([cmd, "--inventory", "x", "--env", bad, *extra] if cmd != "ui" else [cmd, "--env", bad])

    def test_library_refuses_too(self):
        with self.assertRaisesRegex(ValueError, "environment"):
            settings(env="production")
        from ocio.spec import Workflow, SpecError
        with self.assertRaises(SpecError):
            Workflow("w", "PROD", COMP, (), {})


class Iteration75ConsoleAssetsShipInThePackage(unittest.TestCase):
    def test_pyproject_ships_ui_assets(self):
        import tomllib
        with open(os.path.join(HERE, "pyproject.toml"), "rb") as f:
            cfg = tomllib.load(f)
        data = cfg["tool"]["setuptools"]["package-data"]
        self.assertIn("assets/*", data.get("ocio.ui", []))
        needed = {"wrapper.html", "shell.css", "shell.js", "guide.html"}
        self.assertTrue(needed <= set(os.listdir(os.path.join(HERE, "ocio", "ui", "assets"))))


class Iteration76AnyAmbiguousAttemptMeansMayExist(unittest.TestCase):
    def test_lost_response_then_throttling_is_reported_as_possibly_created(self):
        from ocio.providers import ProviderError

        class LostThen429(FakeOCI):
            n = 0

            def create(self, kind, comp, params, tags, token):
                if kind == "instance":
                    self.n += 1
                    if self.n == 1:
                        super().create(kind, comp, params, tags, token)          # accepted ...
                        raise ProviderError(0, "transport error: ReadTimeout", retryable=True)   # ... reply lost
                    raise ProviderError(429, "TooManyRequests", retryable=True)
                return super().create(kind, comp, params, tags, token)
        fake = LostThen429()
        e, wf = _network_and_wave(fake, [W("vm1", "a")])
        res = e.apply(wf)
        self.assertNotEqual(res.status, "SUCCEEDED")
        events = [x["event"] for x in e.j.entries if x.get("step") == "vm1"]
        self.assertIn("create_unconfirmed", events)                          # flagged: it may exist
        self.assertTrue(any("vm1" in str(o) for o in res.orphans), res.orphans)


class Iteration77TokenAgeAlsoForUnconfirmedCreates(unittest.TestCase):
    def test_resume_refuses_an_unconfirmed_create_older_than_the_token_life(self):
        from ocio.engine import workflow_hash, retry_token
        fake = FakeOCI()
        e, wf = _network_and_wave(fake, [W("vm1", "a")])
        rid = "r-unconfirmed"
        e.j.append(run_id=rid, event="run_started", workflow=wf.name, workflow_hash=workflow_hash(wf),
                   steps=[s.id for s in wf.steps])
        e.j.append(run_id=rid, step="vm1", event="creating", retry_token=retry_token(rid, "vm1", 0), ts=1000.0,
                   params_hash="x", kind="instance")
        e.j.append(run_id=rid, step="vm1", event="create_unconfirmed", error="lost reply")
        e2 = Engine(fake, e.j, sleep=lambda s: None, poll_seconds=0, wall=lambda: 1000.0 + 25 * 3600)
        res = e2.apply(wf, run_id=rid)
        self.assertNotEqual(res.status, "SUCCEEDED")
        self.assertIn("retry token may have expired", res.error or "")
        self.assertEqual([r for r in fake.res.values() if r["kind"] == "instance"], [])   # nothing re-sent


class Iteration78NoSecondNetworkBesideAPartialOne(unittest.TestCase):
    def _net(self):
        return F.target_network("t", "dev", COMP, TAGS, "10.0.0.0/16", {"app": "10.0.2.0/24", "db": "10.0.3.0/24"})

    def _eng(self, fake, jp):
        return Engine(fake, Journal(jp), sleep=lambda s: None, poll_seconds=0)

    def test_a_missing_subnet_blocks_every_time_instead_of_building_a_second_network(self):
        fake, jp = FakeOCI(), os.path.join(tempfile.mkdtemp(), "j")
        self.assertEqual(P.apply_network(self._eng(fake, jp), self._net()).status, "SUCCEEDED")
        db = [rid for rid, r in fake.res.items() if r["params"].get("display_name") == "t-db"][0]
        fake.res[db]["state"] = "TERMINATED"                                  # deleted in the console
        self.assertEqual(P.apply_network(self._eng(fake, jp), self._net()).status, "BLOCKED_STATE")
        self.assertEqual(P.apply_network(self._eng(fake, jp), self._net()).status, "BLOCKED_STATE")   # still
        self.assertEqual(len([r for r in fake.res.values() if r["kind"] == "vcn" and r["state"] == "AVAILABLE"]), 1)

    def test_an_incomplete_teardown_blocks_instead_of_hiding_the_uncertain_vcn(self):
        fake, jp = FakeOCI(), os.path.join(tempfile.mkdtemp(), "j")
        r = P.apply_network(self._eng(fake, jp), self._net())
        fake.faults[("delete", "vcn")] = [400]
        td = self._eng(fake, jp).teardown(self._net(), r.run_id)
        self.assertEqual(td.status, "TEARDOWN_INCOMPLETE")
        again = P.apply_network(self._eng(fake, jp), self._net())
        self.assertEqual(again.status, "BLOCKED_STATE", again.error)
        self.assertIn("vcn", again.error)
        self.assertEqual(len([x for x in fake.res.values() if x["kind"] == "vcn" and x["state"] == "AVAILABLE"]), 1)

    def test_a_complete_teardown_still_allows_a_fresh_network(self):
        fake, jp = FakeOCI(), os.path.join(tempfile.mkdtemp(), "j")
        r = P.apply_network(self._eng(fake, jp), self._net())
        self.assertEqual(self._eng(fake, jp).teardown(self._net(), r.run_id).status, "TORN_DOWN")
        self.assertEqual(P.apply_network(self._eng(fake, jp), self._net()).status, "SUCCEEDED")


class Iteration79OneJournalOneTarget(unittest.TestCase):
    def _run(self, fake, jp, **kw):
        s = P.Settings(kw.get("env", "dev"), kw.get("comp", COMP), TAGS, kw.get("landing", "t"), "10.0.0.0/16",
                       {"web": "10.0.1.0/24", "app": "10.0.2.0/24", "db": "10.0.3.0/24"})
        return P.run([W("a1", "a")], BLUEPRINTS, s, lambda: Engine(fake, Journal(jp), sleep=lambda x: None,
                                                                   poll_seconds=0), quota=QUOTA)

    def test_another_compartment_or_landing_is_refused_before_any_call(self):
        fake, jp = FakeOCI(), os.path.join(tempfile.mkdtemp(), "j")
        self.assertEqual(self._run(fake, jp).wave_results[0]["status"], "SUCCEEDED")
        n = len(fake.calls)
        for kw in ({"comp": "ocid1.compartment.oc1..other"}, {"landing": "other"}, {"env": "test"}):
            with self.subTest(kw):
                rep = self._run(fake, jp, **kw)
                self.assertTrue(any("journal" in x and "target" in x for x in rep.run_blocked), rep.run_blocked)
        self.assertEqual(len(fake.calls), n)
        self.assertEqual(self._run(fake, jp).wave_results[0]["status"], "SUCCEEDED")     # same target: fine


class Iteration80NoStalePrivateIpOrVlanAcrossSubnets(unittest.TestCase):
    def _asset(self, **vnic):
        import oci
        m = oci.cloud_migrations.models
        c = FakeOCM2({"ta-crm": ("crm-app-01", True, "ACTIVE")})
        c.assets["ta-crm"].user_spec = m.LaunchInstanceDetails(shape="VM.Standard2.1",
                                                               create_vnic_details=m.CreateVnicDetails(**vnic))
        return c

    def test_a_pinned_ip_from_another_subnet_stops_the_wave_before_any_change(self):
        c = self._asset(subnet_id="ocid1.subnet.oc1.phx.old", private_ip="192.168.10.25")
        with self.assertRaisesRegex(O.OCMError, "private_ip 192.168.10.25"):
            _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1")
        self.assertEqual(c.updates, [])

    def test_a_vlan_placement_stops_the_wave_before_any_change(self):
        c = self._asset(vlan_id="ocid1.vlan.oc1.phx.v")
        with self.assertRaisesRegex(O.OCMError, "vlan"):
            _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1")
        self.assertEqual(c.updates, [])

    def test_same_subnet_keeps_the_ip_and_verifies_it(self):
        c = self._asset(subnet_id=SUBNETS["subnet_app"], private_ip="10.20.2.15")
        _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1")
        self.assertEqual(c.assets["ta-crm"].user_spec.create_vnic_details.private_ip, "10.20.2.15")


class Iteration81OnlyPlatformImagesAreResolved(unittest.TestCase):
    def test_custom_and_community_images_are_skipped(self):
        import oci
        from ocio import images as I
        compute = mock.Mock()
        compute.list_images.__name__ = "list_images"
        compute.list_images.return_value = oci.response.Response(200, {}, [
            NS(id="ocid1.image.oc1.phx.golden", display_name="team-golden-ol8", compartment_id=COMP, listing_type="NONE"),
            NS(id="ocid1.image.oc1.phx.comm", display_name="community-ol8", compartment_id="ocid1.compartment.oc1..x",
               listing_type="COMMUNITY"),
            NS(id="ocid1.image.oc1.phx.platform", display_name="Oracle-Linux-8", compartment_id=None, listing_type="NONE")],
            None)
        compute.get_image_shape_compatibility_entry.return_value = NS(data=NS())
        got = I.resolve(compute, COMP, {"IMAGE_OL8": {"operating_system": "Oracle Linux", "operating_system_version": "8"}},
                        "VM.Standard.E5.Flex")
        self.assertEqual(got, {"IMAGE_OL8": "ocid1.image.oc1.phx.platform"})


class Iteration82NsgRuleConvergenceReadsEveryPage(unittest.TestCase):
    def test_existing_rules_on_later_pages_are_not_added_again(self):
        from ocio import netpolicy as NP
        import oci
        m = oci.core.models
        plan = NP.Plan(members={"a-app": ["a1"], "b-db": ["b1"]},
                       rules=[NP.Rule("b-db", "a-app", p) for p in range(1000, 1030)])
        have = [NS(direction="INGRESS", source="nsg-a", tcp_options=NS(destination_port_range=NS(min=p, max=p)))
                for p in range(1000, 1030)]
        added, calls = [], []

        class Net:
            def list_network_security_group_security_rules(self, nsg_id, **kw):
                calls.append(kw)
                start = int(kw.get("page") or 0)
                nxt = start + 10
                return NS(data=have[start:nxt], next_page=str(nxt) if nxt < len(have) else None, headers={})

            def add_network_security_group_security_rules(self, nsg_id, details):
                added.extend(details.security_rules)
        NP.apply(Net(), m, plan, COMP, "ocid1.vcn.oc1.phx.v", existing={"a-app": "nsg-a", "b-db": "nsg-b"})
        self.assertEqual(added, [])
        self.assertTrue(all(c.get("direction") == "INGRESS" for c in calls))
        self.assertEqual(len(calls), 3)


class Iteration83SplittingAnAppKeepsItsInternalDependency(unittest.TestCase):
    def test_web_moves_after_its_database_when_the_reviewer_splits_the_app(self):
        from ocio import discovery as D
        assets = [D.Asset("crm-web-01", "10.0.0.1", L8, 4, 16, {"app": "crm", "tier": "web"}),
                  D.Asset("crm-db-01", "10.0.0.2", L8, 4, 16, {"app": "crm", "tier": "db"})]
        r = D.discover(assets, [("10.0.0.1", "10.0.0.2", 1521, 80)])
        wls, summary = r.to_workloads({"apps": {"crm-db-01": "crmdb"}, "reviewed_by": "J. Doe"})
        deps = {w.name: w.depends_on_apps for w in wls}
        self.assertEqual(deps["crm-web-01"], ("crmdb",))
        rep = P.run(wls, BLUEPRINTS, settings(), None, execute=False)
        self.assertEqual(rep.waves, [["crmdb"], ["crm"]])


class Iteration84HostnamesUniqueAcrossWaves(unittest.TestCase):
    def test_colliding_names_in_different_waves_get_different_labels(self):
        wls = [W("crm_app_01", "a"), W("CRM-APP-01", "b", deps=["a"])]           # same label, two waves
        fake = FakeOCI()
        jp = os.path.join(tempfile.mkdtemp(), "j")
        rep = P.run(wls, BLUEPRINTS, settings(), lambda: Engine(fake, Journal(jp), sleep=lambda s: None, poll_seconds=0),
                    quota=QUOTA)
        self.assertEqual(len(rep.waves), 2)
        labels = [r["params"].get("hostname_label") for r in fake.res.values() if r["kind"] == "instance"]
        self.assertEqual(len(labels), 2)
        self.assertEqual(len(set(labels)), 2, labels)


class Iteration85Ipv6InDiscovery(unittest.TestCase):
    def test_spelling_of_an_address_does_not_matter(self):
        from ocio import discovery as D
        assets = [D.Asset("erp-app-01", "FD00:10::1", L8, 4, 16, {"app": "erp"}),
                  D.Asset("erp-db-01", "fd00:10:0::9", L8, 4, 16, {"app": "erpdb"})]
        r = D.discover(assets, [("fd00:10::1", "FD00:0010::9", 1521, 50)])
        self.assertEqual([d.key for d in r.deps], ["erp->erpdb"])

    def test_unknown_ula_address_is_private_and_must_be_resolved(self):
        from ocio import discovery as D
        assets = [D.Asset("erp-app-01", "fd00:10::1", L8, 4, 16, {"app": "erp"})]
        r = D.discover(assets, [("fd00:10::1", "fd00:10::77", 1521, 50)])
        self.assertEqual([u["dst_ip"] for u in r.unresolved], ["fd00:10::77"])
        self.assertEqual(r.external, [])

    def test_ipv4_mapped_ipv6_matches_the_ipv4_asset(self):
        from ocio import discovery as D
        assets = [D.Asset("a-app-01", "10.0.0.1", L8, 4, 16, {"app": "a"}), D.Asset("b-db-01", "10.0.0.2", L8, 4, 16, {"app": "b"})]
        r = D.discover(assets, [("::ffff:10.0.0.1", "::ffff:10.0.0.2", 5432, 9)])
        self.assertEqual([d.key for d in r.deps], ["a->b"])


class Iteration86InputMistakesGetAMessageNotATraceback(unittest.TestCase):
    def _run(self, args, cwd):
        import subprocess
        p = subprocess.run([sys.executable, "-m", "ocio", *args], cwd=cwd, capture_output=True, text=True,
                           env=dict(os.environ, PYTHONPATH=HERE))
        return p.returncode, p.stdout + p.stderr

    def test_common_mistakes(self):
        d = tempfile.mkdtemp()
        _write(f"{d}/inv.csv", "name,app,tier,os,vcpus,memory_gb,depends_on_apps\nv1,a,App,x,4,16,\n")
        _write(f"{d}/good.csv", "name,app,tier,os,vcpus,memory_gb,depends_on_apps\nv1,a,app,Oracle Linux 8,4,16,\n")
        _write(f"{d}/bad.json", "{not json")
        _write(f"{d}/list.json", "[1, 2]")
        _write(f"{d}/cfg", "[DEFAULT]\nregion=us-phoenix-1\n")
        cases = {
            "missing inventory": ["plan", "--inventory", "nope.csv", "--env", "dev"],
            "bad tier": ["plan", "--inventory", "inv.csv", "--env", "dev"],
            "malformed overrides": ["plan", "--inventory", "good.csv", "--env", "dev", "--overrides", "bad.json"],
            "overrides as a list": ["plan", "--inventory", "good.csv", "--env", "dev", "--overrides", "list.json"],
            "nsg map as a list": ["plan", "--inventory", "good.csv", "--env", "dev", "--nsg-map", "list.json"],
            "missing config": ["run", "--inventory", "good.csv", "--env", "dev", "--compartment", COMP,
                               "--availability-domain", "AD-1", "--tag", "cost_center=a", "--tag", "owner=b",
                               "--apply", "--plan-id", "000000000000", "--config", "nope-cfg"],
            "unknown profile": ["netpolicy", "--inventory", "good.csv", "--assets", "good.csv", "--flows", "good.csv",
                                "--compartment", COMP, "--tag", "cost_center=a", "--tag", "owner=b", "--apply",
                                "--policy-id", "x", "--vcn", "ocid1.vcn.oc1.phx.v", "--config", "cfg", "--profile", "PROD"],
        }
        for name, args in cases.items():
            with self.subTest(name):
                rc, out = self._run(args, d)
                self.assertNotIn("Traceback", out, out)
                self.assertEqual(rc, 2, out)
                self.assertTrue(out.strip(), name)

    def test_release_verify_without_or_with_a_damaged_manifest(self):
        import release as R
        d = tempfile.mkdtemp()
        self.assertEqual(R.main(["verify", d]), 2)
        _write(f"{d}/SHA256SUMS", "not a manifest line\n")
        self.assertEqual(R.main(["verify", d]), 2)

    def test_console_page_error_is_a_500_with_the_reason(self):
        from ocio.ui import launch as LA
        d = tempfile.mkdtemp()
        _write(f"{d}/inv.csv", "name,app,tier,os,vcpus,memory_gb,depends_on_apps\nv1,a,App,x,4,16,\n")
        st = LA.wrapper_state(d, f"{d}/inv.csv")
        with self.assertRaisesRegex(ValueError, "tier"):
            LA.wrapper_page(st, served=True)          # the handler turns this into a 500 page with the reason


class Iteration87RefusalsBeforeAnyChangeExit2(unittest.TestCase):
    def test_refusals_exit_2_with_their_message(self):
        import subprocess
        d = tempfile.mkdtemp()
        _write(f"{d}/inv.csv", "name,app,tier,os,vcpus,memory_gb,depends_on_apps\nv1,a,app,Oracle Linux 8,4,16,\n")
        for args in (["run", "--inventory", "inv.csv", "--env", "dev", "--compartment", COMP, "--availability-domain",
                      "AD-1", "--apply"],                                                     # no --plan-id
                     ["plan", "--inventory", "inv.csv", "--env", "dev", "--tag", "cost_center=a", "--tag", "owner=b",
                      "--compartment", "ocid1.vcn.oc1.phx.x"]):                             # a VCN, not a compartment
            p = subprocess.run([sys.executable, "-m", "ocio", *args], cwd=d, capture_output=True, text=True,
                               env=dict(os.environ, PYTHONPATH=HERE))
            with self.subTest(args[0]):
                self.assertEqual(p.returncode, 2, p.stderr)
                self.assertTrue(p.stderr.strip())
                self.assertNotIn("Traceback", p.stderr)
                self.assertNotIn('"plan_id"', p.stdout)                       # refused before planning

    def test_live_smoke_refusal_exits_2(self):
        import subprocess
        p = subprocess.run([sys.executable, os.path.join(HERE, "scripts", "live_smoke.py"), "--compartment",
                            "ocid1.vcn.oc1..aaaa", "--availability-domain", "AD-1"], capture_output=True, text=True)
        self.assertEqual(p.returncode, 2, p.stderr)
        self.assertIn("compartment", p.stderr)


class Iteration89DataCannotBreakOutOfItsScriptBlock(unittest.TestCase):
    def test_html_comment_and_script_tags_in_names_are_escaped(self):
        import re
        from ocio.ui import launch as LA
        d = tempfile.mkdtemp()
        _write(f"{d}/inv.csv", "name,app,tier,os,vcpus,memory_gb,depends_on_apps\n"
                               "x<!--<script>,a</script>,app,Oracle Linux 8,4,16,\n")
        page = LA.wrapper_page(LA.wrapper_state(d, f"{d}/inv.csv"), served=True)
        meta = re.search(r'<script id="embeddedMetadata" type="application/json">(.*?)</script>', page, re.S).group(1)
        self.assertNotIn("<", meta)
        self.assertIn("\\u003c!--\\u003cscript\\u003e", meta)


class Iteration90JournalLockOnWindows(unittest.TestCase):
    def test_msvcrt_branch_excludes_a_second_writer_and_releases(self):
        import types
        import ocio.journal as JM
        held = set()

        def locking(fd, mode, n):                       # like msvcrt.locking: OSError when the region is locked
            ino = os.fstat(fd).st_ino
            if mode == fake.LK_NBLCK:
                if ino in held:
                    raise OSError(36, "Resource deadlock avoided")
                held.add(ino)
            elif mode == fake.LK_UNLCK:
                held.discard(ino)
        fake = types.SimpleNamespace(LK_NBLCK=2, LK_UNLCK=0, locking=locking)
        jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        with mock.patch.dict(sys.modules, {"fcntl": None, "msvcrt": fake}):
            with JM.exclusive(jp):
                with self.assertRaisesRegex(JM.JournalBusy, str(os.getpid())):
                    with JM.exclusive(jp):
                        pass
            with JM.exclusive(jp):                      # released
                pass
        self.assertEqual(held, set())


class Iteration91OcmWaveWithoutTheSdkSaysWhatToInstall(unittest.TestCase):
    def test_clear_refusal_when_oci_is_missing(self):
        import ocio.cli as CLI
        with mock.patch.dict(sys.modules, {"oci": None}):
            with self.assertRaisesRegex(SystemExit, "pip install"):
                CLI.cmd_ocm_wave(CLI.parser().parse_args(
                    ["ocm-wave", "--inventory", "x", "--wave", "1", "--migration-plan", "ocid1.ocmmigrationplan.oc1.phx.p",
                     "--subnet-map", "s", "--compartment", COMP, "--availability-domain", "AD-1"]), print)

    def test_launchers_do_not_promise_every_dry_run(self):
        for f in ("launch.sh", "Launch.bat"):
            self.assertNotIn("plans and dry runs work", open(os.path.join(HERE, f)).read())


class Iteration92ReviewedIdsBelongToTheCommandThatPrintedThem(unittest.TestCase):
    def test_plan_id_from_plan_is_not_offered_to_run(self):
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.skipTest("playwright not installed")
        import subprocess, re, time
        d = tempfile.mkdtemp()
        os.makedirs(f"{d}/examples")
        _write(f"{d}/examples/inventory.csv", open(os.path.join(HERE, "examples", "inventory.csv")).read())
        port = 8790 + os.getpid() % 100
        srv = subprocess.Popen([sys.executable, "-m", "ocio", "ui", "--workdir", d, "--port", str(port), "--no-browser"],
                               cwd=HERE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                               env=dict(os.environ, PYTHONPATH=HERE))
        try:
            opener = None
            for _ in range(50):
                line = srv.stdout.readline()
                m = re.search(r"(/\S*open-console\.html)", line)
                if m:
                    opener = m.group(1)
                    break
            self.assertTrue(opener)
            with sync_playwright() as p:
                b = p.chromium.launch()
                pg = b.new_page()
                pg.goto("file://" + opener)
                pg.wait_for_url(re.compile(rf"http://127\.0\.0\.1:{port}/.*"))
                pg.goto(f"http://127.0.0.1:{port}/#launch")
                pg.wait_for_timeout(400)
                pg.fill("#f-cost_center", "cc"); pg.fill("#f-owner", "me")
                pg.click("#runBtn"); pg.wait_for_selector("#result .result-panel b", timeout=60000)   # plan
                pg.click("input[name=command][value=run]"); pg.click("input[name=r-mode][value=apply]")
                self.assertEqual(pg.input_value("#f-plan_id"), "")          # plan's id is not run's id
                b.close()
        finally:
            srv.terminate()
            srv.wait(10)


class Iteration93MalformedRequestsGetA400(unittest.TestCase):
    def test_bad_bodies_and_values(self):
        from ocio.ui import launch as LA, wrapper as WR
        d = tempfile.mkdtemp()
        c = LA.Console(d, token="t", runner=lambda argv: (0, ""))
        for body in ("x", [1], {"command": "plan", "radios": "x"}, {"command": "plan", "fields": [1]}):
            with self.subTest(body=body):
                self.assertEqual(c.handle("preview", body)[0], 400)
        argv, probs = LA.build_argv({"command": "ocm-wave", "fields": {"wave": "²"}}, d)
        self.assertTrue(any("whole number" in p for p in probs), probs)
        st = LA.wrapper_state(HERE)
        for body in ("x", {"plan": "abc"}, {"plan": [1]}, {"plan": {"plan_id": 5}, "approvals": "x"}):
            with self.subTest(wrapper=body):
                self.assertEqual(WR.handle_api("simulate", body, st)[0], 400)
                self.assertEqual(WR.handle_api("validate", body, st)[0], 400)

    def test_content_length_is_parsed_strictly(self):
        from ocio.ui.launch import content_length
        self.assertEqual(content_length("12"), 12)
        self.assertEqual(content_length(None), 0)
        for bad in ("-1", "1e3", "²", "abc", "12 3"):
            with self.subTest(bad):
                self.assertIsNone(content_length(bad))

    def test_approvals_with_non_objects_do_not_crash(self):
        from ocio.ui import launch as LA, wrapper as WR
        st = LA.wrapper_state(HERE)
        plan = WR.handle_api("plan", {}, st)[1]
        self.assertEqual(WR.handle_api("simulate", {"plan": plan, "approvals": ["x", 1, None]}, st)[0], 200)


class Iteration94EvidencePageReadsTheControlRun(unittest.TestCase):
    def test_control_failure_is_not_shown_as_passed(self):
        from ocio.ui import wrapper as WR
        root = tempfile.mkdtemp()
        os.makedirs(f"{root}/examples")
        _write(f"{root}/examples/mutate_results.txt", "control (unmodified code): exit 1\nKILLED    a\nSURVIVED  b\nKILLED    c\n")
        _, _, m = WR.results(root)
        self.assertEqual((m["mutants"], m["detected"], m["control_passed"]), (3, 2, False))
        _write(f"{root}/examples/mutate_results.txt", "control (unmodified code): exit 0\nKILLED    a\nTIMEOUT   b\n")
        _, _, m = WR.results(root)
        self.assertEqual((m["mutants"], m["detected"], m["control_passed"]), (2, 2, True))


class Iteration95NetpolicyApplyNeverCreatesAnNsgTwice(unittest.TestCase):
    """A failed rule add after the NSGs were created must not lose their ids: the map is written as each NSG is
    created, and before creating, the VCN is listed for an NSG ocio already made under that name."""

    def _base(self, d):
        inv = Iteration30CutoverGate()._estate(d)
        return ["netpolicy", "--inventory", inv, "--assets", f"{d}/assets.csv", "--flows", f"{d}/flows.csv",
                "--compartment", COMP, "--tag", "cost_center=a", "--tag", "owner=b", "--journal", f"{d}/n.jsonl",
                "--nsg-map-out", f"{d}/nsg.json"]

    def _net(self, listed):
        made = []

        def create(d_, opc_retry_token=None):                 # a new NSG every call: the retry token has expired
            g = NS(id=f"ocid1.networksecuritygroup.oc1.phx.{d_.display_name}-{len(made)}", display_name=d_.display_name,
                   freeform_tags=d_.freeform_tags, lifecycle_state="AVAILABLE")
            made.append(g)
            listed.append(g)
            return NS(data=g)
        net = mock.Mock()
        net.create_network_security_group.side_effect = create
        net.list_network_security_groups.side_effect = lambda **kw: NS(data=list(listed), next_page=None)
        net.list_network_security_group_security_rules.return_value = NS(data=[])
        return net, made

    def test_a_failed_rule_add_then_a_rerun_creates_each_nsg_once(self):
        import migrate as M
        import oci
        d, out = tempfile.mkdtemp(), []
        base = self._base(d)
        M.main(base, out=out.append)
        apply = base + ["--apply", "--policy-id", json.loads(out[-1])["policy_id"], "--vcn", "ocid1.vcn.oc1.phx.v"]
        net, made = self._net([])
        net.add_network_security_group_security_rules.side_effect = oci.exceptions.ServiceError(500, "InternalError", {}, "x")
        with self.assertRaises(oci.exceptions.ServiceError):
            M.main(apply, out=out.append, net_client=net)
        self.assertEqual(sorted(json.load(open(f"{d}/nsg.json"))), ["shop-app", "shop-db"])   # written as created
        os.remove(f"{d}/nsg.json")                            # even without the map, the VCN listing finds them
        net.add_network_security_group_security_rules.side_effect = None
        self.assertEqual(M.main(apply, out=out.append, net_client=net), 0)
        self.assertEqual(len(made), 2)
        self.assertEqual(json.load(open(f"{d}/nsg.json")), {g.display_name: g.id for g in made})

    def test_a_same_named_nsg_ocio_did_not_make_is_refused_not_adopted(self):
        from ocio import netpolicy as N
        import oci
        pl = [F.place(W("a1", "shop"), BLUEPRINTS, {}), F.place(W("d1", "shop", "db"), BLUEPRINTS, {})]
        plan = N.build(pl, [("a1", "d1", 1521, 5)])
        theirs = NS(id="ocid1.networksecuritygroup.oc1.phx.theirs", display_name="shop-db", freeform_tags={},
                    lifecycle_state="AVAILABLE")
        net, made = self._net([theirs])
        with self.assertRaisesRegex(ValueError, "shop-db"):
            N.apply(net, oci.core.models, plan, COMP, "ocid1.vcn.oc1.phx.v")
        self.assertEqual(made, [])
        gone = NS(id="ocid1.networksecuritygroup.oc1.phx.old", display_name="shop-db",
                  freeform_tags={"ocio_nsg": "shop-db"}, lifecycle_state="TERMINATED")
        net, made = self._net([gone])
        ids = N.apply(net, oci.core.models, plan, COMP, "ocid1.vcn.oc1.phx.v")
        self.assertNotEqual(ids["shop-db"], gone.id)          # a terminated NSG is not reused


class Iteration96JournalSurvivesAMissingFinalNewline(unittest.TestCase):
    def test_append_after_a_file_without_final_newline_keeps_entries_separate(self):
        from ocio.journal import _SHARED
        p = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        j = Journal(p); j.append(event="a"); j.append(event="b")
        data = open(p).read()
        open(p, "w").write(data.rstrip("\n"))               # e.g. copied by a tool that drops the final EOL
        Journal(p).append(event="c")
        _SHARED.clear()                                     # what a new process sees
        j2 = Journal(p)
        self.assertEqual([e["event"] for e in j2.entries], ["a", "b", "c"])
        self.assertTrue(j2.verify())
        self.assertEqual(j2._s.line_of, [1, 2, 3])


class Iteration97DamagedJournalEntriesAreRefusedByLine(unittest.TestCase):
    def test_a_json_line_that_is_not_an_entry_is_a_journal_error(self):
        from ocio.journal import JournalError
        p = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        Journal(p).append(event="a")
        good = open(p).read()
        for junk in ("null", "[1, 2]", '"text"', "7"):
            with open(p, "w") as f:
                f.write(good + junk + "\n")
            with self.assertRaisesRegex(JournalError, "line 2 .*not a journal entry"):
                Journal(p)

    def test_appending_after_an_entry_with_no_hash_is_a_journal_error_not_a_crash(self):
        from ocio.journal import JournalError
        p = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        j = Journal(p); j.append(event="a"); j.append(event="b")
        lines = open(p).read().splitlines()
        last = json.loads(lines[-1]); del last["hash"]
        open(p, "w").write(lines[0] + "\n" + json.dumps(last) + "\n")
        j = Journal(p)
        self.assertEqual(j.verify_detail()["line"], 2)
        with self.assertRaisesRegex(JournalError, "line 2 has no hash"):
            j.append(event="x")
        self.assertEqual(len(open(p).read().splitlines()), 2)      # nothing written

    def test_an_entry_whose_outputs_is_not_an_object_does_not_crash_the_indexes(self):
        p = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        Journal(p).append(run_id="r", step="s", event="ready", outputs=None)
        from ocio.journal import _SHARED
        _SHARED.clear()
        self.assertEqual(Journal(p).existing()["s"]["id"], None)


class Iteration98JournalHandlesShareStateAndSeeEdits(unittest.TestCase):
    def test_two_handles_opened_before_the_file_exists_share_state(self):
        p = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        h1, h2 = Journal(p), Journal(p)
        h1.append(run_id="r", step="vm1", event="creating", params_hash="x")
        h1.append(run_id="r", step="vm1", event="ready", outputs={"id": "ocid1.instance..1"})
        self.assertEqual(list(h2.existing()), ["vm1"])
        self.assertEqual(h2.state("r")["vm1"]["status"], "ready")

    def test_an_edit_after_a_handle_was_opened_is_seen_by_its_reads(self):
        p = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        j = Journal(p); j.append(event="approval", approved=False, by="")
        e = json.loads(open(p).read()); e["approved"] = True; e["by"] = "mallory"
        open(p, "w").write(json.dumps(e, sort_keys=True) + "\n")
        self.assertFalse(j.verify())
        self.assertTrue(j.entries[0]["approved"])               # it reads what is on disk now


class Iteration99ChangedTagsNeverFinishAnInterruptedRun(unittest.TestCase):
    """Tags are stamped on every resource a run creates, so a resume with different tags would leave one network
    with two cost centres. The workflow hash covers tags; the resume is refused as changed settings."""

    def test_interrupted_network_resumed_with_other_tags_is_blocked(self):
        from ocio.providers import Crash
        fake, jp = FakeOCI(crash_after_create={"t-vcn"}), os.path.join(tempfile.mkdtemp(), "j.jsonl")
        eng = lambda: Engine(fake, Journal(jp), sleep=lambda s: None)
        with self.assertRaises(Crash):
            P.run([W("a1", "a")], BLUEPRINTS, settings(), eng, quota=QUOTA)
        other = P.Settings("dev", COMP, dict(TAGS, cost_center="cc-9"), "t", "10.0.0.0/16",
                           {"web": "10.0.1.0/24", "app": "10.0.2.0/24", "db": "10.0.3.0/24"})
        r = P.run([W("a1", "a")], BLUEPRINTS, other, eng, quota=QUOTA)
        self.assertEqual(r.target_network, "BLOCKED_CHANGED")
        self.assertEqual({x["tags"].get("cost_center") for x in fake.live().values()}, {"cc"})
        r = P.run([W("a1", "a")], BLUEPRINTS, settings(), eng, quota=QUOTA)      # original tags: resumes
        self.assertEqual(r.target_network, "SUCCEEDED")
        self.assertEqual({x["tags"].get("cost_center") for x in fake.live().values()}, {"cc"})

    def test_workflow_hash_changes_with_tags(self):
        from ocio.engine import workflow_hash
        from ocio.spec import Workflow
        a = Workflow("w", "dev", COMP, (), {"cost_center": "a"})
        b = Workflow("w", "dev", COMP, (), {"cost_center": "b"})
        self.assertNotEqual(workflow_hash(a), workflow_hash(b))

    def test_the_wave_label_ocio_sets_does_not_bind_the_run(self):
        from ocio.engine import workflow_hash
        from ocio.spec import Workflow
        a = Workflow("w", "dev", COMP, (), {"cost_center": "a", "migration_wave": "2"})
        b = Workflow("w", "dev", COMP, (), {"cost_center": "a", "migration_wave": "1"})
        self.assertEqual(workflow_hash(a), workflow_hash(b))


class Iteration100AdmissionBeforeTheNetworkIsJournalledAndCurrent(unittest.TestCase):
    def _eng(self, fake, jp):
        return lambda: Engine(fake, Journal(jp), sleep=lambda s: None)

    def test_a_refusal_before_the_network_is_journalled(self):
        fake, jp = FakeOCI(), os.path.join(tempfile.mkdtemp(), "j.jsonl")
        rep = P.run([W("a1", "a")], BLUEPRINTS, settings(), self._eng(fake, jp), quota=QUOTA,
                    admit=lambda w, pid: {"allowed": False, "reasons": ["capacity check stale"], "evidence_hash": "e1"})
        self.assertTrue(rep.run_blocked)
        adm = [e for e in Journal(jp).entries if e.get("event") == "admission"]
        self.assertEqual([(e["wave"], e["allowed"], e["reasons"], e["evidence_hash"], e["phase"]) for e in adm],
                         [(1, False, ["capacity check stale"], "e1", "before_network")])
        self.assertEqual(fake.live(), {})

    def test_a_rerun_asks_about_the_first_wave_still_to_create_not_a_landed_one(self):
        fake, jp = FakeOCI(), os.path.join(tempfile.mkdtemp(), "j.jsonl")
        wls, s = [W("a1", "a"), W("b1", "b")], settings(max_apps_per_wave=1)
        r1 = P.run(wls, BLUEPRINTS, s, self._eng(fake, jp), quota=QUOTA, admit=lambda w, pid: {"allowed": w == 1})
        self.assertEqual([(w["wave"], w["status"]) for w in r1.wave_results], [(1, "SUCCEEDED"), (2, "BLOCKED_ADMISSION")])
        asked = []

        def admit(w, pid):
            asked.append(w)
            return {"allowed": w == 2, "reasons": [] if w == 2 else ["wave 1 evidence expired"]}
        r2 = P.run(wls, BLUEPRINTS, s, self._eng(fake, jp), quota=QUOTA, admit=admit)
        self.assertEqual(r2.run_blocked, [])
        self.assertNotIn(1, asked)
        self.assertEqual([(w["wave"], w["status"]) for w in r2.wave_results], [(1, "SUCCEEDED"), (2, "SUCCEEDED")])


class Iteration101NoEtagReapplyIsNotAnsweredFromTheTokenCache(unittest.TestCase):
    def test_apply_restore_apply_without_etags_excludes_again(self):
        from ocio import ocm as O

        class C(FakeOCM2):
            def get_target_asset(self, target_asset_id):
                r = super().get_target_asset(target_asset_id)
                r.headers = {}                                  # a service that sends no etag on GET
                return r
        c = C({"ta-crm": ("crm-app-01", True, "ACTIVE"), "ta-x": ("x-01", False, "ACTIVE")})
        snaps = []
        _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1", on_before=snaps.append)
        _ocm_driver(c).restore(snaps[0])
        self.assertFalse(c.assets["ta-x"].is_excluded_from_execution)
        _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1")
        self.assertTrue(c.assets["ta-x"].is_excluded_from_execution)     # not answered from the token cache

    def test_with_an_etag_the_token_is_still_derived_from_it(self):
        from ocio import ocm as O
        self.assertEqual(O.retry_token("p", "a", {"x": 1}, "e1"), O.retry_token("p", "a", {"x": 1}, "e1"))
        self.assertNotEqual(O.retry_token("p", "a", {"x": 1}, "e1"), O.retry_token("p", "a", {"x": 1}, "e2"))


class Iteration102BeforeStateReadsTheAssetsItWillExclude(unittest.TestCase):
    def test_an_excluded_assets_spec_is_journalled_and_restored(self):
        import oci
        m = oci.cloud_migrations.models
        c = FakeOCM2({"ta-crm": ("crm-app-01", True, "ACTIVE"), "ta-x": ("x-01", False, "ACTIVE")})
        c.assets["ta-x"].user_spec = m.LaunchInstanceDetails(shape="VM.Standard.E4.Flex", display_name="x-01")
        snaps = []
        _ocm_driver(c).apply_wave([_ocm_place()], SUBNETS, COMP, "AD-1", on_before=snaps.append)
        self.assertEqual(snaps[0]["ta-x"]["user_spec"]["shape"], "VM.Standard.E4.Flex")
        res = _ocm_driver(c).restore(snaps[0])
        self.assertNotIn("ta-x", res["user_spec_was_empty_kept_current"])
        self.assertEqual(c.assets["ta-x"].user_spec.shape, "VM.Standard.E4.Flex")


def _rsa_pem(passphrase=None):
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.primitives import serialization as S
    k = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    enc = S.BestAvailableEncryption(passphrase) if passphrase else S.NoEncryption()
    return k.private_bytes(S.Encoding.PEM, S.PrivateFormat.TraditionalOpenSSL, enc)


class Iteration103LimitsClientGetsTheSdkTimeout(unittest.TestCase):
    def test_the_quota_client_uses_the_timeout_every_other_client_gets(self):
        cfg = {"region": "us-phoenix-1", "tenancy": "ocid1.tenancy.oc1..t", "user": "ocid1.user.oc1..u",
               "fingerprint": "aa:bb:cc:dd:ee:ff:00:11:22:33:44:55:66:77:88:99", "key_content": _rsa_pem().decode()}
        q = C.OCILimitsQuota(COMP, config=cfg, timeout=(3, 7))
        self.assertEqual(q.client.base_client.timeout, (3, 7))

    def test_the_cli_passes_sdk_timeout_to_the_quota_source(self):
        import inspect
        import re
        from ocio import cli
        src = inspect.getsource(cli)
        calls = re.findall(r"C\.OCILimitsQuota\(([^)]*)\)", src)
        self.assertTrue(calls)
        self.assertTrue(all("timeout=a.sdk_timeout" in c for c in calls), calls)


class Iteration104SecurityTokenAuthUsesThePassPhrase(unittest.TestCase):
    def test_an_encrypted_key_file_loads_with_the_profiles_pass_phrase(self):
        from ocio import auth
        d = tempfile.mkdtemp()
        with open(f"{d}/key.pem", "wb") as f:
            f.write(_rsa_pem(b"secret"))
        _write(f"{d}/token", "header.payload.sig")
        _write(f"{d}/config", f"[DEFAULT]\nfingerprint=aa:bb:cc:dd:ee:ff:00:11:22:33:44:55:66:77:88:99\n"
                              f"key_file={d}/key.pem\npass_phrase=secret\ntenancy=ocid1.tenancy.oc1..t\n"
                              f"region=us-phoenix-1\nsecurity_token_file={d}/token\n")
        cfg, signer = auth.make("security_token", config_file=f"{d}/config")
        self.assertEqual(type(signer).__name__, "SecurityTokenSigner")


class Iteration105SpecInputsAreCheckedNotCoerced(unittest.TestCase):
    def _doc(self, sub_id="web", params=None, deps=()):
        return {"name": "n", "environment": "dev", "compartment_id": "c", "steps": [
            {"id": "Vcn", "kind": "vcn", "params": {"cidr_block": "10.0.0.0/16"}},
            {"id": sub_id, "kind": "subnet", "params": {} if params is None else params, "depends_on": deps}]}

    def test_a_reference_to_an_uppercase_step_is_a_reference(self):
        from ocio.spec import load, resolve, SpecError
        with self.assertRaisesRegex(SpecError, "references Vcn without depending on it"):
            load(self._doc(params={"vcn_id": "${Vcn.id}"}))
        wf = load(self._doc(params={"vcn_id": "${Vcn.id}"}, deps=["Vcn"]))
        self.assertEqual(resolve(wf.step("web").params, {"Vcn": {"id": "ocid1.vcn..X"}}), {"vcn_id": "ocid1.vcn..X"})

    def test_anything_that_looks_like_a_reference_but_is_not_one_is_refused(self):
        from ocio.spec import load, SpecError
        for bad in ("${vcn.display-name}", "${vcn}", "${.id}", "${vcn.id", "pre-${Vcn.id}"):
            with self.assertRaises(SpecError, msg=bad):
                load(self._doc(params={"x": bad}, deps=["Vcn"]))

    def test_depends_on_and_params_must_have_the_right_shape(self):
        from ocio.spec import load, SpecError
        with self.assertRaisesRegex(SpecError, "depends_on must be a list"):
            load(self._doc(deps="Vcn"))
        for bad in ("oops", ["a"], 3):
            with self.assertRaisesRegex(SpecError, "params must be an object"):
                load(self._doc(params=bad))
        with self.assertRaisesRegex(SpecError, "step ids"):
            load(dict(self._doc(), steps=[{"id": 7, "kind": "vcn", "params": {}}]))
        with self.assertRaisesRegex(SpecError, "tags must be an object"):
            load(dict(self._doc(), tags=["x"]))


class Iteration106MemoryHeavyVmsGetEnoughOcpusForTheirMemory(unittest.TestCase):
    def test_a_4_vcpu_192_gb_database_is_sized_at_3_ocpus_and_placed(self):
        db = F.Workload("ora-db-01", "ledger", "db", L8, 4, 192)
        self.assertEqual(F.size(db, "VM.Standard.E5.Flex"), {"ocpus": 3, "memory_gbs": 192})   # 64 GB per OCPU
        p = F.place(db, BLUEPRINTS, {})
        self.assertEqual((p.params["ocpus"], p.params["memory_gbs"]), (3, 192))
        self.assertEqual(F.shape_problems(p.params["shape"], 3, 192), [])
        rep = P.run([db, F.Workload("api-app-01", "api", "app", L8, 2, 8, ("ledger",))], BLUEPRINTS, settings(), None,
                    execute=False)
        self.assertEqual(rep.blocked_apps, {})

    def test_cpu_bound_sizing_is_unchanged(self):
        self.assertEqual(F.size(W("a", "a", vcpus=16, mem=32), "VM.Standard.E5.Flex"), {"ocpus": 8, "memory_gbs": 32})
        self.assertEqual(F.size(W("a", "a", vcpus=4, mem=64), "VM.Standard.A1.Flex"), {"ocpus": 4, "memory_gbs": 64})


class Iteration107RuleProposerKeepsItsProposalsValid(unittest.TestCase):
    def test_memory_headroom_raises_ocpus_to_keep_the_ratio(self):
        from ocio import agent as A
        w = F.Workload("crm-app-01", "crm", "app", L8, 2, 48)
        rp = A.RuleProposer(BLUEPRINTS, {"crm-app-01": {"mem_peak_pct": 90}})
        prop = rp.propose(w)
        self.assertEqual(prop["overrides"], {"memory_gbs": 72, "ocpus": 2})
        rep = P.run([w], BLUEPRINTS, settings(), None, proposer=rp, execute=False)
        self.assertEqual(rep.rejected_proposals, [])
        self.assertEqual({(p.params["ocpus"], p.params["memory_gbs"]) for p in rep.placements}, {(2, 72)})


class Iteration108TierTagsAreReadWhateverTheirCase(unittest.TestCase):
    def test_db_and_Db_tags_are_db_tags(self):
        from ocio.discovery import Asset, discover
        a = [Asset("pay-01", "10.0.0.1", L8, 4, 32, {"app": "pay", "tier": "DB"}),
             Asset("pay-02", "10.0.0.2", L8, 2, 8, {"app": "pay", "tier": "web"}),
             Asset("pay-03", "10.0.0.3", L8, 2, 8, {"app": "pay", "tier": " Db "})]
        r = discover(a, [("10.0.0.2", "10.0.0.1", 443, 50)])
        self.assertEqual([(r.tier[n].value, r.tier[n].source) for n in ("pay-01", "pay-02", "pay-03")],
                         [("db", "tag"), ("web", "tag"), ("db", "tag")])

    def test_a_tier_tag_that_is_not_a_tier_is_flagged_not_silently_ignored(self):
        from ocio.discovery import Asset, discover
        r = discover([Asset("x-01", "10.0.0.1", L8, 2, 8, {"tier": "database"})], [("10.0.0.9", "10.0.0.1", 1521, 5)])
        self.assertEqual(r.tier["x-01"].value, "db")
        self.assertLess(r.tier["x-01"].confidence, 0.6)                  # lands in low_confidence_vms
        self.assertIn("'database'", r.tier["x-01"].evidence)


class Iteration109ListenerNamesMatchAssetsAndUnknownOnesAreRefused(unittest.TestCase):
    def test_upper_case_listener_names_reach_their_vm(self):
        from ocio.discovery import Asset, discover
        r = discover([Asset("hr-db-01", "10.0.0.1", L8, 4, 32)], [], listeners={"HR-DB-01": {1521}})
        self.assertEqual((r.tier["hr-db-01"].value, r.tier["hr-db-01"].source), ("db", "ports"))

    def test_a_listener_for_a_vm_not_in_the_assets_is_refused(self):
        from ocio.discovery import Asset, discover
        with self.assertRaisesRegex(ValueError, "hr-db-02"):
            discover([Asset("hr-db-01", "10.0.0.1", L8, 4, 32)], [], listeners={"hr-db-02": {1521}})


class Iteration110TrafficToItselfIsNotEvidence(unittest.TestCase):
    def test_a_vm_whose_only_traffic_is_to_itself_is_silent(self):
        from ocio.discovery import Asset, discover
        assets = [Asset("orders-app-01", "10.0.1.1", L8, 2, 8), Asset("orders-app-02", "10.0.1.2", L8, 2, 8)]
        r = discover(assets, [("10.0.1.1", "10.0.1.1", 8080, 900), ("10.0.1.2", "10.0.1.2", 8080, 900)])
        r0 = discover(assets, [])
        self.assertEqual(r.silent_vms, ["orders-app-01", "orders-app-02"])
        self.assertEqual({n: (f.value, f.confidence) for n, f in r.app.items()},
                         {n: (f.value, f.confidence) for n, f in r0.app.items()})
        self.assertEqual(r.excluded_infra, {"self (a VM to its own address)": 1800})


class Iteration111BlankRequiredTagsAreMissingTags(unittest.TestCase):
    def test_whitespace_only_cost_center_and_owner_are_refused(self):
        from ocio import policy
        wf = F.target_network("mig", "prod", COMP, {"cost_center": " ", "owner": "\t"}, "10.20.0.0/16",
                              {"web": "10.20.1.0/24"})
        self.assertEqual(policy.required_tags()(wf), ["workflow missing required tag(s): ['cost_center', 'owner']"])


class Iteration112CidrBlocksMustBeIpv4(unittest.TestCase):
    def test_an_ipv6_subnet_prefix_is_a_policy_violation_not_a_crash(self):
        s = P.Settings("prod", COMP, TAGS, "mig", "10.20.0.0/16",
                       {"web": "fd00:20:1::/64", "app": "10.20.2.0/24", "db": "10.20.3.0/24"})
        rep = P.run([W("crm-app-01", "crm")], BLUEPRINTS, s, None, execute=False)
        self.assertTrue(any("IPv4" in v for v in map(str, rep.policy_violations)), rep.policy_violations)

    def test_an_ipv6_vcn_prefix_is_a_violation_too(self):
        from ocio import policy
        wf = F.target_network("mig", "dev", COMP, TAGS, "fd00:20::/48", {"web": "fd00:20:1::/64"})
        self.assertTrue(any("IPv4" in v for v in policy.cidr_sanity(wf)))


class Iteration113AdmissionTypesAndRecordedFailures(unittest.TestCase):
    POL = {"required_checks": ["capacity", "app_health"], "max_age_seconds": 900}

    def _rows(self):
        return [{"name": "capacity", "passed": True, "observer": "ann", "source_ref": "CHG-1"},
                {"name": "app_health", "passed": True, "observer": "ann", "source_ref": "dash/1"}]

    def test_a_wave_of_true_or_1_point_0_is_not_wave_1(self):
        from ocio import admission as AD
        import time as _t
        now = _t.time()
        for w in (True, 1.0, "1"):
            doc = {"plan_id": "abc123", "wave": w, "observed_at": now, "checks": self._rows()}
            self.assertFalse(AD.evaluate("abc123", 1, [doc], self.POL, now)["allowed"], w)
        doc = {"plan_id": "abc123", "wave": 1, "observed_at": now, "checks": self._rows()}
        self.assertTrue(AD.evaluate("abc123", 1, [doc], self.POL, now)["allowed"])

    def test_evidence_that_records_a_failed_check_is_refused_even_if_not_required(self):
        from ocio import admission as AD
        import time as _t
        now = _t.time()
        doc = {"plan_id": "abc123", "wave": 1, "observed_at": now, "checks": self._rows() + [
            {"name": "rollback_rehearsed", "passed": False, "observer": "bob", "source_ref": "RB-7"}]}
        r = AD.evaluate("abc123", 1, [doc], self.POL, now)
        self.assertFalse(r["allowed"])
        self.assertTrue(any("rollback_rehearsed" in x for x in r["reasons"]), r["reasons"])

    def test_a_policy_check_name_with_surrounding_space_is_refused(self):
        from ocio import admission as AD
        with self.assertRaisesRegex(ValueError, "surrounding"):
            AD.check_policy({"required_checks": ["capacity "], "max_age_seconds": 900})


class Iteration114HeadroomIsKeptOfTheLimitNotOfWhatIsLeft(unittest.TestCase):
    def _wave(self, n, ocpus):
        from ocio.spec import Step, Workflow
        return Workflow(f"wave-{n}", "dev", COMP, tuple(
            Step(f"vm{n}-{k}", "instance", {"shape": "VM.Standard.E5.Flex", "ocpus": 1, "memory_gbs": 1})
            for k in range(ocpus)), {})

    def test_waves_never_eat_into_the_reserved_tenth_of_a_static_limit(self):
        q = C.StaticQuota({"standard-e5-core-count": 100, "standard-e5-memory-count": 10_000})
        results = []
        for n, size in enumerate([90, 9, 1], 1):
            wf = self._wave(n, size)
            short = C.preflight(wf, q, "AD-1", headroom=0.10)
            results.append(bool(short))
            if not short:
                q.record_use(C.wave_demand(wf))
        self.assertEqual(results, [False, True, True])          # 90 fits; 10 of 100 stay free

    def test_the_live_limit_total_is_used_plus_available(self):
        class Client:
            def get_resource_availability(self, service, limit, compartment, availability_domain=None):
                return NS(data=NS(used=50, available=50))
        q = C.OCILimitsQuota(COMP, client=Client())
        self.assertTrue(C.preflight(self._wave(1, 45), q, "AD-1", headroom=0.10))   # 45 > 50 - 10
        self.assertEqual(C.preflight(self._wave(1, 40), q, "AD-1", headroom=0.10), [])


class Iteration115ExternalOkNeedsAReviewer(unittest.TestCase):
    def _r(self):
        from ocio.discovery import Asset, discover
        a = [Asset("crm-app-01", "10.0.0.1", L8, 2, 8, {"app": "crm"}),
             Asset("erp-db-01", "10.0.0.2", L8, 2, 8, {"app": "erp"})]
        return discover(a, [("10.0.0.1", "10.0.0.50", 1521, 900)])     # erp's SCAN address, not in vips.csv

    def test_declaring_a_private_address_external_must_name_who_decided(self):
        with self.assertRaisesRegex(ValueError, "reviewed_by"):
            self._r().to_workloads({"external_ok": ["10.0.0.50"]})
        wls, summary = self._r().to_workloads({"external_ok": ["10.0.0.50"], "reviewed_by": "ann"})
        self.assertEqual(summary["reviewed_by"], "ann")
        self.assertEqual(summary["external_ok"], ["10.0.0.50"])

    def test_external_ok_must_be_a_list_of_addresses(self):
        with self.assertRaisesRegex(ValueError, "external_ok must be a list"):
            self._r().to_workloads({"external_ok": "10.0.0.50", "reviewed_by": "ann"})


class Iteration116AnOverrideBelowTheSourceSizeNeedsApproval(unittest.TestCase):
    def test_shrinking_a_vm_below_its_source_is_an_approval_reason(self):
        from ocio import agent as A
        w = F.Workload("ledger-app-01", "ledger", "app", L8, 16, 128)
        p = F.place(w, BLUEPRINTS, {"ocpus": 1, "memory_gbs": 8})
        reasons = A.approval_reasons("dev", [p])
        self.assertTrue(any("ocpus 8 -> 1" in x and "below the source" in x for x in reasons), reasons)
        self.assertTrue(any("memory_gbs 128 -> 8" in x for x in reasons), reasons)
        self.assertEqual(A.approval_reasons("dev", [F.place(w, BLUEPRINTS, {"ocpus": 8})]), [])


class Iteration117OsFamilyReadsAbbreviationsAndRefusesAmbiguity(unittest.TestCase):
    def test_families(self):
        cases = {"Win2016 Datacenter": "windows", "W2K19": "windows", "Windows Server 2022": "windows",
                 "win 2019 std": "windows", "Ubuntu 22.04 LTS": "linux", "CentOS 7": "linux", "Linux/UNIX": "linux",
                 "Red Hat BYOL Linux": "linux", "Oracle Solaris 11": "unknown", "Darwin 23": "unknown",
                 "Linux (Windows Subsystem image builder)": "unknown", "Rocky Linux 9": "linux",
                 "AlmaLinux 8": "linux", "Twin-engine appliance": "unknown"}
        self.assertEqual({k: F.os_family(k) for k in cases}, cases)


class Iteration118SimulatedOcidsDoNotDependOnThreadOrder(unittest.TestCase):
    """demo_v2 differed from its saved output in 1 of 300 runs under load (Monte Carlo seed 1080): the stand-in OCI
    numbered resources from one counter shared by parallel creates, so an OCID in a message depended on which
    thread got the lock first."""

    def test_the_same_requests_in_another_order_get_the_same_ids(self):
        reqs = [("instance", COMP, {"display_name": f"vm{i}", "subnet_id": None}, {}, f"tok-{i}") for i in range(6)]

        def ids(order):
            f = FakeOCI()
            vcn = f.create("vcn", COMP, {"display_name": "v"}, {}, "t-vcn")
            for _ in range(5):
                f.state("vcn", vcn)
            out = {}
            for k in order:
                kind, comp, params, tags, tok = reqs[k]
                out[tok] = f.create("subnet", comp, dict(params, vcn_id=vcn), tags, tok)
            return out
        self.assertEqual(ids(range(6)), ids(reversed(range(6))))
        self.assertEqual(len(set(ids(range(6)).values())), 6)


class Iteration119RepeatedPageTokensStopNsgListings(unittest.TestCase):
    """Found by the final mutation run: the repeated-token guard in the NSG rule listing (tune-up 82) had no test,
    and neither did the same guard in the VCN's NSG listing (tune-up 95). A service that repeats a page token
    would otherwise loop forever."""

    def test_rule_listing_refuses_a_repeated_page_token(self):
        from ocio import netpolicy as NP

        class Net:
            def list_network_security_group_security_rules(self, nsg_id, **kw):
                return NS(data=[], next_page="same", headers={})
        with self.assertRaisesRegex(ValueError, "repeated page token"):
            NP._all_rules(Net(), "nsg-a")

    def test_nsg_listing_refuses_a_repeated_page_token(self):
        from ocio import netpolicy as NP

        class Net:
            def list_network_security_groups(self, **kw):
                return NS(data=[], next_page="same", headers={})
        with self.assertRaisesRegex(ValueError, "repeated page token"):
            NP._nsgs_in_vcn(Net(), COMP, "ocid1.vcn.oc1.phx.v")
