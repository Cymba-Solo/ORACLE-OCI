"""Tests for v2: discovery, wave planning at scale, capacity, the agent guard, the pipeline, the SDK
adapter's live-tenancy behaviours (offline), and the command-line tools. Run: python -B -m unittest"""
import csv
import json
import os
import random
import sys
import tempfile
import threading
import time
import unittest
from collections import defaultdict
from unittest import mock

from ocio import agent as A, capacity as C, discovery as D, factory as F, ocm as O, pipeline as P, synth
from ocio.catalog import BLUEPRINTS, E5
from ocio.engine import Engine, RetryPolicy
from ocio.journal import Journal
from ocio.providers import Crash, FakeOCI, GONE, OCISDKProvider, ProviderError
from ocio.spec import Step, Workflow

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(HERE, "scripts"))
COMP = "ocid1.compartment.oc1..t"
TAGS = {"cost_center": "cc-1", "owner": "team"}
QUOTA = C.StaticQuota({n: 1e9 for pair in C.SHAPE_LIMITS.values() for n in pair})


def duplicates(fake):
    """Live resources sharing a display name: a real duplicate count (a new retry token always gets a new
    OCID, so counting tokens would always say 0)."""
    names = [r["params"].get("display_name") for r in fake.live().values()]
    return len(names) - len(set(names))


def _write(path, text):
    with open(path, "w") as f:
        f.write(text)


def W(name, app, tier="app", os_="Oracle Linux 8", vcpus=4, mem=16, deps=()):
    return F.Workload(name, app, tier, os_, vcpus, mem, tuple(deps))


def settings(env="dev", **kw):
    return P.Settings(env, COMP, TAGS, "t", "10.0.0.0/16",
                      {"web": "10.0.1.0/24", "app": "10.0.2.0/24", "db": "10.0.3.0/24"}, **kw)


class Clock:
    def __init__(self):
        self.t = 0.0
    def __call__(self):
        return self.t
    def sleep(self, s):
        self.t += s


def engines(fake, path, **kw):
    c = Clock()
    return lambda: Engine(fake, Journal(path), sleep=c.sleep, clock=c, rng=random.Random(1), **kw)


# ------------------------------------------------------------------ wave planning


class PlannerTests(unittest.TestCase):
    def test_dependency_loop_moves_together_and_later_apps_follow(self):
        ws = [W("a", "a", deps=["b"]), W("b", "b", deps=["c"]), W("c", "c", deps=["a"]), W("d", "d", deps=["a"])]
        self.assertEqual(F.plan_waves(ws), [["a", "b", "c"], ["d"]])
        self.assertEqual(F.mutual_groups(ws), [["a", "b", "c"]])

    def test_vm_cap_splits_waves_and_oversized_unit_moves_alone(self):
        ws = [W(f"x{i}", "big") for i in range(5)] + [W("s1", "s1"), W("s2", "s2"), W("s3", "s3")]
        waves = F.plan_waves(ws, max_apps_per_wave=10, max_vms_per_wave=2)
        self.assertIn(["big"], waves)
        self.assertTrue(all(len(w) <= 2 for w in waves if w != ["big"]))
        self.assertEqual(sorted(a for w in waves for a in w), ["big", "s1", "s2", "s3"])

    def test_solo_apps_get_their_own_wave(self):
        ws = [W("a", "a"), W("b", "b"), W("c", "c")]
        waves = F.plan_waves(ws, max_apps_per_wave=3, solo_apps=["b"])
        self.assertIn(["b"], waves)
        with self.assertRaises(F.FactoryError):
            F.plan_waves(ws, solo_apps=["ghost"])

    def test_every_dependency_is_satisfied_at_scale(self):
        wls, truth = synth.inventory(300, seed=5)
        waves = F.plan_waves(wls, max_apps_per_wave=10, max_vms_per_wave=40)
        pos = {a: i for i, w in enumerate(waves) for a in w}
        self.assertEqual(set(pos), {w.app for w in wls})
        for a, d in truth["deps"]:
            self.assertLessEqual(pos[d], pos[a], f"{a} moves before its dependency {d}")
            if pos[d] == pos[a]:
                self.assertTrue(any(a in g and d in g for g in F.mutual_groups(wls)), (a, d))

    def test_planning_is_fast_at_10k_vms(self):
        wls, _ = synth.inventory(2300, seed=1)
        t = time.perf_counter()
        F.plan_waves(wls, 25, 200); F.mutual_groups(wls)
        self.assertLess(time.perf_counter() - t, 3.0)        # measured ~0.06 s; guards against quadratic code


# ------------------------------------------------------------------ capacity


class CapacityTests(unittest.TestCase):
    def wf(self, *specs):
        steps = tuple(Step(f"v{i}", "instance", {"shape": s, "ocpus": o, "memory_gbs": m}) for i, (s, o, m) in enumerate(specs))
        return Workflow("wave-1", "dev", COMP, steps, TAGS)

    def test_demand_and_preflight(self):
        wf = self.wf((E5, 2, 16), (E5, 4, 32), ("VM.Standard3.Flex", 1, 8))
        self.assertEqual(C.wave_demand(wf), {"standard-e5-core-count": 6, "standard-e5-memory-count": 48,
                                             "standard3-core-count": 1, "standard3-memory-count": 8})
        ok = C.StaticQuota({"standard-e5-core-count": 6, "standard-e5-memory-count": 48,
                            "standard3-core-count": 1, "standard3-memory-count": 8})
        self.assertEqual(C.preflight(wf, ok, "AD-1"), [])
        self.assertTrue(C.preflight(wf, ok, "AD-1", headroom=0.1))              # 10% must stay free
        short = C.StaticQuota({"standard-e5-core-count": 5, "standard-e5-memory-count": 48,
                               "standard3-core-count": 1, "standard3-memory-count": 8})
        self.assertTrue(any("standard-e5-core-count" in v for v in C.preflight(wf, short, "AD-1")))

    def test_unknown_quota_and_unmapped_shape_block(self):
        self.assertTrue(any("unknown" in v for v in C.preflight(self.wf((E5, 1, 8)), C.StaticQuota({}), "AD-1")))
        self.assertTrue(any("no known service-limit" in v for v in C.preflight(self.wf(("BM.GPU.X", 1, 8)), QUOTA, "AD-1")))

    def test_oci_limits_quota_reads_available_and_fails_to_unknown(self):
        client = mock.Mock()
        client.get_resource_availability.return_value = mock.Mock(data=mock.Mock(available=40))
        q = C.OCILimitsQuota(COMP, client=client)
        self.assertEqual(q.available("standard-e5-core-count", "AD-1"), 40)
        client.get_resource_availability.assert_called_with("compute", "standard-e5-core-count", COMP, availability_domain="AD-1")
        client.get_resource_availability.side_effect = RuntimeError("not authorized")
        self.assertIsNone(q.available("standard-e5-core-count", "AD-1"))
        v = C.preflight(CapacityTests.wf(self, (E5, 1, 8)), q, "AD-1")
        self.assertTrue(any("not authorized" in x for x in v), v)          # the reason is shown, not just "unknown"

    def test_limiter_aimd(self):
        lim = C.AdaptiveLimiter(initial=8, minimum=1, maximum=10)
        lim.acquire(); lim.release(throttled=True)
        self.assertEqual(lim.limit, 4)
        for _ in range(4):
            lim.acquire(); lim.release(throttled=False)
        self.assertEqual(lim.limit, 5)
        for _ in range(200):
            lim.acquire(); lim.release(False)
        self.assertEqual(lim.limit, 10)                                        # capped at maximum
        for _ in range(10):
            lim.acquire(); lim.release(True)
        self.assertEqual(lim.limit, 1)                                         # floored at minimum
        with self.assertRaises(ValueError):
            C.AdaptiveLimiter(initial=0)

    def test_limiter_never_exceeds_its_limit_under_threads(self):
        lim = C.AdaptiveLimiter(initial=3, maximum=3)
        peak, cur, lk = [0], [0], threading.Lock()

        def work():
            for _ in range(30):
                lim.acquire()
                with lk:
                    cur[0] += 1; peak[0] = max(peak[0], cur[0])
                time.sleep(0.0005)
                with lk:
                    cur[0] -= 1
                lim.release(False)
        ts = [threading.Thread(target=work) for _ in range(12)]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertLessEqual(peak[0], 3)

    def test_adaptive_pacing_beats_fixed_pool_on_a_strict_server(self):
        def trial(limiter):
            wls, _ = synth.inventory(25, seed=3)
            fake = FakeOCI(latency=0.003, max_in_flight=3)
            jp = os.path.join(tempfile.mkdtemp(), "j")
            mk = lambda: Engine(fake, Journal(jp), max_workers=24, retry=RetryPolicy(12, 0.002, 0.05),  # headroom: no scheduling luck
                                poll_seconds=0.001, rng=random.Random(3), limiter=limiter)
            rep = P.run(wls, BLUEPRINTS, settings(max_apps_per_wave=25, max_vms_per_wave=200,
                                                   stop_on_wave_failure=False), mk, quota=QUOTA)
            return sum(w["status"] == "SUCCEEDED" for w in rep.wave_results), len(rep.wave_results), fake.throttled
        ok_l, n_l, t_l = trial(C.AdaptiveLimiter(initial=2, maximum=24))
        self.assertEqual(ok_l, n_l)
        ok_f, n_f, t_f = trial(None)
        self.assertLess(t_l, t_f)                        # fewer 429s than a fixed pool of 24 workers


# ------------------------------------------------------------------ discovery


def asset(name, ip, tags=None, os_="Oracle Linux 8"):
    return D.Asset(name, ip, os_, 4, 16, tags or {})


class DiscoveryTests(unittest.TestCase):
    def small(self):
        assets = [asset("crm-web-01", "10.0.0.1"), asset("crm-app-01", "10.0.0.2"), asset("crm-db-01", "10.0.0.3"),
                  asset("hr-app-01", "10.0.0.4", {"app": "people", "tier": "app"}), asset("idle-01", "10.0.0.9")]
        flows = [("10.0.0.1", "10.0.0.2", 8080, 400), ("10.0.0.2", "10.0.0.3", 1521, 900),
                 ("10.0.0.4", "10.0.0.2", 8080, 60),          # hr calls crm
                 ("10.0.0.2", "192.0.2.10", 1414, 30),         # crm calls a mainframe outside the estate
                 ("10.0.0.1", "10.255.0.2", 53, 999), ("10.255.0.9", "10.0.0.3", 22, 5),
                 ("198.51.100.7", "10.0.0.1", 443, 5000)]       # users reach the web tier
        return D.discover(assets, flows)

    def test_tiers_apps_and_dependency_direction(self):
        r = self.small()
        self.assertEqual((r.tier["crm-db-01"].value, r.tier["crm-web-01"].value, r.tier["crm-app-01"].value), ("db", "web", "app"))
        self.assertIn("1521", r.tier["crm-db-01"].evidence)
        self.assertEqual(r.app["hr-app-01"].value, "people"); self.assertEqual(r.app["hr-app-01"].source, "tag")
        self.assertEqual({d.key for d in r.deps}, {"people->crm"})              # client -> server, not reverse

    def test_infrastructure_external_and_silent_are_reported_not_dropped(self):
        r = self.small()
        self.assertEqual(set(r.excluded_infra), {"53 (DNS)", "22 (SSH)"})
        self.assertEqual(r.external, [{"from_app": "crm", "dst_ip": "192.0.2.10", "port": 1414, "connections": 30}])
        self.assertEqual(r.silent_vms, ["idle-01"])

    def test_unreviewed_kept_rejected_dropped_and_bad_decisions_refused(self):
        r = self.small()
        wls, s = r.to_workloads()
        self.assertEqual({w.name: w.depends_on_apps for w in wls}["hr-app-01"], ("crm",))
        self.assertEqual(s["unreviewed_kept"], 1)
        wls, s = r.to_workloads({"dependencies": {"people->crm": "reject"}, "reviewed_by": "t"})
        self.assertEqual({w.name: w.depends_on_apps for w in wls}["hr-app-01"], ())
        for bad in ({"dependencies": {"people->crm": "maybe"}}, {"dependencies": {"x->y": "accept"}},
                    {"tiers": {"crm-db-01": "database"}}):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                r.to_workloads(bad)

    def test_split_app_keeps_dependencies_on_every_part(self):
        r = self.small()
        wls, _ = r.to_workloads({"apps": {"crm-db-01": "crm-data"}, "reviewed_by": "t"})
        deps = {w.name: w.depends_on_apps for w in wls}
        self.assertEqual(deps["hr-app-01"], ("crm", "crm-data"))

    def test_tags_beat_inference_for_tiers(self):
        r = D.discover([asset("x-01", "10.0.0.1", {"tier": "web"}), asset("y-01", "10.0.0.2")],
                       [("10.0.0.2", "10.0.0.1", 1521, 50)])
        self.assertEqual((r.tier["x-01"].value, r.tier["x-01"].source), ("web", "tag"))   # serves 1521, tagged web

    def test_generic_named_vms_joined_by_traffic_are_still_flagged(self):
        assets = [asset("srv1001", "10.0.0.1"), asset("srv1002", "10.0.0.2"), asset("ledger-db-01", "10.0.0.9")]
        flows = [("10.0.0.1", "10.0.0.9", 1521, 50), ("10.0.0.2", "10.0.0.9", 1521, 50)]   # share a peer
        r = D.discover(assets, flows)
        self.assertEqual(r.app["srv1001"].value, r.app["srv1002"].value)                  # one traffic-connected group
        self.assertLess(r.app["srv1001"].confidence, 0.6)                                 # but a generic name: review
        self.assertIn("srv1001", r.report()["low_confidence_vms"])
        # Strong evidence too (one balancer in front of both, same backend): a generic name is still reviewed.
        lb = assets + [asset("shop-web-01", "10.0.0.5", tags={"app": "shop", "tier": "web"})]
        r2 = D.discover(lb, flows + [("10.0.0.5", "10.0.0.1", 8080, 90), ("10.0.0.5", "10.0.0.2", 8080, 90)])
        self.assertEqual(r2.app["srv1001"].value, r2.app["srv1002"].value)
        self.assertLess(r2.app["srv1001"].confidence, 0.6)

    def test_name_group_split_by_traffic_is_split_and_flagged(self):
        # "ledger", not "crm": prefixes of 3 letters or fewer are treated as generic (always flagged) by design,
        # so this test needs a normal-length name to exercise the traffic-split path.
        assets = [asset("ledger-app-01", "10.0.0.1"), asset("ledger-app-02", "10.0.0.2"),
                  asset("one-db-01", "10.0.0.8"), asset("two-db-01", "10.0.0.9")]
        flows = [("10.0.0.1", "10.0.0.8", 1521, 50), ("10.0.0.2", "10.0.0.9", 5432, 50)]  # nothing in common
        r = D.discover(assets, flows)
        self.assertNotEqual(r.app["ledger-app-01"].value, r.app["ledger-app-02"].value)
        self.assertTrue(all(r.app[n].confidence < 0.6 for n in ("ledger-app-01", "ledger-app-02")))
        connected = D.discover(assets, flows + [("10.0.0.1", "10.0.0.2", 7000, 20)])
        self.assertEqual(connected.app["ledger-app-01"].value, "ledger")
        self.assertGreaterEqual(connected.app["ledger-app-01"].confidence, 0.6)

    def test_split_dependent_app_keeps_its_dependencies(self):
        assets = [asset("shop-app-01", "10.0.0.1", {"app": "shop"}), asset("shop-app-02", "10.0.0.2", {"app": "shop"}),
                  asset("crm-app-01", "10.0.0.3")]
        flows = [("10.0.0.1", "10.0.0.3", 8080, 40), ("10.0.0.2", "10.0.0.3", 8080, 40)]
        wls, _ = D.discover(assets, flows).to_workloads({"apps": {"shop-app-02": "shop2"}, "reviewed_by": "t"})
        deps = {w.name: w.depends_on_apps for w in wls}
        self.assertEqual((deps["shop-app-01"], deps["shop-app-02"]), (("crm",), ("crm",)))

    def test_vip_scan_and_second_nic_traffic_becomes_a_dependency(self):
        assets = [asset("crm-app-01", "10.0.0.2"), asset("ledger-db-01", "10.0.0.8;10.1.0.8"),
                  asset("ledger-db-02", "10.0.0.9")]
        flows = [("10.0.0.2", "10.9.9.9", 1521, 80),       # SCAN address of the ledger RAC
                 ("10.0.0.2", "10.1.0.8", 1521, 20)]       # second NIC of ledger-db-01
        r = D.discover(assets, flows)
        self.assertEqual([u["dst_ip"] for u in r.unresolved], ["10.9.9.9"])
        with self.assertRaisesRegex(ValueError, "10.9.9.9"):
            r.to_workloads()                                   # unresolved: no inventory yet
        self.assertEqual(r.to_workloads({"external_ok": ["10.9.9.9"], "reviewed_by": "ann"})[1]["unreviewed_kept"], 1)
        r2 = D.discover(assets, flows, vips={"10.9.9.9": ["ledger-db-01", "ledger-db-02"]})
        self.assertEqual(r2.unresolved, [])
        self.assertEqual({d.key: d.connections for d in r2.deps}, {"crm->ledger": 100})
        with self.assertRaises(ValueError):
            D.discover(assets, flows, vips={"10.9.9.9": ["ghost"]})

    def test_confidence_is_monotone(self):
        self.assertLess(D.dep_confidence(3, 1), D.dep_confidence(30, 1))
        self.assertLess(D.dep_confidence(30, 1), D.dep_confidence(30, 3))
        self.assertLessEqual(D.dep_confidence(10 ** 6, 100), 0.99)

    def test_generic_names_never_produce_a_silent_mixed_group(self):
        for seed in range(3):
            assets, flows, _, truth = synth.estate(60, seed=seed)
            true_app = {a.ip: truth["app"][a.name] for a in assets}
            r = random.Random(seed)
            for i, a in enumerate(assets):
                if not a.tags and r.random() < 0.4:
                    a.name = f"srv{10000 + i}"
            res = D.discover(assets, flows)
            flagged = set(res.report()["low_confidence_vms"])
            groups = defaultdict(set)
            for a in assets:
                groups[res.app[a.name].value].add(true_app[a.ip])
            for a in assets:
                if len(groups[res.app[a.name].value]) > 1:
                    self.assertIn(a.name, flagged, f"seed {seed}: {a.name} in a mixed group without a flag")

    def test_accuracy_on_synthetic_estates(self):
        for seed in (1, 2, 3):
            assets, flows, listeners, truth = synth.estate(80, seed=seed)
            res = D.discover(assets, flows, listeners)
            hi = {(d.from_app, d.to_app) for d in res.deps if d.confidence >= 0.6}
            allf = {(d.from_app, d.to_app) for d in res.deps}
            self.assertGreaterEqual(len(hi & truth["deps"]) / max(1, len(hi)), 0.95)         # precision, high band
            self.assertGreaterEqual(len(allf & truth["deps"]) / len(truth["deps"]), 0.95)    # recall, all
            self.assertEqual(sum(res.tier[a.name].value == truth["tier"][a.name] for a in assets), len(assets))

    def test_loaders_report_line_numbers_and_duplicates(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "a.csv")
        _write(p, "name,ip,os,vcpus,memory_gb\nx,10.0.0.1,Linux,4,8\ny,10.0.0.1,Linux,4,8\n")
        with self.assertRaises(ValueError):
            D.load_assets(p)
        _write(p, "name,ip,os,vcpus,memory_gb\nx,10.0.0.1,Linux,four,8\n")
        with self.assertRaisesRegex(ValueError, "line 2"):
            D.load_assets(p)


# ------------------------------------------------------------------ agent and guard


class AgentTests(unittest.TestCase):
    def setUp(self):
        self.wls = [W("app1", "crm", vcpus=4, mem=16), W("db1", "crm", tier="db"),
                    W("win1", "hr", os_="Microsoft Windows Server 2022"), W("bsd1", "legacy", os_="FreeBSD 13")]
        self.g = A.Guard(self.wls, BLUEPRINTS)

    def p(self, **kw):
        base = {"workload": "app1", "blueprint": "app-linux@v1", "overrides": {}, "rationale": "ok"}
        base.update(kw)
        return base

    def test_valid_proposal_accepted(self):
        d = self.g.check(self.p(overrides={"memory_gbs": 32}), "app1")
        self.assertTrue(d.accepted, d.reasons)
        self.assertEqual(d.placement.params["memory_gbs"], 32)

    def test_every_rule_rejects(self):
        cases = {
            "extra key": dict(self.p(), extra=1),
            "missing key": {k: v for k, v in self.p().items() if k != "rationale"},
            "unknown workload": self.p(workload="ghost"),
            "other workload": self.p(workload="db1", blueprint="db-linux@v1"),
            "wrong archetype": self.p(blueprint="db-linux@v1"),
            "unknown blueprint": self.p(blueprint="app-linux@v9"),
            "locked field": self.p(overrides={"assign_public_ip": True}),
            "downsize": self.p(overrides={"ocpus": 1}),
            "oversize": self.p(overrides={"ocpus": 65}),
            "bool as int": self.p(overrides={"ocpus": True}),
            "float": self.p(overrides={"memory_gbs": 20.5}),
            "mem per ocpu": self.p(overrides={"memory_gbs": 1000}),
            "shape not allowed": self.p(overrides={"shape": "BM.GPU.H100.8"}),
            "shape wrong type": self.p(overrides={"shape": {"x": 1}}),
            "rationale too long": self.p(rationale="x" * 501),
            "rationale control chars": self.p(rationale="\x00\x1b[31m"),
            "overrides not object": self.p(overrides="memory_gbs=64"),
            "not an object": ["app1"],
        }
        for name, prop in cases.items():
            with self.subTest(name):
                self.assertFalse(self.g.check(prop, "app1").accepted)
        d = A.Guard(self.wls, BLUEPRINTS).check(
            {"workload": "db1", "blueprint": "db-linux@v1", "overrides": {"subnet": "subnet_public"}, "rationale": ""}, "db1")
        self.assertFalse(d.accepted)

    def test_reasons_name_the_rule(self):
        locked = self.g.check(self.p(overrides={"assign_public_ip": True}), "app1")
        self.assertTrue(any("'assign_public_ip' is locked" in r for r in locked.reasons), locked.reasons)
        subnet = self.g.check(self.p(overrides={"subnet": "subnet_db"}), "app1")     # has a rule, but locked here
        self.assertTrue(any("'subnet' is locked" in r for r in subnet.reasons), subnet.reasons)
        small = A.Guard([W("tiny", "x", vcpus=2, mem=8)], BLUEPRINTS)                 # source size: 1 OCPU
        d = small.check({"workload": "tiny", "blueprint": "app-linux@v1", "overrides": {"ocpus": True},
                         "rationale": ""}, "tiny")
        self.assertFalse(d.accepted); self.assertTrue(any("integer" in r for r in d.reasons), d.reasons)
        none = self.g.check({"workload": "bsd1", "blueprint": None, "overrides": {}, "rationale": ""}, "bsd1")
        self.assertTrue(none.reasons[0].startswith("no blueprint is valid for this workload"), none.reasons)

    def test_fuzz_never_violates_invariants_and_never_raises(self):
        wls, _ = synth.inventory(40, seed=4)
        g, accepted = A.Guard(wls, BLUEPRINTS), 0
        with mock.patch.object(A.Guard, "_check", side_effect=A.Guard._check, autospec=True) as spy:
            for seed in range(25):
                for d in A.review(wls, A.HostileProposer(BLUEPRINTS, seed), g):
                    if not d.accepted:
                        self.assertFalse(any("guard error" in r for r in d.reasons), d.reasons)
                        continue
                    accepted += 1
                    w, ov, bp = d.placement.workload, d.placement.overrides, d.placement.blueprint
                    base = F.size(w)
                    self.assertEqual(d.proposal["workload"], w.name)
                    self.assertEqual(bp.id(), F.place(w, BLUEPRINTS, {}).blueprint.id())
                    self.assertTrue(set(ov) <= bp.customizable)
                    for k in ("ocpus", "memory_gbs"):
                        if k in ov:
                            self.assertIs(type(ov[k]), int); self.assertGreaterEqual(ov[k], base[k])
                    pr = d.placement.params
                    self.assertIs(pr["assign_public_ip"], False)
                    self.assertIn(pr["shape"], A.Bounds().shapes)
                    self.assertEqual(F.shape_problems(pr["shape"], pr["ocpus"], pr["memory_gbs"]), [])
                    self.assertLessEqual(pr["ocpus"], A.Bounds().max_ocpus)
                    self.assertLessEqual(pr["memory_gbs"], min(A.Bounds().max_memory_gbs, pr["ocpus"] * 64))
                    self.assertIn(pr.get("subnet", "subnet_app"), A.Bounds().subnets)
            self.assertGreater(spy.call_count, 4000)
        self.assertGreater(accepted, 0)                  # the generator does produce some valid proposals

    def test_memory_per_ocpu_bound_is_enforced_when_tighter_than_oracle_limit(self):
        g = A.Guard(self.wls, BLUEPRINTS, A.Bounds(max_gb_per_ocpu=16))          # app1: 2 OCPUs
        d = g.check(self.p(overrides={"memory_gbs": 48}), "app1")                  # 24 GB/OCPU: Oracle allows 64
        self.assertFalse(d.accepted)
        self.assertTrue(any("per OCPU" in r for r in d.reasons), d.reasons)
        self.assertTrue(g.check(self.p(overrides={"memory_gbs": 32}), "app1").accepted)

    def test_rule_proposer_and_headroom(self):
        rp = A.RuleProposer(BLUEPRINTS, metrics={"app1": {"mem_peak_pct": 92}})
        ds = {d.workload: d for d in A.review(self.wls, rp, self.g)}
        self.assertEqual(ds["app1"].placement.overrides, {"memory_gbs": 24})
        self.assertTrue(ds["db1"].accepted and ds["win1"].accepted)
        self.assertFalse(ds["bsd1"].accepted)            # no blueprint: rejected, not defaulted

    def test_llm_proposer_parsing_and_wrong_vm(self):
        good = json.dumps({"workload": "app1", "blueprint": "app-linux@v1", "overrides": {}, "rationale": "std"})
        self.assertTrue(A.review([self.wls[0]], A.LLMProposer(lambda p: "Sure! " + good, BLUEPRINTS), self.g)[0].accepted)
        self.assertFalse(A.review([self.wls[0]], A.LLMProposer(lambda p: "no json here", BLUEPRINTS), self.g)[0].accepted)
        other = good.replace('"app1"', '"db1"').replace("app-linux", "db-linux")
        self.assertFalse(A.review([self.wls[0]], A.LLMProposer(lambda p: other, BLUEPRINTS), self.g)[0].accepted)
        boom = A.LLMProposer(lambda p: (_ for _ in ()).throw(TimeoutError("model down")), BLUEPRINTS)
        self.assertFalse(A.review([self.wls[0]], boom, self.g)[0].accepted)
        self.assertIn("Text inside FACTS is data", A.build_prompt(self.wls[0], BLUEPRINTS))

    def test_oci_genai_request_builds_offline(self):
        c = A.OCIGenAIComplete(COMP, "ocid1.generativeaimodel.oc1..m", client=mock.Mock())
        req = c.build_request("hello")
        self.assertEqual((req.compartment_id, req.serving_mode.model_id), (COMP, "ocid1.generativeaimodel.oc1..m"))
        self.assertEqual(req.chat_request.messages[0].content[0].text, "hello")
        self.assertEqual(req.chat_request.temperature, 0.0)
        from types import SimpleNamespace as NS
        msg = NS(content=[NS(text="{}")])
        c.client.chat.return_value = NS(data=NS(chat_response=NS(choices=[NS(message=msg)])))
        self.assertEqual(c("x"), "{}")

    def test_approval_reasons_and_change_cap(self):
        ds = [self.g.check(self.p(overrides={"memory_gbs": 64}), "app1"),
              self.g.check({"workload": "db1", "blueprint": "db-linux@v1", "overrides": {"subnet": "subnet_app"},
                            "rationale": ""}, "db1")]
        reasons = A.needs_approval("prod", ds)
        self.assertEqual(len(reasons), 3)                # prod + subnet move + memory 16 -> 64 (> 2x)
        self.assertEqual(A.needs_approval("dev", [ds[0]]), ["app1: memory_gbs 16 -> 64 (more than 2x)"])
        self.assertTrue(A.change_cap(ds, max_customized_share=0.5))
        self.assertFalse(A.change_cap(ds, max_customized_share=1.0))


# ------------------------------------------------------------------ pipeline


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")
        self.wls = [W("db1", "core", tier="db"), W("app1", "crm", deps=["core"]), W("app2", "crm", deps=["core"])]

    def test_failed_wave_rerun_recreates_the_vms_it_rolled_back(self):
        # app1 becomes ready, app2 fails, so app1 is rolled back. Re-running must create app1 again, not
        # count it as existing because an earlier run once had it ready.
        fake = FakeOCI(fail_provision={"app2"})
        wls = [W("app1", "crm"), W("app2", "crm")]
        rep = P.run(wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        self.assertEqual(rep.wave_results[0]["status"], "FAILED_ROLLED_BACK")
        self.assertIn("app1", rep.wave_results[0]["rolled_back"])
        fake.fail_provision.clear()
        rep = P.run(wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        self.assertEqual(rep.wave_results[0]["status"], "SUCCEEDED", rep.wave_results)
        live = sorted(r["params"]["display_name"] for r in fake.live().values() if r["kind"] == "instance")
        self.assertEqual(live, ["app1", "app2"])

    def test_dry_run_reports_wave_policy_violations_from_a_bad_blueprint(self):
        # A team's catalog that lets web servers take public IPs: only the wave plan shows it, and the dry
        # run must say so before anyone approves anything.
        bad = tuple(F.Blueprint(b.name, b.version, b.match_tier, b.match_os, dict(b.defaults, assign_public_ip=True),
                                b.customizable) if b.match_tier == "web" else b for b in BLUEPRINTS)
        wls = [W("web1", "shop", tier="web"), W("app1", "shop")]
        rep = P.run(wls, bad, settings("prod"), None, execute=False)
        self.assertTrue(any(v.startswith("wave 1:") and "public IP" in v for v in rep.policy_violations),
                        rep.policy_violations)
        self.assertEqual(P.run(wls, BLUEPRINTS, settings("prod"), None, execute=False).policy_violations, [])

    def test_finished_waves_are_not_approved_again(self):
        fake, asked = FakeOCI(), []
        approver = lambda name, reasons, plan, wh: (asked.append(name) or True, "tester")
        rep = P.run(self.wls, BLUEPRINTS, settings("prod"), engines(fake, self.jp), quota=QUOTA, approver=approver)
        self.assertTrue(asked and all(w["status"] == "SUCCEEDED" for w in rep.wave_results))
        n_approvals = sum(1 for e in Journal(self.jp).entries if e.get("event") == "approval")
        asked.clear()
        rep = P.run(self.wls, BLUEPRINTS, settings("prod"), engines(fake, self.jp), quota=QUOTA, approver=approver)
        self.assertEqual(asked, [])                     # nothing to do, so nothing to approve
        self.assertEqual(sum(1 for e in Journal(self.jp).entries if e.get("event") == "approval"), n_approvals)

    def test_prod_needs_an_approval_and_it_is_journalled(self):
        fake = FakeOCI()
        rep = P.run(self.wls, BLUEPRINTS, settings("prod"), engines(fake, self.jp), quota=QUOTA)
        self.assertEqual(rep.wave_results[0]["status"], "BLOCKED_APPROVAL")
        self.assertEqual([r for r in fake.live().values() if r["kind"] == "instance"], [])
        rep = P.run(self.wls, BLUEPRINTS, settings("prod"), engines(fake, self.jp), quota=QUOTA,
                    approver=lambda name, reasons, plan, wave_hash: (True, "J.C. Glover"))
        self.assertEqual([w["status"] for w in rep.wave_results], ["SUCCEEDED", "SUCCEEDED"])
        ap = [e for e in Journal(self.jp).entries if e.get("event") == "approval"]
        self.assertEqual([(e["approved"], e["by"]) for e in ap], [(False, ""), (True, "J.C. Glover"), (True, "J.C. Glover")])
        self.assertTrue(Journal(self.jp).verify())

    def test_quota_shortfall_blocks_before_any_instance_is_created(self):
        fake = FakeOCI()
        tight = C.StaticQuota({"standard-e5-core-count": 1, "standard-e5-memory-count": 1})
        rep = P.run(self.wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=tight)
        self.assertEqual(rep.wave_results[0]["status"], "BLOCKED_QUOTA")
        self.assertFalse([c for c in fake.calls if c[0] == "create" and c[1] == "instance"])

    def test_plan_only_and_execute_requires_quota(self):
        rep = P.run(self.wls, BLUEPRINTS, settings(), None, execute=False)
        self.assertEqual(rep.waves, [["core"], ["crm"]])
        with self.assertRaises(ValueError):
            P.run(self.wls, BLUEPRINTS, settings(), engines(FakeOCI(), self.jp))

    def test_change_cap_stops_the_run_before_anything_is_created(self):
        fake = FakeOCI()
        rp = A.RuleProposer(BLUEPRINTS, metrics={"app1": {"mem_peak_pct": 99}, "app2": {"mem_peak_pct": 99}})
        rep = P.run(self.wls, BLUEPRINTS, settings(max_customized_share=0.3), engines(fake, self.jp),
                    quota=QUOTA, proposer=rp)
        self.assertTrue(rep.run_blocked)
        self.assertEqual(fake.calls, [])

    def test_crash_then_rerun_resumes_without_duplicates_or_new_landing_zone(self):
        fake = FakeOCI(crash_after_create={"app2"})
        with self.assertRaises(Crash):
            P.run(self.wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        vcn_creates = sum(1 for c in fake.calls if c[:2] == ("create", "vcn"))
        rep = P.run(self.wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        self.assertEqual([w["status"] for w in rep.wave_results], ["SUCCEEDED", "SUCCEEDED"])
        self.assertEqual(sum(1 for c in fake.calls if c[:2] == ("create", "vcn")), vcn_creates)
        self.assertEqual(duplicates(fake), 0)
        names = sorted(r["params"]["display_name"] for r in fake.live().values() if r["kind"] == "instance")
        self.assertEqual(names, ["app1", "app2", "db1"])
        calls = len(fake.calls)
        rep = P.run(self.wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)   # third run: nothing to do
        new = fake.calls[calls:]
        self.assertTrue(new and all(c[0] == "state" for c in new), new)     # it only reads, to verify
        self.assertTrue(all("already exists" in w["why"] for w in rep.wave_results))

    def test_resume_preflight_counts_only_remaining_steps(self):
        fake = FakeOCI(crash_after_create={"app1"})
        wls = [W("app1", "crm", vcpus=8, mem=32), W("app2", "crm", vcpus=8, mem=32)]
        q = C.StaticQuota({"standard-e5-core-count": 8, "standard-e5-memory-count": 64})
        with self.assertRaises(Crash):
            P.run(wls, BLUEPRINTS, settings(quota_headroom=0.0), engines(fake, self.jp), quota=q)
        q2 = C.StaticQuota({"standard-e5-core-count": 4, "standard-e5-memory-count": 32})   # app1 now holds quota
        rep = P.run(wls, BLUEPRINTS, settings(quota_headroom=0.0), engines(fake, self.jp), quota=q2)
        self.assertEqual(rep.wave_results[0]["status"], "SUCCEEDED", rep.wave_results)

    def test_resume_preflight_skips_vms_created_but_not_yet_ready(self):
        # The process dies while waiting for app1 to boot: the journal says "created", not "ready". app1
        # already holds its quota, so the Limits API shows none left; the re-run must not count it again.
        fake = FakeOCI()
        orig, died = fake.state, []

        def state(kind, rid):
            if kind == "instance" and fake.res[rid]["params"]["display_name"] == "app1" and not died:
                died.append(rid)
                raise Crash("process died while waiting for app1")
            return orig(kind, rid)
        fake.state = state
        wls = [W("app1", "crm", vcpus=8, mem=32), W("app2", "crm", vcpus=8, mem=32)]
        with self.assertRaises(Crash):
            P.run(wls, BLUEPRINTS, settings(quota_headroom=0.0), engines(fake, self.jp), quota=QUOTA)
        st = {e.get("step"): e["event"] for e in Journal(self.jp).entries if e.get("step") == "app1"}
        self.assertEqual(st["app1"], "created")
        none_left = C.StaticQuota({"standard-e5-core-count": 0, "standard-e5-memory-count": 0})
        rep = P.run(wls, BLUEPRINTS, settings(quota_headroom=0.0), engines(fake, self.jp), quota=none_left)
        self.assertEqual(rep.wave_results[0]["status"], "SUCCEEDED", rep.wave_results)
        self.assertEqual(duplicates(fake), 0)


class ContentIdentityTests(unittest.TestCase):
    """Re-running after the inputs change: identity is by VM, never by wave number."""

    def setUp(self):
        self.jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")

    def test_inventory_change_between_runs_creates_new_vms_once_and_never_duplicates(self):
        fake = FakeOCI()
        first = [W("b1", "bbb"), W("c1", "ccc", deps=["bbb"])]
        P.run(first, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        second = [W("a1", "aaa")] + first                      # a new app shifts every wave number
        rep = P.run(second, BLUEPRINTS, settings(max_apps_per_wave=1), engines(fake, self.jp), quota=QUOTA)
        self.assertTrue(all(w["status"] == "SUCCEEDED" for w in rep.wave_results), rep.wave_results)
        names = sorted(r["params"]["display_name"] for r in fake.live().values() if r["kind"] == "instance")
        self.assertEqual(names, ["a1", "b1", "c1"])
        self.assertEqual(duplicates(fake), 0)

    def test_changed_settings_of_an_existing_vm_are_reported_as_drift_not_recreated(self):
        fake = FakeOCI()
        wls = [W("b1", "bbb")]
        P.run(wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        rep = P.run(wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA,
                    overrides={"b1": {"memory_gbs": 24}})
        self.assertEqual(rep.wave_results[0]["drift"], ["b1"])
        self.assertEqual(duplicates(fake), 0)

    def test_changed_target_network_is_refused_not_reused(self):
        fake = FakeOCI()
        P.run([W("b1", "bbb")], BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        vcns = sum(1 for c in fake.calls if c[:2] == ("create", "vcn"))
        changed = P.Settings("dev", COMP, TAGS, "t", "10.9.0.0/16", {"app": "10.9.2.0/24"})
        rep = P.run([W("b1", "bbb")], BLUEPRINTS, changed, engines(fake, self.jp), quota=QUOTA)
        self.assertEqual(rep.landing_zone, "BLOCKED_CHANGED")
        self.assertEqual(sum(1 for c in fake.calls if c[:2] == ("create", "vcn")), vcns)

    def test_interrupted_run_with_changed_inputs_is_refused(self):
        fake = FakeOCI(crash_after_create={"c1"})
        wls = [W("b1", "bbb"), W("c1", "bbb")]
        with self.assertRaises(Crash):
            P.run(wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        rep = P.run(wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA,
                    overrides={"c1": {"memory_gbs": 24}})
        self.assertEqual(rep.wave_results[0]["status"], "BLOCKED_CHANGED")
        self.assertEqual(duplicates(fake), 0)


class BlockingAndApprovalTests(unittest.TestCase):
    def setUp(self):
        self.jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")

    def test_refused_vm_blocks_its_app_and_every_dependent(self):
        wls = [W("web1", "shop", tier="web"), W("odd1", "shop", os_="FreeBSD 13", deps=["zpay"]),
               W("z1", "zpay"), W("r1", "reports", deps=["shop"])]
        rep = P.run(wls, BLUEPRINTS, settings(), None, execute=False)
        self.assertEqual(rep.blocked_apps, {"shop": "VM odd1 could not be placed",
                                            "reports": "depends on blocked app shop"})
        self.assertEqual(rep.waves, [["zpay"]])

    def test_subnet_move_needs_approval_on_the_overrides_path_too(self):
        fake = FakeOCI()
        rep = P.run([W("d1", "core", tier="db")], BLUEPRINTS, settings("dev"), engines(fake, self.jp), quota=QUOTA,
                    overrides={"d1": {"subnet": "subnet_app"}})
        self.assertEqual(rep.wave_results[0]["status"], "BLOCKED_APPROVAL")
        self.assertFalse([c for c in fake.calls if c[:2] == ("create", "instance")])

    def test_approval_is_bound_to_the_reviewed_plan_and_wave(self):
        wls = [W("a1", "crm")]
        reviewed = P.run(wls, BLUEPRINTS, settings("prod"), None, execute=False).plan_id
        rep = P.run(wls, BLUEPRINTS, settings("prod", expected_plan_id=reviewed), engines(FakeOCI(), self.jp),
                    quota=QUOTA, approver=lambda *a: (True, "reviewer"))
        self.assertEqual(rep.wave_results[-1]["status"], "SUCCEEDED")
        ap = [e for e in Journal(self.jp).entries if e.get("event") == "approval"][0]
        self.assertEqual((ap["plan_id"], len(ap["wave_hash"])), (reviewed, 64))
        changed = P.run(wls + [W("a2", "crm")], BLUEPRINTS, settings("prod", expected_plan_id=reviewed),
                        engines(FakeOCI(), self.jp + "2"), quota=QUOTA, approver=lambda *a: (True, "reviewer"))
        self.assertTrue(changed.run_blocked and not changed.wave_results)


class ShapeLimitTests(unittest.TestCase):
    def test_sizes_respect_documented_flex_limits(self):
        self.assertEqual(F.size(W("v", "a", vcpus=16, mem=4)), {"ocpus": 8, "memory_gbs": 8})    # >= 1 GB per OCPU
        with self.assertRaises(F.FactoryError):
            F.place(W("v", "a", vcpus=300, mem=64), BLUEPRINTS, {})                              # 150 OCPUs > 126
        self.assertTrue(F.shape_problems("VM.Standard3.Flex", 32, 600))                           # 512 GB cap
        self.assertEqual(F.shape_problems("VM.Standard.E5.Flex", 2, 128), [])
        self.assertTrue(F.shape_problems("VM.Standard.E5.Flex", 2, 129))                          # 64 GB per OCPU
        g = A.Guard([W("x", "a", vcpus=4, mem=16)], BLUEPRINTS)
        d = g.check({"workload": "x", "blueprint": "app-linux@v1", "overrides": {"shape": "VM.Standard3.Flex",
                     "ocpus": 40}, "rationale": ""}, "x")
        self.assertFalse(d.accepted)


# ------------------------------------------------------------------ engine teardown


class TeardownTests(unittest.TestCase):
    def test_teardown_deletes_newest_first_and_reports(self):
        jp = os.path.join(tempfile.mkdtemp(), "j")
        fake = FakeOCI()
        e = engines(fake, jp)()
        lz = F.landing_zone("t", "dev", COMP, TAGS, "10.0.0.0/16", {"app": "10.0.2.0/24", "db": "10.0.3.0/24"})
        r = e.apply(lz)
        t = engines(fake, jp)().teardown(lz, r.run_id)
        self.assertEqual(t.status, "TORN_DOWN"); self.assertEqual(t.rolled_back[-1], "vcn")
        self.assertEqual(fake.live(), {})
        fake2 = FakeOCI(faults={("delete", "vcn"): [400]})
        e2 = engines(fake2, jp + "2")()
        r2 = e2.apply(lz)
        t2 = engines(fake2, jp + "2")().teardown(lz, r2.run_id)
        self.assertEqual(t2.status, "TEARDOWN_INCOMPLETE"); self.assertEqual(t2.orphans[0]["step"], "vcn")


class TokenAgeAndTags(unittest.TestCase):
    def test_unconfirmed_create_older_than_token_life_is_not_resent(self):
        jp = os.path.join(tempfile.mkdtemp(), "j")
        lz = F.landing_zone("t", "dev", COMP, TAGS, "10.0.0.0/16", {"app": "10.0.2.0/24"})
        j = Journal(jp)
        j.append(run_id="r1", event="run_started", workflow=lz.name,
                 workflow_hash=__import__("ocio.engine", fromlist=["x"]).workflow_hash(lz))
        j.append(run_id="r1", step="vcn", event="creating", retry_token="t", ts=1000.0)
        fake = FakeOCI()
        e = Engine(fake, Journal(jp), wall=lambda: 1000.0 + 25 * 3600, sleep=lambda s: None, clock=lambda: 0)
        r = e.apply(lz, run_id="r1")
        self.assertEqual(r.status, "FAILED_ROLLED_BACK")
        self.assertIn("ocio_step=vcn", r.error)
        self.assertFalse([c for c in fake.calls if c[0] == "create"])         # nothing re-sent
        e2 = Engine(FakeOCI(), Journal(jp + "b"), wall=lambda: 1000.0 + 3600, sleep=lambda s: None, clock=lambda: 0)
        self.assertEqual(e2.apply(lz).status, "SUCCEEDED")

    def test_created_resources_carry_run_and_step_tags(self):
        fake = FakeOCI()
        e = engines(fake, os.path.join(tempfile.mkdtemp(), "j"))()
        r = e.apply(F.landing_zone("t", "dev", COMP, TAGS, "10.0.0.0/16", {"app": "10.0.2.0/24"}))
        for res in fake.live().values():
            self.assertEqual(res["tags"]["ocio_run"], r.run_id)
            self.assertIn(res["tags"]["ocio_step"], ("vcn", "subnet_app"))
            self.assertEqual(res["tags"]["owner"], "team")


# ------------------------------------------------------------------ SDK adapter: live-tenancy behaviours, offline


class SDKLiveBehaviours(unittest.TestCase):
    def adapter(self, image_map=None):
        import oci
        with mock.patch.object(oci.core, "VirtualNetworkClient") as vn, mock.patch.object(oci.core, "ComputeClient") as cc:
            p = OCISDKProvider(config={}, availability_domain="AD-1", image_map=image_map)
        return p, vn, cc

    def test_sdk_retries_are_off(self):
        import oci
        _, vn, cc = self.adapter()
        for client in (vn, cc):
            self.assertIsInstance(client.call_args.kwargs["retry_strategy"], oci.retry.NoneRetryStrategy)

    def test_404_means_gone_only_after_our_own_delete(self):
        import oci
        p, _, _ = self.adapter()
        p.net.get_vcn.side_effect = oci.exceptions.ServiceError(404, "NotAuthorizedOrNotFound", {}, "gone")
        with self.assertRaises(ProviderError) as cm:          # could be a permissions problem: not "gone"
            p.state("vcn", "ocid1.vcn.x")
        self.assertFalse(cm.exception.transient)
        p.net.delete_vcn.side_effect = oci.exceptions.ServiceError(404, "NotAuthorizedOrNotFound", {}, "x")
        with self.assertRaises(ProviderError):                # delete never accepted: cannot confirm
            p.delete("vcn", "ocid1.vcn.x")
        p.net.delete_vcn.side_effect = None
        p.delete("vcn", "ocid1.vcn.x")                        # accepted (2xx) ...
        self.assertEqual(p.state("vcn", "ocid1.vcn.x"), GONE) # ... so a later 404 means gone
        p.net.delete_vcn.side_effect = oci.exceptions.ServiceError(404, "NotAuthorizedOrNotFound", {}, "x")
        p.delete("vcn", "ocid1.vcn.x")                        # re-sent delete of something already deleted

    def test_transport_errors_are_retryable(self):
        import oci, requests
        p, _, _ = self.adapter()
        for err in (oci.exceptions.RequestException("reset"), requests.exceptions.ReadTimeout("slow")):
            p.compute.get_instance.side_effect = err
            with self.assertRaises(ProviderError) as cm:
                p.state("instance", "ocid1.instance.x")
            self.assertTrue(cm.exception.transient, err)

    def test_409_on_delete_is_retryable_but_not_on_create(self):
        import oci
        p, _, _ = self.adapter()
        p.net.delete_subnet.side_effect = oci.exceptions.ServiceError(409, "Conflict", {}, "vnic detaching")
        with self.assertRaises(ProviderError) as cm:
            p.delete("subnet", "ocid1.subnet.x")
        self.assertTrue(cm.exception.transient)
        p.compute.launch_instance.side_effect = oci.exceptions.ServiceError(409, "Conflict", {}, "x")
        with self.assertRaises(ProviderError) as cm:
            p.create("instance", COMP, {"shape": E5, "subnet_id": "s", "image_id": "ocid1.image.x"}, TAGS, "tok")
        self.assertFalse(cm.exception.transient)                 # 409 on create is a real conflict

    def test_images_resolved_or_refused(self):
        p, _, _ = self.adapter(image_map={"IMAGE_OL8": "ocid1.image.oc1.phx.ol8"})
        d = p.build("instance", COMP, {"shape": E5, "subnet_id": "s", "image_id": "IMAGE_OL8"}, TAGS)
        self.assertEqual(d.source_details.image_id, "ocid1.image.oc1.phx.ol8")
        with self.assertRaises(ProviderError):
            p.build("instance", COMP, {"shape": E5, "subnet_id": "s", "image_id": "IMAGE_WIN2022"}, TAGS)

    def test_fixed_shapes_send_no_shape_config_and_dns_labels_are_cleaned(self):
        p, _, _ = self.adapter()
        fixed = p.build("instance", COMP, {"shape": "VM.Standard.E2.1.Micro", "subnet_id": "s",
                                           "image_id": "ocid1.image.x"}, TAGS)
        self.assertIsNone(fixed.shape_config)
        flex = p.build("instance", COMP, {"shape": E5, "subnet_id": "s", "image_id": "ocid1.image.x", "ocpus": 2}, TAGS)
        self.assertEqual(flex.shape_config.ocpus, 2)
        self.assertEqual(p.build("vcn", COMP, {"cidr_block": "10.0.0.0/16", "dns_label": "acme-prod"}, TAGS).dns_label, "acmeprod")
        self.assertEqual([OCISDKProvider.dns_label(x) for x in ("9lives", "---", None)], ["lives", None, None])


class OCMTests(unittest.TestCase):
    """The migration path: blueprint settings into Oracle Cloud Migrations target assets (offline)."""

    def setUp(self):
        import oci
        self.m = oci.cloud_migrations.models
        self.p = F.place(W("crm-app-01", "crm", vcpus=8, mem=32), BLUEPRINTS, {"memory_gbs": 48})
        self.subnets = {"subnet_app": "ocid1.subnet.oc1.phx.app", "subnet_db": "ocid1.subnet.oc1.phx.db", "subnet_web": "ocid1.subnet.oc1.phx.web"}

    def summary(self, sid, name, excluded=False, rec=None):
        from types import SimpleNamespace as NS
        return NS(id=sid, migration_asset=NS(display_name=name), is_excluded_from_execution=excluded,
                  recommended_spec=rec)

    def test_user_spec_carries_blueprint_settings_and_no_image(self):
        d = O.target_asset_update(self.m, self.p, self.subnets, COMP, "AD-1", tags={"owner": "t"})
        u = d.user_spec
        self.assertEqual((d.type, d.is_excluded_from_execution), ("INSTANCE", False))
        self.assertEqual((u.shape, u.shape_config.ocpus, u.shape_config.memory_in_gbs), (E5, 4, 48))
        self.assertEqual((u.create_vnic_details.subnet_id, u.create_vnic_details.assign_public_ip), ("ocid1.subnet.oc1.phx.app", False))
        self.assertFalse(hasattr(u, "source_details") and u.source_details)        # OCM uses the replicated volume
        self.assertEqual(u.freeform_tags["ocio_blueprint"], "app-linux@v1")

    def test_matching_refuses_missing_and_ambiguous(self):
        sums = [self.summary("ta1", "a"), self.summary("ta2", "b"), self.summary("ta3", "b")]
        self.assertEqual(O.match_target_assets(sums, ["a"]), {"a": "ta1"})
        for names in (["b"], ["zzz"]):
            with self.subTest(names), self.assertRaises(ValueError):
                O.match_target_assets(sums, names)
        self.assertEqual(O.match_target_assets(sums, ["b"], mapping={"b": "ta3"}), {"b": "ta3"})

    def test_driver_excludes_first_includes_wave_and_verifies(self):
        from types import SimpleNamespace as NS
        rec = NS(shape=E5, shape_config=NS(ocpus=2, memory_in_gbs=16))
        c = FakeOCM({"ta-crm": ("crm-app-01", False, rec), "ta-other": ("hr-app-01", False, None),
                     "ta-done": ("old-01", True, None)})
        res = O.OCMDriver(c, "ocid1.ocmmigrationplan.oc1.phx.plan1", self.m, sleep=lambda s: None).apply_wave([self.p], self.subnets, COMP, "AD-1")
        self.assertEqual([u[0] for u in c.updates], ["ta-other", "ta-crm"])        # exclude BEFORE include
        self.assertTrue(c.assets["ta-other"].is_excluded_from_execution)
        self.assertFalse(c.assets["ta-crm"].is_excluded_from_execution)
        self.assertEqual(c.assets["ta-crm"].user_spec.shape_config.memory_in_gbs, 48)
        self.assertEqual(res["verified_included"], ["ta-crm"])
        self.assertEqual(res["sizing_differences"][0]["ocm_recommended"], (E5, 2, 16))   # from the full asset

    def test_driver_failure_midway_never_leaves_extra_assets_included(self):
        c = FakeOCM({"ta-crm": ("crm-app-01", False, None), "ta-other": ("hr-app-01", False, None)},
                    fail_on={"ta-crm": 400})                                       # include fails (not retryable)
        with self.assertRaises(O.OCMError):
            O.OCMDriver(c, "ocid1.ocmmigrationplan.oc1.phx.plan1", self.m, sleep=lambda s: None).apply_wave([self.p], self.subnets, COMP, "AD-1")
        self.assertTrue(c.assets["ta-other"].is_excluded_from_execution)          # fewer included, never more

    def test_driver_retries_throttling_and_detects_an_update_that_did_not_stick(self):
        c = FakeOCM({"ta-crm": ("crm-app-01", False, None)}, fail_on={"ta-crm": 429}, fail_times=2)
        O.OCMDriver(c, "ocid1.ocmmigrationplan.oc1.phx.plan1", self.m, sleep=lambda s: None).apply_wave([self.p], self.subnets, COMP, "AD-1")
        self.assertEqual(c.assets["ta-crm"].user_spec.shape, E5)                 # retried through two 429s
        lazy = FakeOCM({"ta-crm": ("crm-app-01", False, None)}, ignore_updates=True)
        with self.assertRaisesRegex(O.OCMError, "not applied"):
            O.OCMDriver(lazy, "ocid1.ocmmigrationplan.oc1.phx.plan1", self.m, attempts=3, sleep=lambda s: None).apply_wave(
                [self.p], self.subnets, COMP, "AD-1")

    def test_verification_checks_availability_domain_and_public_ip(self):
        class Drifting(FakeOCM):
            def update_target_asset(self, target_asset_id, details, **kw):
                super().update_target_asset(target_asset_id, details, **kw)
                if details.user_spec is not None:
                    self.assets[target_asset_id].user_spec.availability_domain = "AD-OTHER"
        c = Drifting({"ta-crm": ("crm-app-01", False, None)})
        with self.assertRaisesRegex(O.OCMError, "not applied"):
            O.OCMDriver(c, "ocid1.ocmmigrationplan.oc1.phx.plan1", self.m, attempts=2, sleep=lambda s: None).apply_wave(
                [self.p], self.subnets, COMP, "AD-1")

        class PublicIP(FakeOCM):
            def update_target_asset(self, target_asset_id, details, **kw):
                super().update_target_asset(target_asset_id, details, **kw)
                if details.user_spec is not None:
                    self.assets[target_asset_id].user_spec.create_vnic_details.assign_public_ip = True
        c = PublicIP({"ta-crm": ("crm-app-01", False, None)})
        with self.assertRaisesRegex(O.OCMError, "not applied"):
            O.OCMDriver(c, "ocid1.ocmmigrationplan.oc1.phx.plan1", self.m, attempts=2, sleep=lambda s: None).apply_wave(
                [self.p], self.subnets, COMP, "AD-1")

    def test_not_migrated_reads_created_resource_id(self):
        c = FakeOCM({"ta-a": ("a-01", True, None), "ta-b": ("b-01", True, None)})
        c.assets["ta-a"].created_resource_id = "ocid1.instance.x"
        c.assets["ta-b"].created_resource_id = None
        d = O.OCMDriver(c, "ocid1.ocmmigrationplan.oc1.phx.plan1", self.m, sleep=lambda s: None)
        self.assertEqual(d.not_migrated(["a-01", "b-01", "ghost"]), ["b-01", "ghost"])

    def test_driver_refuses_mapping_outside_the_plan(self):
        c = FakeOCM({"ta-crm": ("crm-app-01", False, None)})
        with self.assertRaisesRegex(O.OCMError, "not in migration plan"):
            O.OCMDriver(c, "ocid1.ocmmigrationplan.oc1.phx.plan1", self.m, sleep=lambda s: None).apply_wave(
                [self.p], self.subnets, COMP, "AD-1", mapping={"crm-app-01": "ta-elsewhere"})
        self.assertEqual(c.updates, [])

    def _cli(self, d, *extra):
        return ["ocm-wave", "--inventory", os.path.join(HERE, "examples", "inventory.csv"), "--wave", "1",
                "--migration-plan", "ocid1.ocmmigrationplan.oc1.phx.plan1", "--subnet-map", f"{d}/sub.json", "--compartment", COMP,
                "--availability-domain", "AD-1", "--tag", "cost_center=a", "--tag", "owner=b",
                "--journal", f"{d}/ocm.jsonl", *extra]

    def test_cli_dry_run_sends_nothing(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        _write(f"{d}/sub.json", json.dumps(self.subnets))
        client = mock.Mock()
        self.assertEqual(M.main(self._cli(d), out=out.append, ocm_client=client), 0, out[-1])
        self.assertIn("target_asset_updates", json.loads(out[-1]))
        self.assertEqual(client.mock_calls, [])

    def test_plan_id_covers_the_migration_plan_and_subnets(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        _write(f"{d}/sub.json", json.dumps(self.subnets))
        M.main(self._cli(d), out=out.append, ocm_client=mock.Mock())
        pid = json.loads(out[-1])["plan_id"]
        other_plan = [x if x != "ocid1.ocmmigrationplan.oc1.phx.plan1" else "ocid1.ocmmigrationplan.oc1.phx.other" for x in self._cli(d)]
        M.main(other_plan, out=out.append, ocm_client=mock.Mock())
        self.assertNotEqual(json.loads(out[-1])["plan_id"], pid)
        _write(f"{d}/sub.json", json.dumps(dict(self.subnets, subnet_app="ocid1.subnet.oc1.phx.elsewhere")))
        M.main(self._cli(d), out=out.append, ocm_client=mock.Mock())
        self.assertNotEqual(json.loads(out[-1])["plan_id"], pid)

    def test_cli_apply_needs_reviewed_plan_quota_and_approval_in_prod(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        _write(f"{d}/sub.json", json.dumps(self.subnets))
        M.main(self._cli(d), out=out.append, ocm_client=mock.Mock())
        pid, apps = json.loads(out[-1])["plan_id"], json.loads(out[-1])["apps"]
        with open(os.path.join(HERE, "examples", "inventory.csv"), newline="") as f:
            names = [r["name"] for r in csv.DictReader(f) if r["app"] in apps]
        self.assertTrue(names)
        client = FakeOCM({f"ta-{n}": (n, False, None) for n in names})
        with self.assertRaises(SystemExit):                                        # no --plan-id
            M.main(self._cli(d, "--apply"), out=out.append, ocm_client=client, quota=QUOTA)
        self.assertEqual(M.main(self._cli(d, "--apply", "--plan-id", "000000000000", "--approve-by", "x"),
                                out=out.append, ocm_client=client, quota=QUOTA), 2)     # not the reviewed plan
        self.assertEqual(M.main(self._cli(d, "--apply", "--plan-id", pid), out=out.append, ocm_client=client,
                                quota=QUOTA), 2)                                       # prod: no approver
        tight = C.StaticQuota({"standard-e5-core-count": 1, "standard-e5-memory-count": 1})
        self.assertEqual(M.main(self._cli(d, "--apply", "--plan-id", pid, "--approve-by", "J. Doe"),
                                out=out.append, ocm_client=client, quota=tight), 2)    # does not fit the quota
        self.assertEqual(client.updates, [])
        self.assertEqual(M.main(self._cli(d, "--apply", "--plan-id", pid, "--approve-by", "J. Doe"),
                                out=out.append, ocm_client=client, quota=QUOTA), 0, out[-1])
        self.assertEqual(json.loads(out[-1])["approval"]["by"], "J. Doe")
        self.assertEqual(sorted(json.loads(out[-1])["verified_included"]), sorted(f"ta-{n}" for n in names))
        j = Journal(f"{d}/ocm.jsonl")
        self.assertTrue(j.verify())
        self.assertEqual([e["event"] for e in j.entries], ["approval", "ocm_before_state", "ocm_wave_applied"])

    def test_cli_wave_waits_for_the_waves_it_depends_on(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        _write(f"{d}/sub.json", json.dumps(self.subnets))
        _write(f"{d}/inv.csv", "name,app,tier,os,vcpus,memory_gb,depends_on_apps\n"
                               "core-db-01,core,db,Oracle Linux 8,4,16,\ncrm-app-01,crm,app,Oracle Linux 8,4,16,core\n")
        args = [x if x != os.path.join(HERE, "examples", "inventory.csv") else f"{d}/inv.csv" for x in self._cli(d)]
        args = [x if x != "1" else "2" for x in args] + ["--env", "dev"]
        M.main(args, out=out.append, ocm_client=mock.Mock())
        pid = json.loads(out[-1])["plan_id"]
        c = FakeOCM({"ta-core": ("core-db-01", True, None), "ta-crm": ("crm-app-01", True, None)})
        c.assets["ta-core"].created_resource_id = None                    # wave 1 not migrated yet
        self.assertEqual(M.main(args + ["--apply", "--plan-id", pid], out=out.append, ocm_client=c, quota=QUOTA), 2)
        self.assertIn("not yet migrated", out[-1])
        self.assertEqual(c.updates, [])
        c.assets["ta-core"].created_resource_id = "ocid1.instance.core"
        self.assertEqual(M.main(args + ["--apply", "--plan-id", pid], out=out.append, ocm_client=c, quota=QUOTA), 0, out[-1])


class FakeOCM:
    """Stateful stand-in for oci.cloud_migrations.MigrationClient: list / get / update target assets.
    assets: {id: (source_name, excluded, recommended_spec)}. fail_on: {id: status} for update calls
    (fail_times of them); ignore_updates: accept updates but change nothing (to test verification)."""

    def __init__(self, assets, fail_on=None, fail_times=99, ignore_updates=False):
        from types import SimpleNamespace as NS
        self.assets = {k: NS(id=k, migration_asset=NS(display_name=n), is_excluded_from_execution=x,
                             recommended_spec=r, user_spec=None, created_resource_id=None)
                       for k, (n, x, r) in assets.items()}
        self.fail_on, self.fail_left, self.ignore, self.updates = dict(fail_on or {}), fail_times, ignore_updates, []

    def list_target_assets(self, migration_plan_id, page=None):
        from types import SimpleNamespace as NS
        return NS(data=NS(items=list(self.assets.values())), next_page=None)

    def get_target_asset(self, target_asset_id):
        from types import SimpleNamespace as NS
        return NS(data=self.assets[target_asset_id])

    def update_target_asset(self, target_asset_id, details, **kw):
        import oci
        if target_asset_id in self.fail_on and self.fail_left > 0:
            self.fail_left -= 1
            raise oci.exceptions.ServiceError(self.fail_on[target_asset_id], "Err", {}, "injected")
        self.updates.append((target_asset_id, details))
        if self.ignore:
            return
        a = self.assets[target_asset_id]
        if details.is_excluded_from_execution is not None:
            a.is_excluded_from_execution = details.is_excluded_from_execution
        if details.user_spec is not None:
            import copy
            a.user_spec = copy.deepcopy(details.user_spec)       # the server keeps its own copy


# ------------------------------------------------------------------ command-line tools


class ReviewRound2Tests(unittest.TestCase):
    """Defects found by the second independent review, each reproduced first, then fixed."""

    def setUp(self):
        self.jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")

    def test_resume_after_waves_are_renumbered_does_not_duplicate(self):
        fake = FakeOCI(crash_after_create={"b1"})
        v1 = [W("a1", "a"), W("b1", "b", deps=["a"])]                    # b in wave 2
        with self.assertRaises(Crash):
            P.run(v1, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        v2 = [W("a1", "a"), W("b1", "b")]                                 # dependency dropped: b moves to wave 1
        rep = P.run(v2, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        self.assertTrue(all(w["status"] == "SUCCEEDED" for w in rep.wave_results), rep.wave_results)
        self.assertEqual(duplicates(fake), 0)

    def test_interrupted_run_split_across_new_waves_is_refused(self):
        fake = FakeOCI(crash_after_create={"b2"})
        v1 = [W("a1", "a"), W("b1", "b", deps=["a"]), W("b2", "b", deps=["a"])]
        with self.assertRaises(Crash):
            P.run(v1, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        v2 = [W("a1", "a"), W("b1", "b", deps=["a"]), W("b2", "c", deps=["b"])]   # b2 now in a later wave
        rep = P.run(v2, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        self.assertIn("BLOCKED_CHANGED", [w["status"] for w in rep.wave_results])
        self.assertEqual(duplicates(fake), 0)

    def test_skipped_vms_are_checked_in_oci_not_just_the_journal(self):
        fake = FakeOCI()
        wls = [W("a1", "a")]
        P.run(wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        rid = next(r for r, x in fake.res.items() if x["params"].get("display_name") == "a1")
        fake.res[rid]["state"] = GONE                                     # deleted by hand
        rep = P.run(wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        self.assertEqual(rep.wave_results[0]["status"], "SUCCEEDED")
        live = [x for x in fake.live().values() if x["params"].get("display_name") == "a1"]
        self.assertEqual(len(live), 1)                                    # created again, once
        rid2 = next(r for r, x in fake.res.items() if x["params"].get("display_name") == "a1" and x["state"] == "RUNNING")
        fake.res[rid2]["state"] = "STOPPED"                               # exists, but not ready
        rep = P.run(wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        self.assertEqual(rep.wave_results[0]["status"], "BLOCKED_STATE", rep.wave_results)

    def test_failed_rollback_is_never_reported_as_success(self):
        class Blind(FakeOCI):
            blind = None

            def state(self, kind, rid):
                if rid == self.blind:
                    raise ProviderError(503, "blip")
                return super().state(kind, rid)

            def delete(self, kind, rid):
                if self.res[rid]["params"]["display_name"] == "a1":
                    self.blind = rid
                    raise ProviderError(503, "delete not accepted")            # rollback of a1 fails
                return super().delete(kind, rid)
        fake = Blind(fail_provision={"a2"})
        wls = [W("a1", "a"), W("a2", "a")]
        mk = engines(fake, self.jp, retry=RetryPolicy(2, 0, 0))
        rep = P.run(wls, BLUEPRINTS, settings(), mk, quota=QUOTA)
        self.assertEqual(rep.wave_results[0]["status"], "FAILED_ROLLBACK_INCOMPLETE")
        fake.fail_provision.clear()
        fake.blind = None                                                 # a1 is still RUNNING: delete never happened
        rep = P.run(wls, BLUEPRINTS, settings(), mk, quota=QUOTA)
        self.assertEqual(rep.wave_results[0]["status"], "BLOCKED_STATE", rep.wave_results)
        self.assertIn("rollback or teardown failed", rep.wave_results[0]["why"][0])

    def test_unexpected_error_still_rolls_back(self):
        class Broken(FakeOCI):
            def create(self, kind, *a):
                if kind == "subnet":
                    raise TypeError("SDK model rejected a value")
                return super().create(kind, *a)
        fake = Broken()
        e = Engine(fake, Journal(self.jp), poll_seconds=0, sleep=lambda s: None)
        r = e.apply(F.target_network("t", "dev", COMP, TAGS, "10.0.0.0/16", {"app": "10.0.2.0/24"}))
        self.assertEqual(r.status, "FAILED_ROLLED_BACK")
        self.assertIn("unexpected error", r.error)
        self.assertEqual(fake.live(), {})

    def test_create_that_may_exist_is_reported_with_its_tags(self):
        class Transport(FakeOCI):                                          # timeout / reset: no HTTP status
            def create(self, kind, *a):
                if kind == "subnet":
                    raise ProviderError(0, "transport error: ReadTimeout", retryable=True)
                return super().create(kind, *a)
        for status, reported in ((503, True), ("transport", True), (400, False), (429, False)):
            with self.subTest(status=status):
                fake = Transport() if status == "transport" else FakeOCI(faults={("create", "subnet"): [status] * 10})
                jp = os.path.join(tempfile.mkdtemp(), "j")
                e = Engine(fake, Journal(jp), poll_seconds=0, sleep=lambda s: None, retry=RetryPolicy(2, 0, 0))
                r = e.apply(F.target_network("t", "dev", COMP, TAGS, "10.0.0.0/16", {"app": "10.0.2.0/24"}))
                unconfirmed = [o for o in r.orphans if o["id"] is None]
                self.assertEqual(bool(unconfirmed), reported, r.orphans)
                if reported:
                    self.assertIn("ocio_step=subnet_app", unconfirmed[0]["error"])
                    self.assertEqual(r.status, "FAILED_ROLLBACK_INCOMPLETE")

    def test_teardown_reports_unconfirmed_creates(self):
        fake = FakeOCI(crash_after_create={"t-app"})
        e = Engine(fake, Journal(self.jp), poll_seconds=0, sleep=lambda s: None)
        wf = F.target_network("t", "dev", COMP, TAGS, "10.0.0.0/16", {"app": "10.0.2.0/24"})
        with self.assertRaises(Crash):
            e.apply(wf)
        rid = [x for x in Journal(self.jp).entries if x.get("event") == "run_started"][0]["run_id"]
        r = e.teardown(wf, rid)
        self.assertEqual(r.status, "TEARDOWN_INCOMPLETE")
        self.assertTrue(any(o["id"] is None and o["step"] == "subnet_app" for o in r.orphans), r.orphans)

    def test_wave_is_skipped_when_a_wave_it_depends_on_failed(self):
        fake = FakeOCI(fail_provision={"a1"})
        wls = [W("a1", "a"), W("b1", "b", deps=["a"]), W("c1", "c")]
        rep = P.run(wls, BLUEPRINTS, settings(stop_on_wave_failure=False, max_apps_per_wave=1),
                    engines(fake, self.jp), quota=QUOTA)
        st = {tuple(w["apps"]): w["status"] for w in rep.wave_results}
        self.assertEqual(st[("a",)], "FAILED_ROLLED_BACK")
        self.assertEqual(st[("b",)], "SKIPPED_DEPENDENCY")
        self.assertEqual(st[("c",)], "SUCCEEDED")                         # independent wave still runs
        self.assertFalse(any(x["params"].get("display_name") == "b1" for x in fake.live().values()))

    def test_static_quota_shrinks_as_waves_land(self):
        fake = FakeOCI()
        wls = [W("a1", "a", vcpus=8, mem=32), W("b1", "b", vcpus=8, mem=32)]   # 4 OCPUs / 32 GB each
        q = C.StaticQuota({"standard-e5-core-count": 6, "standard-e5-memory-count": 64})
        rep = P.run(wls, BLUEPRINTS, settings(quota_headroom=0.0, max_apps_per_wave=1), engines(fake, self.jp), quota=q)
        self.assertEqual([w["status"] for w in rep.wave_results], ["SUCCEEDED", "BLOCKED_QUOTA"])

    def test_policy_violations_stop_before_any_engine_is_built(self):
        bad_tags = P.Settings("dev", COMP, {"owner": "x"}, "t", "10.0.0.0/16",
                              {"web": "10.0.1.0/24", "app": "10.0.2.0/24", "db": "10.0.3.0/24"})
        rep = P.run([W("a1", "a")], BLUEPRINTS, bad_tags, lambda: self.fail("no engine may be built"), quota=QUOTA)
        self.assertTrue(rep.policy_violations)
        self.assertEqual(rep.wave_results, [])

    def test_plan_id_covers_every_input_that_reaches_an_api(self):
        wls = [W("a1", "a")]
        base = P.run(wls, BLUEPRINTS, settings(), None, execute=False).plan_id
        other_tags = P.Settings("dev", COMP, dict(TAGS, owner="someone-else"), "t", "10.0.0.0/16",
                                {"web": "10.0.1.0/24", "app": "10.0.2.0/24", "db": "10.0.3.0/24"})
        self.assertNotEqual(P.run(wls, BLUEPRINTS, other_tags, None, execute=False).plan_id, base)
        for kw in ({"availability_domain": "AD-2"}, {"bound_inputs": {"image_map": {"IMAGE_OL8": "ocid1.image.x"}}}):
            with self.subTest(kw=kw):
                self.assertNotEqual(P.run(wls, BLUEPRINTS, settings(**kw), None, execute=False).plan_id, base)
        self.assertNotEqual(P.run(wls, BLUEPRINTS, P.Settings("dev", COMP, TAGS, "other", "10.0.0.0/16",
                            {"web": "10.0.1.0/24", "app": "10.0.2.0/24", "db": "10.0.3.0/24"}), None,
                            execute=False).plan_id, base)

    def test_resolve_records_an_operator_confirmed_deletion(self):
        import migrate as M
        fake = FakeOCI()
        P.run([W("a1", "a")], BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        live = P.existing_steps(Journal(self.jp))["a1"]
        with self.assertRaises(SystemExit):
            M.main(["resolve", "--journal", self.jp, "--step", "a1", "--id", "ocid1.wrong", "--by", "x"], out=lambda *_: None)
        self.assertEqual(M.main(["resolve", "--journal", self.jp, "--step", "a1", "--id", live["id"], "--by", "J. Doe"],
                                out=lambda *_: None), 0)
        self.assertNotIn("a1", P.existing_steps(Journal(self.jp)))
        self.assertEqual(Journal(self.jp).entries[-1]["by"], "J. Doe")
        self.assertTrue(Journal(self.jp).verify())


class ReviewRound3Tests(unittest.TestCase):
    """Re-review of the round-2 fixes: the advertised remedies must actually work."""

    def setUp(self):
        self.jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")

    def test_teardown_clears_a_blocked_state_after_a_failed_rollback(self):
        import migrate as M
        fake = FakeOCI(fail_provision={"a2"}, faults={("delete", "instance"): [0] + [500] * 6})
        wls = [W("a1", "a"), W("a2", "a")]
        mk = engines(fake, self.jp, retry=RetryPolicy(6, 0, 0))
        r1 = P.run(wls, BLUEPRINTS, settings(), mk, quota=QUOTA)
        self.assertEqual(r1.wave_results[0]["status"], "FAILED_ROLLBACK_INCOMPLETE")
        rid = r1.wave_results[0]["run_ids"][0]
        fake.fail_provision.clear()
        self.assertEqual(P.run(wls, BLUEPRINTS, settings(), mk, quota=QUOTA).wave_results[0]["status"], "BLOCKED_STATE")
        out = []
        self.assertEqual(M.main(["teardown", "--journal", self.jp, "--run-id", rid], out=out.append), 0)   # dry run
        self.assertIn("rollback_failed", out[-1])
        self.assertEqual(M.main(["teardown", "--journal", self.jp, "--run-id", rid, "--apply"], out=out.append,
                                provider_factory=lambda: fake), 0, out[-1])
        rep = P.run(wls, BLUEPRINTS, settings(), mk, quota=QUOTA)
        self.assertEqual(rep.wave_results[0]["status"], "SUCCEEDED", rep.wave_results)
        self.assertEqual(duplicates(fake), 0)

    def test_teardown_clears_a_blocked_change_and_closes_the_run(self):
        fake = FakeOCI(crash_after_create={"b1"})
        v1 = [W("a1", "a"), W("b1", "b", deps=["a"]), W("b2", "b", deps=["a"])]
        with self.assertRaises(Crash):
            P.run(v1, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        v2 = [W("a1", "a"), W("b1", "b", vcpus=8, deps=["a"]), W("b2", "b", deps=["a"])]   # resized since
        rep = P.run(v2, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        self.assertIn("BLOCKED_CHANGED", [w["status"] for w in rep.wave_results])
        rid = [r for r, _, _, steps in P.unfinished_runs(Journal(self.jp)) if "b1" in steps][0]
        td = engines(fake, self.jp)().teardown(None, rid)
        self.assertEqual(td.status, "TEARDOWN_INCOMPLETE")       # b1's create was never confirmed: reported
        self.assertTrue(any(o["step"] == "b1" and o["id"] is None for o in td.orphans))
        # The operator finds the tagged instance and deletes it, then records the run as handled:
        for x in fake.res.values():
            if x["params"].get("display_name") == "b1":
                x["state"] = GONE
        Journal(self.jp).append(run_id=rid, event="run_torn_down", by="operator")
        self.assertEqual([r for r, *_ in P.unfinished_runs(Journal(self.jp))], [])
        rep = P.run(v2, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        self.assertTrue(all(w["status"] == "SUCCEEDED" for w in rep.wave_results), rep.wave_results)
        self.assertEqual(duplicates(fake), 0)

    def test_complete_teardown_closes_the_run(self):
        fake = FakeOCI()
        e = engines(fake, self.jp)()
        wf = F.target_network("t", "dev", COMP, TAGS, "10.0.0.0/16", {"app": "10.0.2.0/24"})
        orig, died = fake.state, []

        def state(kind, rid):
            if kind == "subnet" and not died:
                died.append(rid)
                raise Crash("died while waiting")
            return orig(kind, rid)
        fake.state = state
        with self.assertRaises(Crash):
            e.apply(wf)
        rid = P.unfinished_runs(Journal(self.jp))[0][0]
        self.assertEqual(e.teardown(None, rid).status, "TORN_DOWN")          # kinds read from the journal
        self.assertEqual(P.unfinished_runs(Journal(self.jp)), [])
        self.assertEqual(fake.live(), {})

    def test_vm_deleted_by_hand_inside_an_interrupted_run_gets_a_new_token(self):
        fake = FakeOCI(crash_after_create={"a2"})
        wls = [W("a1", "a"), W("a2", "a")]
        with self.assertRaises(Crash):
            P.run(wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        for x in fake.res.values():
            if x["params"].get("display_name") == "a1" and x["kind"] == "instance":
                x["state"] = GONE                                           # a1 was ready; now deleted by hand
        rep = P.run(wls, BLUEPRINTS, settings(), engines(fake, self.jp), quota=QUOTA)
        self.assertEqual(rep.wave_results[0]["status"], "SUCCEEDED", rep.wave_results)
        live = sorted(x["params"]["display_name"] for x in fake.live().values() if x["kind"] == "instance")
        self.assertEqual(live, ["a1", "a2"])

    def test_hub_caller_does_not_join_apps_with_different_backends(self):
        assets = [asset("core-01", "10.0.0.1"), asset("core-02", "10.0.0.2"), asset("core-03", "10.0.0.3"),
                  asset("core-04", "10.0.0.4"), asset("xdb", "10.0.1.1", tags={"app": "ledger", "tier": "db"}),
                  asset("ydb", "10.0.1.2", tags={"app": "hr", "tier": "db"}),
                  asset("mon-01", "10.0.9.9", tags={"app": "monitoring", "tier": "app"})]
        flows = [("10.0.0.1", "10.0.1.1", 1521, 100), ("10.0.0.2", "10.0.1.1", 1521, 100),
                 ("10.0.0.3", "10.0.1.2", 5432, 100), ("10.0.0.4", "10.0.1.2", 5432, 100)]
        flows += [("10.0.9.9", f"10.0.0.{i}", 8080, 50) for i in (1, 2, 3, 4)]
        r = D.discover(assets, flows)
        self.assertTrue({"core-01", "core-02", "core-03", "core-04"} <= set(r.report()["low_confidence_vms"]))
        self.assertNotEqual(r.app["core-01"].value, r.app["core-03"].value)
        # Replicas behind one balancer that call the same backend stay trusted.
        same = flows[:2] + [("10.0.9.9", "10.0.0.1", 8080, 50), ("10.0.9.9", "10.0.0.2", 8080, 50)]
        self.assertEqual(D.discover(assets, same).app["core-01"].confidence, 0.8)
        # A caller of many apps (a scheduler) is a hub: being called by it joins nothing.
        many = [asset(f"svc{k}-app-01", f"10.0.2.{k}") for k in range(5)]
        hub = [("10.0.9.9", f"10.0.2.{k}", 8080, 10) for k in range(5)]
        r3 = D.discover(assets[:2] + many + assets[6:], hub + [("10.0.9.9", "10.0.0.1", 8080, 50),
                                                                ("10.0.9.9", "10.0.0.2", 8080, 50)])
        self.assertLess(r3.app["core-01"].confidence, 0.6)


class DiscoveryRound2Tests(unittest.TestCase):
    def test_unknown_private_source_must_be_placed_by_a_reviewer(self):
        assets = [asset("crm-app-01", "10.0.0.2"), asset("ledger-db-01", "10.0.0.8")]
        flows = [("10.0.0.2", "10.0.0.8", 1521, 50), ("10.0.0.77", "10.0.0.8", 1521, 40),   # unlisted VM / 2nd NIC
                 ("203.0.113.5", "10.0.0.2", 443, 999)]                                        # public users: fine
        r = D.discover(assets, flows)
        self.assertEqual([u["src_ip"] for u in r.unresolved_sources], ["10.0.0.77"])
        with self.assertRaisesRegex(ValueError, "10.0.0.77"):
            r.to_workloads()
        r.to_workloads({"external_ok": ["10.0.0.77"], "reviewed_by": "ann"})

    def test_vip_traffic_reaches_every_vm_behind_it_and_mixed_vips_are_flagged(self):
        assets = [asset("crm-app-01", "10.0.0.2"), asset("ledger-db-01", "10.0.0.8", tags={"app": "ledger"}),
                  asset("risk-db-01", "10.0.0.9", tags={"app": "risk"})]
        r = D.discover(assets, [("10.0.0.2", "10.9.9.9", 1521, 80)],
                       vips={"10.9.9.9": ["ledger-db-01", "risk-db-01"]})
        self.assertEqual({d.key: d.connections for d in r.deps}, {"crm->ledger": 80, "crm->risk": 80})
        flagged = set(r.report()["low_confidence_vms"])
        self.assertTrue({"ledger-db-01", "risk-db-01"} <= flagged)

    def test_vms_behind_one_vip_belong_together_even_when_reached_directly(self):
        # Two RAC nodes behind one SCAN address, each reached directly by a different client: without the
        # VIP map nothing in the traffic joins them; the VIP map is declared evidence that it should.
        assets = [asset("ledger-db-01", "10.0.0.8"), asset("ledger-db-02", "10.0.0.9"),
                  asset("crm-app-01", "10.0.0.2", tags={"app": "crm", "tier": "app"}),
                  asset("hr-app-01", "10.0.0.3", tags={"app": "hr", "tier": "app"})]
        flows = [("10.0.0.2", "10.0.0.8", 1521, 60), ("10.0.0.3", "10.0.0.9", 1521, 60)]
        self.assertNotEqual(D.discover(assets, flows).app["ledger-db-01"].value,
                            D.discover(assets, flows).app["ledger-db-02"].value)
        r = D.discover(assets, flows, vips={"10.9.9.9": ["ledger-db-01", "ledger-db-02"]})
        self.assertEqual(r.app["ledger-db-01"].value, r.app["ledger-db-02"].value)
        self.assertEqual(r.app["ledger-db-01"].confidence, 0.8)

    def test_shared_backend_does_not_silently_merge_two_apps_with_one_name(self):
        A_ = lambda n, ip, **kw: asset(n, ip, **kw)
        assets = [A_("prod-app-01", "10.0.0.1"), A_("prod-app-02", "10.0.0.2"), A_("prod-app-03", "10.0.0.3"),
                  A_("prod-app-04", "10.0.0.4"), A_("shared-db-01", "10.0.0.9", tags={"app": "shared", "tier": "db"}),
                  A_("xweb-web-01", "10.0.1.1"), A_("yweb-web-01", "10.0.1.2")]
        flows = [("10.0.1.1", "10.0.0.1", 8080, 500), ("10.0.1.1", "10.0.0.2", 8080, 500),
                 ("10.0.1.2", "10.0.0.3", 8080, 500), ("10.0.1.2", "10.0.0.4", 8080, 500)]
        flows += [(f"10.0.0.{i}", "10.0.0.9", 1521, 300) for i in (1, 2, 3, 4)]
        r = D.discover(assets, flows)
        flagged = set(r.report()["low_confidence_vms"])
        self.assertTrue({"prod-app-01", "prod-app-02", "prod-app-03", "prod-app-04"} <= flagged,
                        {n: r.app[n] for n in ("prod-app-01", "prod-app-03")})
        # Replicas behind one client stay trusted (the load-balanced pattern).
        r2 = D.discover(assets[:2] + assets[4:6], flows[:2] + flows[4:6])
        self.assertEqual(r2.app["prod-app-01"].confidence, 0.8)


class DeterminismTests(unittest.TestCase):
    """Approvals are bound to a plan id computed in one process and checked in another, and the published
    figures are reproduced from fixed seeds. Both break if anything depends on set order, which follows
    Python's per-process hash seed. (Found when two runs of the evidence script disagreed.)"""

    SCRIPT = (
        "import hashlib, json, sys\n"
        "sys.path.insert(0, %r)\n"
        "from ocio import synth, discovery as D, pipeline as P, agent as A\n"
        "from ocio.catalog import BLUEPRINTS\n"
        "a, f, l, t = synth.estate(40, seed=2)\n"
        "rep = D.discover(a, f, l).report()\n"
        "w, _ = synth.inventory(40, seed=2)\n"
        "s = P.Settings('prod', 'c', {'cost_center': 'a', 'owner': 'b'}, 'm', '10.0.0.0/16',\n"
        "               {'web': '10.0.1.0/24', 'app': '10.0.2.0/24', 'db': '10.0.3.0/24'})\n"
        "r = P.run(w, BLUEPRINTS, s, None, execute=False, proposer=A.RuleProposer(BLUEPRINTS, {}))\n"
        "print(hashlib.sha256(json.dumps([f, sorted(t['deps']), rep, r.waves], sort_keys=True,\n"
        "      default=str).encode()).hexdigest(), r.plan_id)\n")

    def test_same_inputs_same_results_under_any_hash_seed(self):
        import subprocess
        outs = set()
        for h in ("0", "1", "7"):
            p = subprocess.run([sys.executable, "-B", "-c", self.SCRIPT % HERE], capture_output=True, text=True,
                               env=dict(os.environ, PYTHONHASHSEED=h), timeout=120)
            self.assertEqual(p.returncode, 0, p.stderr)
            outs.add(p.stdout)
        self.assertEqual(len(outs), 1, outs)


class CLITests(unittest.TestCase):
    @mock.patch("time.sleep", lambda s: None)        # FakeOCI needs polls; no real waiting in tests
    def test_live_smoke_dry_run_touches_nothing_and_apply_cleans_up(self):
        import live_smoke as L
        d, out = tempfile.mkdtemp(), []
        rc = L.main(["--compartment", COMP, "--availability-domain", "AD-1", "--journal", os.path.join(d, "a")],
                    provider_factory=lambda: self.fail("dry run must not create a provider"), out=out.append)
        self.assertEqual(rc, 0)
        fake, out = FakeOCI(), []
        rc = L.main(["--compartment", COMP, "--availability-domain", "AD-1", "--apply", "--with-instance",
                     "--image-ocid", "ocid1.image.oc1..x", "--journal", os.path.join(d, "b")],
                    provider_factory=lambda: fake, out=out.append)
        self.assertEqual((rc, json.loads(out[-1])["result"], fake.live()), (0, "PASS", {}))

    @mock.patch("time.sleep", lambda s: None)        # FakeOCI needs polls; no real waiting in tests
    def test_migrate_discover_plan_run(self):
        import migrate as M
        d, out = tempfile.mkdtemp(), []
        est = os.path.join(HERE, "examples", "estate")
        M.main(["discover", "--assets", f"{est}/assets.csv", "--flows", f"{est}/flows.csv", "--listeners",
                f"{est}/listeners.csv", "--out", f"{d}/f.json"], out=out.append)
        with open(f"{d}/f.decisions-template.json") as f:
            tpl = json.load(f)
        _write(f"{d}/dec.json", json.dumps({"dependencies": tpl["dependencies"]}))
        M.main(["discover", "--assets", f"{est}/assets.csv", "--flows", f"{est}/flows.csv", "--out", f"{d}/f.json",
                "--decisions", f"{d}/dec.json", "--inventory-out", f"{d}/inv.csv"], out=out.append)
        self.assertEqual(M.main(["plan", "--inventory", f"{d}/inv.csv", "--env", "dev", "--tag", "cost_center=a",
                                 "--tag", "owner=b"], out=out.append), 0)
        base = ["run", "--inventory", f"{d}/inv.csv", "--compartment", COMP, "--availability-domain", "AD-1",
                "--journal", f"{d}/run.jsonl", "--tag", "cost_center=a", "--tag", "owner=b"]
        M.main(base, out=out.append)                                       # dry run prints the plan id
        pid = json.loads(out[-2])["plan_id"]
        with self.assertRaises(SystemExit):                               # --apply without a reviewed plan
            M.main(base + ["--apply"], out=out.append, provider_factory=FakeOCI, quota=QUOTA)
        self.assertEqual(M.main(base + ["--apply", "--approve-by", "tester", "--plan-id", "000000000000"],
                                out=out.append, provider_factory=FakeOCI, quota=QUOTA), 2)   # stale plan id: stops
        fake = FakeOCI()
        rc = M.main(base + ["--apply", "--approve-by", "tester", "--plan-id", pid], out=out.append,
                    provider_factory=lambda: fake, quota=QUOTA)
        self.assertEqual(rc, 0, out[-1])
        self.assertTrue(json.loads(out[-1])["journal_intact"])
        untagged = [x for x in base if x not in ("--tag", "cost_center=a", "owner=b")]
        out2 = []
        plan_untagged = ["plan", "--inventory", f"{d}/inv.csv", "--compartment", COMP]
        self.assertEqual(M.main(plan_untagged, out=out2.append), 2)       # no default tags: the dry run says so
        self.assertTrue(any("required tag" in v for v in json.loads(out2[-1])["summary"]["policy_violations"]))
        pid2 = json.loads(out2[-1])["plan_id"]
        self.assertNotEqual(pid2, pid)                                     # tags are part of what is approved
        self.assertEqual(M.main(untagged, out=out2.append), 2)             # run's dry run: same exit rule as plan
        fresh = [x.replace("run.jsonl", "run2.jsonl") for x in untagged]
        untouched = FakeOCI()
        self.assertEqual(M.main(fresh + ["--apply", "--approve-by", "t", "--plan-id", pid2], out=out2.append,
                                provider_factory=lambda: untouched, quota=QUOTA), 2)  # --apply stops on policy...
        self.assertEqual(untouched.calls, [])                                  # ...before any API call


if __name__ == "__main__":
    unittest.main()
