"""Mutation harness: break one guarantee at a time in a COPY of the code; the suite must fail.

Each mutant names a guarantee and the exact line that provides it, and replaces that line with one that
does not. A SURVIVED mutant is a guarantee no test would notice losing. The harness refuses to run if any
target no longer matches the code exactly once (after a refactor, a stale mutant guards nothing while
still looking like coverage), and if the unmodified copy does not pass its own suite.

Run:  python -B mutate.py          (MUTATE_JOBS=N parallel copies, default CPU count; MUTATE_TIMEOUT=s)

How it works: each mutant is (name, file under ocio/, exact original text, replacement). For each one the
package (ocio, tests, scripts, examples, and the docs the tests read) is copied to a temporary folder, the one
replacement is made there, and the whole unit-test suite runs in that copy. The working tree is never modified.

Output: "control (unmodified code): exit 0", then one line per mutant, "KILLED <name>" (a test failed: the
guarantee is guarded), "TIMEOUT <name>" (the suite hung: also detected, reported apart) or "SURVIVED <name>" (no
test noticed: a gap to close with a test), then "D/N detected (...); S survived; control exit 0".
Exit codes: 0 nothing survived; 1 at least one survived; 2 stale targets or a failing control run (nothing run).
Redirect stdout to a file (examples/mutate_results.txt) to keep a record."""
import os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
M = [
    ("locked-field override allowed", "factory.py", "    if locked:\n", "    if False:\n"),
    ("missing blueprint defaults to first", "factory.py",
     "    if not matches:\n        raise FactoryError", "    if not matches:\n        matches = list(blueprints)[:1]\n    if False:\n        raise FactoryError"),
    ('sizing rounds down', 'factory.py', 'math.ceil(w.vcpus / VCPUS_PER_OCPU.get(shape, 2))', 'w.vcpus // VCPUS_PER_OCPU.get(shape, 2)'),
    ("wave ignores dependencies", "factory.py", "level[g] = 1 + max((level[d] for d in gdeps[g]), default=-1)", "level[g] = 0"),
    ("overrides not reported", "factory.py", "return Placement(w, bp, params, dict(overrides))", "return Placement(w, bp, params, {})"),
    ("placement mutated by wave build", "factory.py", "params = dict(p.params)                       # copy", "params = p.params  # copy"),
    ("policy gates skipped", "engine.py", "        if violations:\n            self.j.append", "        if False:\n            self.j.append"),
    ("no retry on throttling", "engine.py", "if not e.transient or attempt", "if True or attempt"),
    ("4xx retried", "providers.py", "return self.status in TRANSIENT", "return True"),
    ("no rollback", "engine.py", "            self._rollback(rid, created, res)\n", "            pass\n"),
    ("rollback in creation order", "engine.py", "in reversed(created):", "in created:"),
    ("orphans hidden", "engine.py", '                res.orphans.append({"step": sid, "id": ocid, "error": str(e)})', "                pass"),
    ("random retry token (no idempotency)", "engine.py",
     'return hashlib.sha256(f"{run_id}/{step_id}/{generation}".encode()).hexdigest()[:64]', "return uuid.uuid4().hex"),
    ("token ignores rollback generation", "engine.py", 'f"{run_id}/{step_id}/{generation}"', 'f"{run_id}/{step_id}"'),
    ("resume ignores journal", "engine.py", "        prior = self.j.state(rid)\n", "        prior = {}\n"),
    ("resume accepts changed workflow", "engine.py", 'started[0]["workflow_hash"] != wf_hash', "False"),
    ("no wait for ready", "engine.py", "        self._wait(step.kind, ocid, READY[step.kind])\n        out", "        out"),
    ('wait timeout ignored', 'engine.py', '            if now >= deadline:', '            if False:'),
    ('journal chain not verified', 'journal.py', '            if _h(prev, body) != e.get("hash"):', '            if False:'),
    ("public prod subnet allowed", "policy.py", 'if s.kind == "subnet" and not s.params.get("prohibit_public_ip_on_vnic", False):', "if False:"),
    ("CIDR overlap allowed", "policy.py", "            if na.overlaps(nb):", "            if False:"),
    ("unresolved ref becomes blank", "spec.py", '                raise SpecError(f"unresolved reference {params}") from e', '                return ""'),
    ("cycle not detected", "spec.py", '            raise SpecError(f"dependency cycle', '            break\n            raise SpecError(f"dependency cycle'),
    ('SDK maps 429 as permanent', 'providers.py', 'raise ProviderError(e.status, msg, capacity=', 'raise ProviderError(400, msg, capacity='),
    # ---- v2: wave planner
    ("dependency loop not grouped", "factory.py", "                elif nxt in on:\n", "                elif False:\n"),
    ("VM cap ignored", "factory.py", "too_many_vms = max_vms_per_wave is not None and cur_vms + n_vms > max_vms_per_wave", "too_many_vms = False"),
    ("solo apps ignored", "factory.py", "solo = any(a in solo_apps for a in u)", "solo = False"),
    # ---- v2: capacity
    ("quota shortfall ignored", "capacity.py", "            if amount > avail - reserve:", "            if False:"),
    ("unknown quota assumed fine", "capacity.py", "        if avail is None:\n            why =", "        if avail is None:\n            continue\n            why ="),
    ("quota headroom ignored", "capacity.py", "reserve = headroom * (total if isinstance(total, (int, float)) else avail)", "reserve = 0"),
    ("limiter never backs off", "capacity.py", "self.limit = max(self.minimum, self.limit // 2)", "self.limit = self.limit"),
    ("limiter exceeds maximum", "capacity.py", "self.limit = min(self.maximum, self.limit + 1)", "self.limit = self.limit + 1"),
    ("engine hides 429 from limiter", "engine.py", "throttled = e.status == 429", "throttled = False"),
    # ---- v2: discovery
    ("infrastructure traffic counted", "discovery.py", "        if port in INFRA_PORTS:\n            excluded", "        if False:\n            excluded"),
    ("dependency direction reversed", "discovery.py", "fa, ta = app[s.name].value, app[d.name].value", "ta, fa = app[s.name].value, app[d.name].value"),
    ("unreviewed dependencies dropped", "discovery.py", '            summary["accepted" if v == "accept" else "unreviewed_kept"] += 1\n', '            if v != "accept":\n                continue\n            summary["accepted"] += 1\n'),
    ("external dependencies dropped", "discovery.py", "(unresolved if _private(dst) else external)[(app[s.name].value, dst, port)] += n", "pass"),
    ("unresolved private address read as external", "discovery.py", "(unresolved if _private(dst) else external)[", "(external)["),
    ("generic names trusted", "discovery.py", "if len(comps) == 1 and not generic:", "if len(comps) == 1:"),
    ("name groups trusted despite traffic split", "discovery.py", "if len(comps) == 1 and not generic:", "if not generic:"),
    ("split app loses dependencies", "discovery.py", "for fa in maps_to[a]:", "for fa in sorted(maps_to[a])[:1]:"),
    ("inference beats tags", "discovery.py", 'if tag in ("web", "app", "db"):', "if False:"),
    # ---- v2: agent guard
    ("archetype not checked", "agent.py", "        if bp_id != expected:\n", "        if False:\n"),
    ("locked fields allowed", "agent.py", "            if k not in bp.customizable:\n", "            if False:\n"),
    ("downsizing allowed", "agent.py", "elif not base[k] <= v <= hi:", "elif not 0 <= v <= hi:"),
    ("bool accepted as int", "agent.py", 'if type(v) is not int:\n                    r.append(f"{k} must be an integer")', 'if not isinstance(v, int):\n                    r.append(f"{k} must be an integer")'),
    ("proposal for another VM accepted", "agent.py", "if expected_workload is not None and name != expected_workload:", "if False:"),
    ("shape type not checked", "agent.py", "if not isinstance(v, str) or v not in self.bounds.shapes:", "if v not in self.bounds.shapes:"),
    ("memory per OCPU not checked", "agent.py", "and m > o * self.bounds.max_gb_per_ocpu:", "and False:"),
    ("change cap off", "agent.py", "if acc and cust / len(acc) > max_customized_share:", "if False:"),
    ("prod needs no approval", "agent.py", 'out = ["production environment"] if environment == "prod" else []', "out = []"),
    ("2x growth needs no approval", "agent.py", "if k in ov and ov[k] > 2 * base[k]:", "if False:"),
    # ---- v2: pipeline
    ("approval bypassed", "pipeline.py", '            if not ok:\n                stop("BLOCKED_APPROVAL"', '            if False:\n                stop("BLOCKED_APPROVAL"'),
    ("approval not journalled", "pipeline.py", 'eng.j.append(event="approval"', '(lambda **k: None)(event="approval"'),
    ("quota not checked", "pipeline.py", "        shortfall = C.preflight(new, quota,", "        shortfall = [] and C.preflight(new, quota,"),
    ("finished wave re-approved and re-run", "pipeline.py", "        if not todo.steps:\n            drift", "        if False:\n            drift"),
    ("resume preflight counts created steps", "pipeline.py", "[st.id for st in todo.steps if st.id not in in_flight]", "[st.id for st in todo.steps]"),
    ("unfinished run restarted, not resumed", "pipeline.py", "results.append(engine_factory().apply(_restrict(wf, steps), run_id=rid))", "results.append(engine_factory().apply(_restrict(wf, steps)))"),
    ("change cap does not stop run", "pipeline.py", "if not execute or rep.run_blocked or rep.policy_violations:", "if not execute or rep.policy_violations:"),
    ("policy violations do not stop --apply", "pipeline.py", "if not execute or rep.run_blocked or rep.policy_violations:", "if not execute or rep.run_blocked:"),
    ("execute without quota allowed", "pipeline.py", "    if quota is None:\n        raise ValueError", "    if False:\n        raise ValueError"),
    # ---- v2: SDK adapter, live-tenancy behaviours
    ("SDK retries left on", "providers.py", 'kw["retry_strategy"] = oci.retry.NoneRetryStrategy()', "pass"),
    ("404 after our own delete is an error", "providers.py", "if e.status == 404 and rid in self._deleted:   # deleted VCNs/subnets", "if e.status == 404 and False:   # deleted VCNs/subnets"),
    ("any 404 read as deleted", "providers.py", "if e.status == 404 and rid in self._deleted:   # deleted VCNs/subnets", "if e.status == 404:   # deleted VCNs/subnets"),
    ("409 on delete not retried", "providers.py", "(retryable): {e}\", retryable=True)", "(retryable): {e}\", retryable=False)"),
    ("transport errors not retried", "providers.py", "{type(e).__name__}: {e}\", retryable=True)", "{type(e).__name__}: {e}\", retryable=False)"),
    ("unmapped image sent to OCI", "providers.py", '        raise ProviderError(400, f"image {img!r} is not an image OCID', '        return img\n        raise ProviderError(400, f"image {img!r} is not an image OCID'),
    ("shape config sent for fixed shapes", "providers.py", "if flex else None", "if True else None"),
    ("DNS label not cleaned", "providers.py", "        return v or None\n", "        return value\n"),
    # ---- v2: engine teardown
    ("teardown hides failures", "engine.py", '            res.status = "TEARDOWN_INCOMPLETE"', "            pass"),
    # ---- v2 review fixes: content identity, blocking, plan binding, token age, OCM, discovery inputs
    ('rolled-back step still counted as existing', 'journal.py', '            del self.live[sid]\n', '            pass\n'),
    ("interrupted run resumed with changed inputs", "pipeline.py", "or workflow_hash(_restrict(wf, steps)) != rh:", "or False:"),
    ("target network reused with changed settings", "pipeline.py", "            if rh != h:\n                return Result(run_id=rid, status=\"BLOCKED_CHANGED\",\n                              error=f\"target network", "            if False:\n                return Result(run_id=rid, status=\"BLOCKED_CHANGED\",\n                              error=f\"target network"),
    ("refused VM does not block its app", "pipeline.py", '        out.setdefault(app_of[vm], f"VM {vm} could not be placed")', "        pass"),
    ("blocked app's dependents not blocked", "pipeline.py", "                if hit:\n", "                if False:\n"),
    ("blocked apps still planned", "pipeline.py", "rep.placements = [p for p in placements if p.workload.app not in rep.blocked_apps]", "rep.placements = list(placements)"),
    ("plan id ignores tags", "pipeline.py", '"tags": sorted(settings.tags.items()),', ""),
    ("reviewed plan id not enforced", "pipeline.py", "if s.expected_plan_id and s.expected_plan_id != rep.plan_id:", "if False:"),
    ("wave policy not checked in dry run", "pipeline.py", 'rep.policy_violations += [f"wave {i}: {v}" for v in policy_mod.evaluate(wf0)]', "pass"),
    ("expired retry token re-sent", "engine.py", "if age > self.token_max_age:", "if False:"),
    ("created resources not tagged with run and step", "engine.py", "tags = dict(wf.tags, ocio_run=rid, ocio_step=sid)", "tags = dict(wf.tags)"),
    ("Flex shape limits not enforced", "factory.py", "    if not 1 <= ocpus <= max_ocpus:", "    if False:"),
    ("Flex memory ceiling not enforced", "factory.py", "    if memory_gbs > min(max_mem, ocpus * MAX_GB_PER_OCPU):", "    if False:"),
    ("OCM: ambiguous source name matched", "ocm.py", "elif len(by_name.get(vm, [])) == 1:", "elif by_name.get(vm):"),
    ("OCM: other waves not excluded", "ocm.py", "if x.id not in in_wave and not getattr", "if False and not getattr"),
    ("OCM: public IP from blueprint ignored", "ocm.py", 'assign_public_ip=bool(p.get("assign_public_ip"))', "assign_public_ip=True"),
    ("OCM CLI: prod wave applied without approval", "cli.py", "    if reasons and not a.approve_by:", "    if False:"),
    ("OCM CLI: apply without reviewed plan id", "cli.py", '    if not a.plan_id:\n        raise Refused("ocm-wave', '    if False:\n        raise Refused("ocm-wave'),
    ("VIP members not linked", "discovery.py", "            links[x].update(y for y in names if y != x)", "            pass"),
    ("documentation ranges treated as internal", "discovery.py", "    return any(a in n for n in _INTERNAL)", "    return a.is_private"),
    ("unresolved destinations not refused", "discovery.py", "        if open_:\n            raise ValueError", "        if False:\n            raise ValueError"),
    ("quota error reason dropped", "capacity.py", "{f' ({why})' if why else ''}", ""),
    ("synthetic estate depends on hash seed", "synth.py", 'for dep in sorted(info["deps"]):', 'for dep in info["deps"]:'),
    # ---- second independent review: each defect reproduced, fixed, and guarded by a test
    ("interrupted runs looked up by wave name only", "pipeline.py", "        if not set(steps) & ids:\n            continue", "        if name != wf.name:\n            continue"),
    ("skipped VMs not checked in OCI", "pipeline.py", "        problems = verify_existing(eng, wf, existing_steps(eng.j))\n        if problems:", "        problems = []\n        if problems:"),
    ("VM gone from OCI still counted as existing", "pipeline.py", '            eng.j.append(run_id=x["run_id"], step=st.id, event="observed_gone", outputs={"id": x["id"]})', "            pass"),
    ('failed rollback treated as deleted', 'journal.py', '            self.live[sid] = dict(cur, uncertain=True)', '            del self.live[sid]'),
    ("unexpected errors skip rollback", "engine.py", "        except Exception as e:                  # noqa: BLE001 - any error: undo what this run created", "        except (StepFailed, SpecError) as e:"),
    ("unconfirmed creates not reported", "engine.py", "            for sid in self._unconfirmed(rid):", "            for sid in []:"),
    ('4xx create reported as possibly existing', 'engine.py', '(st == 0 or (isinstance(st, int) and st >= 500))', '(True)'),
    ("teardown ignores unconfirmed creates", "engine.py", '            if v.get("status") in ("creating", "create_unconfirmed"):', "            if False:"),
    ("dependent wave runs after its dependency failed", "pipeline.py", "        missing = sorted(_closure(apps, deps) & not_done)", "        missing = []"),
    ("static quota never shrinks", "capacity.py", "                self._a[k] -= v", "                pass"),
    ('plan id ignores bound inputs', 'pipeline.py', '"bound": settings.bound_inputs}', '"bound": None}'),
    ("plan id ignores availability domain", "pipeline.py", '"ad": settings.availability_domain,', ""),
    ('OCM: includes before excluding', 'ocm.py', '        excluded = []\n        for x in to_exclude:                                # 1 exclude first\n            self._update(f"exclude {x.id}", x.id, self.m.UpdateVmTargetAssetDetails(is_excluded_from_execution=True))\n            excluded.append(x.id)\n        updated = []\n        for p in wave_placements:                           # 2 then include the wave\n            self._update(f"update {ids[p.workload.name]}", ids[p.workload.name], specs[p.workload.name])\n            updated.append(p.workload.name)\n', '        updated = []\n        for p in wave_placements:\n            self._update(f"update {ids[p.workload.name]}", ids[p.workload.name], specs[p.workload.name])\n            updated.append(p.workload.name)\n        excluded = []\n        for x in to_exclude:\n            self._update(f"exclude {x.id}", x.id, self.m.UpdateVmTargetAssetDetails(is_excluded_from_execution=True))\n            excluded.append(x.id)\n'),
    ("OCM: result not verified", "ocm.py", "            if included == in_wave and not wrong:", "            if True:"),
    ("OCM: throttling not retried", "ocm.py", "        return status in (409, 429) or (isinstance(status, int) and status >= 500)", "        return False"),
    ("OCM: mapping outside the plan accepted", "ocm.py", "        if bad:\n            raise OCMError(f\"mapping names", "        if False:\n            raise OCMError(f\"mapping names"),
    ("OCM CLI: quota not checked", "cli.py", "    shortfall = C.preflight(wf, quota, a.availability_domain, a.quota_headroom)", "    shortfall = []"),
    ("OCM CLI: approval not journalled", "cli.py", '        j.append(event="approval", workflow=f"ocm-', '        (lambda **k: None)(event="approval", workflow=f"ocm-'),
    ('CLI: plan id ignores OCM inputs', 'cli.py', 'out = {"migration_plan": a.migration_plan, "wave": a.wave, "subnet_map": _load_json(a.subnet_map),', 'out = {"wave": a.wave,'),
    ("CLI: run --apply without plan id", "cli.py", "    if a.apply and not a.plan_id:", "    if False:"),
    ("resolve accepts any id", "cli.py", '    if not live or live["id"] != a.id:', "    if False:"),
    ("unknown private sources ignored", "discovery.py", "            if _private(src):\n                for d in ds:", "            if False:\n                for d in ds:"),
    ("unresolved sources not refused", "discovery.py", "        if open_src:", "        if False:"),
    ("VIP traffic credited to one VM", "discovery.py", "        by_ip[vip] = [by_name[x] for x in sorted(set(names))]", "        by_ip[vip] = [by_name[sorted(names)[0]]]"),
    ("VIP spanning apps not flagged", "discovery.py", "        if len({app[x].value for x in names}) > 1:", "        if False:"),
    ("VIP flow counted once per VM", "discovery.py", "                if (fa, ta) not in counted:", "                if True:"),
    ("shared backend merges apps silently", "discovery.py", "                                                       or callees[x] & callees[y] & bridge)}", "                                                       or callees[x] & callees[y])}"),
    # ---- re-review of the round-2 fixes
    ("teardown skips resources whose rollback failed", "engine.py", 'not in ("created", "ready", "rollback_failed"):', 'not in ("created", "ready"):'),
    ("complete teardown leaves the run open", "engine.py", '            self.j.append(run_id=run_id, event="run_torn_down")', "            pass"),
    ('torn-down run treated as interrupted', 'journal.py', 'elif ev in ("run_succeeded", "run_failed", "run_torn_down"):', 'elif ev in ("run_succeeded", "run_failed"):'),
    ("hand-deleted VM re-sent with its old token", "engine.py", 'e.get("event") in ("rolled_back", "observed_gone"))', 'e.get("event") == "rolled_back")'),
    ("hub caller joins apps", "discovery.py", "len(callee_groups[c]) <= HUB_CALLEE_APPS", "True"),
    ("shared caller trusted despite different backends", "discovery.py", "for c in callers[x] & callers[y]) and compatible(x, y)", "for c in callers[x] & callers[y])"),
    ("OCM wave ignores its dependencies", "cli.py", "    if pending and not a.dependencies_done_by:", "    if False:"),
    ("OCM: migrated read from presence alone", "ocm.py", 'if x is None or not getattr(x, "created_resource_id", None):', "if x is None:"),
    ("OCM: availability domain not verified", "ocm.py", '            and getattr(got, "availability_domain", None) == want.availability_domain\n', ""),
    ("OCM: public IP not verified", "ocm.py", "            and bool(getattr(vnic, \"assign_public_ip\", None)) == bool(want.create_vnic_details.assign_public_ip)", "            and True"),
    ("run dry run exits 0 despite policy violations", "cli.py", "return 0 if not (rep.run_blocked or rep.policy_violations) else 2      # same rule as `plan`", "return 0"),
    # ---- tune-up 13-56: one mutant per guarantee added since the harness was last extended
    ("13 fault domains not spread", "factory.py", "            out[n] = FAULT_DOMAINS[i % 3]", "            out[n] = FAULT_DOMAINS[0]"),
    ("14 Arm sized as x86", "factory.py", 'VCPUS_PER_OCPU = {"VM.Standard.A1.Flex": 1}', 'VCPUS_PER_OCPU = {}'),
    ("15 host capacity retried like any 500", "engine.py", 'if getattr(e, "capacity", False) and attempt >= self.capacity_attempts:', "if False:"),
    ("17 unknown AD accepted", "tenancy.py", "    if ad not in names:", "    if False:"),
    ("18 OCID type not checked", "ocid.py", "    if types and m.group(1) not in types:", "    if False:"),
    ("27 burstable allowed in prod", "policy.py", '            and s.params.get("baseline_ocpu_utilization") not in (None, "BASELINE_1_1")]', "            and False]"),
    ("28 NSG rules stateless", "netpolicy.py", "is_stateless=False,", "is_stateless=True,"),
    ("30 cutover gate ignores blocked flows", "netpolicy.py", "            if not ok:\n                blocked.append", "            if False:\n                blocked.append"),
    ("31 NSG rules re-added on every run", "netpolicy.py", "missing = [r for r in rules if (ids[r.src_nsg], r.port) not in have]", "missing = list(rules)"),
    ("31 NSG create without retry token", "netpolicy.py", "opc_retry_token=_token(vcn_id, name)", "opc_retry_token=None"),
    ("32 OCM work-request failure ignored", "ocm.py", "            if status in WR_BAD:", "            if False:"),
    ("33 OCM update without If-Match", "ocm.py", '            kw["if_match"] = etag', "            pass"),
    ("35 OCM asset state not checked", "ocm.py", "        if not_ready:", "        if False:"),
    ("37 repeated page token loops", "ocm.py", "            if page in seen:", "            if False:"),
    ("39 admission refusal ignored", "pipeline.py", '            if not adm.get("allowed"):', "            if False:"),
    ("39 network built before admission", "pipeline.py", '        if not first.get("allowed"):', "        if False:"),
    ("39 stale evidence accepted", "admission.py", '    elif now - at > policy["max_age_seconds"]:', "    elif False:"),
    ("39 failed check accepted", "admission.py", '        if r.get("passed") is not True:', "        if False:"),
    ("39 conflicting evidence picked", "admission.py", "    if len(mine) > 1:", "    if False:"),
    ("41 journal lock not taken", "journal.py", "            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)", "            pass"),
    ("43 session region not checked", "cli.py", '    if want and cfg.get("region") != want:', "    if False:"),
    ("45 two VMs on one target asset", "ocm.py", "for tid, vms in sorted(shared.items()) if len(vms) > 1]", "for tid, vms in sorted(shared.items()) if False]"),
    ("46 OCM spec replaced not merged", "ocm.py", "    if base is None:\n        return ours", "    if True:\n        return ours"),
    ("47 rejection without reviewer", "discovery.py", "        if changes and (not isinstance(who, str) or not who.strip()):", "        if False:"),
    ("48 restore without reviewed id", "cli.py", "    if a.restore_id != rid:", "    if False:"),
    ("49 polls never back off", "engine.py", "            interval = min(interval * 2, max(self.MAX_POLL_SECONDS, self.poll))", "            pass"),
    ("52 edited entry not located", "journal.py", '            if e.get("prev") != prev:', "            if False:"),
    ("54 memory rounded down", "factory.py", "memory = max(1, math.ceil(w.memory_gb))", "memory = max(1, int(w.memory_gb))"),
    ("54 bad tier accepted", "catalog.py", "                if tier not in TIERS:", "                if False:"),
    ("55 unknown solo app ignored", "pipeline.py", "    if unknown_solo:", "    if False:"),
    ('65 Arm shape falls back to an x86 image', 'factory.py', '        if shape in ARM_SHAPES:', '        if False:'),
    ('66 misspelt decision section ignored', 'discovery.py', '        if typos:', '        if False:'),
    ('66 unknown VM in decisions ignored', 'discovery.py', '            if ghosts:', '            if False:'),
    ('74 environment spelling unchecked', 'spec.py', '        if self.environment not in ENVIRONMENTS:', '        if False:'),
    ('76 possibly accepted attempt forgotten', 'engine.py', '                    ambiguous = True', '                    pass'),
    ('79 journal not bound to its target', 'pipeline.py', '    if bound and {k: bound[0].get(k) for k in target} != target:', '    if False:'),
    ('80 stale private IP kept across subnets', 'ocm.py', '        if getattr(v, "private_ip", None) and v.subnet_id and v.subnet_id != w.subnet_id:', '        if False:'),
    ('80 VLAN placement kept with a subnet', 'ocm.py', '        if getattr(v, "vlan_id", None):', '        if False:'),
    ('82 NSG rule listing loops on a repeated token', 'netpolicy.py', '        if page in seen:\n            raise ValueError(f"listing rules', '        if False:\n            raise ValueError(f"listing rules'),
    ('83 calls inside one app dropped', 'discovery.py', '                        internal.add((s.name, d.name))', '                        pass'),
    ('84 hostnames assigned per wave', 'factory.py', '    hosts = hostnames(all_placements if all_placements is not None else in_wave)', '    hosts = hostnames(in_wave)'),
    ('85 IPv4-mapped IPv6 not reduced', 'discovery.py', '    if a.version == 6 and a.ipv4_mapped is not None:', '    if False:'),
    ('89 embedded JSON not escaped', 'ui/wrapper.py', 'data = json.dumps(value).replace("<", "\\\\u003c").replace(">", "\\\\u003e").replace("&", "\\\\u0026")', 'data = json.dumps(value)'),
    ('93 any Content-Length accepted', 'ui/launch.py', '    return int(header) if header.isascii() and header.isdigit() else None', '    return int(header)'),
    ('94 mutation control assumed passed', 'ui/wrapper.py', 'control = line.strip().endswith("exit 0")', 'control = True'),
    ('95 foreign same-named NSG adopted', 'netpolicy.py', '        if len(same) > len(ours):', '        if False:'),
    ('95 NSG map written only at the end', 'cli.py', 'existing=existing, journal=j, on_created=save)', 'existing=existing, journal=j, on_created=None)'),
    ('96 entry glued to a line without newline', 'journal.py', 'if f.seek(0, os.SEEK_END) and (f.seek(-1, os.SEEK_END), f.read(1))[1] != b"\\n":', 'if False:'),
    ('97 non-object journal line accepted', 'journal.py', '            if not isinstance(e, dict):', '            if False:'),
    ('97 append chains to a hash-less entry', 'journal.py', '        if not (isinstance(h, str) and len(h) == 64):', '        if False:'),
    # '98 handles before the file exists not shared' was removed: since tune-up 98 every read reloads a changed
    # file, so a handle that missed the shared state still reads the right entries. Equivalent: no test can tell.
    ('98 reads never reload after an edit', 'journal.py', '            if s.stat != now:', '            if False:'),
    ('99 tags not part of the run hash', 'engine.py', '"tags": {k: v for k, v in (wf.tags or {}).items() if k not in _OCIO_LABELS}},', '"tags": {}},'),
    ('100 pre-network admission not journalled', 'pipeline.py', 'j0.append(event="admission", workflow=f"wave-{w}",', 'dict(event="admission", workflow=f"wave-{w}",'),
    ('100 pre-network admission always asks wave 1', 'pipeline.py', '            w = pending[0]', '            w = 1'),
    ('101 no-etag token reused across calls', 'ocm.py', 'etag or f"no-etag/{os.urandom(16).hex()}"', 'etag'),
    ('102 excluded assets not read for the before-state', 'ocm.py', 'for x in [self._get(y.id).data for y in to_exclude] + before:', 'for x in list(to_exclude) + before:'),
    ('103 limits client without the SDK timeout', 'capacity.py', '            if timeout is not None:', '            if False:'),
    ('104 security token key without pass phrase', 'auth.py', 'pass_phrase=cfg.get("pass_phrase"))', 'pass_phrase=None)'),
    ('105 malformed reference passed as text', 'spec.py', '            if "${" in v and not REF.fullmatch(v):', '            if False:'),
    ('105 depends_on string split into letters', 'spec.py', '        if not isinstance(deps, (list, tuple)) or not all(isinstance(d, str) for d in deps):', '        if False:'),
    ('106 OCPUs ignore memory', 'factory.py', ', math.ceil(memory / MAX_GB_PER_OCPU))', ')'),
    ('107 proposer breaks the memory ratio', 'agent.py', '            if need > base["ocpus"]:', '            if False:'),
    ('108 tier tag case-sensitive', 'discovery.py', 'tag = str(a.tags.get("tier") or "").strip().lower()', 'tag = str(a.tags.get("tier") or "")'),
    ('109 unknown listener VMs dropped', 'discovery.py', '    if unknown:\n        raise ValueError(f"listeners name VMs', '    if False:\n        raise ValueError(f"listeners name VMs'),
    ('109 listener names case-sensitive', 'discovery.py', 'served[n if n in by_name else folded[n.lower()][0]]', 'served[n]'),
    ('110 self-traffic counted as evidence', 'discovery.py', '        if len(ss) == 1 and list(ds) == list(ss):', '        if False:'),
    ('111 blank required tags accepted', 'policy.py', 'if not str(wf.tags.get(k) or "").strip()]', 'if not wf.tags.get(k)]'),
    ('112 IPv6 CIDR passed to subnet_of', 'policy.py', '        if net.version != 4:', '        if False:'),
    ('113 boolean or float wave binds', 'admission.py', 'type(d.get("wave")) is int and ', ''),
    ('113 recorded failed check ignored', 'admission.py', '        if any(r.get("passed") is not True for r in named[name]):', '        if False:'),
    ('113 spaced check names accepted', 'admission.py', '    if spaced:', '    if False:'),
    ('114 headroom of what is left', 'capacity.py', 'headroom * (total if isinstance(total, (int, float)) else avail)', 'headroom * avail'),
    ('115 external_ok without a reviewer', 'discovery.py', '+ [f"external_ok {x}" for x in sorted(ack & (', '+ [f"external_ok {x}" for x in sorted(set() & ('),
    ('116 shrinking below the source unapproved', 'agent.py', '            elif k in ov and ov[k] < base[k]:', '            elif False:'),
    ('117 ambiguous OS string guessed', 'factory.py', '    if win != lin:', '    if win or lin:'),
]


def run(root):
    """Exit code of the whole suite in ROOT; a hang (a mutant that loops) counts as detected."""
    try:
        return subprocess.run([sys.executable, "-B", "-m", "unittest", "-q", "-f"], cwd=root, capture_output=True,
                              env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"), timeout=TIMEOUT).returncode
    except subprocess.TimeoutExpired:
        return "timeout"


TIMEOUT = int(os.environ.get("MUTATE_TIMEOUT", "300"))     # the unmodified suite takes ~10 s


def copy_to(tmp):
    """Copy what the test suite needs (ocio/, tests/, scripts/, examples/, pyproject.toml, the docs, launchers and demos) into
    tmp, without caches or lock files."""
    for d in ("ocio", "tests", "scripts", "examples"):
        shutil.copytree(os.path.join(HERE, d), os.path.join(tmp, d), ignore=shutil.ignore_patterns("__pycache__", "*.lock"))
    for f in ("pyproject.toml", "README.md", "RUNBOOK.md", "BRIEF.md", "TUNEUP_LOG.md",
              "launch.sh", "Launch.command", "Launch.bat", "demo.py", "demo_v2.py"):      # the launcher tests read these
        if os.path.exists(os.path.join(HERE, f)):
            shutil.copy(os.path.join(HERE, f), tmp)


def check_targets():
    """Every mutant must find its target exactly once in the CURRENT code; a stale target would silently
    stop guarding a guarantee, so the harness refuses to run with one."""
    bad = []
    for name, fn, old, new in M:
        src = open(os.path.join(HERE, "ocio", fn)).read()
        if src.count(old) != 1:
            bad.append(f"{name}: target found {src.count(old)} times in ocio/{fn}")
    return bad


def trial(m):
    """Apply one mutant in a fresh temporary copy and run the suite there. Returns (name, verdict): KILLED,
    TIMEOUT or SURVIVED."""
    name, fn, old, new = m
    src = open(os.path.join(HERE, "ocio", fn)).read()
    with tempfile.TemporaryDirectory() as t:
        copy_to(t)
        with open(os.path.join(t, "ocio", fn), "w") as f:
            f.write(src.replace(old, new))
        rc = run(t)
        return name, "TIMEOUT" if rc == "timeout" else ("KILLED" if rc else "SURVIVED")


if __name__ == "__main__":
    from concurrent.futures import ThreadPoolExecutor
    stale = check_targets()
    if stale:
        print("stale mutants (fix them first):\n  " + "\n  ".join(stale))
        sys.exit(2)
    with tempfile.TemporaryDirectory() as t:
        copy_to(t)
        ctrl = run(t)
    print(f"control (unmodified code): exit {ctrl}", flush=True)
    if ctrl != 0:
        print("the unmodified copy fails its own suite: mutation results would mean nothing; stopping")
        sys.exit(2)
    results = []
    jobs = int(os.environ.get("MUTATE_JOBS", str(max(1, (os.cpu_count() or 2)))))
    with ThreadPoolExecutor(max_workers=jobs) as ex:
        for name, verdict in ex.map(trial, M):
            print(f"{verdict:9s} {name}", flush=True)
            results.append(verdict)
    killed, hung, survived = results.count("KILLED"), results.count("TIMEOUT"), results.count("SURVIVED")
    print(f"\n{killed + hung}/{len(M)} detected ({killed} by a failing test, {hung} by timeout); {survived} survived; "
          f"control exit {ctrl}")
    sys.exit(0 if survived == 0 else 1)
