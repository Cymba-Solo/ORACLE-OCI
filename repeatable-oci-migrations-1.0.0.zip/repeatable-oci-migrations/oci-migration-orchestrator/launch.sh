#!/bin/sh
# OCIO one-click launch (Linux, macOS): opens the launch console in your browser.
# Needs Python 3.10 or newer. Live OCI commands also need the SDK: python3 -m pip install "oci==2.189.0"
cd "$(dirname "$0")" || exit 1
for PY in python3 python; do
  if command -v "$PY" >/dev/null 2>&1 && "$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)'; then
    "$PY" -c 'import oci' 2>/dev/null || echo "Note: the OCI SDK is not installed; plan, discover and run dry runs work; ocm-wave and live OCI calls need: $PY -m pip install \"oci==2.189.0\""
    exec "$PY" -m ocio ui --workdir . "$@"
  fi
done
echo "Python 3.10 or newer was not found. Install it from https://www.python.org/downloads/ and try again."
printf "Press Enter to close. "; read -r _
exit 1
