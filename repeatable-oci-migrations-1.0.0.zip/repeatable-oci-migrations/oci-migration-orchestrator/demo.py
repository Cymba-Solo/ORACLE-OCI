"""SIMULATED end-to-end migration factory run against FakeOCI. No OCI tenancy involved.

  python -B demo.py

What it shows, in order (the engine and factory are the real code; only OCI is an in-memory stand-in):
  Placement  every VM of examples/inventory.csv placed on a blueprint, with examples/overrides.json applied
             (keys starting with "_" are comments and dropped). Prints the deviation report (standard vs
             customized, per blueprint) and every refusal with its reason: a VM with no valid blueprint is
             refused, never given a default.
  Waves      apps grouped into dependency-ordered waves.
  Execution  the target network, then each wave, in prod, against a fake OCI that throttles (429), fails a
             server call (503), lets one instance fail to provision (portal-web-02: its wave rolls back) and
             "kills the process" right after crm-app-02 is created. After the crash the same wave is resumed
             from the journal with its run id, and must not create crm-app-02 a second time.
  Result     live resources, how many share a name (duplicates: must be 0), whether the journal's hash chain
             is intact, and the simulated seconds spent in backoff and polls.
The output is deterministic (fixed seeds, virtual clock) and saved as examples/demo_output.txt; the Monte Carlo
script re-runs this demo and requires a byte-identical result.
"""
import json
import os
import random
import tempfile

from ocio import factory as F
from ocio.catalog import BLUEPRINTS, load_inventory
from ocio.engine import Engine
from ocio.journal import Journal
from ocio.providers import Crash, FakeOCI

HERE = os.path.dirname(os.path.abspath(__file__))
COMP, ENV = "ocid1.compartment.oc1..acme-prod", "prod"
TAGS = {"cost_center": "cc-4410", "owner": "migration-factory"}


class Clock:
    """Virtual clock handed to the engine: calling it returns simulated time, sleep() adds to it instantly, so
    backoffs and readiness polls cost no real time and the printed output is identical on every run."""
    t = 0.0
    def __call__(self): return self.t
    def sleep(self, s): self.t += s


def main():
    """Run the demo and print its report to stdout (see the module docstring for what each section means)."""
    inv = load_inventory(os.path.join(HERE, "examples", "inventory.csv"))
    raw = json.load(open(os.path.join(HERE, "examples", "overrides.json")))
    overrides = {k: {f: v for f, v in o.items() if not f.startswith("_")} for k, o in raw.items()}

    # 1. Cookie cutter: place every workload; refusals are reported, never defaulted.
    placements, refused = [], []
    for w in inv:
        try:
            placements.append(F.place(w, BLUEPRINTS, overrides.get(w.name, {})))
        except F.FactoryError as e:
            refused.append(str(e))
    print("== Placement ==")
    print(json.dumps(F.deviation_report(placements), indent=2))
    print("Refused:"); [print("  -", r) for r in refused]

    placed = [p.workload for p in placements]
    waves = F.plan_waves(placed)
    print("\n== Waves ==", waves)

    # 2. Execute: target network, then waves. Faults injected: throttling, one failed instance, a crash.
    fake = FakeOCI(faults={("create", "instance"): [429, 0, 503]},
                   fail_provision={"portal-web-02"}, crash_after_create={"crm-app-02"})
    jp = os.path.join(tempfile.mkdtemp(), "journal.jsonl")
    clock = Clock()
    mk = lambda: Engine(fake, Journal(jp), sleep=clock.sleep, clock=clock, rng=random.Random(7))

    z = mk().apply(F.target_network("acme", ENV, COMP, TAGS, "10.20.0.0/16",
                                  {"web": "10.20.1.0/24", "app": "10.20.2.0/24", "db": "10.20.3.0/24"}))
    print("\n== Target network ==", z.status)
    for i, apps in enumerate(waves, start=1):
        wf = F.wave_workflow(i, apps, placements, z.outputs, ENV, COMP, TAGS)
        try:
            r = mk().apply(wf)
        except Crash as c:
            print(f"wave {i} {apps}: PROCESS CRASHED ({c}) — resuming from journal")
            run_id = [e for e in Journal(jp).entries if e.get("event") == "run_started"][-1]["run_id"]
            r = mk().apply(wf, run_id=run_id)
        line = f"wave {i} {apps}: {r.status}"
        if r.rolled_back:
            line += f" | rolled back {r.rolled_back}"
        if r.error:
            line += f" | {r.error}"                    # whole message: it ends with the reason OCI gave
        print(line)

    live = sorted(x["params"]["display_name"] for x in fake.live().values())
    print("\n== Result in (simulated) OCI ==")
    print("live resources:", len(live)); print(" ", live)
    print("live resources sharing a name (duplicates):", len(live) - len(set(live)))
    print("journal chain intact:", Journal(jp).verify(), "| simulated seconds spent in backoff/polls:", round(clock.t, 1))


if __name__ == "__main__":
    main()
