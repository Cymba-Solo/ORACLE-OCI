# Runbook: Repeatable OCI Migrations

How to use the orchestrator, from an inventory to migrated waves. Every command below has been run in
the build environment. The `--apply` paths ran through the test suite: `run` against the **simulated** OCI,
`ocm-wave` against a **stand-in** OCM client. Neither has run against a live tenancy or a real OCM plan
(§7 is the first live test). It is labelled where it applies.

**Two ways to execute a wave.** `ocm-wave` (§5a) is the **migration** path: it writes the blueprint
settings into an Oracle Cloud Migrations (OCM) migration plan, and OCM replicates the VM's disks and
launches the target from them. `run` (§5b) builds the target network and launches **new** instances from
images: use it for rebuilds, pilots and greenfield, not to carry a VM's disks across.

## 0. Setup

```
python3 -m pip install oci          # only for live runs and the offline SDK tests (tested with oci 2.189.0)
python3 -B -m unittest              # the test suite; all tests must pass before anything else
python3 -B demo_v2.py               # all five parts against a simulated OCI with injected faults
```

For live runs, an OCI config file (`~/.oci/config`) with an API key for a user in the group described
in §8, or another authentication mode (§0b).

`python3 -m pip install .` installs the `ocio` command; `python3 -m ocio <command>` and
`python3 scripts/migrate.py <command>` are the same program. Every command that would change OCI is a dry run unless `--apply` is given.

### 0a. One-click console (OCI Migration Control)

Double-click `Launch.command` (macOS), `Launch.bat` (Windows) or run `./launch.sh` (Linux). It starts
`ocio ui`: a console on `127.0.0.1` showing the plan, waves, discovery and evidence, with a launcher whose radio
buttons pick the command (discover, plan, run, ocm-wave, netpolicy, status), the mode (dry run or apply), the
environment and the inputs. The launcher builds the same command line you would type, shows it, and runs it.

- **Security.** The console listens on 127.0.0.1 only and checks the Host header. Every request needs a per-launch
  token, which is never in any page the server returns. It reaches your browser only through a private launch
  file (mode 0600 in a 0700 folder), which is deleted when the console stops.
- **Apply from the console** follows the same rules as the CLI: the dry run prints the plan id, and Apply needs it.
- `ocio ui --write console.html` writes the console as one offline HTML file and exits.
- `Launch.bat` and the Windows journal lock have **not been run on Windows** (no Windows host in the build environment).

### 0b. Authentication and common flags

| Flag | Meaning |
|---|---|
| `--auth api_key` (default) | `~/.oci/config` profile (`--profile`, `--config`) with an API key |
| `--auth security_token` | A session from `oci session authenticate`: the profile's `security_token_file` and `key_file` (decrypted with its `pass_phrase`, if any) |
| `--auth instance_principal` | On an OCI instance in a dynamic group; no keys on disk |
| `--auth resource_principal` | Inside an OCI service that provides one (e.g. Functions) |
| `--region` | The region the reviewed plan is for. Part of the plan id; a session in any other region is refused before anything is sent |
| `--sdk-timeout C,R` | Connect and read timeouts in seconds for every OCI client, including the Limits client |
| `--quota-headroom 0.1` | Keep 10% **of each limit** free. The share is of the limit's total (the `--quota-file` value as given, or `used + available` from the Limits API), not of what is left, so it does not shrink as waves land |

Any refusal before a change exits **2** with one line saying why. Input errors (a missing file, a bad CSV line)
are reported the same way; `OCIO_DEBUG=1` shows the traceback.

## 1. Discover: who belongs to which app, and what depends on what

Oracle Cloud Migrations already inventories the VMs. Add network evidence, and discovery proposes app
groups, tiers and dependencies. Each finding comes with a confidence and the evidence behind it.

| File | Columns | Where it typically comes from |
|---|---|---|
| `assets.csv` | `name, ip, os, vcpus, memory_gb, tags` | Oracle Cloud Migrations inventory export or RVTools, plus an IP column. `tags` is optional, e.g. `app=crm;tier=web;critical=yes` |
| `flows.csv` | `src_ip, dst_ip, dst_port, connections` | Any flow source aggregated over 1–4 weeks: vSphere/NSX flow exports, firewall logs, or periodic `ss -tn` / `netstat -an` snapshots |
| `listeners.csv` (optional) | `name, port[, process]` | `ss -ltn` / `netstat -an` per VM |
| `vips.csv` (optional) | `vip, name` | Load-balancer VIPs, Oracle RAC SCAN/VIP addresses and second NICs, each mapped to the VM(s) behind it |

A VM with several addresses lists them in `ip` separated by `;`.

```
python3 scripts/migrate.py discover --assets assets.csv --flows flows.csv --listeners listeners.csv \
        --vips vips.csv --out findings.json
```

This writes `findings.json` and `findings.decisions-template.json`. Review the template:

- **High-confidence dependencies (≥ 0.6)** are pre-filled as `accept`.
- **Low-confidence ones** are listed separately. For each, choose `accept` or `reject` and move it into `dependencies`.
- **Fix wrong groupings** under `apps` (`"vm-name": "app"`) and tiers under `tiers` (`web | app | db`).
- **Read the warnings:**
  - `low_confidence_vms`: the grouping or tier rests on weak evidence;
  - `silent_vms`: no traffic was observed, so no dependencies can be inferred;
  - `infrastructure_only_vms`: only SSH, DNS, NTP or similar admin traffic was seen, so nothing shows what the VM serves or calls;
  - `external_dependencies`: public addresses outside the inventory, such as SaaS;
  - `unresolved_private_destinations` and `unresolved_private_sources`: **private** addresses (RFC 1918,
    100.64/10) that are not a VM and not in `vips.csv`. Usually a VIP, a SCAN address, a second NIC, or an
    unlisted VM. Map each one (`vips.csv`, or a second `;`-separated address in `assets.csv`), or list it under
    `external_ok` if it really is outside the estate (a mainframe, a partner link); that, like any rejected
    dependency or regrouping, needs `reviewed_by`. **The reviewed inventory is
    refused while any is open**, because a missed dependency would put an app in the wrong wave;
  - `excluded_infrastructure_traffic`: DNS, NTP, SSH and similar, not treated as app dependencies.

Then produce the reviewed inventory:

```
python3 scripts/migrate.py discover --assets assets.csv --flows flows.csv --out findings.json \
        --decisions decisions.json --inventory-out inventory.csv
```

**Rules you can rely on**
- A tag always beats an inference.
- An unreviewed dependency is **kept**. It can only make a wave later, never earlier.
- Only a reviewer can drop a dependency.
- Apps that depend on each other move together in one wave.
- Traffic to a VIP or SCAN address counts for every VM behind it. If those VMs land in different apps, all are
  flagged.
- A host-name group is trusted (confidence 0.8) only when traffic shows its VMs belong together: they talk to
  each other, share a client, or share a backend inside the group. VMs that merely call the same outside
  server keep the name but are flagged, because unrelated apps sharing one database look exactly like that.

## 2. Blueprints: the cookie cutter

Blueprints live in `ocio/catalog.py`, one per workload archetype (tier + OS family).

- `defaults` are the locked standard: shape, image and public-IP policy.
- `customizable` lists the only fields a workload may change. Anything else is refused, and the field is named.
- To change a standard, add a **new version** (`app-linux@v2`) rather than editing v1, so earlier runs stay reproducible.
- Images are symbolic (`IMAGE_OL8`). For live runs, map them to the region's image OCIDs in a JSON file passed as `--image-map`. An unmapped image is refused, never guessed.

## 3. Plan: report-only, nothing is created

```
python3 scripts/migrate.py plan --inventory inventory.csv --overrides overrides.json --env prod \
        --max-apps-per-wave 3 --max-vms-per-wave 40 --solo billing
```

The plan prints:
- the **deviation report** (share of the estate placed fully standard, and every customization);
- the **refusals**, each with its reason;
- the **waves**;
- the **mutual groups**;
- the **blocked apps**: an app with any VM that could not be placed does not move at all (it would arrive
  without that VM), and neither does any app that depends on it. Each one is listed with the reason;
- the **policy violations** the waves would hit (missing tags, overlapping CIDRs, public IPs in prod);
- the **plan id**, a digest of placements, waves, environment, compartment, tags, network, availability domain
  and every other input that reaches an API call. Every `--apply` must name it (§5). Use the id printed by the
  dry run of the **same command** (`run` or `ocm-wave`), since each adds its own inputs (image map; OCM plan,
  wave, subnet map, mapping).

Exit code 2 means something is blocked or violates policy. Tags have no defaults: pass every tag the
required-tags policy names (`cost_center` and `owner` in the shipped policy) with `--tag key=value`.

This is stage 1 of adoption and is safe to run anywhere.

`overrides.json` holds reviewed per-VM customizations, for example `{"billing-app-01": {"memory_gbs": 192, "_why": "..."}}`. Keys starting with `_` are notes.

## 4. Optional: agent-assisted customization

`--agent rule` uses the built-in deterministic proposer. It applies the standard blueprint, and adds memory headroom where `--metrics` shows peak memory use ≥ 85%. Proposals pass through the guard:

- the right blueprint for the workload;
- only customizable fields;
- never smaller than the source;
- bounded sizes and allowed shapes and subnets only;
- a proposal must be for the VM it was asked about.

A rejected proposal is listed with its reasons and the VM is not placed. If more than 30% of a run is customized, the run stops (`--max-customized-share`).

To use a language model, wire `ocio.agent.LLMProposer` to `ocio.agent.OCIGenAIComplete(compartment_id, model_id)` in code. The model choice, endpoint and the `generative-ai-family` policy are yours. The request format is built and checked offline; **it has not been called against OCI Generative AI.** Whatever the model says, the same guard decides.

## 5a. Migrate a wave with Oracle Cloud Migrations (`ocm-wave`)

Prerequisite: an OCM migration plan whose target assets cover the wave's VMs, set up the usual OCM way
(inventory, migration project, replication). Then:

```
python3 scripts/migrate.py ocm-wave --inventory inventory.csv --overrides overrides.json --env prod \
        --compartment ocid1.compartment.oc1..xxx --availability-domain "Uocm:PHX-AD-1" \
        --tag cost_center=cc-4410 --tag owner=migration-team \
        --migration-plan ocid1.ocmmigrationplan.oc1..xxx --subnet-map subnets.json --wave 1
# dry run: prints each target asset update and the plan id. Then, after review:
#   ... --apply --plan-id <id from the dry run> --approve-by "Name"
```

- `subnets.json` maps `subnet_web`, `subnet_app`, `subnet_db` to existing subnet OCIDs.
- For each VM in the wave, the target asset's `user_spec` gets the blueprint's shape, OCPUs, memory, subnet,
  public-IP setting, AD and tags, and the asset is included. **No image**: OCM launches from the replicated
  boot volume. Every other target asset in the plan is excluded from execution.
- Target assets are matched to VMs by the source asset's display name. A VM with no match, or with more than
  one, is refused; give `--mapping` (JSON: VM name → target asset OCID) to settle it. A mapping that names an
  asset outside this migration plan is refused.
- Where the blueprint size differs from OCM's own `recommended_spec`, the output lists it for review.
- `--apply` needs `--plan-id`. The wave's demand must fit the quota (Limits API, or `--quota-file`), and a wave
  that needs approval (prod, subnet move, more than 2× growth) needs `--approve-by`. If the plan changed since
  the dry run, nothing is sent.
- **Dependencies first.** Every VM of an app this wave depends on must already show a target instance in the
  plan (`created_resource_id` on its target asset; read this way per the SDK's description, to be confirmed on
  a real plan). Otherwise the wave is refused. If those VMs were migrated outside this plan, a named person can
  confirm it with `--dependencies-done-by "Name"`; the confirmation is journalled.
- **Order of changes**, because executing the plan launches every included asset: (1) exclude every
  out-of-wave asset, (2) update and include the wave's assets, (3) re-read the plan, with backoff, until it
  shows exactly the wave included and each asset's shape, size and subnet applied. Nothing outside the
  wave is ever newly included. If a call fails part-way, out-of-wave assets that were *already* included may
  still be, so the command exits 1, says not to execute the plan, and journals why; re-run `ocm-wave` to
  finish. Throttling, conflicts and server errors are retried, bounded.
- Approval and outcome are written to the hash-chained journal (`--journal`, default `ocio-ocm.jsonl`).
- **Before-state and restore.** Before the first change, `ocm-wave --apply` journals every asset it may change
  (included or not, and its `user_spec`). To put the plan back:
  `python3 -m ocio ocm-restore --journal ocio-ocm.jsonl --migration-plan <plan OCID> [--wave N]`. That is a dry
  run that prints a `restore_id`; then add `--apply --restore-id <id>`. Assets to be excluded are restored
  first, and every update is conditional (If-Match) and waited on. An asset whose `user_spec` was empty keeps
  its current one (the API cannot clear it), and the output says so.
- **Asset states.** A target asset that OCM marks FAILED, NEEDS_ATTENTION or DELETED stops the wave before any
  change. A 412 (the asset changed since it was read) stops it too: re-run after checking the console.
- **Readiness evidence** (optional, §5d): `--admission-policy policy.json --admission evidence.json`.
- **Executing the migration plan stays an OCM action** (console, CLI or API), taken after reviewing it there.
- Not yet run against OCM: request models and method signatures are checked against oci SDK 2.189.0, and the
  flow against a stand-in client. How quickly OCM reflects an update is not known; step 3 waits for it.

## 5b. Rebuild or pilot: launch new instances (`run`)

```
python3 scripts/migrate.py run --inventory inventory.csv --overrides overrides.json --env prod \
        --compartment ocid1.compartment.oc1..xxx --availability-domain "Uocm:PHX-AD-1" \
        --tag cost_center=cc-4410 --tag owner=migration-team --image-map images.json \
        --journal wave-run.jsonl                # dry run: prints the plan and its plan id
# then: ... --apply --plan-id <id from the dry run> [--approve-by "Name"]
```

What happens with `--apply`, in order (nothing at all if the plan id differs or policy fails):

1. **Target network**, created once and reused. One VCN and one subnet per tier; web subnets allow
   public IPs outside prod only. On purpose it adds **no gateways, route rules or security rules**: subnets use
   the VCN's default route table and default security list, which per Oracle allows SSH (22) and ICMP 3/4 from
   authorized sources, ICMP 3 from inside the VCN, and all egress. Connectivity to the source site and any
   tightening are the network team's, before wave 1. Re-running with different network settings is refused
   (`BLOCKED_CHANGED`) rather than building a second network.
2. **Then for each wave:**
   - **Dependencies first.** A wave whose apps depend on a wave that did not complete is skipped (`SKIPPED_DEPENDENCY`).
   - **Check what exists.** VMs the journal says exist are confirmed with OCI before they are skipped (§ below).
   - **Quota preflight.** Demand per shape family is compared with the compartment's limits, read from the Limits API or from `--quota-file`. A shortfall or an unknown value **blocks the wave before anything is created**. A `--quota-file` is a snapshot, so each successful wave's use is subtracted before the next is checked.
   - **Readiness evidence**, if an admission policy is given (§5d). The first wave that still has something to create is checked before even the network is built; every decision is journalled.
   - **Dry-run plan**, then **approval.** Every prod wave needs one, and so does a subnet move, a size increase above 2×, or an override below the source size. Interactively, the approver sees each VM's shape, size, subnet and public-IP setting and types their name; or `--approve-by` records a pre-approval for the plan named by `--plan-id`. Every decision is written to the journal with the wave's hash and the plan id.
   - **Execution:**
     - retry tokens, so a re-send never duplicates. OCI keeps a token for 24 hours, so a create that was sent
       but never confirmed more than 23 hours ago is **not** re-sent: the step stops and names the tags to look
       for (`ocio_run`, `ocio_step`, which every created resource carries);
     - waits for the ready state;
     - throttling retried with backoff, under an adaptive limit on calls in flight (`--max-in-flight` is the ceiling);
     - on failure of any kind, rollback in reverse order. Anything that could not be deleted is reported by
       OCID; a create that hit a server or network error, and so may exist without a confirmed OCID, is
       reported with the tags to find it by.
3. **Waves stop at the first failure** by default. (Programmatically, `stop_on_wave_failure=False` continues
   with waves that do not depend on the failed one.)

**After a crash or a stop, run the same command again with the same `--journal`.**
Waves are matched by **content**, not by number, so a changed inventory cannot be mistaken for a finished wave.
- VMs the journal shows as created (and not rolled back) are found whichever run or wave created them, then
  **confirmed with OCI** before being skipped. Confirmed gone (deleted by hand): created again. Present but not
  running, or unreadable: the wave stops (`BLOCKED_STATE`). If their settings have changed since, the wave
  reports them as `drift`; nothing is changed in place.
- An interrupted run resumes with the same tokens, without duplicate creates, even if its VMs now sit in a
  differently numbered wave, but only if its inputs are unchanged and its VMs are still in one wave; otherwise
  it is refused (`BLOCKED_CHANGED`) until it is torn down or the inputs restored.
- A failed wave was rolled back and starts fresh. If its rollback failed for a VM, that VM is checked again:
  if OCI shows it gone, the wave proceeds; if it still exists, the wave stops until it is deleted.
- To undo a run, or clear a `BLOCKED_STATE` / `BLOCKED_CHANGED`, tear it down. Dry run first:
  `python3 scripts/migrate.py teardown --journal wave-run.jsonl --run-id <run id>`, then add `--apply`. It
  deletes newest first, including resources whose earlier rollback failed, reports creates that were never
  confirmed (by their `ocio_run` / `ocio_step` tags), and, when nothing is left over, closes the run so it is
  no longer resumed.
- If OCI can no longer show a resource at all (for example a 404, which OCI also returns for "not
  authorized"), and you have confirmed it is gone, record that:
  `python3 scripts/migrate.py resolve --journal wave-run.jsonl --step <vm> --id <ocid> --by "Name"`.

The journal is hash-chained. `python3 -m ocio status --journal wave-run.jsonl` summarises it: whether the
chain is intact (and the first broken line, if not), the head hash, open and finished runs, what exists, and
event counts. Keep the journal: it is the audit record. Rules that protect it:
- **One journal, one target.** The first run binds a journal to its compartment, environment and landing
  network; a run for any other target is refused. Use one `--journal` per target.
- **One writer.** Commands that write hold an exclusive lock (`<journal>.lock`); a second process is refused with
  the holder's pid. The lock is per host: do not share a journal between hosts on a network file system.
- **Damage is refused, never skipped.** A line that is not a JSON object, or a torn last line, stops every command
  with its line number. Move the file aside and keep it; do not edit it in place.
- **Edits are detected** by the hash chain. A process notices a change made while it runs by the file's inode,
  size or modification time; an edit that keeps all three is not noticed until one of them changes.

## 5c. Network security groups from observed traffic (`netpolicy`)

```
python3 -m ocio netpolicy --inventory inventory.csv --assets assets.csv --flows flows.csv \
        --compartment ocid1.compartment.oc1..xxx --tag cost_center=cc-4410 --tag owner=migration-team
# dry run: one NSG per app tier, least-privilege rules, what the default security list would deny, the
# hybrid flows per wave the network team must route, and a policy_id. Then:
#   ... --apply --policy-id <id> --vcn <VCN OCID> --nsg-map-out nsg.json
```

- Rules are stateful TCP ingress from the calling tier's NSG, one per observed port; at most 25 are added per call,
  and only missing ones (all pages of existing rules are read first).
- **Never two NSGs for one name.** The map is written after each create. Before creating, the VCN is listed: an NSG
  of that name tagged `ocio_nsg=<name>` is reused; one without the tag is someone else's, and the run stops
  before creating anything.
- Pass `--nsg-map nsg.json` to `run` or `ocm-wave` and each VNIC joins its app tier's NSG.

## 5d. Readiness evidence (admission)

Approval answers "may this change happen?"; admission answers "is the estate ready for it right now?".
Give a policy and one evidence document per wave (templates in `examples/`):

```
{"required_checks": ["capacity", "application_health"], "max_age_seconds": 900}              # policy
{"plan_id": "<plan id>", "wave": 1, "observed_at": "2026-10-21T17:00:00Z",                     # evidence
 "checks": [{"name": "capacity", "passed": true, "observer": "Ann", "source_ref": "CHG-1042"}, ...]}
```

A wave is admitted only if exactly one document names this plan id and this wave (an integer). It must be
observed within `max_age_seconds` and not in the future (60 s clock skew), have exactly one row per required
check with `passed: true`, an observer and a source reference, and **record no other check as failed**.
The policy is part of the plan id. Every decision is journalled with the SHA-256 of the evidence. This checks the
evidence's shape, binding and age; it does not prove the claims in it are true.

**To undo a wave on purpose,** use `migrate.py teardown` (above): newest first, journalled, orphans reported.

## 6. Exit codes and what they mean

| Status in the output | Meaning | What to do |
|---|---|---|
| exit code 2, `stopped` | The plan differs from `--plan-id`, the change cap was exceeded, or policy fails. Zero API calls. | Review the new plan; fix the input. |
| `BLOCKED` (policy) | A gate failed on the plan. Zero API calls. | Fix the input, for example missing tags or overlapping CIDRs. |
| `BLOCKED_CHANGED` | The target network or an interrupted run was created with different settings, or an interrupted run's VMs are now split across waves. | Restore the settings, or `migrate.py teardown --run-id <id> --apply` first. If an unconfirmed create is reported, find it by its tags and delete it, then close the run (or re-run teardown). |
| `BLOCKED_STATE` | A VM or network resource the journal lists is not running, cannot be read, or survived a failed rollback. | Investigate in OCI. `migrate.py teardown --run-id <id> --apply` deletes it; `resolve` records it if it is confirmed gone. |
| `SKIPPED_DEPENDENCY` | An app in this wave depends on a wave that did not complete. | Fix that wave first. |
| `BLOCKED_QUOTA` | The wave does not fit the limits, or the limits could not be read. | Raise limits or shrink waves (`--max-vms-per-wave`). Confirm the Limits service name (§8). |
| `BLOCKED_APPROVAL` | No approval was recorded. | Approve, or use `--approve-by`. |
| `BLOCKED_ADMISSION` | The wave's readiness evidence is missing, stale, for another plan or wave, or records a failed check. | Observe again and supply one fresh document for this plan id and wave (§5d). |
| `FAILED_ROLLED_BACK` | A step failed; the wave was undone. | Read `why`, fix, re-run the same command. |
| `FAILED_ROLLBACK_INCOMPLETE` | Rollback could not delete something, or a create may exist without a confirmed OCID. | Orphans are listed by OCID, or by the `ocio_run` / `ocio_step` tags to search for. Delete them, then re-run. |

## 7. First live test (smoke test)

This has **not been run** in the build environment, so it is the first real test. It creates one VCN and one private subnet, plus optionally one Always Free-eligible instance, verifies them, and then deletes everything again.

```
python3 scripts/live_smoke.py --compartment ocid1.compartment.oc1..xxx --availability-domain "Uocm:PHX-AD-1"
python3 scripts/live_smoke.py --compartment ... --availability-domain ... --apply
python3 scripts/live_smoke.py --compartment ... --availability-domain ... --apply --with-instance \
        --image-ocid ocid1.image.oc1.phx.xxx
```

The first command is a dry run. A pass prints `"result": "PASS"`, with `journal_intact: true` and no orphans. If it fails, the report and the journal say where. Use a sandbox compartment.

## 8. IAM: the minimum the operator group needs

From Oracle's *Common Policies* page, verbatim, with the group renamed:

```
Allow group MigrationOperators to manage instance-family in compartment <migration-compartment>
Allow group MigrationOperators to read app-catalog-listing in tenancy
Allow group MigrationOperators to use volume-family in compartment <migration-compartment>
Allow group MigrationOperators to use virtual-network-family in compartment <migration-compartment>
```

Creating the target network (VCN and subnets) needs network management. Oracle's template grants it tenancy-wide (`manage virtual-network-family in tenancy`). Scope it to the migration compartment instead:

```
Allow group MigrationOperators to manage virtual-network-family in compartment <migration-compartment>
```

For `ocm-wave`, from Oracle's *Oracle Cloud Migrations User Policies* page, verbatim:

```
Allow group <OPERATORS-GROUP> to manage ocm-migration-family in compartment id <MIGRATION-COMPARTMENT-OCID>
```

Oracle's resource-types page lists `ocm-target-asset` (UpdateTargetAsset needs `use`, ListTargetAssets
`inspect`), so a narrower `use ocm-target-asset` grant should suffice for `ocm-wave` alone. That narrower
statement is my reading, not a published example; confirm it before relying on it.

**Not confirmed from Oracle's pages; check before relying on them:**
- **The statement for reading service limits.** Oracle's limits page mentions `inspect resource-availability` without a full example; a candidate is `Allow group MigrationOperators to inspect resource-availability in tenancy`.
- **The Limits API service name for compute.** The code defaults to `compute`. Confirm it with:

```
oci limits service list --compartment-id <tenancy-ocid>
oci limits resource-availability get --compartment-id <compartment-ocid> --service-name compute \
    --limit-name standard-e5-core-count --availability-domain <AD>
```

If the lookup fails, the run blocks with "availability ... is unknown" rather than assuming the wave fits. As an alternative, give `--quota-file` a JSON of known limits.

The compute limit names come from Oracle's *Limits by Service* page and are per availability domain: `standard-e5-core-count` / `standard-e5-memory-count` for VM.Standard.E5.Flex, `standard-e4-*` for E4.Flex, and `standard3-*` for Standard3.Flex.

## 9. Limits of this version

- **The live tenancy and OCM have not been exercised.** The SDK adapter is checked offline: request models, retries off, 404 handled as "gone" only after our own delete (OCI also answers 404 for "not authorized"), retryable 409 on delete, transport errors retried, Flex shape limits, fixed vs Flex shapes, and DNS-label cleaning.
- **Data replication and cutover stay with Oracle Cloud Migrations.** `ocm-wave` sets the target of each asset and which assets a plan execution includes; it does not execute the plan.
- **The OCM target-asset match by source display name** must be confirmed on a real plan; `--mapping` is the fallback.
- **Resource types:** VCN, subnet and instance on the `run` path, and NSGs with their rules via `netpolicy`.
  Block volumes and load balancers are next.
- **Not run on Windows:** `Launch.bat` and the Windows journal lock (`msvcrt`) are untested.
- **Sizing is x86 and Arm A1 Flex only:** OCPUs cover both the source vCPUs and its memory at 64 GB per OCPU;
  other shapes are not size-checked.
- **Discovery groups apps by tags, then names checked against traffic.** With non-standard host names and no tags, expect more low-confidence findings to review. On the synthetic estates, groupings that mix apps were always flagged (`examples/evidence.json`); real estates will differ.
- **Re-runs read every finished VM's state from OCI** before skipping it: about one call per VM.
- **One discovery pattern is not flagged:** a caller in front of VMs that share a misleading name and make no
  calls of their own looks exactly like load-balanced replicas, and is trusted.
- **"Gone" after a 404 is known only within one process.** OCI answers 404 for both "deleted" and "not authorized", so a VCN or subnet deleted by an earlier process and later seen as 404 is reported as an orphan, not assumed gone. Confirm it and use `resolve`.
- **The scale results are measured in a 2-CPU container against the simulated OCI.** They show the planner and pacing behaviour, not OCI's real throughput. `scripts/scale_test.py` and `scripts/evidence.py` reproduce the scale, discovery and guard figures in `BRIEF.md`; `demo_v2.py`, the test suite and `mutate.py` reproduce the rest.
