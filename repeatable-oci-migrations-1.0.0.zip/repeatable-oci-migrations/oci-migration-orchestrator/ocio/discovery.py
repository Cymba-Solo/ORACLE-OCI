"""Discovery: propose app groups, tiers and app-to-app dependencies from observed evidence.

Oracle Cloud Migrations discovers VMs and their size (vCenter, AWS EC2, or a CSV such as RVTools). Its
published discovery material does not cover which VMs form an application or what depends on what, and
those are exactly the inputs wave planning needs. This module proposes them from three exports:

  assets.csv      name, ip, os, vcpus, memory_gb[, tags]      ip: one or more, "10.0.0.5;10.0.1.5"
                                                               tags: "app=crm;tier=web;critical=yes"
  vips.csv        vip, name                                    optional: load-balancer VIPs, Oracle RAC
                                                               SCAN/VIP addresses -> the VM(s) serving them
  flows.csv       src_ip, dst_ip, dst_port, connections        aggregated over an observation window
  listeners.csv   name, port[, process]                        optional: listening ports per VM

Every finding carries a source, a confidence in [0, 1] and its evidence. Nothing here is final:
a person reviews the findings (decisions.json) and the result is turned into the inventory the
blueprint factory already reads. Rules that keep this safe:

  * Declared beats inferred. A tag (app=, tier=) wins over anything inferred, with confidence 1.0.
  * A dependency that has not been reviewed is KEPT. Keeping an unneeded dependency only makes a wave
    later; dropping a real one moves a database before the app that needs it is ready.
  * Only a reviewer can drop a dependency ("reject"). Low confidence alone never drops one.
  * Administrative and infrastructure traffic (SSH, RDP, DNS, NTP, LDAP, Kerberos, SNMP, syslog,
    WinRM, node exporters) is not an application dependency and is excluded, and listed as excluded.
  * Traffic to addresses outside the inventory is reported as an external dependency (for example a
    mainframe or a SaaS endpoint), never silently dropped. A PRIVATE address that is not in the inventory
    and not in the VIP map is "unresolved": it is most likely a VIP, a SCAN address or a second NIC of an
    estate VM, i.e. a dependency discovery cannot see yet. The reviewed inventory is not written until
    each one is mapped (vips.csv) or acknowledged as truly external (decisions "external_ok"). The same
    holds for a PRIVATE SOURCE address not in the inventory (an unlisted VM or a second NIC).
  * Traffic to a VIP counts for every VM behind it; if those VMs end up in different apps, all are flagged.
  * A VM with no observed traffic is flagged: no evidence is not evidence of no dependencies.
"""
from __future__ import annotations

import csv
import ipaddress
import json
import re
from collections import defaultdict
from dataclasses import dataclass, field

from .factory import Workload

DB_PORTS = {1521: "Oracle DB", 1522: "Oracle DB", 5432: "PostgreSQL", 3306: "MySQL", 1433: "SQL Server",
            27017: "MongoDB", 50000: "Db2", 6379: "Redis"}
WEB_PORTS = {80: "HTTP", 443: "HTTPS", 8443: "HTTPS-alt"}
INFRA_PORTS = {22: "SSH", 3389: "RDP", 53: "DNS", 123: "NTP", 88: "Kerberos", 389: "LDAP", 636: "LDAPS",
               161: "SNMP", 162: "SNMP trap", 514: "syslog", 5985: "WinRM", 5986: "WinRM-TLS", 9100: "node exporter"}
TIER_TOKENS = {"web", "app", "db", "api", "svc", "srv"}
GENERIC_NAMES = {"srv", "server", "vm", "host", "node", "app", "web", "db", "box", "machine", "inst", "ec2"}


@dataclass
class Asset:
    """One source VM as exported (assets.csv row): name, address(es), OS string, vCPUs, memory in GB (may be
    fractional, e.g. 15.5 from an MB export) and optional tags such as app=, tier=, critical=."""
    name: str
    ip: str                  # one address, or several separated by ";"
    os: str
    vcpus: int
    memory_gb: int
    tags: dict = field(default_factory=dict)

    @property
    def ips(self):
        """The VM's addresses as a list: the ip field split on ";", blanks dropped."""
        return [norm_ip(x) for x in self.ip.split(";") if x.strip()]


# RFC 1918 private ranges and RFC 6598 shared (carrier-grade NAT) space: where an enterprise's own VIPs,
# SCAN addresses and second NICs live. (Python's is_private also covers documentation ranges such as
# 192.0.2.0/24, which are not internal networks.)
# IPv6: fc00::/7 (unique local addresses, RFC 4193) is the IPv6 equivalent of RFC 1918.
_INTERNAL = [ipaddress.ip_network(n) for n in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "100.64.0.0/10",
                                               "fc00::/7")]


def norm_ip(text):
    """One spelling per address, so files from different tools match: IPv6 compressed and lower case
    (FD00:0010::9 -> fd00:10::9), an IPv4-mapped IPv6 address reduced to its IPv4 (::ffff:10.0.0.1 -> 10.0.0.1).
    Anything that is not an IP address is returned stripped, unchanged."""
    t = str(text).strip()
    try:
        a = ipaddress.ip_address(t)
    except ValueError:
        return t
    if a.version == 6 and a.ipv4_mapped is not None:
        return str(a.ipv4_mapped)
    return a.compressed


def _private(ip):
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return any(a in n for n in _INTERNAL)


@dataclass
class Finding:
    """One inferred or declared fact about a VM (its app or its tier): the value, where it came from
    (tag | ports | name | name+traffic | default), a confidence in [0, 1], and the evidence in words.
    Anything below 0.6 is listed for review in DiscoveryResult.report()."""
    value: str
    source: str              # tag | ports | name | default
    confidence: float
    evidence: str


@dataclass
class Dependency:
    """An app-to-app dependency seen in traffic: from_app initiates connections to to_app's service ports.

    connections: total connections over the observation window (a flow to a VIP counts once, not once per
    VM behind it); pairs: distinct (source VM, destination VM) pairs; ports: destination ports seen;
    confidence: dep_confidence(connections, pairs)."""
    from_app: str
    to_app: str
    confidence: float
    connections: int
    pairs: int
    ports: list

    @property
    def key(self):
        """"from_app->to_app": the name a reviewer uses for this dependency in decisions.json."""
        return f"{self.from_app}->{self.to_app}"


@dataclass
class DiscoveryResult:
    """Everything discover() found, before review: per-VM app and tier findings, dependencies, external and
    unresolved traffic, excluded infrastructure traffic, silent VMs and apps tagged critical. report() gives
    the JSON a reviewer reads; to_workloads() turns the reviewed result into the factory's inventory."""
    assets: list
    app: dict                 # vm name -> Finding
    tier: dict                # vm name -> Finding
    deps: list                # [Dependency]
    external: list            # [{from_app, dst_ip, port, connections}] public / documented-external addresses
    unresolved: list          # same shape: PRIVATE addresses not in the inventory or the VIP map
    excluded_infra: dict      # port label (or "self ...": a VM to its own address) -> connections
    silent_vms: list          # VMs with no observed traffic at all
    critical_apps: list
    unresolved_sources: list = field(default_factory=list)   # [{src_ip, to_vm, to_app, port, connections}]:
                                                             # PRIVATE sources not in the inventory
    infrastructure_only_vms: list = field(default_factory=list)   # traffic seen, but only on admin/infra
                                                                  # ports (SSH, DNS, ...): no evidence of what
                                                                  # the VM serves or calls; review
    internal_pairs: list = field(default_factory=list)   # [(src vm, dst vm)] calls between VMs of one discovered
                                                         # app: they become dependencies if a review splits it

    def report(self) -> dict:
        """JSON-serialisable summary for review (findings.json): VM and app counts, where app and tier evidence
        came from, VMs whose app or tier confidence is below 0.6, every dependency with its confidence and
        evidence counts, external and unresolved addresses, excluded infrastructure traffic, silent VMs and
        critical apps. Read-only."""
        return {
            "vms": len(self.assets),
            "apps": sorted({f.value for f in self.app.values()}),
            "app_sources": _count(f.source for f in self.app.values()),
            "tier_sources": _count(f.source for f in self.tier.values()),
            "low_confidence_vms": sorted(n for n in self.app if min(self.app[n].confidence, self.tier[n].confidence) < 0.6),
            "dependencies": [{"dep": d.key, "confidence": d.confidence, "connections": d.connections,
                              "vm_pairs": d.pairs, "ports": d.ports} for d in self.deps],
            "external_dependencies": self.external,
            "unresolved_private_destinations": self.unresolved,
            "unresolved_private_sources": self.unresolved_sources,
            "excluded_infrastructure_traffic": self.excluded_infra,
            "silent_vms": self.silent_vms,
            "infrastructure_only_vms": self.infrastructure_only_vms,
            "critical_apps": self.critical_apps,
        }

    def to_workloads(self, decisions=None):
        """Turn the reviewed findings into the factory's inventory. Returns (workloads, summary).

        decisions: {"dependencies": {"a->b": "accept"|"reject"}, "apps": {vm: app}, "tiers": {vm: tier},
        "external_ok": [ip, ...], "reviewed_by": name}. reviewed_by is required as soon as a decision rejects
        a dependency or moves a VM to another app or tier. Unreviewed dependencies are kept (see the module
        docstring); when apps are renamed, merged or split, each kept dependency carries over to every app the
        VMs ended up in. Raises ValueError (nothing written) while any unresolved private destination or source
        is neither mapped nor listed in external_ok, for a decision other than accept/reject, for a decision
        about a dependency discovery did not propose, for a tier other than web/app/db, or for a change
        without a reviewer. summary counts accepted, rejected and unreviewed-kept dependencies (+ reviewed_by)."""
        decisions = decisions or {}
        known = {"dependencies", "apps", "tiers", "external_ok", "reviewed_by"}
        typos = sorted(k for k in decisions if k not in known and not str(k).startswith("_"))
        if typos:                                   # a misspelt section would otherwise be ignored silently
            raise ValueError(f"decisions: unknown section(s) {typos}; use {sorted(known)} (keys starting with '_' "
                             f"are comments)")
        for section in ("apps", "tiers"):
            ghosts = sorted(set(decisions.get(section, {})) - set(self.app))
            if ghosts:                              # a misspelt VM name would otherwise change nothing, silently
                raise ValueError(f"decisions {section}: {ghosts} not in the assets; check the VM names")
        ext_ok = decisions.get("external_ok", [])
        if not isinstance(ext_ok, list) or not all(isinstance(x, str) for x in ext_ok):
            raise ValueError("decisions external_ok must be a list of addresses (set('10.0.0.5') would be its "
                             "characters)")
        ack = {norm_ip(x) for x in ext_ok}
        open_ = sorted({u["dst_ip"] for u in self.unresolved} - ack)
        if open_:
            raise ValueError(f"unresolved private destinations {open_}: map them in vips.csv (a VIP, SCAN address "
                             f"or second NIC of an estate VM) or list them under 'external_ok' if truly external")
        open_src = sorted({u["src_ip"] for u in self.unresolved_sources} - ack)
        if open_src:
            raise ValueError(f"unresolved private sources {open_src}: add the VM (or its second address, ';'-separated "
                             f"in assets.csv), or list them under 'external_ok' if truly outside the estate")
        dd = decisions.get("dependencies", {})
        bad = {k: v for k, v in dd.items() if v not in ("accept", "reject")}
        if bad:
            raise ValueError(f"dependency decisions must be 'accept' or 'reject': {bad}")
        unknown = set(dd) - {d.key for d in self.deps}
        if unknown:
            raise ValueError(f"decisions name dependencies discovery did not propose: {sorted(unknown)}")
        app_of = {n: decisions.get("apps", {}).get(n, f.value) for n, f in self.app.items()}
        tier_of = {n: decisions.get("tiers", {}).get(n, f.value) for n, f in self.tier.items()}
        bad_tiers = {n: t for n, t in tier_of.items() if t not in ("web", "app", "db")}
        if bad_tiers:
            raise ValueError(f"tiers must be web, app or db: {bad_tiers}")
        # Rejecting a discovered dependency, or regrouping VMs into other apps or tiers, changes which waves
        # things land in: a wrong call puts an app in OCI before what it talks to. Such a change must name
        # who made it, and the name travels with the reviewed inventory. (Accepting changes nothing.)
        who = decisions.get("reviewed_by")
        changes = ([k for k, v in dd.items() if v == "reject"]
                   + [f"app of {n}" for n, a in decisions.get("apps", {}).items() if a != getattr(self.app.get(n), "value", a)]
                   + [f"tier of {n}" for n, t in decisions.get("tiers", {}).items() if t != getattr(self.tier.get(n), "value", t)]
                   # declaring a PRIVATE address outside the estate drops the dependency it carried
                   + [f"external_ok {x}" for x in sorted(ack & ({u["dst_ip"] for u in self.unresolved}
                                                                | {u["src_ip"] for u in self.unresolved_sources}))])
        if changes and (not isinstance(who, str) or not who.strip()):
            raise ValueError(f"decisions change discovery's findings ({changes[:5]}{' ...' if len(changes) > 5 else ''}) "
                             f"but name no reviewer: add \"reviewed_by\": \"<name>\" to the decisions file")
        kept = defaultdict(set)
        summary = {"accepted": 0, "rejected": 0, "unreviewed_kept": 0}
        if isinstance(who, str) and who.strip():
            summary["reviewed_by"] = who.strip()
        if ack:
            summary["external_ok"] = sorted(ack)
        for d in self.deps:
            v = dd.get(d.key)
            if v == "reject":
                summary["rejected"] += 1
                continue
            summary["accepted" if v == "accept" else "unreviewed_kept"] += 1
            kept[d.from_app].add(d.to_app)
        # A reviewer may rename, merge or split apps. Each discovered app maps to the set of reviewed apps
        # its VMs ended up in; dependencies carry over to every one of them (conservative on a split).
        maps_to = defaultdict(set)
        for n in self.app:
            maps_to[self.app[n].value].add(app_of[n])
        deps_by_app = defaultdict(set)
        for a, tos in kept.items():
            for t in tos:
                for fa in maps_to[a]:
                    for ta in maps_to[t]:
                        if fa != ta:
                            deps_by_app[fa].add(ta)
        for sv, dv in self.internal_pairs:       # traffic inside a discovered app that the review split apart
            if app_of[sv] != app_of[dv]:
                deps_by_app[app_of[sv]].add(app_of[dv])
        wls = [Workload(a.name, app_of[a.name], tier_of[a.name], a.os, a.vcpus, a.memory_gb,
                        tuple(sorted(deps_by_app.get(app_of[a.name], ())))) for a in self.assets]
        return wls, summary


def _count(it):
    out = defaultdict(int)
    for x in it:
        out[x] += 1
    return dict(sorted(out.items()))


def _tags(text):
    out = {}
    for part in (text or "").split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip().lower()] = v.strip()
    return out


def load_assets(path) -> list[Asset]:
    """Read assets.csv (columns name, ip, os, vcpus, memory_gb, optional tags) into Assets.

    UTF-8 with or without a byte-order mark. vcpus must be a whole number above 0 and memory_gb a number above
    0 (fractions kept). Raises ValueError naming the line for a missing column or bad value, and for duplicate
    VM names or duplicate addresses anywhere in the file (an address must identify one VM)."""
    out = []
    with open(path, newline="", encoding="utf-8-sig") as f:   # Excel "CSV UTF-8" adds a BOM
        for i, r in enumerate(csv.DictReader(f), start=2):
            try:
                mem = float(r["memory_gb"])                  # 15.5 from an MB export is fine; sizing rounds up
                if int(r["vcpus"]) <= 0 or not mem > 0:
                    raise ValueError(f"vcpus and memory_gb must be greater than 0 (got {r['vcpus']}, {r['memory_gb']})")
                out.append(Asset(r["name"].strip(), r["ip"].strip(), r["os"].strip(), int(r["vcpus"]),
                                 int(mem) if mem == int(mem) else mem, _tags(r.get("tags"))))
            except (KeyError, ValueError) as e:
                raise ValueError(f"assets line {i}: {e!r}") from e
    names = [a.name for a in out]
    ips = [ip for a in out for ip in a.ips]
    if len(names) != len(set(names)):
        raise ValueError("assets have duplicate names")
    if len(ips) != len(set(ips)):
        raise ValueError("assets have duplicate ips")
    return out


def load_vips(path) -> dict:
    """vip -> [vm names] (several rows for one VIP: e.g. RAC nodes behind a SCAN address)."""
    out = defaultdict(list)
    with open(path, newline="", encoding="utf-8-sig") as f:   # Excel "CSV UTF-8" adds a BOM
        for i, r in enumerate(csv.DictReader(f), start=2):
            try:
                out[norm_ip(r["vip"])].append(r["name"].strip())
            except KeyError as e:
                raise ValueError(f"vips line {i}: {e!r}") from e
    return dict(out)


def load_flows(path) -> list[tuple]:
    """Read flows.csv (src_ip, dst_ip, dst_port, connections) into (src, dst, port, connections) tuples.
    UTF-8 with or without a BOM; ValueError naming the line for a missing column or non-integer value."""
    out = []
    with open(path, newline="", encoding="utf-8-sig") as f:   # Excel "CSV UTF-8" adds a BOM
        for i, r in enumerate(csv.DictReader(f), start=2):
            try:
                out.append((norm_ip(r["src_ip"]), norm_ip(r["dst_ip"]), int(r["dst_port"]), int(r["connections"])))
            except (KeyError, ValueError) as e:
                raise ValueError(f"flows line {i}: {e!r}") from e
    return out


def load_listeners(path) -> dict:
    """Read listeners.csv (name, port[, process]) into {vm name: {ports}}. Ports a VM listens on count as
    served ports for tier inference even if no flow to them was observed. ValueError names a bad line."""
    out = defaultdict(set)
    with open(path, newline="", encoding="utf-8-sig") as f:   # Excel "CSV UTF-8" adds a BOM
        for i, r in enumerate(csv.DictReader(f), start=2):
            try:
                out[r["name"].strip()].add(int(r["port"]))
            except (KeyError, ValueError) as e:
                raise ValueError(f"listeners line {i}: {e!r}") from e
    return dict(out)


# A caller whose callees belong to more than this many apps is a hub (scheduler, health checker, batch
# driver): being called by it says nothing about which app a VM belongs to.
HUB_CALLEE_APPS = 3


def name_app(name: str) -> str:
    """'crm-web-01' -> 'crm'; 'billing02' -> 'billing'. Strips a trailing number, then a tier word."""
    base = re.sub(r"[-_]?\d+$", "", name.lower())
    parts = [p for p in re.split(r"[-_]", base) if p]
    while len(parts) > 1 and parts[-1] in TIER_TOKENS:
        parts.pop()
    return "-".join(parts) or name.lower()


def dep_confidence(connections: int, pairs: int) -> float:
    """Heuristic, monotone in both inputs: ~0.5 at 10 connections from one VM pair; more VM pairs
    showing the same dependency raise it faster than more connections from one pair."""
    c = 1.0 - 0.5 ** (connections / 10.0)
    p = 1.0 - 0.5 ** pairs
    return round(min(0.99, 0.6 * c + 0.4 * p), 3)


def discover(assets, flows, listeners=None, min_connections=1, vips=None) -> DiscoveryResult:
    """Propose apps, tiers and dependencies from assets, flows, optional listeners and an optional VIP map.

    Rules (see the module docstring for why): tags win with confidence 1.0; tiers are inferred from served
    ports (database, web, other, none); untagged VMs are grouped by name pattern only where traffic connects
    them, otherwise split or flagged; VIPs count for every VM behind them; infrastructure ports are excluded
    and counted; private addresses outside the inventory are "unresolved", public ones "external"; flows
    with fewer than min_connections are ignored. Raises ValueError if a VIP names an unknown VM or is also
    a VM address. Pure computation: no I/O."""
    flows = [(norm_ip(a), norm_ip(b), p, n) for a, b, p, n in flows]           # callers may pass raw spellings
    vips = {norm_ip(k): v for k, v in (vips or {}).items()} or None
    listeners = listeners or {}
    by_ip = {ip: [a] for a in assets for ip in a.ips}
    by_name = {a.name: a for a in assets}
    for vip, names in (vips or {}).items():
        unknown = [n for n in names if n not in by_name]
        if unknown:
            raise ValueError(f"VIP {vip} maps to VMs not in the assets: {unknown}")
        if vip in by_ip:
            raise ValueError(f"VIP {vip} is also listed as a VM address")
        by_ip[vip] = [by_name[x] for x in sorted(set(names))]   # traffic to a VIP reaches EVERY VM behind it
    # --- a VM's traffic to its own address (local health checks, an app calling itself by IP) says nothing
    # about which app it belongs to or what it serves to others: set aside, counted like infrastructure traffic
    selfish = 0
    kept = []
    for f in flows:
        ss, ds = by_ip.get(f[0], ()), by_ip.get(f[1], ())
        if len(ss) == 1 and list(ds) == list(ss):
            if f[3] >= min_connections:
                selfish += f[3]
        else:
            kept.append(f)
    flows = kept
    # --- observed server ports per VM: declared listeners plus ports other VMs connect to. Listener names are
    # matched to asset names ignoring case (CMDB and agent exports often upper-case host names); a listener for
    # a VM that is not in the assets is refused, like a VIP that names one: dropping it would hide a typo.
    folded = defaultdict(list)
    for a in assets:
        folded[a.name.lower()].append(a.name)
    served = defaultdict(set)
    unknown = sorted(n for n in listeners if n not in by_name and len(folded.get(n.lower(), ())) != 1)
    if unknown:
        raise ValueError(f"listeners name VMs not in the assets: {unknown}; remove those rows or add the VMs")
    for n, ports in listeners.items():
        served[n if n in by_name else folded[n.lower()][0]] |= set(ports)
    for src, dst, port, n in flows:
        if n >= min_connections and port not in INFRA_PORTS:
            for d in by_ip.get(dst, ()):
                served[d.name].add(port)

    tier, app = {}, {}
    for a in assets:
        ports = served.get(a.name, set())
        tag = str(a.tags.get("tier") or "").strip().lower()          # "DB", " Db " are db tags
        if tag in ("web", "app", "db"):
            tier[a.name] = Finding(tag, "tag", 1.0, "tier tag")
        else:
            db = sorted(p for p in ports if p in DB_PORTS)
            web = sorted(p for p in ports if p in WEB_PORTS)
            other = sorted(p for p in ports if p not in DB_PORTS and p not in WEB_PORTS)
            if db and not web:
                tier[a.name] = Finding("db", "ports", 0.9, f"serves {', '.join(f'{p} ({DB_PORTS[p]})' for p in db)}")
            elif web and not db:
                tier[a.name] = Finding("web", "ports", 0.85, f"serves {', '.join(f'{p} ({WEB_PORTS[p]})' for p in web)}")
            elif db and web:
                tier[a.name] = Finding("db", "ports", 0.5, f"serves both database {db} and web {web} ports; review")
            elif other:
                tier[a.name] = Finding("app", "ports", 0.7, f"serves non-web, non-database ports {other[:5]}")
            else:
                tier[a.name] = Finding("app", "default", 0.3, "no server ports observed; defaulted to app")
            if tag:                                  # a tier tag that is not a tier: inferred, but flagged
                f = tier[a.name]
                tier[a.name] = Finding(f.value, f.source, min(f.confidence, 0.5),
                                       f"{f.evidence}; tier tag {a.tags['tier']!r} is not web, app or db; review")
        if a.tags.get("app"):
            app[a.name] = Finding(a.tags["app"], "tag", 1.0, "app tag")

    # --- app grouping by name, checked against traffic. A name pattern alone is weak evidence: generic
    # host names (srv12345, vm-0042) would otherwise collapse unrelated VMs into one large "app".
    # A name group is trusted only if traffic among its members connects them; otherwise it is split
    # into its traffic-connected parts, and each part is flagged for review.
    untagged = [a for a in assets if a.name not in app]
    tagged_by_pattern = defaultdict(set)          # built once: O(n), not O(groups x VMs)
    for a in assets:
        if a.name in app:
            tagged_by_pattern[name_app(a.name)].add(a.name)
    groups = defaultdict(list)
    for a in untagged:
        groups[name_app(a.name)].append(a)
    links, callers, callees = defaultdict(set), defaultdict(set), defaultdict(set)
    for src, dst, port, n in flows:
        if n >= min_connections and port not in INFRA_PORTS:
            for s in by_ip.get(src, ()):
                for d in by_ip.get(dst, ()):
                    links[s.name].add(d.name); links[d.name].add(s.name)
                    callees[s.name].add(d.name); callers[d.name].add(s.name)
    for names in (vips or {}).values():              # VMs serving one VIP / SCAN address belong together
        for x in names:
            links[x].update(y for y in names if y != x)
    group_of = {a.name: (a.tags.get("app") or name_app(a.name)) for a in assets}
    callee_groups = {x: {group_of[y] for y in ys} for x, ys in callees.items()}
    callee_groups = defaultdict(set, callee_groups)
    for guess, members in groups.items():
        # Deliberately conservative: any prefix of 3 letters or fewer counts as generic and is always flagged.
        # This also flags short real app names (crm, hr, erp). Measured on synthetic estates, dropping the rule
        # saves 1-2 points of VMs to review and still left 0 mixed groups unflagged, but the synthetic data does
        # not contain random short prefixes (e.g. "ab12"), so the rule stays until real data shows it is safe.
        generic = guess in GENERIC_NAMES or re.fullmatch(r"[a-z]{1,3}", guess) is not None
        if len(members) == 1:
            app[members[0].name] = Finding(guess, "name", 0.35 if generic else 0.4, "name pattern unique to this VM")
            continue
        names = {m.name for m in members}
        # Tagged VMs with the same name pattern count as bridges. STRONG evidence that two members belong
        # together: they talk to each other, OR are both called by the same client that is not a hub (calls
        # VMs of at most HUB_CALLEE_APPS apps) AND they call compatible backends (load-balanced replicas),
        # OR both call the same server WITHIN the name group (replicas sharing their own app's backend).
        # Known residual: a hub caller that only ever calls VMs sharing one misleading name, none of which
        # call anything themselves, still joins them; that pattern is indistinguishable from replicas.
        # WEAK evidence: they only call the same server, or servers of the same app, OUTSIDE the group. That is also what two unrelated
        # apps look like when they share a database or message bus, so a group held together only by weak
        # evidence keeps its name but is flagged for review instead of being trusted.
        bridge = names | tagged_by_pattern.get(guess, set())

        def compatible(x, y):   # replicas call the same backends; two apps behind one caller usually do not
            return not callees[x] or not callees[y] or bool(callee_groups[x] & callee_groups[y])

        def shared_caller(x, y):
            return any(len(callee_groups[c]) <= HUB_CALLEE_APPS for c in callers[x] & callers[y]) and compatible(x, y)

        def strong(x):
            return {y for y in bridge if y != x and (y in links[x] or shared_caller(x, y)
                                                       or callees[x] & callees[y] & bridge)}

        def weak(x):            # call the same server, or servers of the same app, outside the group
            return strong(x) | {y for y in bridge if y != x and callee_groups[x] & callee_groups[y]}

        active = {m for m in names if links[m]}      # a VM with no traffic is evidence of nothing either way
        silent = names - active

        def components(near):
            comps, seen = [], set()
            for m in sorted(active):
                if m in seen:
                    continue
                comp, todo = set(), [m]
                while todo:
                    x = todo.pop()
                    if x in comp:
                        continue
                    comp.add(x)
                    todo.extend(near(x) - comp)
                comp &= active
                seen |= comp
                comps.append(sorted(comp))
            return comps
        comps = components(strong)
        for m in sorted(silent):
            app[m] = Finding(guess, "name", 0.35, f"name pattern '{guess}' only: no traffic observed for this VM; review")
        members = [m for m in members if m.name in active]
        if not members:
            continue
        if len(comps) > 1 and len(components(weak)) == 1:
            for m in members:
                app[m.name] = Finding(guess, "name", 0.35 if generic else 0.5,
                                      f"name pattern shared by {len(members)} VMs, joined only by calling the same "
                                      f"servers outside the group (could be one app, or several sharing a backend); review")
        elif len(comps) == 1 and not generic:
            for m in members:
                app[m.name] = Finding(guess, "name", 0.8,
                                      f"name pattern shared by {len(members)} VMs, and traffic connects them")
        elif len(comps) == 1:
            for m in members:
                app[m.name] = Finding(guess, "name", 0.35,
                                      f"generic name pattern '{guess}'; traffic connects these {len(members)} VMs; review")
        else:
            for k, comp in enumerate(comps, start=1):
                for m in comp:
                    app[m] = Finding(f"{guess}-group{k}", "name+traffic", 0.35,
                                     f"name pattern '{guess}' is shared by {len(members)} VMs, but traffic splits "
                                     f"them into {len(comps)} separate groups; review")

    # --- VIPs whose VMs ended up in different apps: the VIP itself says they belong together, so flag
    for vip, names in sorted((vips or {}).items()):
        if len({app[x].value for x in names}) > 1:
            for x in names:
                f = app[x]
                app[x] = Finding(f.value, f.source, min(f.confidence, 0.35),
                                 f"{f.evidence}; serves VIP {vip} together with VMs grouped into other apps; review")

    # --- dependencies: src app initiates to dst app's service port
    agg = defaultdict(lambda: {"connections": 0, "pairs": set(), "ports": set()})
    external, unresolved, unresolved_src = defaultdict(int), defaultdict(int), defaultdict(int)
    excluded = defaultdict(int)
    seen_vms, app_seen, internal = set(), set(), set()
    for src, dst, port, n in flows:
        if n < min_connections:
            continue
        ss, ds = by_ip.get(src, []), by_ip.get(dst, [])
        seen_vms.update(x.name for x in ss + ds)
        if port in INFRA_PORTS:
            excluded[f"{port} ({INFRA_PORTS[port]})"] += n
            continue
        app_seen.update(x.name for x in ss + ds)
        if not ss:
            # Inbound from outside the estate (users, partners) is not a dependency. But a PRIVATE source
            # address that is not in the inventory is most likely an estate VM's second NIC or an unlisted
            # VM, so it is reported like an unresolved destination and must be placed by a reviewer.
            if _private(src):
                for d in ds:
                    unresolved_src[(src, d.name, app[d.name].value, port)] += n
            continue
        for s in ss:
            if not ds:
                (unresolved if _private(dst) else external)[(app[s.name].value, dst, port)] += n
                continue
            counted = set()                # a flow to a VIP reaches every VM behind it, but is ONE flow
            for d in ds:
                fa, ta = app[s.name].value, app[d.name].value
                if fa == ta:
                    if s.name != d.name:   # inside one app: not a dependency now, but one if a reviewer splits it
                        internal.add((s.name, d.name))
                    continue
                g = agg[(fa, ta)]
                if (fa, ta) not in counted:
                    g["connections"] += n
                    counted.add((fa, ta))
                g["pairs"].add((s.name, d.name))
                g["ports"].add(port)
    deps = sorted((Dependency(fa, ta, dep_confidence(g["connections"], len(g["pairs"])), g["connections"],
                              len(g["pairs"]), sorted(g["ports"])) for (fa, ta), g in agg.items()),
                  key=lambda x: (-x.confidence, x.key))
    ext = [{"from_app": a, "dst_ip": ip, "port": p, "connections": n}
           for (a, ip, p), n in sorted(external.items())]
    unres = [{"from_app": a, "dst_ip": ip, "port": p, "connections": n}
             for (a, ip, p), n in sorted(unresolved.items())]
    unres_src = [{"src_ip": ip, "to_vm": vm, "to_app": a, "port": p, "connections": n}
                 for (ip, vm, a, p), n in sorted(unresolved_src.items())]
    if selfish:
        excluded["self (a VM to its own address)"] += selfish
    critical = sorted({app[a.name].value for a in assets if a.tags.get("critical", "").lower() in ("yes", "true", "1")})
    return DiscoveryResult(assets, app, tier, deps, ext, unres, dict(sorted(excluded.items())),
                           sorted(a.name for a in assets if a.name not in seen_vms), critical, unres_src,
                           sorted(a.name for a in assets if a.name in seen_vms and a.name not in app_seen),
                           sorted(internal))


def load_decisions(path) -> dict:
    """Read a reviewer's decisions.json as is; DiscoveryResult.to_workloads validates its contents."""
    with open(path) as f:
        return json.load(f)
