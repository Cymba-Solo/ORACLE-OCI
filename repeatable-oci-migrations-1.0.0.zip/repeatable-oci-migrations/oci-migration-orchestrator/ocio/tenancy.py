"""Checks against the tenancy itself, before anything is created.

Availability-domain names are tenancy-specific: the prefix (e.g. "Uocm:" in "Uocm:PHX-AD-1", the
example in the SDK's LaunchInstanceDetails documentation) differs between tenancies, and many regions
have a single AD. A wrong name fails only at launch time, part-way through a wave; this fails first.
"""
from __future__ import annotations


def availability_domains(identity, tenancy_id):
    """oci.identity.IdentityClient.list_availability_domains(compartment_id=<tenancy>) -> names."""
    return [ad.name for ad in identity.list_availability_domains(compartment_id=tenancy_id).data]


def check_availability_domain(identity, tenancy_id, ad):
    """Return the tenancy's AD names if `ad` is one of them; otherwise ValueError listing the real names. One
    read-only Identity call (list_availability_domains on the tenancy), made before anything is created.
    """
    names = availability_domains(identity, tenancy_id)
    if ad not in names:
        raise ValueError(f"availability domain {ad!r} is not in this tenancy/region; it has: {names}")
    return names
