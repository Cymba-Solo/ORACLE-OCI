"""One-click launch: a radio-button console that builds, previews and runs ocio commands.

HOW IT IS STARTED
  Double-click Launch.command (macOS), Launch.bat (Windows) or launch.sh (Linux), or run `ocio ui`.
  That starts serve() below: a small web server on 127.0.0.1 only, on a free port, which opens the
  console in the default browser. Closing the terminal window stops it.

WHAT THE CONSOLE DOES
  Radio buttons choose the command (discover, plan, run, ocm-wave, netpolicy, status) and its options
  (environment, dry run or apply, authentication mode, fault-domain spread, image source, quota source,
  cutover check). Only the fields that matter for the current choices are shown. The exact command is
  previewed as it is built; Run executes it and shows the output; a plan id or policy id printed by a dry
  run is carried into the form, so dry run -> review -> apply is three clicks.

ONE SCHEMA, CHECKED ON THE SERVER
  SCHEMA below is the single definition of every radio group and field. The page uses it to show fields
  and preview the command; the server uses the SAME schema to validate every value and build the argument
  list itself (build_argv). The page never sends a command line, and nothing goes through a shell:
  values are passed as separate arguments to `python -m ocio`, and a value starting with "-" is refused,
  so a field cannot smuggle in a flag.

NOTHING IS WEAKER THAN THE COMMAND LINE
  Apply goes through exactly the same gates as typing the command: the reviewed --plan-id / --policy-id,
  a named approver for waves that need one (there is no terminal, so the interactive prompt answers "not
  approved"), quota, policy, cutover, admission, region and journal lock. The console adds a confirmation
  step before an apply; it removes none.

LOCAL-ONLY SERVER
  Bound to 127.0.0.1. Every API request must carry the per-session token (a random 32-byte value, compared in
  constant time) and a Host header naming this server (blocks DNS rebinding); POSTs must be application/json
  (a cross-site form cannot send that without a CORS preflight this server never answers). One command runs
  at a time. The token is NEVER in a page the server returns: 127.0.0.1 is reachable by every account on the
  machine, so anything GET / returns is public to them. It reaches the operator's browser only through a
  private launch file (0600 in a 0700 folder, write_launch_file) as a URL fragment, which browsers never send
  to a server, and the page moves it into the tab's sessionStorage and off the address bar (TOKEN_BOOT).

OPENED AS A FILE
  console.html saved from the server (or `ocio ui --write console.html`) works without Python as a command
  builder: same radios, same preview, a Copy button; Run is replaced by a note saying how to launch.
"""
from __future__ import annotations

import hmac
import json
import os
import re
import secrets
import shlex
import subprocess
import sys
import threading
import time

from . import shell

PACKAGE_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LIVE = ("run", "ocm-wave", "netpolicy")

# ------------------------------------------------------------------ the schema (single source of truth)

COMMANDS = [
    ("discover", "Discover", "search", "Assets and observed flows -> apps, tiers, dependencies, a review file."),
    ("plan", "Plan", "layers", "Inventory -> blueprints, deviations, refusals and dependency-ordered waves. No OCI calls."),
    ("run", "Run (rebuild)", "play", "Build the target network and launch from images, wave by wave. Dry run unless Apply."),
    ("ocm-wave", "OCM wave", "waves", "Write one wave's blueprint settings into an Oracle Cloud Migrations plan."),
    ("netpolicy", "Network policy", "network", "Observed flows -> least-privilege NSGs; creates them with Apply."),
    ("status", "Journal status", "file", "Read-only: journal integrity, runs, resources. Safe at any time."),
]

# key, label, commands, options [(value, label, hint)], default
RADIOS = [
    ("mode", "Mode", LIVE, [("dry", "Dry run", "Shows what would happen. Sends nothing to OCI."),
                            ("apply", "Apply", "Changes the tenancy. Needs the reviewed id from a dry run.")], "dry"),
    ("env", "Environment", ("plan",) + LIVE, [("dev", "Development", ""), ("test", "Test", ""),
                                              ("prod", "Production", "Approval required; stricter policy gates.")], "dev"),
    ("auth", "Authentication", LIVE, [
        ("api_key", "API key", "~/.oci/config profile"),
        ("security_token", "Session token", "oci session authenticate"),
        ("instance_principal", "Instance principal", "Running on an OCI instance"),
        ("resource_principal", "Resource principal", "Running in an OCI service")], "api_key"),
    ("fd", "Fault domains", ("plan", "run", "ocm-wave"), [
        ("spread", "Spread each tier", "Round-robin over FAULT-DOMAIN-1..3"),
        ("oci", "Let OCI choose", "--no-fault-domain-spread")], "spread"),
    ("images", "Images", ("run",), [("map", "Image map file", "Symbol -> image OCID, per region"),
                                    ("resolve", "Resolve from region", "Newest compatible platform image")], "map"),
    ("quota", "Quota source", ("run", "ocm-wave"), [("api", "Limits API", "Read live from the tenancy"),
                                                    ("file", "Quota file", "JSON snapshot: limit -> available")], "api"),
    ("cutover", "Cutover check", ("plan", "run", "ocm-wave"), [
        ("off", "Off", ""), ("on", "Check observed flows", "Stop a wave whose traffic the network would deny")], "off"),
]

# key, label, kind, flag, commands, when {radio: value}, required (True | False | {radio: value}), default, hint
FIELDS = [
    ("inventory", "Inventory CSV", "path_in", "--inventory", ("plan", "run", "ocm-wave", "netpolicy"), {}, True, "examples/inventory.csv", ""),
    ("assets", "Assets CSV", "path_in", "--assets", ("discover", "netpolicy"), {}, True, "examples/estate/assets.csv", ""),
    ("flows", "Flows CSV", "path_in", "--flows", ("discover", "netpolicy"), {}, True, "examples/estate/flows.csv", ""),
    ("listeners", "Listeners CSV", "path_in", "--listeners", ("discover",), {}, False, "", "optional"),
    ("decisions", "Review decisions JSON", "path_in", "--decisions", ("discover",), {}, False, "", "optional: reviewed findings"),
    ("out", "Findings output", "path_out", "--out", ("discover",), {}, True, "findings.json", ""),
    ("inventory_out", "Inventory output", "path_out", "--inventory-out", ("discover",), {}, True, "inventory.csv", ""),
    ("cut_assets", "Assets CSV", "path_in", "--assets", ("plan", "run", "ocm-wave"), {"cutover": "on"}, True, "", ""),
    ("cut_flows", "Flows CSV", "path_in", "--flows", ("plan", "run", "ocm-wave"), {"cutover": "on"}, True, "", ""),
    ("nsg_map", "NSG map JSON", "path_in", "--nsg-map", ("plan", "run", "ocm-wave"), {"cutover": "on"}, False, "", "from netpolicy --apply"),
    ("compartment", "Compartment OCID", "ocid:compartment,tenancy", "--compartment", ("plan",) + LIVE, {}, {"mode": "apply"}, "", ""),
    ("ad", "Availability domain", "text", "--availability-domain", ("plan", "run", "ocm-wave"), {}, {"mode": "apply"}, "", "e.g. Uocm:PHX-AD-1"),
    ("region", "Region", "region", "--region", ("plan",) + LIVE, {}, False, "", "e.g. us-phoenix-1: bound into the plan id"),
    ("cost_center", "Tag: cost_center", "text", "--tag cost_center=", ("plan",) + LIVE, {}, True, "", "required tag"),
    ("owner", "Tag: owner", "text", "--tag owner=", ("plan",) + LIVE, {}, True, "", "required tag"),
    ("wave", "Wave number", "int", "--wave", ("ocm-wave",), {}, True, "1", ""),
    ("migration_plan", "OCM migration plan OCID", "ocid:", "--migration-plan", ("ocm-wave",), {}, True, "", ""),
    ("subnet_map", "Subnet map JSON", "path_in", "--subnet-map", ("ocm-wave",), {}, True, "", "subnet_web/app/db -> subnet OCID"),
    ("mapping", "VM -> target asset JSON", "path_in", "--mapping", ("ocm-wave",), {}, False, "", "optional"),
    ("image_map", "Image map JSON", "path_in", "--image-map", ("run",), {"images": "map"}, False, "", ""),
    ("resolve_images", "Image symbols JSON", "path_in", "--resolve-images", ("run",), {"images": "resolve"}, True, "", ""),
    ("quota_file", "Quota file JSON", "path_in", "--quota-file", ("run", "ocm-wave"), {"quota": "file"}, True, "", ""),
    ("vcn", "Target VCN OCID", "ocid:vcn", "--vcn", ("netpolicy",), {"mode": "apply"}, True, "", ""),
    ("nsg_map_out", "NSG map output", "path_out", "--nsg-map-out", ("netpolicy",), {"mode": "apply"}, True, "nsg-map.json", ""),
    ("plan_id", "Reviewed plan id", "text", "--plan-id", ("run", "ocm-wave"), {"mode": "apply"}, True, "", "printed by the dry run"),
    ("policy_id", "Reviewed policy id", "text", "--policy-id", ("netpolicy",), {"mode": "apply"}, True, "", "printed by the dry run"),
    ("approve_by", "Approved by", "person", "--approve-by", ("run", "ocm-wave"), {"mode": "apply"}, False, "", "your name: pre-approves waves that need it"),
    ("profile", "Config profile", "text", "--profile", LIVE, {"auth": "api_key"}, False, "DEFAULT", ""),
    ("journal", "Journal file", "path_out", "--journal", LIVE, {}, True, "", ""),
    ("status_journal", "Journal file", "path_in", "--journal", ("status",), {}, True, "", ""),
]
JOURNAL_DEFAULT = {"run": "ocio-run.jsonl", "ocm-wave": "ocio-ocm.jsonl", "netpolicy": "ocio-netpolicy.jsonl"}
FLAG_ONLY = {("mode", "apply"): "--apply", ("fd", "oci"): "--no-fault-domain-spread"}
RADIO_FLAG = {"env": "--env", "auth": "--auth"}


def schema():
    """SCHEMA as JSON-ready data for the page: commands, radio groups (with the commands they apply to and
    their default), fields (kind, flag, commands, when, required, default, hint), journal defaults and the
    flag mappings. The page uses it only to show fields and preview; build_argv is authoritative.
    """
    return {"commands": [{"key": k, "label": l, "icon": i, "desc": d} for k, l, i, d in COMMANDS],
            "radios": [{"key": k, "label": l, "commands": list(c), "default": dflt,
                        "options": [{"value": v, "label": lab, "hint": h} for v, lab, h in o]} for k, l, c, o, dflt in RADIOS],
            "fields": [{"key": k, "label": l, "kind": kind, "flag": flag, "commands": list(c), "when": w,
                        "required": r, "default": d, "hint": h} for k, l, kind, flag, c, w, r, d, h in FIELDS],
            "journal_default": JOURNAL_DEFAULT, "flag_only": {f"{k}={v}": f for (k, v), f in FLAG_ONLY.items()},
            "radio_flag": RADIO_FLAG}


def _matches(when, radios):
    return all(radios.get(k) == v for k, v in when.items())


def _check(kind, value, workdir):
    if any(ord(ch) < 32 for ch in value) or len(value) > 512:
        return "contains control characters or is too long"
    if value.startswith("-"):
        return "may not start with '-'"
    if kind == "path_in":
        p = value if os.path.isabs(value) else os.path.join(workdir, value)
        return None if os.path.isfile(p) else f"no such file: {p}"
    if kind == "path_out":
        p = value if os.path.isabs(value) else os.path.join(workdir, value)
        return None if os.path.isdir(os.path.dirname(os.path.abspath(p))) else "its folder does not exist"
    if kind.startswith("ocid:"):
        from ocio.ocid import problem
        types = tuple(t for t in kind[5:].split(",") if t) or None
        return problem(value, types)
    if kind == "int":                                  # ASCII digits only: "²".isdigit() is True in Python
        return None if value.isascii() and value.isdigit() and int(value) > 0 else "must be a whole number above 0"
    if kind == "region":
        return None if re.fullmatch(r"[a-z]{2,}-[a-z]+-\d+", value) else "not a region name like us-phoenix-1"
    if kind == "person":
        return None if value.strip() else "must name a person"
    return None


def build_argv(config, workdir):
    """(argv for `python -m ocio`, [problem, ...]) from {"command", "radios": {...}, "fields": {...}}.
    Everything is checked against SCHEMA; unknown commands, radio values or fields are refused."""
    problems = []
    cmd = config.get("command")
    if cmd not in [c[0] for c in COMMANDS]:
        return [], [f"unknown command {cmd!r}"]
    radios_in = config.get("radios") or {}
    fields_in = config.get("fields") or {}
    radios = {}
    for key, label, cmds, opts, dflt in RADIOS:
        if cmd in cmds:
            v = radios_in.get(key, dflt)
            if v not in [o[0] for o in opts]:
                problems.append(f"{label}: {v!r} is not an option")
            radios[key] = v
    unknown = sorted(set(radios_in) - {r[0] for r in RADIOS}) + sorted(set(fields_in) - {f[0] for f in FIELDS})
    if unknown:
        problems.append(f"unknown settings: {unknown}")
    argv = [cmd]
    for key in ("env", "auth"):
        if key in radios:
            argv += [RADIO_FLAG[key], radios[key]]
    for (key, val), flag in FLAG_ONLY.items():
        if radios.get(key) == val:
            argv.append(flag)
    for key, label, kind, flag, cmds, when, required, default, hint in FIELDS:
        if cmd not in cmds or not _matches(when, radios):
            continue
        need = required if isinstance(required, bool) else _matches(required, radios)
        value = str(fields_in.get(key, "") or "").strip()
        if not value:                                   # the same defaults the page pre-fills
            value = JOURNAL_DEFAULT.get(cmd, "") if key == "journal" else default
        if not value:
            if need:
                problems.append(f"{label} is required")
            continue
        p = _check(kind, value, workdir)
        if p:
            problems.append(f"{label}: {p}")
            continue
        if flag.endswith("="):                              # --tag key=value
            name, rest = flag.split(" ", 1)
            argv += [name, rest + value]
        else:
            argv += [flag, value]
    return argv, problems


def content_length(header):
    """The request body length from a Content-Length header: ASCII digits only; None for anything else (a
    negative value would make rfile.read(-1) block until the client hangs up). A missing header is 0."""
    if header is None or header == "":
        return 0
    return int(header) if header.isascii() and header.isdigit() else None


def display(argv):
    """The argv as one POSIX-shell-quoted line, prefixed 'python -m ocio', for showing and copying."""
    return "python -m ocio " + " ".join(shlex.quote(a) for a in argv)


# ------------------------------------------------------------------ the page

PANELS = """
<section class="panel" style="margin-bottom:20px"><div class="panel-header"><div><h2>1 · Command</h2><p>What to do. Each is safe to try as a dry run.</p></div></div>
<div class="panel-body"><div id="commands" class="radio-cards" role="radiogroup" aria-label="Command"></div></div></section>
<div class="page-grid">
<section class="panel"><div class="panel-header"><div><h2>2 · Options</h2><p>Only the choices that apply to this command.</p></div></div>
<div class="panel-body" id="radios"></div></section>
<section class="panel"><div class="panel-header"><div><h2>3 · Inputs</h2><p>Paths are relative to the launch folder.</p></div></div>
<div class="panel-body" id="fields"></div></section>
</div>
<section class="panel" style="margin-top:20px"><div class="panel-header"><div><h2>4 · Command</h2><p id="previewNote">Exactly what will run.</p></div>
<div class="two-col-actions" style="margin:0"><button class="button secondary" id="copyBtn"><span data-icon="copy"></span>Copy</button>
<button class="button primary" id="runBtn"><span data-icon="play"></span><span id="runLabel">Run</span></button></div></div>
<div class="panel-body"><div class="code-box" id="preview" aria-live="polite"></div><div id="problems"></div><div id="result"></div></div></section>
<section class="panel" id="status" style="margin-top:20px"><div class="panel-header"><div><h2>Journal status</h2><p>Read-only summary of a run journal: integrity, open runs, what exists.</p></div></div>
<div class="panel-body"><div class="hint">Choose <b>Journal status</b> above, give the journal file, and Run. It takes no lock, so it is safe while a run is in progress.</div></div></section>
"""

STYLE = """<style>
.radio-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
.radio-card{display:flex;gap:11px;align-items:flex-start;border:1px solid #dedfd5;border-radius:6px;padding:13px 14px;background:#fff;cursor:pointer;transition:.15s}
.radio-card:hover{border-color:#859a73}.radio-card input{margin-top:2px;accent-color:var(--red)}
.radio-card b{display:block;font-size:12px;font-weight:600;color:#3f4936}.radio-card small{display:block;font-size:10px;color:#868c7b;margin-top:4px;line-height:1.5}
.radio-card:has(input:checked){border-color:var(--red);box-shadow:0 0 0 1px var(--red) inset;background:#fffaf8}
.radio-card:has(input:focus-visible){outline:2px solid var(--red);outline-offset:2px}
fieldset.rgroup{border:0;margin:0 0 16px;padding:0}fieldset.rgroup legend{font-size:10px;color:#748465;margin-bottom:8px;letter-spacing:.3px}
.ropts{display:flex;flex-wrap:wrap;gap:6px}.ropt{display:inline-flex;align-items:center;gap:7px;border:1px solid #dce2d2;border-radius:5px;padding:8px 11px;font-size:11px;background:#fff;cursor:pointer;color:#4e5545}
.ropt input{accent-color:var(--red);margin:0}.ropt:has(input:checked){border-color:var(--red);background:#fffaf8;color:#2e3328}
.ropt:has(input:focus-visible){outline:2px solid var(--red);outline-offset:2px}.rhint{font-size:10px;color:#8b927e;margin-top:6px;min-height:14px}
.field .req{color:var(--red)}.field small{display:block;font-size:9px;color:#949a89;margin-top:5px}
.result-panel pre{white-space:pre-wrap;overflow-wrap:anywhere;font:10px/1.65 ui-monospace,Consolas,monospace;margin:8px 0 0;max-height:460px;overflow:auto;color:inherit}
.apply-banner{border:1px solid #eed7c8;background:#fbf0e9;color:#8e4b33;border-radius:5px;padding:10px 12px;font-size:11px;margin:0 0 14px;display:flex;gap:8px;align-items:center}
@media(max-width:960px){.radio-cards{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:700px){.radio-cards{grid-template-columns:1fr}}
</style>"""


# The session token never appears in a page the server returns (any local account can GET a page). It reaches the
# browser only through the private launch file (write_launch_file) as a URL fragment, which browsers never send
# to a server; this script moves it into the tab's sessionStorage and removes it from the address bar.
TOKEN_BOOT = ("<script>(function(){var m=location.hash.match(/^#k=([A-Za-z0-9_-]{20,})/),t=null;"
              "if(m){try{sessionStorage.setItem('ocio-token',m[1])}catch(e){}t=m[1];"
              "history.replaceState(null,'',location.pathname+location.search);}"
              "if(!t){try{t=sessionStorage.getItem('ocio-token')}catch(e){}}"
              "window.OCIO_LIVE=t?{token:t}:null;window.OCIO_SERVED=true;})();</script>")


def _boot(served, workdir):
    return (json.dumps({"schema": schema(), "workdir": workdir or "", "served": bool(served)})
            .replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026"))


def write_launch_file(url, token):
    """A private HTML file (0600, in a fresh 0700 folder) that sends the browser to url#k=<token>. The browser is
    opened on THIS file, so the token is never in a page the server returns nor on a process command line (only
    the file's path is). Returns the file path."""
    import tempfile
    d = tempfile.mkdtemp(prefix="ocio-console-")                     # mkdtemp creates the folder with mode 0700
    path = os.path.join(d, "open-console.html")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    target = f"{url}#k={token}"
    with os.fdopen(fd, "w") as f:
        f.write(f'<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="0;url={target}">'
                f'<title>Opening the console</title><p>Opening the console. If nothing happens, '
                f'<a href="{target}">open it here</a>.</p>')
    return path


def console_html(served=False, workdir=None):
    """The console as its own page in the shell. Served (by `ocio ui`), it runs commands with the session token the
    private launch file put in the tab;
    without one it is a command builder (for opening as a file). `ocio ui` serves the wrapper instead, with this
    console as one of its pages (embed())."""
    nav = [("launch", "Launch console", "play", "#top"), ("guide", "Project guide", "book", "/guide" if served else "#guide-note"),
           ("status", "Journal status", "file", "#status")]
    body = """<div class="connection-bar"><div><span class="connection-dot"></span><b id="connText"></b><span class="connection-detail" id="connDetail"></span></div></div>""" + PANELS + """<div class="hint" id="guide-note">The project guide opens from the sidebar when the console is launched (double-click Launch). Opened as a file, this page builds commands to copy.</div>"""
    script = _CONSOLE_JS + "\nocioLaunchInit(" + _boot(served, workdir) + ");"
    return shell.page("OCIO Launch Console", "Launch console",
                      "Choose with radio buttons. Preview the exact command. Run it, dry run first.",
                      body, nav=nav, active="launch", crumb="Launch console",
                      environment="LOCAL CONSOLE" if served else "COMMAND BUILDER",
                      head_extra=(TOKEN_BOOT if served else "") + STYLE, script=script)


def embed(served=False, workdir=None):
    """The console as a page inside the provisioned wrapper: its style, plus window.OCIO_LAUNCH = {html, mount}
    which the wrapper's 'launch' page renders and mounts (see ocio.ui.wrapper PATCHES)."""
    return (STYLE + "<script>" + _CONSOLE_JS + "\nwindow.OCIO_LAUNCH={html:()=>" +
            json.dumps(PANELS).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026") +
            ",mount:()=>ocioLaunchInit(" + _boot(served, workdir) + ")};</script>")


_CONSOLE_JS = r"""
function ocioLaunchInit(BOOT){
const S=BOOT.schema,el=id=>document.getElementById(id);
const LIVE=!!(window.OCIO_LIVE&&window.OCIO_LIVE.token);
let st=window.__ocioLaunchState;
if(!st){st=window.__ocioLaunchState={command:'plan',radios:{},fields:{}};
for(const r of S.radios)st.radios[r.key]=r.default;
for(const f of S.fields)if(f.default)st.fields[f.key]=f.default;}
const match=(when)=>Object.entries(when||{}).every(([k,v])=>st.radios[k]===v);
const activeRadios=()=>S.radios.filter(r=>r.commands.includes(st.command));
const activeFields=()=>S.fields.filter(f=>f.commands.includes(st.command)&&match(f.when));
const required=f=>f.required===true||(typeof f.required==='object'&&match(f.required));
function quote(a){return /^[A-Za-z0-9_@%+=:,./-]+$/.test(a)?a:"'"+a.replace(/'/g,"'\\''")+"'"}
function argv(){
  const a=[st.command],probs=[];
  const live=activeRadios().map(r=>r.key);
  for(const k of ['env','auth'])if(live.includes(k))a.push(S.radio_flag[k],st.radios[k]);
  for(const [kv,flag] of Object.entries(S.flag_only)){const [k,v]=kv.split('=');if(live.includes(k)&&st.radios[k]===v)a.push(flag)}
  for(const f of activeFields()){
    let v=(st.fields[f.key]||'').trim();
    if(!v&&f.key==='journal')v=S.journal_default[st.command]||'';
    if(!v){if(required(f))probs.push(f.label+' is required');continue}
    if(v.startsWith('-'))probs.push(f.label+": may not start with '-'");
    if(f.flag.endsWith('=')){const [n,rest]=f.flag.split(' ');a.push(n,rest+v)}else a.push(f.flag,v);
  }
  return [a,probs];
}
function renderCommands(){
  el('commands').innerHTML=S.commands.map(c=>`<label class="radio-card" data-meta='${esc(JSON.stringify({title:c.label,rows:[["Command","ocio "+c.key],["What it does",c.desc],["Changes OCI",["run","ocm-wave","netpolicy"].includes(c.key)?"only with Apply":"never"]]}))}'><input type="radio" name="command" value="${esc(c.key)}" ${c.key===st.command?'checked':''}><span><b>${icon(c.icon)} ${esc(c.label)}</b><small>${esc(c.desc)}</small></span></label>`).join('');
  el('commands').querySelectorAll('input').forEach(i=>i.addEventListener('change',()=>{st.command=i.value;for(const k of ['plan_id','policy_id'])st.fields[k]=(st.ids||{})[st.command+':'+k]||'';render()}));
}
function renderRadios(){
  const rs=activeRadios();
  el('radios').innerHTML=rs.length?rs.map(r=>{const cur=r.options.find(o=>o.value===st.radios[r.key]);return `<fieldset class="rgroup"><legend>${esc(r.label)}</legend><div class="ropts" role="radiogroup">${r.options.map(o=>`<label class="ropt"><input type="radio" name="r-${esc(r.key)}" value="${esc(o.value)}" ${o.value===st.radios[r.key]?'checked':''}>${esc(o.label)}</label>`).join('')}</div><div class="rhint">${esc(cur&&cur.hint||'')}</div></fieldset>`}).join(''):'<p class="explain">No options: this command has none.</p>';
  if(st.radios.mode==='apply'&&rs.some(r=>r.key==='mode'))el('radios').insertAdjacentHTML('afterbegin',`<div class="apply-banner">${icon('alert')} Apply changes the tenancy. The same gates as the command line apply, and you confirm first.</div>`);
  el('radios').querySelectorAll('input').forEach(i=>i.addEventListener('change',()=>{st.radios[i.name.slice(2)]=i.value;render()}));
}
function renderFields(){
  const fs=activeFields();
  el('fields').innerHTML=fs.map(f=>{const v=st.fields[f.key]??(f.key==='journal'?S.journal_default[st.command]||'':'');return `<div class="field"><label for="f-${esc(f.key)}">${esc(f.label)} ${required(f)?'<span class="req">*</span>':''}</label><input id="f-${esc(f.key)}" data-key="${esc(f.key)}" value="${esc(v)}" placeholder="${esc(f.hint||'')}" autocomplete="off" spellcheck="false">${f.hint?`<small>${esc(f.hint)}</small>`:''}</div>`}).join('')||'<p class="explain">No inputs needed.</p>';
  el('fields').querySelectorAll('input').forEach(i=>i.addEventListener('input',()=>{st.fields[i.dataset.key]=i.value;renderPreview()}));
}
function renderPreview(){
  const [a,probs]=argv();
  el('preview').textContent='python -m ocio '+a.map(quote).join(' ');
  el('problems').innerHTML=probs.length?`<div class="result-panel error">${probs.map(esc).join('<br>')}</div>`:'';
  const apply=st.radios.mode==='apply'&&activeRadios().some(r=>r.key==='mode');
  el('runLabel').textContent=LIVE?(apply?'Apply…':'Run'):'Run (launch first)';
  el('runBtn').disabled=!LIVE||probs.length>0;
}
function render(){renderCommands();renderRadios();renderFields();renderPreview();hydrate()}
async function post(path,body){
  const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json','X-Console-Token':(window.OCIO_LIVE||{}).token||''},body:JSON.stringify(body)});
  const j=await r.json();if(!r.ok)throw Error((j.problems||[j.error||'Request failed']).join('; '));return j;
}
async function run(){
  const busy=el('runBtn');busy.disabled=true;el('result').innerHTML=`<div class="result-panel">Running… ${esc(el('preview').textContent)}</div>`;
  try{
    const j=await post('run',{command:st.command,radios:st.radios,fields:st.fields});
    const ok=j.returncode===0;
    el('result').innerHTML=`<div class="result-panel ${ok?'':'error'}"><b>exit ${j.returncode}</b> · ${j.seconds}s · ${esc(j.command)}<pre>${esc(j.output)}</pre></div>`;
    // A reviewed id belongs to the command that printed it: plan and run bind different inputs, so plan's id
    // would be refused by run --apply. Keep it per command, and fill it only for that command.
    st.ids=st.ids||{};
    for(const k of ['plan_id','policy_id'])if(j[k]){st.ids[st.command+':'+k]=j[k];st.fields[k]=j[k];toast(k.replace('_',' ')+' '+j[k]+' kept for '+st.command+' (its own dry run)')}
    renderFields();renderPreview();
  }catch(e){el('result').innerHTML=`<div class="result-panel error">${esc(e.message)}</div>`;busy.disabled=false}
}
el('runBtn').addEventListener('click',()=>{
  const apply=st.radios.mode==='apply'&&activeRadios().some(r=>r.key==='mode');
  if(!apply)return run();
  modal('Apply to the tenancy?',`<p class="explain">This command changes OCI. Every gate still applies: the reviewed id, approval, quota, policy, cutover, admission, region and the journal lock.</p><div class="code-box">${esc(el('preview').textContent)}</div><div class="modal-actions"><button class="button secondary" id="cancelApply">Cancel</button><button class="button primary" id="confirmApply">Apply</button></div>`);
  el('cancelApply').onclick=closeModal;el('confirmApply').onclick=()=>{closeModal();run()};
});
el('copyBtn').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(el('preview').textContent);toast('Command copied')}catch(_){toast('Select the command and copy it')}});
if(el('connText'))el('connText').textContent=LIVE?'Local console connected':'Command builder (opened as a file)';
if(el('connDetail'))el('connDetail').textContent=LIVE?('Runs on this computer only · launch folder '+BOOT.workdir):'Double-click Launch to run commands from here';
render();
}
"""


# ------------------------------------------------------------------ the server

def _parse_ids(output):
    found = {}
    for k in ("plan_id", "policy_id"):
        m = re.findall(r'"%s":\s*"([0-9a-f]{8,64})"' % k, output)
        if m:
            found[k] = m[-1]
    return found


class Console:
    """Request handling, separate from HTTP so it can be tested directly."""

    def __init__(self, workdir, token=None, timeout=7200, runner=None):
        self.workdir = os.path.abspath(workdir)
        self.token = token or secrets.token_urlsafe(32)
        self.timeout = timeout
        self.lock = threading.Lock()
        self.runner = runner or self._subprocess

    def authorized(self, headers, port):
        """True only if the X-Console-Token header equals this session's token (constant-time compare) AND the
        Host header is 127.0.0.1:<port> or localhost:<port>, which blocks DNS-rebinding pages on other origins.
        """
        tok = headers.get("X-Console-Token") or ""
        host = (headers.get("Host") or "").lower()
        return (hmac.compare_digest(tok, self.token)
                and host in (f"127.0.0.1:{port}", f"localhost:{port}"))

    def _subprocess(self, argv):
        env = dict(os.environ, PYTHONPATH=PACKAGE_ROOT + os.pathsep + os.environ.get("PYTHONPATH", ""),
                   PYTHONIOENCODING="utf-8")
        p = subprocess.run([sys.executable, "-m", "ocio", *argv], cwd=self.workdir, env=env,
                           stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=self.timeout)
        return p.returncode, (p.stdout or "") + (("\n" + p.stderr) if p.stderr else "")

    def handle(self, path, body):
        """(status, payload) for POST /api/<path>."""
        if path not in ("preview", "run"):
            return 404, {"error": "unknown endpoint"}
        if not isinstance(body, dict) or not isinstance(body.get("radios", {}), dict) \
                or not isinstance(body.get("fields", {}), dict):
            return 400, {"problems": ["the request must be an object with 'command', and 'radios' and 'fields' objects"]}
        argv, problems = build_argv(body, self.workdir)
        if problems:
            return 400, {"problems": problems, "command": display(argv) if argv else ""}
        if path == "preview":
            return 200, {"command": display(argv), "argv": argv}
        if not self.lock.acquire(blocking=False):
            return 409, {"error": "another command is still running; wait for it to finish"}
        try:
            t0 = time.monotonic()
            try:
                rc, output = self.runner(argv)
            except subprocess.TimeoutExpired:
                rc, output = 124, f"stopped after {self.timeout} s"
            return 200, dict({"command": display(argv), "returncode": rc, "output": output[-200000:],
                              "seconds": round(time.monotonic() - t0, 1)}, **_parse_ids(output))
        finally:
            self.lock.release()


def wrapper_state(workdir, inventory=None, env="dev", assets=None, flows=None):
    """What the provisioned wrapper shows and its API acts on: an inventory (default examples/inventory.csv in
    workdir), planning settings for env, and optional discovery inputs (default examples/estate/ when present)."""
    from . import wrapper
    wd = os.path.abspath(workdir)
    pick = lambda v, d: (v if os.path.isabs(v) else os.path.join(wd, v)) if v else (os.path.join(wd, d) if os.path.exists(os.path.join(wd, d)) else None)
    inv = pick(inventory, "examples/inventory.csv")
    if not inv or not os.path.isfile(inv):
        raise SystemExit(f"ocio ui: no inventory at {inv}; pass --inventory")
    return {"inventory": inv, "settings": wrapper.default_settings(env), "assets": pick(assets, "examples/estate/assets.csv"),
            "flows": pick(flows, "examples/estate/flows.csv")}


def wrapper_page(state, served=False):
    """The provisioned wrapper with ocio's workspace, and the launch console as one of its pages."""
    from . import wrapper
    ws = wrapper.workspace(state["inventory"], state["settings"])
    return wrapper.html(ws, served=served, launch_js=embed(served, os.path.dirname(state["inventory"])))


WRAPPER_API = ("plan", "validate", "dry-run", "simulate", "discover")


def serve(workdir=".", port=0, open_browser=True, out=print, state=None):
    """Run the console server on 127.0.0.1 until interrupted, then return 0.

    port 0 picks a free port. GET / serves the provisioned wrapper (ocio.ui.wrapper) with ocio's workspace (and no
    token: see write_launch_file), the launch console being one of its pages; GET /console serves the launch console
    on its own; GET /guide serves the wrapped guide. POST /api/preview and /api/run go to Console.handle; the
    wrapper's own engine calls (POST /api/plan, validate, dry-run, simulate, discover) go to
    wrapper.handle_api; all after the token, Host, content-type and size (1 MB) checks. Responses are not cached
    and may not be framed. Commands run in workdir. With open_browser, the default browser is opened.
    """
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from . import wrapper
    console = Console(workdir)
    state = state or wrapper_state(workdir)

    class H(BaseHTTPRequestHandler):
        """Request handler bound to this server: the routes and checks described above."""
        def log_message(self, *a):
            pass

        def _send(self, status, body, ctype="application/json"):
            data = body if isinstance(body, bytes) else (json.dumps(body) if ctype == "application/json" else body).encode()
            self.send_response(status)
            self.send_header("Content-Type", ctype + "; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Referrer-Policy", "no-referrer")
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            host = (self.headers.get("Host") or "").lower()
            if host not in (f"127.0.0.1:{srv.server_port}", f"localhost:{srv.server_port}"):
                return self._send(403, {"error": "wrong host"})
            if self.path in ("/", "/index.html"):
                try:
                    return self._send(200, wrapper_page(state, served=True), "text/html")
                except (OSError, ValueError) as e:       # e.g. an inventory with a bad row: say so, do not hang up
                    return self._send(500, f"<!doctype html><title>ocio console</title><pre>The console could not "
                                           f"build its page: {shell.esc(e)}</pre>", "text/html")
            if self.path == "/console":
                return self._send(200, console_html(served=True, workdir=console.workdir), "text/html")
            if self.path == "/guide":
                from . import guide
                return self._send(200, guide.html(), "text/html")
            return self._send(404, {"error": "not found"})

        def do_POST(self):
            if not console.authorized(self.headers, srv.server_port):
                return self._send(403, {"error": "missing or wrong console token"})
            if (self.headers.get("Content-Type") or "").split(";")[0].strip() != "application/json":
                return self._send(415, {"error": "JSON only"})
            n = content_length(self.headers.get("Content-Length"))
            if n is None:
                return self._send(400, {"error": "bad Content-Length"})
            if n > 1_000_000:
                return self._send(413, {"error": "too large"})
            try:
                body = json.loads(self.rfile.read(n) or b"{}")
            except ValueError:
                return self._send(400, {"error": "bad JSON"})
            path = self.path.removeprefix("/api/")
            if path in WRAPPER_API:
                try:
                    status, payload = wrapper.handle_api(path, body, state)
                except (ValueError, OSError) as e:
                    status, payload = 400, {"error": str(e)}
            else:
                status, payload = console.handle(path, body)
            return self._send(status, payload)

    srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    url = f"http://127.0.0.1:{srv.server_port}/"
    opener = write_launch_file(url, console.token)
    out(f"OCI Migration Control: {url}  (launch folder {console.workdir}). Close this window or press Ctrl+C to stop.")
    out(f"To open it (only your account can read this file): {opener}")
    if open_browser:
        import pathlib
        import webbrowser
        threading.Timer(0.4, lambda: webbrowser.open(pathlib.Path(opener).as_uri())).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
        import shutil
        shutil.rmtree(os.path.dirname(opener), ignore_errors=True)    # the token dies with the server
    return 0
