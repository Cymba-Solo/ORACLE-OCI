"""The console shell every rendered page uses: the OCI Standalone Wrapper's layout and behaviour.

One function, page(), returns a complete, self-contained HTML document: the wrapper's stylesheet and
script inlined (no network, no external fonts), its sidebar, top bar, footer, modal, toast, accessible
hover/focus metadata (any element with data-meta='{"title":..., "rows":[[k, v], ...]}') and the
wordmark sparkles, with the page's own content in the main column.

Brand. The wrapper's mark was the word ORACLE in Oracle's red with an OCI-console breadcrumb, which
presents a page as Oracle's own. This project is independent, so the mark is OCI MIGRATION CONTROL (the same
mark the provisioned wrapper page uses, with the same sparkle anchors) and the footer says what the page is. Everything else is the wrapper's
design unchanged.
"""
from __future__ import annotations

import html
import json
import os

_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")


def _asset(name):
    with open(os.path.join(_ASSETS, name), encoding="utf-8") as f:
        return f.read()


def esc(v):
    """HTML-escape any value for text or a quoted attribute (None becomes empty)."""
    return html.escape("" if v is None else str(v), quote=True)


def meta(title, rows):
    """data-meta attribute value for the hover/focus metadata tooltip (escaped for an attribute)."""
    return esc(json.dumps({"title": str(title), "rows": [[str(k), str(v)] for k, v in rows]}))


WORDMARK = ('<span class="wordmark" aria-label="OCI Migration Control" style="font-size:24px;letter-spacing:3px">'
            '<span class="wordmark-glyph" aria-hidden="true">O<span class="sparkle-point sparkle-o" data-sparkle-anchor="o"></span></span>'
            '<span class="wordmark-glyph" aria-hidden="true">C<span class="sparkle-point sparkle-r" data-sparkle-anchor="r"></span></span>'
            '<span class="wordmark-glyph" aria-hidden="true">I<span class="sparkle-point sparkle-e" data-sparkle-anchor="e"></span></span>'
            '</span>')       # the same mark as the provisioned wrapper's page (ocio.ui.wrapper)


def page(title, heading, subtitle, body, nav=(), active=None, eyebrow="REPEATABLE OCI MIGRATIONS",
         crumb=None, environment="NON-PRODUCTION", region="", actions="", script="", head_extra="",
         description="Repeatable OCI migrations: plan, launch and verify."):
    """nav: [(key, label, icon, href)], active: key. body/actions/script: trusted HTML/JS built by ocio.
    Everything else is escaped here."""
    from ocio import __version__
    links = "".join(
        f'<a href="{esc(href)}"{" class=\"active\" aria-current=\"page\"" if key == active else ""}>'
        f'<span data-icon="{esc(icon)}"></span>{esc(label)}</a>' for key, label, icon, href in nav)
    region_html = (f'<span class="region"><span data-icon="globe"></span><span>{esc(region)}</span></span>'
                   if region else "")
    env_html = f'<span class="environment">{esc(environment)}</span>' if environment else ""
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(title)}</title><meta name="description" content="{esc(description)}">
<style>{_asset("shell.css")}</style>{head_extra}</head>
<body>
<div class="shell">
<aside class="sidebar" id="sidebar">
<a class="brand" href="/" aria-label="OCI Migration Control home">{WORDMARK}<span class="brand-sub">MIGRATION CONTROL</span></a>
<div class="workspace"><span class="workspace-icon" aria-label="Workspace initials JG">JG</span><div><b>Glover workspace</b><small>Migration console</small></div></div>
<div class="nav-label">WORKSPACE</div><nav id="nav" aria-label="Main navigation">{links}</nav>
<div class="side-bottom"><div class="safe-box"><span class="icon" data-icon="shield"></span><div><b>Intent stays human.</b><p>Every wave. Every exception.<br>Visible and reviewable.</p></div></div>
<div class="profile"><span class="avatar">JG</span><div><b>J.C. Glover</b><small>glover.jwg@gmail.com</small></div><span class="status-dot"></span></div></div>
</aside>
<div class="main-shell">
<header class="topbar"><button class="icon-button mobile-menu" id="menuBtn" aria-label="Toggle navigation" data-icon="menu"></button><div class="crumb">Repeatable OCI Migrations <span>/</span> <b>{esc(crumb or heading)}</b></div><div class="top-actions">{region_html}{env_html}</div></header>
<main id="main"><a id="top"></a><div class="page-heading"><div><div class="eyebrow">{esc(eyebrow)}</div><h1>{esc(heading)}</h1><p>{esc(subtitle)}</p></div><div class="heading-actions">{actions}</div></div>
<div id="view">{body}</div>
<footer><span>J.C. Glover <span class="footer-dot">·</span> Repeatable OCI Migrations <span class="footer-dot">·</span> ocio {esc(__version__)}</span><span>Independent project for Oracle Cloud Infrastructure <span class="footer-dot">·</span> not an Oracle product</span></footer>
</main>
</div></div>
<div class="modal-overlay" id="modal" hidden><section role="dialog" aria-modal="true" aria-labelledby="modalTitle" class="modal"><header><div><span class="eyebrow" id="modalEyebrow">OCIO</span><h2 id="modalTitle"></h2></div><button id="closeModal" class="icon-button" aria-label="Close dialog" data-icon="close"></button></header><div id="modalBody"></div></section></div>
<div class="toast" id="toast" role="status" hidden></div>
<script>{_asset("shell.js")}
hydrate();
document.getElementById('closeModal').addEventListener('click',closeModal);
document.getElementById('modal').addEventListener('click',e=>{{if(e.target.id==='modal')closeModal()}});
document.addEventListener('keydown',e=>{{if(e.key==='Escape'&&!document.getElementById('modal').hidden)closeModal()}});
document.getElementById('menuBtn').addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
document.getElementById('nav').addEventListener('click',e=>{{if(e.target.closest('a'))document.getElementById('sidebar').classList.remove('open')}});
</script>
<script>{script}</script>
</body></html>"""
