"""Put a standalone HTML document inside the console shell (the wrapper), without the two clashing.

wrap_document(doc_html) keeps the document's content, figures and chart script, and:
  * scopes its stylesheet under a .doc container: every selector is prefixed with ".doc", and the
    document-level ones (:root, html, body) become ".doc" itself, so the document's rules cannot restyle the
    shell (sidebar, top bar) and its variables (--ink, --accent, ...) live on the container;
  * drops its dark-mode blocks: the wrapper's shell is a light design, and a dark document inside a light
    shell reads as two products;
  * neutralises the shell's global table/link/footer rules inside .doc, which the document does not set;
  * removes remote font links (offline, as the wrapper is) and head-only tags from fragment documents;
  * points the chart script's colour lookups at the .doc container instead of <html>;
  * builds the sidebar from the document's numbered sections (h2 with <span class="n">NN</span>).

guide.html() serves the packaged guide (assets/guide.html) wrapped; `python -m ocio.ui.guide IN OUT`
writes a wrapped copy of any document produced by the same generator.
"""
from __future__ import annotations

import html as _html
import re
import os
import sys

from . import shell

_ASSET = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "guide.html")


def _split_rules(css):
    """Top-level blocks of a stylesheet: (prelude, body) pairs, with comments removed."""
    css = re.sub(r"/\*.*?\*/", "", css, flags=re.S)
    out, i, n = [], 0, len(css)
    while i < n:
        j = css.find("{", i)
        if j < 0:
            break
        prelude, depth, k = css[i:j].strip(), 1, j + 1
        while k < n and depth:
            depth += {"{": 1, "}": -1}.get(css[k], 0)
            k += 1
        out.append((prelude, css[j + 1:k - 1]))
        i = k
    return out


def _split_selectors(sel):
    parts, depth, cur = [], 0, ""
    for ch in sel:
        depth += {"(": 1, ")": -1}.get(ch, 0)
        if ch == "," and depth == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    return [p.strip() for p in parts + [cur] if p.strip()]


def _scope_selector(s, root):
    if re.fullmatch(r":root|html|body", s):
        return root
    if s.startswith(":root") or s.startswith("html"):
        return None                                   # :root[data-theme=...] and similar theme switches: dropped
    if s.startswith("body"):
        return root + s[4:]
    return f"{root} {s}"


def scope_css(css, root=".doc"):
    """Rewrite a stylesheet so it applies only inside `root`: each selector is prefixed with root; :root, html
    and body become root itself; theme switches (:root[...], html[...]) and prefers-color-scheme: dark blocks
    are dropped; other @media blocks are scoped recursively; @keyframes and other at-rules are kept as is.
    Comments are removed. Selector lists are split on top-level commas only (not inside :not(...)).
    """
    out = []
    for prelude, body in _split_rules(css):
        if prelude.startswith("@media"):
            if "prefers-color-scheme" in prelude and "dark" in prelude:
                continue
            inner = scope_css(body, root)
            if inner.strip():
                out.append(f"{prelude}{{{inner}}}")
        elif prelude.startswith("@"):
            out.append(f"{prelude}{{{body}}}")         # @keyframes, @font-face, @supports: unchanged
        else:
            sels = [x for x in (_scope_selector(s, root) for s in _split_selectors(prelude)) if x]
            if sels:
                out.append(f"{','.join(sels)}{{{body}}}")
    return "\n".join(out)


RESET = """
.doc{display:block;min-width:0}
.doc table th,.doc table td{background:none;color:inherit}
.doc th{background:none}
.doc a{color:var(--accent);text-decoration:underline;text-underline-offset:2px}
.doc footer{display:grid;justify-content:normal;padding:18px 0 0}
.doc .wrap{padding-top:8px}
"""


def wrap_document(doc_html, title="Repeatable OCI Migrations · Guide", heading="Project guide",
                  subtitle="The design, the evidence and its limits.", console_href="/"):
    """Return a complete shell page (shell.page) containing doc_html. See the module docstring for what is
    kept, scoped and removed. The sidebar gets a link to the console (console_href) and one link per numbered
    section (h2 with <span class="n">NN</span>), anchored by ids added to those spans. The document's scripts
    are kept and run after the shell's script."""
    head_css = "".join(re.findall(r"<style[^>]*>(.*?)</style>", doc_html, flags=re.S))
    body = re.search(r"<body[^>]*>(.*)</body>", doc_html, flags=re.S)
    body = body.group(1) if body else doc_html
    scripts = re.findall(r"<script[^>]*>(.*?)</script>", body, flags=re.S)
    content = re.sub(r"<script[^>]*>.*?</script>", "", body, flags=re.S)
    # A fragment document (no <head>/<body>) carries these inline. Remote font links are dropped too: the
    # shell is offline by design, and the document's font stacks fall back to system fonts.
    content = re.sub(r"<style[^>]*>.*?</style>|<title>.*?</title>|<meta[^>]*>|<link[^>]*>", "", content, flags=re.S)
    script = "\n".join(scripts).replace("getComputedStyle(document.documentElement)",
                                        "getComputedStyle(document.querySelector('.doc'))")
    nav = [("console", "Launch console", "play", console_href)]
    for i, (num, text) in enumerate(re.findall(r'<h2[^>]*><span class="n">(\d+)</span>([^<]+)', content)):
        anchor = f"sec-{num}"
        content = content.replace(f'<span class="n">{num}</span>{text}', f'<span class="n" id="{anchor}">{num}</span>{text}', 1)
        nav.append((anchor, f"{num} · {_html.unescape(text).strip()}", "file", f"#{anchor}"))
    style = f"<style>{scope_css(head_css)}\n{RESET}</style>"
    return shell.page(title, heading, subtitle, f'<div class="doc">{content}</div>', nav=nav, active=None,
                      crumb="Project guide", environment="DOCUMENT", head_extra=style, script=script)


def html():
    """The packaged guide (assets/guide.html) wrapped in the shell, or a short placeholder page if this build
    does not include it. Served at /guide by the console.
    """
    if not os.path.exists(_ASSET):
        return shell.page("Guide", "Project guide", "Not packaged in this build.",
                          '<div class="empty-state"><h3>No guide in this build</h3></div>')
    with open(_ASSET, encoding="utf-8") as f:
        return wrap_document(f.read())


if __name__ == "__main__":
    src, dst = sys.argv[1], sys.argv[2]
    with open(src, encoding="utf-8") as f:
        page = wrap_document(f.read(), console_href=sys.argv[3] if len(sys.argv) > 3 else "/")
    with open(dst, "w", encoding="utf-8") as f:
        f.write(page)
    print(f"wrote {dst}")
