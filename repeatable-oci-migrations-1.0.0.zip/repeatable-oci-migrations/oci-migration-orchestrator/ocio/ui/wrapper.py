"""The provisioned OCI Standalone Wrapper, served with ocio's own data.

WHAT THIS IS
  assets/wrapper.html is the wrapper exactly as provided (SHA-256 recorded in PROVISIONED_SHA256). This
  module does not redesign it. It does three things:

  1. DATA. Builds the wrapper's embedded workspace (embeddedMetadata: plan, catalog, flows, dependencies,
     evidence, scale, mutations) from ocio: the plan is ocio's real plan for the given inventory and settings,
     translated field by field into the shape the wrapper reads (to_wrapper_plan); evidence, scale and
     mutation numbers come from ocio's result files (examples/*.json, mutate results), never from the sample.
     The operator documents it embeds are ocio's own RUNBOOK and README.
  2. PATCHES. A short list of exact text replacements (PATCHES), each required to match exactly once, so a
     changed wrapper is refused instead of half-patched. Each exists for one of two reasons:
       * facts: text that described the other package (its `oci_orchestrator` commands, its file names, its
         verified-behaviour list, a 64-hex-only plan id) would be false next to ocio's data;
       * brand: the ORACLE wordmark, the console-style breadcrumb and the "Oracle-themed branding" wording
         present the page as Oracle's own; the mark is OCI MIGRATION CONTROL with the same sparkle anchors.
     Two small additions hook ocio in: a "Launch console" page (the radio-button launcher) in the wrapper's
     own navigation, and the served-mode switch (local engine connected, session token).
  3. API. When served by `ocio ui`, the wrapper's own local-engine calls (POST /api/plan, validate, dry-run,
     simulate, discover) are answered by ocio (handle_api): planning, validation against ocio's plan id, a dry
     run, and a simulation through ocio's real engine against its in-memory OCI (FakeOCI, no tenancy calls).

FIELD MAPPING (ocio -> wrapper)
  inventory row  id=name=VM name, app, tier, archetype = blueprint id ("app-linux@v1") or "no blueprint",
                 ocpus = source vCPUs / 2 (the x86 OCPU equivalent ocio sizes from; Arm differs), memory_gb,
                 os, ips [] (the planning inventory has no addresses; discovery's assets do)
  placement      blueprint, blueprint_version, spec {shape, ocpus, memory_gb, subnet_id (the tier subnet key)},
                 deviations = override field names
  wave           index 0-based (ocio numbers waves from 1: wave index i is ocio wave i + 1), apps, vm_ids
  blocked        ocio's blocked apps with their reasons
  context        environment (dev | test | prod), region (or "not set"), compartment, network, tags,
                 admission_policy when given
  caps           apps / vms per wave; criticality is not an ocio concept ("n/a")
"""
from __future__ import annotations

import hashlib
import json
import os
import re

_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
PACKAGE_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
PROVISIONED_SHA256 = "5769a18624bafba23ce0b48ffd3ed56da1073f1f89650a82dd3a8e7ff6a11d3e"

WORDMARK_OLD = ('<span class="oracle" aria-label="Oracle"><span class="oracle-glyph" aria-hidden="true">O<span class="sparkle-point sparkle-o" data-sparkle-anchor="o"></span></span>'
                '<span class="oracle-glyph" aria-hidden="true">R<span class="sparkle-point sparkle-r" data-sparkle-anchor="r"></span></span>'
                '<span class="oracle-glyph" aria-hidden="true">A</span><span class="oracle-glyph" aria-hidden="true">C</span>'
                '<span class="oracle-glyph" aria-hidden="true">L</span><span class="oracle-glyph" aria-hidden="true">E<span class="sparkle-point sparkle-e" data-sparkle-anchor="e"></span></span></span>'
                '<span class="brand-sub">MIGRATION CONTROL</span>')
WORDMARK_NEW = ('<span class="oracle" aria-label="OCI Migration Control" style="font-size:24px;letter-spacing:3px">'
                '<span class="oracle-glyph" aria-hidden="true">O<span class="sparkle-point sparkle-o" data-sparkle-anchor="o"></span></span>'
                '<span class="oracle-glyph" aria-hidden="true">C<span class="sparkle-point sparkle-r" data-sparkle-anchor="r"></span></span>'
                '<span class="oracle-glyph" aria-hidden="true">I<span class="sparkle-point sparkle-e" data-sparkle-anchor="e"></span></span></span>'
                '<span class="brand-sub">MIGRATION CONTROL</span>')

VERIFIED_OLD = ("['Whole-application placement and SCC atomicity','Independent dependency-reachability oracle',"
                "'Crash reconciliation without duplicate creates','Source sizing floors and hostile proposal refusal',"
                "'Quota and evidence admission fail closed','OCM staging, exclusion and snapshot restoration']")
VERIFIED_NEW = ("['Whole-application waves; dependency loops move together','Crash resume without duplicate creates "
                "(retry tokens, journal)','Sizing never below the source; hostile agent proposals refused',"
                "'Quota, policy, cutover and evidence admission fail closed','OCM: exclude first, If-Match, work-request "
                "waits, recorded before-state and restore','Every planted defect caught by the tests (mutation run)']")

# (reason, old, new): each must match exactly once in the provisioned file.
PATCHES = [
    ("brand: own wordmark instead of ORACLE", WORDMARK_OLD, WORDMARK_NEW),
    ("brand: own home link label", 'aria-label="Oracle-themed Migration Control home"', 'aria-label="OCI Migration Control home"'),
    ("brand: no console-style breadcrumb", 'Cloud infrastructure <span>/</span> Migration Control', 'OCI Migration Control'),
    ("brand: footer", 'Independent project <span class="footer-dot">·</span> Oracle-themed interface <span class="footer-dot">·</span> v0.1.0',
     'Independent project <span class="footer-dot">·</span> built for Oracle Cloud Infrastructure <span class="footer-dot">·</span> not an Oracle product'),
    ("brand: about dialog", 'Oracle-themed branding identifies its target platform; this is not an Oracle product or endorsement.',
     'It is built for Oracle Cloud Infrastructure and is not an Oracle product or endorsement.'),
    ("brand: settings", 'Oracle-themed independent project by J.C. Glover; not an Oracle product or endorsement.',
     'Independent project by J.C. Glover for Oracle Cloud Infrastructure; not an Oracle product or endorsement.'),
    ("facts: ocio's documents", 'href="assets/SCRIPT_GUIDE.md" target="_blank" rel="noopener"><span data-icon="book"></span> Operator documentation',
     'href="assets/RUNBOOK.md" target="_blank" rel="noopener"><span data-icon="book"></span> Operator runbook'),
    ("facts: ocio's documents (about dialog)", '<a class="button secondary" href="assets/SCRIPT_GUIDE.md" target="_blank" rel="noopener">${icon(\'book\')}Read script guide</a>',
     '<a class="button secondary" href="assets/RUNBOOK.md" target="_blank" rel="noopener">${icon(\'book\')}Read the runbook</a>'),
    ("facts: ocio's discover command", 'python -m oci_orchestrator discover \\\\\\n  --inventory examples/inventory.json \\\\\\n  --flows examples/flows.json',
     'ocio discover \\\\\\n  --assets examples/estate/assets.csv \\\\\\n  --flows examples/estate/flows.csv'),
    ("facts: how to start", 'Open OCI_Migration_Wrapper.html directly in your browser.</div><p class="explain">Catalog edits',
     'Double-click Launch (or run: ocio ui) to connect the local engine.</div><p class="explain">Catalog edits'),
    ("facts: how to start (settings)", 'Open OCI_Migration_Wrapper.html directly in your browser.</div><p class="explain">Everything needed',
     'Double-click Launch (or run: ocio ui) to connect the local engine.</div><p class="explain">Everything needed'),
    ("facts: ocio plan ids are 12 hex characters", "/^[a-f0-9]{64}$/.test(p.plan_id)", "/^[a-f0-9]{12,64}$/.test(p.plan_id)"),
    ("facts: ocio's verified behaviour", VERIFIED_OLD, VERIFIED_NEW),
    ("facts: blueprints are sized from the source VM",
     "<div class=\"summary-item\">Default sizing<b>${esc(b.defaults.ocpus)} OCPU / ${esc(b.defaults.memory_gb)} GB</b></div>",
     "<div class=\"summary-item\">Default sizing<b>${typeof b.defaults.ocpus==='number'?esc(b.defaults.ocpus)+' OCPU / '+esc(b.defaults.memory_gb)+' GB':'Sized from the source VM'}</b></div>"),
    ("hook: served mode (local engine + session token)", "state.local=false;state.token=null;$('#connectionText').textContent='Standalone workspace · metadata included';$('#connectionDetail').textContent='Offline browser mode · no cloud connection';",
     "state.local=!!window.OCIO_LIVE;\nstate.token=window.OCIO_LIVE?window.OCIO_LIVE.token:null;\n$('#connectionText').textContent=state.local?'Local ocio engine connected':'Standalone workspace · metadata included';\n$('#connectionDetail').textContent=state.local?'127.0.0.1 only · simulations use the in-memory OCI, never your tenancy':'Offline browser mode · no cloud connection';"),
    ("hook: launch console page", "settings:['Workspace settings','Connection details and operational boundaries.','settings']};",
     "settings:['Workspace settings','Connection details and operational boundaries.','settings'],launch:['Launch console','Choose with radio buttons. Preview the exact command. Run it, dry run first.','play']};"),
    ("hook: launch console renderer", "const renderers={overview,estate:estateView,",
     "const renderers={launch:()=>window.OCIO_LAUNCH?window.OCIO_LAUNCH.html():'',overview,estate:estateView,"),
    ("hook: launch console nav label", "id==='journal'?'Execution journal':'Settings'", "id==='journal'?'Execution journal':id==='launch'?'Launch console':'Settings'"),
    ("hook: launch console mount", "hydrate();if(state.page==='estate'){", "hydrate();if(state.page==='launch'&&window.OCIO_LAUNCH)window.OCIO_LAUNCH.mount();if(state.page==='estate'){"),
]


def _template():
    with open(os.path.join(_ASSETS, "wrapper.html"), encoding="utf-8") as f:
        text = f.read()
    got = hashlib.sha256(text.encode()).hexdigest()
    if got != PROVISIONED_SHA256:
        raise ValueError(f"assets/wrapper.html is not the provisioned file (sha256 {got}); refusing to patch it")
    return text


def patched():
    """The provisioned wrapper with PATCHES applied; ValueError naming any patch that does not match once."""
    text = _template()
    for reason, old, new in PATCHES:
        n = text.count(old)
        if n != 1:
            raise ValueError(f"wrapper patch '{reason}' matched {n} times; the provisioned file changed")
        text = text.replace(old, new)
    return text


# ------------------------------------------------------------------ data

def to_wrapper_plan(rep, workloads, settings, admission_policy=None):
    """ocio pipeline Report (execute=False) -> the wrapper's plan object (see FIELD MAPPING)."""
    from ocio import factory as F
    placed = {p.workload.name: p for p in rep.placements}
    inventory = []
    for w in workloads:
        p = placed.get(w.name)
        inventory.append({"id": w.name, "name": w.name, "app": w.app, "tier": w.tier, "os": w.os, "ports": [],
                          "archetype": p.blueprint.id() if p else "no blueprint", "ocpus": w.vcpus / 2,
                          "vcpus": w.vcpus, "memory_gb": w.memory_gb, "subnet_id": None, "criticality": 1, "ips": []})
    placements = {}
    for name, p in placed.items():
        placements[name] = {"vm_id": name, "blueprint": p.blueprint.id(), "blueprint_version": str(p.blueprint.version),
                            "spec": {"shape": p.params.get("shape"), "ocpus": p.params.get("ocpus"),
                                     "memory_gb": p.params.get("memory_gbs"),
                                     "subnet_id": p.params.get("subnet") or F.TIER_SUBNETS.get(p.workload.tier)},
                            "deviations": sorted(p.overrides), "source": {"vcpus": p.workload.vcpus,
                                                                         "memory_gb": p.workload.memory_gb}}
    by_app = {}
    for w in workloads:
        by_app.setdefault(w.app, []).append(w.name)
    waves = [{"index": i, "apps": list(apps), "vm_ids": sorted(v for a in apps for v in by_app.get(a, []) if v in placed)}
             for i, apps in enumerate(rep.waves)]
    deps = sorted({(w.app, d) for w in workloads for d in w.depends_on_apps})
    context = {"environment": settings.environment, "region": (settings.bound_inputs or {}).get("region") or "not set",
               "compartment_id": settings.compartment_id, "tags": dict(settings.tags),
               "network": {"vcn_cidr": settings.vcn_cidr, "tier_cidrs": dict(settings.tier_cidrs),
                           "availability_domain": settings.availability_domain}}
    if admission_policy:
        context["admission_policy"] = admission_policy
    return {"schema": 1, "inventory": inventory, "context": context,
            "caps": {"apps": settings.max_apps_per_wave, "vms": settings.max_vms_per_wave, "criticality": "n/a"},
            "dependencies": [{"app": a, "depends_on": b} for a, b in deps], "placements": placements, "waves": waves,
            "blocked": dict(rep.blocked_apps), "plan_id": rep.plan_id}


def catalog():
    """ocio's blueprints in the wrapper's catalog shape (sizing comes from each source VM, not a default)."""
    from ocio.catalog import BLUEPRINTS
    from ocio import factory as F
    out = {}
    for b in BLUEPRINTS:
        shape = b.defaults.get("shape")
        lim = F.SHAPE_SIZE.get(shape)
        out[b.id()] = {"version": str(b.version), "defaults": dict(b.defaults, ocpus="from source", memory_gb="from source"),
                       "customizable": sorted(b.customizable), "match": {"tier": b.match_tier, "os": b.match_os},
                       "bounds": {shape: {"max_ocpus": lim[0], "max_memory_gb": lim[1], "max_gb_per_ocpu": F.MAX_GB_PER_OCPU}}
                       if lim else {}}
    return out


def _load(path, default=None):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def results(root=PACKAGE_ROOT):
    """evidence / scale / mutations for the wrapper, from ocio's own result files. A missing file gives zeros and
    says so in the scope field; nothing is filled in from the sample."""
    mc = _load(os.path.join(root, "examples", "montecarlo_results.json"), {}) or {}
    trials = passed = assertions = shuffled = 0
    for name, r in mc.items():
        if not isinstance(r, dict):
            continue
        if name == "unittest":
            shuffled += r.get("trials", 0)
            continue
        trials += r.get("trials", 0)
        passed += r.get("safety_pass", 0)
        assertions += sum((r.get("per_check_pass") or {}).values())
    evidence = {"scope": "ocio Monte Carlo: synthetic estates and in-memory OCI/OCM, no live tenancy"
                         if mc else "no Monte Carlo results file found in this build",
                "trials": trials, "additional_stress_trials": shuffled, "passed": passed + shuffled,
                "failed": max(0, trials - passed), "assertions": assertions}
    sc = _load(os.path.join(root, "examples", "scale_results.json"), {}) or {}
    rows = [{"vms": r["vms"], "planning_seconds": r["planning_seconds"], "waves": r.get("waves")}
            for r in sc.get("A_measured", [])] or [{"vms": 0, "planning_seconds": 0.0}]
    killed = total = 0
    control = False
    try:
        with open(os.path.join(root, "examples", "mutate_results.txt")) as f:
            for line in f:
                m = re.match(r"^(KILLED|TIMEOUT|SURVIVED)\s", line)
                if m:
                    total += 1
                    killed += m.group(1) != "SURVIVED"
                if line.startswith("control (unmodified code): exit "):
                    control = line.strip().endswith("exit 0")      # the unmodified copy passed its own suite
    except OSError:
        pass
    return evidence, {"tier": "measured, ocio planning on synthetic data", "rows": rows}, \
        {"mutants": total, "detected": killed, "control_passed": control}


def documents(root=PACKAGE_ROOT):
    """ocio's RUNBOOK.md and README.md for the wrapper's embedded documents ("Operator runbook" link), keyed as
    the wrapper's links expect (assets/<name>)."""
    docs = {}
    for name in ("RUNBOOK.md", "README.md"):
        p = os.path.join(root, name)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                docs[f"assets/{name}"] = f.read()
    return docs


def workspace(inventory_path, settings, admission_policy=None):
    """Everything the wrapper embeds, built from ocio for one inventory and Settings."""
    from ocio import pipeline as P
    from ocio.catalog import BLUEPRINTS, load_inventory
    wls = load_inventory(inventory_path)
    rep = P.run(wls, BLUEPRINTS, settings, None, execute=False)
    plan = to_wrapper_plan(rep, wls, settings, admission_policy)
    evidence, scale, mutations = results()
    return {"plan": plan, "catalog": catalog(), "flows": [], "dependencies": plan["dependencies"],
            "evidence": evidence, "scale": scale, "mutations": mutations}


def default_settings(environment="dev"):
    """Planning settings for the console when none are given: the CLI's defaults for the landing zone and wave
    caps, a plan-only compartment placeholder and placeholder required tags (the plan id therefore differs from a
    run with real values; the console's launcher uses the real ones)."""
    from ocio import pipeline as P
    return P.Settings(environment, "ocid1.compartment.oc1..plan-only", {"cost_center": "set-me", "owner": "set-me"},
                      "mig", "10.20.0.0/16", {"web": "10.20.1.0/24", "app": "10.20.2.0/24", "db": "10.20.3.0/24"})


def _embed(text, element_id, value):
    pat = re.compile(r'(<script id="%s" type="application/json">)(.*?)(</script>)' % element_id, re.S)
    # <, > and & escaped as JSON unicode escapes: inside a <script> block, "<!--" followed by "<script" changes how
    # the browser finds the closing tag, so escaping "</" alone lets a VM name freeze the page.
    data = json.dumps(value).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    new, n = pat.subn(lambda m: m.group(1) + data + m.group(3), text)
    if n != 1:
        raise ValueError(f"wrapper has {n} #{element_id} blocks")
    return new


def html(ws, served=False, launch_js=""):
    """The wrapper page: patched, with workspace ws embedded. served: True when served by `ocio ui` (the wrapper
    then uses ocio's local API, with the session token the private launch file put in the tab; the page itself
    never contains it); False for the standalone file."""
    text = _embed(_embed(patched(), "embeddedMetadata", ws), "embeddedDocuments", documents())
    from .launch import TOKEN_BOOT
    boot = TOKEN_BOOT if served else "<script>window.OCIO_LIVE=null;</script>"
    text = text.replace("<script id=\"embeddedMetadata\"", boot + launch_js + "<script id=\"embeddedMetadata\"", 1)
    return text


# ------------------------------------------------------------------ the wrapper's local-engine API, answered by ocio

def handle_api(path, body, state):
    """(status, payload) for the wrapper's own calls. state: {"inventory": path, "settings": Settings,
    "assets": path?, "flows": path?}. Nothing here touches a tenancy."""
    if not isinstance(body, dict) or not isinstance(body.get("plan", {}), dict) \
            or not isinstance(body.get("approvals", []), list):
        return 400, {"error": "the request must be an object; 'plan' an object and 'approvals' a list"}
    if path in ("plan", "validate", "dry-run"):
        ws = workspace(state["inventory"], state["settings"])
        plan = ws["plan"]
        if path == "plan":
            return 200, plan
        sent = (body or {}).get("plan") or {}
        if sent.get("plan_id") != plan["plan_id"]:
            return 400, {"error": f"plan {sent.get('plan_id')!r} is not ocio's current plan {plan['plan_id']} for "
                                  f"these inputs; regenerate it"}
        if path == "validate":
            return 200, {"valid": True, "plan_id": plan["plan_id"]}
        return 200, {"dry_run": True, "plan_id": plan["plan_id"], "waves": plan["waves"], "blocked": plan["blocked"]}
    if path == "simulate":
        return _simulate(body or {}, state)
    if path == "discover":
        from ocio import discovery as D
        if not (state.get("assets") and state.get("flows")):
            return 400, {"error": "discovery needs assets.csv and flows.csv: start with ocio ui --assets ... --flows ..."}
        res = D.discover(D.load_assets(state["assets"]), D.load_flows(state["flows"]))
        rep = res.report()
        return 200, {"groups": {a: [] for a in rep["apps"]}, "dependencies": rep["dependencies"],
                     "review_required": bool(rep["low_confidence_vms"]), "report": rep}
    return 404, {"error": "unknown endpoint"}


def _simulate(body, state):
    import tempfile
    from ocio import capacity as C, pipeline as P
    from ocio.catalog import BLUEPRINTS, load_inventory
    from ocio.engine import Engine
    from ocio.journal import Journal
    from ocio.providers import FakeOCI
    wls = load_inventory(state["inventory"])
    s = state["settings"]
    ws_plan = workspace(state["inventory"], s)["plan"]
    sent = (body.get("plan") or {}).get("plan_id")
    if sent != ws_plan["plan_id"]:
        return 400, {"error": f"plan {sent!r} is not ocio's current plan {ws_plan['plan_id']}; regenerate it"}
    approved = {a.get("wave"): a.get("approver") for a in body.get("approvals") or [] if isinstance(a, dict)
                if a.get("plan_id") == ws_plan["plan_id"] and isinstance(a.get("approver"), str) and a["approver"].strip()}

    def approver(name, reasons, plan, wave_hash):
        i = int(name.split("-")[-1]) - 1                          # wrapper waves are 0-based
        who = approved.get(i)
        return (who is not None), (who or "")
    jp = os.path.join(tempfile.mkdtemp(), "simulation.jsonl")
    fake = FakeOCI()
    quota = C.StaticQuota({n: 1e9 for pair in C.SHAPE_LIMITS.values() for n in pair})
    rep = P.run(wls, BLUEPRINTS, s, lambda: Engine(fake, Journal(jp), sleep=lambda _s: None), quota=quota,
                approver=approver)
    rows = [{"seq": i, "event": e.get("event"), "data": {"key": e.get("step") or e.get("workflow") or e.get("run_id")},
             "hash": e.get("hash")} for i, e in enumerate(Journal(jp).entries)]
    return 200, {"journal": rows, "waves": rep.wave_results, "plan_id": ws_plan["plan_id"],
                 "provider": "in-memory OCI (FakeOCI); no tenancy calls"}
