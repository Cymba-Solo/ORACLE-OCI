"""Browser console for ocio: the wrapper shell (shell.py), the launch console (launch.py), the guide."""
