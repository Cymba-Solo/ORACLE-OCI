'use strict';
/* Console shell behaviour, from the OCI Standalone Wrapper (J.C. Glover): icons, helpers, modal, toast,
   accessible hover/focus metadata, and the wordmark sparkle scheduler. Nothing here reaches the network. */
const icons={grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',server:'<rect x="3" y="3" width="18" height="7" rx="2"/><rect x="3" y="14" width="18" height="7" rx="2"/><path d="M7 6.5h.01M7 17.5h.01M11 6.5h6M11 17.5h6"/>',search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',layers:'<path d="m12 3 10 6-10 6L2 9l10-6Zm-9 11 9 5 9-5M3 18l9 5 9-5"/>',waves:'<path d="M2 7h5l3 10 4-14 3 10h5"/>',shield:'<path d="M12 3 4 6v5c0 5 8 10 8 10s8-5 8-10V6l-8-3Z"/><path d="m8 12 3 3 5-6"/>',check:'<path d="m5 12 4 4L19 6"/>',file:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Z"/><path d="M14 2v6h6M8 13h8M8 17h6"/>',settings:'<path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z"/><path d="m9 3 1-1h4l1 3 3 1 3 1v4l-2 2-1 3-2 3h-4l-2-2-3-1-3-2v-4l2-2 1-3 2-2Z"/>',book:'<path d="M12 5C9 3 5 3 2 4v15c3-1 7-1 10 1 3-2 7-2 10-1V4c-3-1-7-1-10 1Zm0 0v15"/>',globe:'<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>',help:'<circle cx="12" cy="12" r="9"/><path d="M9 9a3 3 0 0 1 6 0c0 2-3 2-3 4m0 3h.01"/>',upload:'<path d="M12 16V3m-5 5 5-5 5 5M3 15v5h18v-5"/>',arrow:'<path d="M4 12h16m-6-6 6 6-6 6"/>',close:'<path d="m6 6 12 12M6 18 18 6"/>',cloud:'<path d="M6 18a5 5 0 0 1-1-10 7 7 0 0 1 13 0 5 5 0 0 1 0 10H6Z"/>',network:'<rect x="8" y="2" width="8" height="6" rx="1"/><rect x="2" y="16" width="7" height="6" rx="1"/><rect x="15" y="16" width="7" height="6" rx="1"/><path d="M12 8v4M5 16v-4h14v4"/>',alert:'<path d="m12 3 10 18H2L12 3Zm0 6v5m0 3h.01"/>',download:'<path d="M12 3v13m-5-5 5 5 5-5M3 17v4h18v-4"/>',terminal:'<path d="m5 7 5 5-5 5m8 0h6"/><rect x="2" y="2" width="20" height="20" rx="3"/>',play:'<path d="m8 4 12 8-12 8V4Z"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',menu:'<path d="M3 6h18M3 12h18M3 18h18"/>',copy:'<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V3H3v13h5"/>'};
const icon=n=>`<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${icons[n]||icons.file}</svg>`;
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clone=v=>JSON.parse(JSON.stringify(v));
const $=s=>document.querySelector(s);
const fmt=n=>Number(n||0).toLocaleString();
function hydrate(){document.querySelectorAll('[data-icon]').forEach(el=>el.innerHTML=icon(el.dataset.icon))}
function toast(msg){$('#toast').textContent=msg;$('#toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('#toast').hidden=true,4500)}
let previousFocus;
function modal(title,html){previousFocus=document.activeElement;$('#modalTitle').textContent=title;$('#modalBody').innerHTML=html;$('#modal').hidden=false;document.body.style.overflow='hidden';hydrate();$('#closeModal').focus()}
function closeModal(){$('#modal').hidden=true;document.body.style.overflow='';previousFocus?.focus()}
function download(name,value,type='application/json'){const data=typeof value==='string'?value:JSON.stringify(value,null,2);const url=URL.createObjectURL(new Blob([data],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}

// Accessible, plan-derived hover/focus metadata. Escape every imported value.
const metadataTooltip=document.createElement('aside');
metadataTooltip.id='metadataTooltip';metadataTooltip.className='metadata-tooltip';metadataTooltip.setAttribute('role','tooltip');metadataTooltip.hidden=true;document.body.append(metadataTooltip);
let metadataTarget=null,metadataTimer=null;
function hideMetadata(){clearTimeout(metadataTimer);if(metadataTarget){metadataTarget.removeAttribute('aria-describedby');metadataTarget=null}metadataTooltip.hidden=true}
function positionMetadata(target){const r=target.getBoundingClientRect(),gap=12;const width=Math.min(350,window.innerWidth-24);metadataTooltip.style.width=width+'px';const height=metadataTooltip.offsetHeight;let left=Math.min(window.innerWidth-width-12,Math.max(12,r.left));let top=r.bottom+gap;if(top+height>window.innerHeight-12)top=Math.max(12,r.top-height-gap);metadataTooltip.style.left=left+'px';metadataTooltip.style.top=top+'px'}
function showMetadata(target){hideMetadata();metadataTarget=target;metadataTimer=setTimeout(()=>{try{const meta=JSON.parse(target.dataset.meta);if(!target.isConnected)return;metadataTooltip.innerHTML='<div class="metadata-heading"><span>'+icon('file')+'</span>'+esc(meta.title)+'</div><dl>'+meta.rows.map(([key,value])=>'<div><dt>'+esc(key)+'</dt><dd>'+esc(value)+'</dd></div>').join('')+'</dl><div class="metadata-footer">Active workspace metadata · no live readiness claim</div>';metadataTooltip.hidden=false;target.setAttribute('aria-describedby','metadataTooltip');positionMetadata(target)}catch(_){hideMetadata()}},180)}
document.addEventListener('mouseover',e=>{const target=e.target.closest('[data-meta]');if(target&&target!==metadataTarget)showMetadata(target);else if(!target&&!e.target.closest('#metadataTooltip'))hideMetadata()});
document.addEventListener('mouseout',e=>{if(metadataTarget&&!metadataTarget.contains(e.relatedTarget)&&!metadataTooltip.contains(e.relatedTarget))hideMetadata()});
document.addEventListener('focusin',e=>{const target=e.target.closest('[data-meta]');if(target)showMetadata(target)});
document.addEventListener('focusout',e=>{if(metadataTarget&&!metadataTarget.contains(e.relatedTarget))hideMetadata()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')hideMetadata()});
window.addEventListener('scroll',hideMetadata,true);window.addEventListener('resize',hideMetadata);



/* Individually timed logo accents, then alternating 3/6-minute quiet periods.
   Production timing uses timers; the pure scheduler is also checked with a
   virtual clock so verification does not require waiting nine real minutes. */
function createBrandSparkleSchedule({schedule,cancel,random,emit}){
  const pauses=[180000,360000],timers=new Set();
  let running=false,pauseIndex=0;
  function later(fn,delay){let timer;timer=schedule(()=>{timers.delete(timer);if(running)fn()},delay);timers.add(timer)}
  function burst(){
    if(!running)return;
    const letters=['o','r','e'];
    for(let i=letters.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[letters[i],letters[j]]=[letters[j],letters[i]]}
    let offset=120+Math.floor(random()*400),lastEnd=0;
    for(const letter of letters){
      const duration=720+Math.floor(random()*300);
      later(()=>emit(letter,duration),offset);
      lastEnd=offset+duration;
      offset=lastEnd+180+Math.floor(random()*620);
    }
    later(burst,lastEnd+pauses[pauseIndex++%pauses.length]);
  }
  return {
    start(){if(running)return;running=true;burst()},
    stop(){running=false;for(const timer of timers)cancel(timer);timers.clear()}
  };
}
/* Logo-only decoration: never changes plan, metadata, approvals or engine state. */
(()=>{
  const preference=window.matchMedia('(prefers-reduced-motion: reduce)');
  const controller=createBrandSparkleSchedule({
    schedule:(fn,ms)=>setTimeout(fn,ms),cancel:id=>clearTimeout(id),random:Math.random,
    emit(letter,duration){
      if(document.hidden||preference.matches)return;
      const anchor=document.querySelector('[data-sparkle-anchor="'+letter+'"]');
      if(!anchor)return;
      const sparkle=document.createElement('span');
      sparkle.className='brand-sparkle';sparkle.setAttribute('aria-hidden','true');
      sparkle.style.setProperty('--sparkle-duration',duration+'ms');
      sparkle.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 0 15.1 8.9 24 12 15.1 15.1 12 24 8.9 15.1 0 12 8.9 8.9Z"/></svg>';
      anchor.append(sparkle);
      sparkle.addEventListener('animationend',()=>sparkle.remove(),{once:true});
    }
  });
  function sync(){
    controller.stop();document.querySelectorAll('.brand-sparkle').forEach(el=>el.remove());
    if(!document.hidden&&!preference.matches)controller.start();
  }
  document.addEventListener('visibilitychange',sync);
  preference.addEventListener('change',sync);
  window.addEventListener('pagehide',()=>controller.stop());
  sync();
})();

