"""Synthetic estates with known ground truth, for measuring discovery and for scale tests. SIMULATED.

An estate is a set of apps. Each app has some of the web / app / db tiers, 1-4 VMs per tier. Apps depend
on earlier apps (a DAG) plus, with probability p_mutual, a mutual pair. Flows are generated from the
truth and then degraded the way real observation data is:

  * p_observe     a true dependency is seen in the observation window with this probability per VM pair
  * noise_flows   low-volume flows between unrelated apps on random high ports (scans, stray clients)
  * infra traffic DNS / NTP / LDAP / SSH / node-exporter flows, which discovery must exclude
  * external      some apps call addresses outside the estate (mainframe, SaaS)
  * p_tagged      share of VMs that carry app= / tier= tags (declared, not inferred)
"""
from __future__ import annotations

import random

from .discovery import Asset
from .factory import Workload

WORDS = ["crm", "billing", "hr", "portal", "ledger", "orders", "catalog", "search", "payments", "claims",
         "fleet", "audit", "payroll", "booking", "inventory", "shipping", "pricing", "loyalty", "risk", "quotes"]
DB_PORT = {"oracle": 1521, "postgres": 5432, "mysql": 3306, "mssql": 1433}
OS = {"linux": "Oracle Linux 8", "windows": "Microsoft Windows Server 2022 (64-bit)"}


def app_names(n):
    """n distinct app names from WORDS, with a numeric suffix once the word list repeats (crm, ..., crm1, ...)."""
    return [WORDS[i % len(WORDS)] + ("" if i < len(WORDS) else str(i // len(WORDS))) for i in range(n)]


def estate(n_apps, seed=0, max_deps=2, p_mutual=0.05, p_observe=0.9, noise_flows=None, p_tagged=0.2,
           p_external=0.1, critical_share=0.05):
    """A synthetic estate with known truth, deterministic for a given seed. SIMULATED data.

    Returns (assets, flows, listeners, truth): Asset rows (one IP each; db VMs always Linux, other tiers
    Windows for about a quarter of apps); flows as (src_ip, dst_ip, port, connections), including intra-app
    traffic, internet users to web tiers, observed dependency traffic (each VM pair seen with probability
    p_observe), optional external calls, infrastructure traffic (DNS, NTP, SSH, node exporter) and
    low-volume noise; listeners {vm: {db port}} for db VMs; and truth {"app", "tier", "deps", "critical"}
    for scoring discovery. See the module docstring for what each probability controls.
    """
    r = random.Random(seed)
    names = app_names(n_apps)
    apps, assets, truth_app, truth_tier = {}, [], {}, {}
    ip_seq = iter(range(1, 10_000_000))

    def ip():
        k = next(ip_seq)
        return f"10.{(k >> 16) & 255}.{(k >> 8) & 255}.{k & 255}"

    for i, a in enumerate(names):
        tiers = r.choice([("web", "app", "db"), ("app", "db"), ("web", "app"), ("app",), ("db",)])
        dbkind = r.choice(list(DB_PORT))
        osfam = "windows" if r.random() < 0.25 else "linux"
        critical = r.random() < critical_share
        vms = {}
        for t in tiers:
            vms[t] = []
            for k in range(1, r.randint(1, 4) + 1):
                name = f"{a}-{t}-{k:02d}"
                tags = {}
                if r.random() < p_tagged:
                    tags = {"app": a, "tier": t}
                if critical:
                    tags["critical"] = "yes"
                fam = "linux" if t == "db" else osfam
                asset = Asset(name, ip(), OS[fam], r.choice([2, 4, 8, 16]), r.choice([8, 16, 32, 64]), tags)
                assets.append(asset); vms[t].append(asset)
                truth_app[name], truth_tier[name] = a, t
        apps[a] = {"vms": vms, "db": dbkind, "deps": set(), "critical": critical}
    for i, a in enumerate(names):
        for d in r.sample(names[:i], min(i, r.randint(0, max_deps))):
            apps[a]["deps"].add(d)
    for i, a in enumerate(names):
        if i and r.random() < p_mutual:
            b = r.choice(names[:i])
            apps[a]["deps"].add(b); apps[b]["deps"].add(a)

    flows, listeners = [], {}

    def server(app):
        v = apps[app]["vms"]
        if "app" in v:
            return v["app"], 8080
        if "db" in v:
            return v["db"], DB_PORT[apps[app]["db"]]
        return v["web"], 443

    def client(app):
        v = apps[app]["vms"]
        return v.get("app") or v.get("web") or v["db"]

    for a, info in apps.items():
        v = info["vms"]
        if "web" in v and "app" in v:
            for s in v["web"]:
                for d in v["app"]:
                    flows.append((s.ip, d.ip, 8080, r.randint(50, 5000)))
        if "app" in v and "db" in v:
            for s in v["app"]:
                for d in v["db"]:
                    flows.append((s.ip, d.ip, DB_PORT[info["db"]], r.randint(50, 5000)))
        if "web" in v:
            for d in v["web"]:
                flows.append((f"198.51.100.{r.randint(1, 254)}", d.ip, 443, r.randint(100, 9000)))   # users
        for dep in sorted(info["deps"]):      # sorted: set order follows the per-process hash seed
            dsts, port = server(dep)
            for s in client(a):
                for d in dsts:
                    if r.random() < p_observe:
                        flows.append((s.ip, d.ip, port, r.randint(3, 800)))
        if r.random() < p_external:
            flows.append((client(a)[0].ip, f"192.0.2.{r.randint(1, 254)}", r.choice([443, 1414, 23]), r.randint(5, 300)))
        for s in [x for t in v.values() for x in t]:
            flows.append((s.ip, "10.255.0.2", 53, r.randint(100, 2000)))
            flows.append((s.ip, "10.255.0.3", 123, r.randint(10, 100)))
            flows.append(("10.255.0.9", s.ip, 22, r.randint(1, 20)))
            flows.append(("10.255.0.10", s.ip, 9100, r.randint(100, 900)))
            if "db" in v and s in v["db"]:
                listeners[s.name] = {DB_PORT[info["db"]]}
    noise = noise_flows if noise_flows is not None else max(1, len(assets) // 20)
    for _ in range(noise):
        s, d = r.sample(assets, 2)
        if truth_app[s.name] != truth_app[d.name] and truth_app[d.name] not in apps[truth_app[s.name]]["deps"]:
            flows.append((s.ip, d.ip, r.randint(20000, 40000), r.randint(1, 3)))
    truth = {"app": truth_app, "tier": truth_tier,
             "deps": {(a, d) for a, info in apps.items() for d in info["deps"]},
             "critical": sorted(a for a, i in apps.items() if i["critical"])}
    return assets, flows, listeners, truth


def inventory(n_apps, seed=0, **kw):
    """Factory inventory (Workloads) straight from the truth: for scale tests of planning and execution."""
    assets, _, _, truth = estate(n_apps, seed, noise_flows=0, **kw)
    deps = {}
    for a, d in truth["deps"]:
        deps.setdefault(a, set()).add(d)
    return [Workload(x.name, truth["app"][x.name], truth["tier"][x.name], x.os, x.vcpus, x.memory_gb,
                     tuple(sorted(deps.get(truth["app"][x.name], ())))) for x in assets], truth
