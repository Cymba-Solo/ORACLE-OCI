"""Workflow specification: steps, dependencies, output references, validation, wave ordering.

A workflow is data, not code. Each step names a resource kind, its parameters, and the steps it
depends on. Parameters may reference earlier outputs as "${step_id.field}". Validation happens
before anything touches OCI: unknown kinds, missing dependencies, cycles, and references to steps
that are not declared dependencies are all rejected.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

REF = re.compile(r"\$\{([A-Za-z0-9_\-]+)\.([a-z0-9_]+)\}")   # step ids may carry capitals (VM names); fields are snake_case
KINDS = {"vcn", "subnet", "instance"}


ENVIRONMENTS = ("dev", "test", "prod")


class SpecError(ValueError):
    """A workflow is malformed or unsafe to order: missing keys, unknown kind, duplicate id, undeclared
    dependency, a reference to a step that is not a dependency, or a cycle.
    """
    pass


@dataclass(frozen=True)
class Step:
    """One resource to create: id (unique in the workflow), kind ('vcn', 'subnet', 'instance'), params (may hold
    "${step_id.field}" references to declared dependencies), and the ids it depends on.
    """
    id: str
    kind: str
    params: dict
    depends_on: tuple = ()


@dataclass(frozen=True)
class Workflow:
    """A named, tagged set of steps for one compartment and environment; the environment is read by the policy
    gates (e.g. prod rules). Immutable: callers build a new one to change it.
    """
    name: str
    environment: str                 # e.g. "prod", "dev" — read by policy gates
    compartment_id: str
    steps: tuple
    tags: dict = field(default_factory=dict)

    def __post_init__(self):
        # The policy gates and approval rules compare the environment with "prod" exactly; any other spelling of
        # production ("PROD", "production") would silently get development rules. So only three values exist.
        if self.environment not in ENVIRONMENTS:
            raise SpecError(f"workflow {self.name}: environment {self.environment!r} must be one of {ENVIRONMENTS}")

    def step(self, sid) -> Step:
        """The step with id sid; KeyError if there is none."""
        for s in self.steps:
            if s.id == sid:
                return s
        raise KeyError(sid)


def _strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for v in value.values():
            yield from _strings(v)
    elif isinstance(value, list):
        for v in value:
            yield from _strings(v)


def _refs(value):
    if isinstance(value, str):
        return REF.findall(value)
    if isinstance(value, dict):
        return [r for v in value.values() for r in _refs(v)]
    if isinstance(value, list):
        return [r for v in value for r in _refs(v)]
    return []


def load(doc: dict) -> Workflow:
    """Build a Workflow from a plain dict (name, environment, compartment_id, steps[], optional tags) and
    validate it. SpecError for missing or mistyped keys, and for anything validate() refuses.
    """
    if not isinstance(doc, dict) or not isinstance(doc.get("steps"), list):
        raise SpecError("malformed workflow: an object with a steps list is required")
    for s in doc["steps"]:                       # shapes checked, never coerced: tuple("vcn") would be ('v','c','n')
        if not isinstance(s, dict):
            raise SpecError(f"malformed workflow: each step must be an object, got {s!r}")
        if not isinstance(s.get("id"), str) or not s.get("id") or not isinstance(s.get("kind"), str):
            raise SpecError(f"malformed workflow: step ids and kinds must be non-empty strings, got {s.get('id')!r}")
        if not isinstance(s.get("params", {}), dict):
            raise SpecError(f"{s['id']}: params must be an object, got {type(s['params']).__name__}")
        deps = s.get("depends_on", [])
        if not isinstance(deps, (list, tuple)) or not all(isinstance(d, str) for d in deps):
            raise SpecError(f"{s['id']}: depends_on must be a list of step ids, got {deps!r}")
    if not isinstance(doc.get("tags", {}), dict):
        raise SpecError("malformed workflow: tags must be an object")
    try:
        steps = tuple(Step(id=s["id"], kind=s["kind"], params=dict(s.get("params", {})),
                           depends_on=tuple(s.get("depends_on", ()))) for s in doc["steps"])
        wf = Workflow(name=doc["name"], environment=doc["environment"], compartment_id=doc["compartment_id"],
                      steps=steps, tags=dict(doc.get("tags", {})))
    except (KeyError, TypeError) as e:
        raise SpecError(f"malformed workflow: {e!r}") from e
    validate(wf)
    return wf


def validate(wf: Workflow):
    """Refuse (SpecError) duplicate step ids, unknown kinds, dependencies on undeclared steps, "${step.field}"
    references to steps not listed in depends_on (their order would not be guaranteed), and cycles. Returns None.
    """
    ids = [s.id for s in wf.steps]
    if len(ids) != len(set(ids)):
        raise SpecError("duplicate step id")
    known = set(ids)
    for s in wf.steps:
        if s.kind not in KINDS:
            raise SpecError(f"{s.id}: unknown kind {s.kind!r}")
        for d in s.depends_on:
            if d not in known:
                raise SpecError(f"{s.id}: depends on undeclared step {d!r}")
        for v in _strings(s.params):
            # Anything that looks like a reference must BE one, as a whole value: "${vcn.display-name}" or
            # "pre-${vcn.id}" passed through as literal text would reach OCI as a name or an OCID.
            if "${" in v and not REF.fullmatch(v):
                raise SpecError(f"{s.id}: {v!r} is not a reference of the form ${{step_id.field}} (a whole value; "
                                f"partial references are not supported)")
        for ref_step, _ in _refs(s.params):
            # A reference must be to a declared dependency, or ordering is not guaranteed.
            if ref_step not in s.depends_on:
                raise SpecError(f"{s.id}: references {ref_step} without depending on it")
    waves(wf)  # raises on cycles


def waves(wf: Workflow) -> list[list[str]]:
    """Kahn's algorithm, grouped into waves. Steps in one wave are independent and may run in parallel."""
    deps = {s.id: set(s.depends_on) for s in wf.steps}
    done, out = set(), []
    while len(done) < len(deps):
        ready = sorted(sid for sid, d in deps.items() if sid not in done and d <= done)
        if not ready:
            raise SpecError(f"dependency cycle among {sorted(set(deps) - done)}")
        out.append(ready)
        done |= set(ready)
    return out


def resolve(params, outputs: dict):
    """Substitute ${step.field} with recorded outputs. Missing outputs are an error, never a blank."""
    if isinstance(params, str):
        m = REF.fullmatch(params)
        if m:
            sid, f = m.groups()
            try:
                return outputs[sid][f]
            except KeyError as e:
                raise SpecError(f"unresolved reference {params}") from e
        if REF.search(params):
            raise SpecError(f"partial references not supported: {params}")
        return params
    if isinstance(params, dict):
        return {k: resolve(v, outputs) for k, v in params.items()}
    if isinstance(params, list):
        return [resolve(v, outputs) for v in params]
    return params
