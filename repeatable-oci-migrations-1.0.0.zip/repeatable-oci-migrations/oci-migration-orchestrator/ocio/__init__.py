"""ocio: repeatable OCI migrations. Blueprint factory, wave planner, journalled engine, OCM driver.

The command line is ocio.cli (installed as `ocio`, or `python -m ocio`)."""
__version__ = "1.0.0"
