"""OCID checks, so a typo or a placeholder is refused here rather than as a 404 halfway through a wave.

Oracle's "Resource Identifiers" page (checked 2026-10-21) gives the syntax
    ocid1.<RESOURCE TYPE>.<REALM>.[REGION][.FUTURE USE].<UNIQUE ID>
The region part is blank for resources that are not regional (a tenancy or compartment OCID has
"..": ocid1.tenancy.oc1..aaaa...). The page names realms oc1 (commercial), oc2 and oc3 (government);
newer realms exist, so any realm of the form oc<N> is accepted rather than rejecting a real one.
"""
from __future__ import annotations

import re

_OCID = re.compile(r"^ocid1\.([a-z0-9]+)\.(oc[0-9]+)\.([a-z0-9-]*)(?:\.([a-z0-9-]*))?\.([A-Za-z0-9_-]+)$")


def problem(value, types=None):
    """None if value is a well-formed OCID (of one of `types`, when given); otherwise the reason."""
    if not isinstance(value, str) or not value:
        return f"{value!r} is not an OCID"
    m = _OCID.match(value)
    if not m:
        return (f"{value!r} is not a well-formed OCID (expected ocid1.<type>.<realm>.<region>.<unique id>, "
                f"e.g. ocid1.compartment.oc1..aaaa...)")
    if types and m.group(1) not in types:
        return f"{value!r} is an OCID of type {m.group(1)!r}, expected {' or '.join(types)}"
    return None


def require(value, types=None, what="value"):
    """Return value unchanged if problem(value, types) finds nothing; otherwise raise ValueError prefixed with
    `what` (the option or field name, so the message says which input is wrong).
    """
    p = problem(value, types)
    if p:
        raise ValueError(f"{what}: {p}")
    return value
