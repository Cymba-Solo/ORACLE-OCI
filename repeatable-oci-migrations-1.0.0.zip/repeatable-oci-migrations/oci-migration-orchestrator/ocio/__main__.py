"""`python -m ocio ...` runs the command line (ocio.cli)."""
import sys

from ocio.cli import main

sys.exit(main())
