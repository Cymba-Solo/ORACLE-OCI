"""Least-privilege network rules from observed traffic, and a cutover reachability check.

WHY THIS EXISTS. The target network keeps the VCN's DEFAULT security list, which (Oracle's Security Lists
page, checked 2026-10-21) allows stateful ingress only for TCP 22 (SSH) and ICMP 3/4 from authorized
sources plus ICMP 3 from the VCN, and all egress. So once an app tier and its database both run in OCI, the
app's calls to the database on, say, 1521 are DENIED unless a rule allows them. That failure appears at
cutover, when it is most expensive. Discovery has already observed every flow, so the rules can be
derived, reviewed and checked before any VM moves.

WHAT IT PRODUCES
  * One network security group (NSG) per app tier ("<app>-<tier>"), every VM of that tier a member.
  * For each observed flow (source app tier -> destination app tier, TCP port): one STATEFUL ingress rule
    on the destination NSG whose source is the source NSG (source_type NETWORK_SECURITY_GROUP, protocol
    "6"). Stateful, so replies need no rule; egress stays open under the default security list.
  * Hybrid flows, per wave: while a wave's partners are still on the source site, traffic crosses the
    site boundary. Those flows are listed (direction, port, VMs) because they need the network team's
    DRG / FastConnect routing and on-premises firewall rules, which no OCI rule can provide.
  * check(): for a wave, every observed flow between VMs that will both be in OCI must be allowed by the
    NSG plan (or by the default security list: only TCP 22). Anything else is a cutover blocker.

APPLY (OCI). create_network_security_group accepts an opc-retry-token, so NSG creation is idempotent.
add_network_security_group_security_rules does NOT (oci 2.189.0), so a blind re-send after a timeout could
duplicate rules. apply() therefore converges: it lists each NSG's rules and adds only the missing ones,
at most 25 per call (the documented per-call limit). Model and method names checked against oci 2.189.0;
not run against a tenancy.

Only TCP is modelled; flows on other protocols are not in the flow export format used here.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field

from .discovery import INFRA_PORTS

# Assume the default security list lets NO application traffic in. Oracle's wording is SSH "from authorized
# source IP addresses", which may or may not include a peer subnet; assuming it does could hide a blocker.
# (SSH is an infrastructure port and is not an application flow here anyway.)
DEFAULT_LIST_TCP = frozenset()
MAX_RULES_PER_CALL = 25


def nsg_name(app, tier):
    """Display name of the NSG for one app tier: '<app>-<tier>' (e.g. 'shop-db'); also the key of --nsg-map."""
    return f"{app}-{tier}"


@dataclass(frozen=True)
class Rule:
    """One stateful TCP ingress rule: traffic to members of dst_nsg on `port` is allowed from members of
    src_nsg. Both are NSG names (nsg_name); apply() turns them into OCIDs.
    """
    dst_nsg: str                   # NSG name the rule is added to (ingress)
    src_nsg: str                   # NSG name allowed in
    port: int

    def key(self):
        """(dst_nsg, src_nsg, port): identity and sort key of the rule."""
        return (self.dst_nsg, self.src_nsg, self.port)


@dataclass
class Plan:
    """Result of build(): NSG membership, the deduplicated rules, and the in-estate flows they cover."""
    members: dict = field(default_factory=dict)          # nsg name -> sorted VM names
    rules: list = field(default_factory=list)            # [Rule]
    flows: list = field(default_factory=list)            # [(src_vm, dst_vm, port, connections)] inside the estate

    def report(self):
        """JSON-ready summary for review: NSG -> members, rules sorted by key, and the number of flows covered."""
        return {"nsgs": {k: v for k, v in sorted(self.members.items())},
                "rules": [{"nsg": r.dst_nsg, "allow_from_nsg": r.src_nsg, "tcp_port": r.port}
                          for r in sorted(self.rules, key=Rule.key)],
                "flows_covered": len(self.flows)}


def observed_flows(assets, flows, vips=None, min_connections=1):
    """[(src_vm, dst_vm, port, connections)] between estate VMs, infrastructure ports excluded. Traffic to a
    VIP counts for every VM behind it (as in discovery)."""
    from .discovery import norm_ip
    by_ip = {ip: [a.name] for a in assets for ip in a.ips}
    for vip, names in (vips or {}).items():
        by_ip[norm_ip(vip)] = sorted(set(names))
    out = {}
    for src, dst, port, n in ((norm_ip(a), norm_ip(b), p, c) for a, b, p, c in flows):
        if n < min_connections or port in INFRA_PORTS:
            continue
        for s in by_ip.get(src, ()):
            for d in by_ip.get(dst, ()):
                if s != d:
                    out[(s, d, port)] = out.get((s, d, port), 0) + n
    return sorted((s, d, p, n) for (s, d, p), n in out.items())


def build(placements, flows):
    """placements: factory placements (VM -> app, tier). flows: observed_flows(...). VMs not placed (refused,
    blocked, or outside the inventory) are not in OCI, so their flows are hybrid, not NSG rules."""
    where = {p.workload.name: (p.workload.app, p.workload.tier) for p in placements}
    plan = Plan()
    for vm, (app, tier) in where.items():
        plan.members.setdefault(nsg_name(app, tier), []).append(vm)
    for v in plan.members.values():
        v.sort()
    rules = set()
    for s, d, port, n in flows:
        if s in where and d in where:
            plan.flows.append((s, d, port, n))
            src, dst = nsg_name(*where[s]), nsg_name(*where[d])
            rules.add(Rule(dst, src, port))
    plan.rules = sorted(rules, key=Rule.key)
    return plan


def check(plan, placements, flows, wave_vms, migrated_vms=(), nsg_map=None):
    """Cutover check for one wave. wave_vms: VMs moving now; migrated_vms: VMs already in OCI.
    Returns {"blocked": [...], "hybrid": [...]}:
      blocked  flows between two VMs that will both be in OCI, allowed neither by the plan's rules nor by
               the default security list. With nsg_map given ({nsg name: OCID}), a rule only counts if both
               of its NSGs exist; a VM only counts as covered if its NSG does.
      hybrid   flows with one end in OCI after this wave and the other still on the source site."""
    in_oci = set(wave_vms) | set(migrated_vms)
    where = {p.workload.name: nsg_name(p.workload.app, p.workload.tier) for p in placements}
    allowed = {r.key() for r in plan.rules
               if nsg_map is None or (r.dst_nsg in nsg_map and r.src_nsg in nsg_map)}
    blocked, hybrid = [], []
    for s, d, port, n in flows:
        if not (s in set(wave_vms) or d in set(wave_vms)):
            continue                                  # not this wave's concern
        if s in in_oci and d in in_oci:
            ok = port in DEFAULT_LIST_TCP or (s in where and d in where and (where[d], where[s], port) in allowed)
            if not ok:
                blocked.append({"from": s, "to": d, "tcp_port": port, "connections": n})
        elif s in in_oci or d in in_oci:
            hybrid.append({"from": s, "to": d, "tcp_port": port, "connections": n,
                           "direction": "OCI -> source site" if s in in_oci else "source site -> OCI"})
    return {"blocked": blocked, "hybrid": hybrid}


def default_list_blocks(placements, flows):
    """Share of observed in-estate flows the DEFAULT security list alone would deny once both ends are in
    OCI: the size of the problem this module exists to solve."""
    where = {p.workload.name for p in placements}
    inside = [f for f in flows if f[0] in where and f[1] in where]
    denied = [f for f in inside if f[2] not in DEFAULT_LIST_TCP]
    return {"flows_between_placed_vms": len(inside), "denied_by_default_security_list": len(denied)}


# ------------------------------------------------------------------ OCI request models and apply

def rule_model(m, src_nsg_id, port, description):
    """oci.core.models.AddSecurityRuleDetails for one Rule: INGRESS, protocol "6" (TCP), source an NSG OCID
    (source_type NETWORK_SECURITY_GROUP), stateful, destination port range [port, port]. The description is
    cut to 255 characters. m is the oci.core.models module (passed in so tests need no SDK client).
    """
    return m.AddSecurityRuleDetails(
        direction="INGRESS", protocol="6", source=src_nsg_id, source_type="NETWORK_SECURITY_GROUP",
        is_stateless=False, description=description[:255],
        tcp_options=m.TcpOptions(destination_port_range=m.PortRange(min=port, max=port)))


def _all_rules(net, nsg_id):
    """Every INGRESS rule of one NSG, all pages. Convergence must see them all: adding rules takes no retry token,
    so a rule missed on page 2 would be added again as a duplicate. A repeated page token is refused."""
    out, page, seen = [], None, set()
    while True:
        kw = {"direction": "INGRESS"}
        if page:
            kw["page"] = page
        resp = net.list_network_security_group_security_rules(nsg_id, **kw)
        out.extend(resp.data or [])
        page = getattr(resp, "next_page", None) or (getattr(resp, "headers", None) or {}).get("opc-next-page")
        if not page:
            return out
        if page in seen:
            raise ValueError(f"listing rules of {nsg_id}: the service repeated page token {page!r}")
        seen.add(page)


def _token(vcn_id, name):
    return hashlib.sha256(f"nsg/{vcn_id}/{name}".encode()).hexdigest()[:64]


_GONE = ("TERMINATING", "TERMINATED")


def _nsgs_in_vcn(net, compartment_id, vcn_id):
    """{display name: [NSG]} for every NSG of the VCN that is not being deleted, all pages."""
    out, page, seen = {}, None, set()
    while True:
        kw = {"compartment_id": compartment_id, "vcn_id": vcn_id}
        if page:
            kw["page"] = page
        resp = net.list_network_security_groups(**kw)
        for g in resp.data or []:
            if getattr(g, "lifecycle_state", None) not in _GONE:
                out.setdefault(g.display_name, []).append(g)
        page = getattr(resp, "next_page", None) or (getattr(resp, "headers", None) or {}).get("opc-next-page")
        if not page:
            return out
        if page in seen:
            raise ValueError(f"listing NSGs of {vcn_id}: the service repeated page token {page!r}")
        seen.add(page)


def apply(net, m, plan, compartment_id, vcn_id, tags=None, defined_tags=None, existing=None, journal=None,
          on_created=None):
    """Create the plan's NSGs and converge their rules (add only what is missing, 25 per call).
    existing: {nsg name: OCID} already created (the map a previous run wrote). Returns {nsg name: OCID}.

    Never two NSGs for one name. The retry token (VCN + name) only protects a create for 24 hours, and a run
    that failed after creating NSGs may not have written its map, so before creating, the VCN is listed: an
    NSG of that name carrying ocio's tag (ocio_nsg=<name>) is reused (journalled as nsg_adopted); one without
    the tag is someone else's and the run stops with nothing created for it. on_created(name, id) is called
    after each create, so the caller can persist the map before the next call can fail."""
    ids = dict(existing or {})
    todo = [n for n in sorted(plan.members) if n not in ids]
    found = _nsgs_in_vcn(net, compartment_id, vcn_id) if todo else {}
    adopt = {}
    for name in todo:                                   # every name is checked before anything is created
        same = found.get(name, [])
        ours = [g for g in same if (getattr(g, "freeform_tags", None) or {}).get("ocio_nsg") == name]
        if len(same) > len(ours):
            raise ValueError(f"VCN {vcn_id} already has an NSG named {name} that ocio did not create "
                             f"({', '.join(g.id for g in same if g not in ours)}); rename it or remove it. "
                             "Nothing was created")
        if len(ours) > 1:
            raise ValueError(f"VCN {vcn_id} has {len(ours)} NSGs named {name} made by ocio "
                             f"({', '.join(g.id for g in ours)}); keep one, delete the others, then re-run. "
                             "Nothing was created")
        if ours:
            adopt[name] = ours[0].id
    for name in todo:
        if name in adopt:
            ids[name] = adopt[name]
            if journal is not None:
                journal.append(event="nsg_adopted", nsg=name, id=ids[name], vcn=vcn_id)
            if on_created is not None:
                on_created(name, ids[name])
            continue
        d = m.CreateNetworkSecurityGroupDetails(compartment_id=compartment_id, vcn_id=vcn_id, display_name=name,
                                                freeform_tags=dict(tags or {}, ocio_nsg=name),
                                                defined_tags=defined_tags or None)
        ids[name] = net.create_network_security_group(d, opc_retry_token=_token(vcn_id, name)).data.id
        if journal is not None:
            journal.append(event="nsg_created", nsg=name, id=ids[name], vcn=vcn_id)
        if on_created is not None:
            on_created(name, ids[name])
    by_dst = {}
    for r in plan.rules:
        by_dst.setdefault(r.dst_nsg, []).append(r)
    for dst, rules in sorted(by_dst.items()):
        have = set()
        for x in _all_rules(net, ids[dst]):
            rng = getattr(getattr(x, "tcp_options", None), "destination_port_range", None)
            if getattr(x, "direction", None) == "INGRESS" and rng is not None and rng.min == rng.max:
                have.add((x.source, rng.min))
        missing = [r for r in rules if (ids[r.src_nsg], r.port) not in have]
        for i in range(0, len(missing), MAX_RULES_PER_CALL):
            batch = missing[i:i + MAX_RULES_PER_CALL]
            net.add_network_security_group_security_rules(ids[dst], m.AddNetworkSecurityGroupSecurityRulesDetails(
                security_rules=[rule_model(m, ids[r.src_nsg], r.port, f"ocio: {r.src_nsg} -> {r.dst_nsg} tcp/{r.port}")
                                for r in batch]))
            if journal is not None:
                journal.append(event="nsg_rules_added", nsg=dst, rules=[[r.src_nsg, r.port] for r in batch])
    return ids

