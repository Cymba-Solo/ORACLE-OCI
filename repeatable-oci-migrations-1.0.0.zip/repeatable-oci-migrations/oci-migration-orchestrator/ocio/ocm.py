"""Drive Oracle Cloud Migrations (OCM) from the blueprint factory: the migration path.

In OCM, a migration plan holds one target asset per source VM. OCM replicates the source VM's disks and,
when the plan is executed, launches each target instance FROM THE REPLICATED BOOT VOLUME. The target's
shape, OCPUs, memory, subnet, availability domain, fault domain and tags are the target asset's
`user_spec` (oci.cloud_migrations.models.LaunchInstanceDetails), and OCM also keeps its own
`recommended_spec`. This module turns each blueprint placement into that user_spec, so:

  * the cookie cutter (blueprints, overrides, refusals, deviation report) decides the target settings;
  * OCM keeps doing what it does: replication, launching from the replicated volumes, cutover;
  * waves are applied by marking out-of-wave target assets is_excluded_from_execution=True (first), then
    including the wave's assets, then re-reading the plan to verify both.

What this module does NOT do: move data, launch instances, or execute the plan. Executing the migration
plan stays an OCM action (console, CLI or API) that the operator takes after reviewing the updated plan.

Verified offline against oci SDK 2.189.0 models (UpdateVmTargetAssetDetails, LaunchInstanceDetails,
LaunchInstanceShapeConfigDetails, CreateVnicDetails; MigrationClient.update_target_asset /
list_target_assets). NOT run against OCM. Matching target assets to source VMs uses the target asset's
migration_asset.display_name; whether that always equals the source VM name must be confirmed on a real
plan, so an explicit mapping file can be given instead, and any ambiguity is refused.
"""
from __future__ import annotations

import os

from . import factory as F


def _flex(shape):
    return isinstance(shape, str) and ".Flex" in shape


def user_spec(m, placement, subnet_ids, compartment_id, availability_domain, fault_domain=None, tags=None,
              capacity_reservation_id=None, defined_tags=None, nsg_ids=None):
    """oci.cloud_migrations.models.LaunchInstanceDetails for one placement. No source_details: OCM
    launches from the replicated boot volume, never from a stock image."""
    p = placement.params
    sub_key = p.get("subnet") or F.TIER_SUBNETS[placement.workload.tier]
    if sub_key not in subnet_ids:
        raise F.FactoryError(f"{placement.workload.name}: no subnet id for {sub_key}")
    return m.LaunchInstanceDetails(
        availability_domain=availability_domain, compartment_id=compartment_id, fault_domain=fault_domain,
        display_name=placement.workload.name, shape=p["shape"], capacity_reservation_id=capacity_reservation_id,
        defined_tags=defined_tags or None,
        shape_config=m.LaunchInstanceShapeConfigDetails(ocpus=p["ocpus"], memory_in_gbs=p["memory_gbs"],
                                                        baseline_ocpu_utilization=p.get("baseline_ocpu_utilization"))
        if _flex(p["shape"]) else None,
        create_vnic_details=m.CreateVnicDetails(subnet_id=subnet_ids[sub_key], nsg_ids=nsg_ids or None,
                                                assign_public_ip=bool(p.get("assign_public_ip"))),
        freeform_tags=dict(tags or {}, ocio_blueprint=placement.blueprint.id()))


def merge_spec(base, ours):
    """ours laid over a copy of base (the asset's current user_spec, else OCM's recommended_spec).

    ocio owns: availability_domain, compartment_id, fault_domain, display_name, shape, shape_config,
    capacity_reservation_id, defined_tags; on the VNIC: subnet_id, nsg_ids, assign_public_ip. Freeform tags
    are merged (ours win on the same key). EVERYTHING ELSE in base is kept as it is: source_details (the
    replicated boot volume), private_ip (keeping a VM's address is a common migration requirement),
    hostname_label, skip_source_dest_check, agent_config, instance_options, in-transit encryption,
    dedicated host, preemptible config, ipxe script. Sending a fresh spec would silently drop all of those
    from the migration plan. Without a base, ours is sent as it is."""
    import copy
    if base is None:
        return ours
    u = copy.deepcopy(base)
    for k in ("availability_domain", "compartment_id", "fault_domain", "display_name", "shape", "shape_config",
              "capacity_reservation_id", "defined_tags"):
        setattr(u, k, getattr(ours, k))
    u.freeform_tags = dict(getattr(base, "freeform_tags", None) or {}, **(ours.freeform_tags or {}))
    v, w = copy.deepcopy(getattr(base, "create_vnic_details", None)), ours.create_vnic_details
    if v is None:
        v = w
    else:
        # Two kept fields cannot survive a subnet change (CreateVnicDetails docs, oci 2.189.0): private_ip "must be
        # an available IP address within the subnet's CIDR", and a request with both vlan_id and subnet_id fails.
        # Dropping a pinned IP would silently change an address people may depend on, so refuse and say what to fix.
        if getattr(v, "vlan_id", None):
            raise ValueError(f"the asset's spec places its VNIC on VLAN {v.vlan_id}; this wave sets subnet "
                             f"{w.subnet_id}, and OCI refuses both together. Remove the VLAN in OCM, or keep this VM "
                             f"out of the wave")
        if getattr(v, "private_ip", None) and v.subnet_id and v.subnet_id != w.subnet_id:
            raise ValueError(f"the asset's spec pins private_ip {v.private_ip} in subnet {v.subnet_id}; this wave "
                             f"moves it to subnet {w.subnet_id}, where that address may not exist. Clear or change "
                             f"the IP in OCM, or map this tier to a subnet that contains it")
        v.subnet_id, v.nsg_ids, v.assign_public_ip = w.subnet_id, w.nsg_ids, w.assign_public_ip
    u.create_vnic_details = v
    return u


def from_dict(cls, data, models):
    """Rebuild an SDK model from oci.util.to_dict output (as journalled), including nested models, lists of
    models and polymorphic types (e.g. source_details -> InstanceSourceViaBootVolumeDetails, chosen by the
    model's own get_subtype). An unknown field is refused rather than dropped."""
    if data is None:
        return None
    if hasattr(cls, "get_subtype"):
        wire = {cls().attribute_map.get(k, k): v for k, v in data.items()}
        sub = cls.get_subtype(wire)
        if sub != cls.__name__:
            if not hasattr(models, sub):
                raise ValueError(f"unknown model subtype {sub}")
            return from_dict(getattr(models, sub), data, models)
    obj = cls()
    for k, v in data.items():
        t = obj.swagger_types.get(k)
        if t is None:
            raise ValueError(f"unknown field {k!r} for {cls.__name__}")
        if isinstance(v, dict) and hasattr(models, t):
            v = from_dict(getattr(models, t), v, models)
        elif isinstance(v, list) and t.startswith("list[") and hasattr(models, t[5:-1]):
            v = [from_dict(getattr(models, t[5:-1]), x, models) for x in v]
        setattr(obj, k, v)
    return obj


def target_asset_update(m, placement, subnet_ids, compartment_id, availability_domain, excluded=False,
                        fault_domain=None, tags=None, capacity_reservation_id=None, defined_tags=None, nsg_ids=None,
                        base=None):
    """base: the asset's current user_spec (or recommended_spec) to keep fields ocio does not own; see
    merge_spec. The dry run has no base and shows ocio's fields only."""
    return m.UpdateVmTargetAssetDetails(
        is_excluded_from_execution=excluded,
        user_spec=merge_spec(base, user_spec(m, placement, subnet_ids, compartment_id, availability_domain,
                                             fault_domain, tags, capacity_reservation_id, defined_tags, nsg_ids)))


def match_target_assets(summaries, vm_names, mapping=None):
    """{vm: target_asset_id}. mapping (vm -> target asset OCID) wins; otherwise match on
    migration_asset.display_name. Unmatched or ambiguous VMs raise, naming them."""
    mapping = dict(mapping or {})
    by_name = {}
    for s in summaries:
        name = getattr(getattr(s, "migration_asset", None), "display_name", None)
        by_name.setdefault(name, []).append(s.id)
    out, problems = {}, []
    for vm in vm_names:
        if vm in mapping:
            out[vm] = mapping[vm]
        elif len(by_name.get(vm, [])) == 1:
            out[vm] = by_name[vm][0]
        elif len(by_name.get(vm, [])) > 1:
            problems.append(f"{vm}: {len(by_name[vm])} target assets share this source name; use a mapping file")
        else:
            problems.append(f"{vm}: no target asset in the plan for this source VM")
    shared = {}
    for vm, tid in out.items():
        shared.setdefault(tid, []).append(vm)
    problems += [f"{sorted(vms)} would all be written to the same target asset {tid}; each VM needs its own"
                 for tid, vms in sorted(shared.items()) if len(vms) > 1]
    if problems:
        raise ValueError("cannot match target assets: " + "; ".join(problems))
    return out


def sizing_differences(assets, placements):
    """Where the blueprint's size differs from OCM's own recommended_spec, for review (not an error).
    assets: full target assets (VmTargetAsset from get_target_asset); summaries do not carry the spec."""
    rec = {}
    for s in assets:
        name = getattr(getattr(s, "migration_asset", None), "display_name", None)
        spec = getattr(s, "recommended_spec", None)
        cfg = getattr(spec, "shape_config", None)
        if name and spec is not None:
            rec[name] = (getattr(spec, "shape", None), getattr(cfg, "ocpus", None), getattr(cfg, "memory_in_gbs", None))
    out = []
    for p in placements:
        r = rec.get(p.workload.name)
        mine = (p.params["shape"], p.params["ocpus"], p.params["memory_gbs"])
        if r and tuple(x for x in r) != mine:
            out.append({"vm": p.workload.name, "blueprint": mine, "ocm_recommended": r})
    return out


class OCMError(Exception):
    """An OCM call or check failed. The message says what failed, keeps Oracle's code, message and opc-request-id
    when there is one, and says whether the migration plan may be part-way updated (then: do not execute it).
    """
    pass


def _spec_matches(got, want):
    if got is None:
        return False
    g, w = getattr(got, "shape_config", None), want.shape_config
    vnic = getattr(got, "create_vnic_details", None)
    return (getattr(got, "shape", None) == want.shape
            and getattr(got, "availability_domain", None) == want.availability_domain
            and getattr(vnic, "subnet_id", None) == want.create_vnic_details.subnet_id
            and bool(getattr(vnic, "assign_public_ip", None)) == bool(want.create_vnic_details.assign_public_ip)
            and (w is None or (getattr(g, "ocpus", None) == w.ocpus and getattr(g, "memory_in_gbs", None) == w.memory_in_gbs)))


def _retryable(e):
    status = getattr(e, "status", None)
    if status is not None:
        return status in (409, 429) or (isinstance(status, int) and status >= 500)
    return type(e).__name__ in ("RequestException", "ConnectTimeout", "ConnectionError", "Timeout", "ReadTimeout")


# Target-asset lifecycle states in which the asset must not be included in a wave (cloud_migrations
# TargetAsset.LIFECYCLE_STATE_*, oci 2.189.0). NEEDS_ATTENTION is OCM's way of saying a person must look first.
ASSET_NOT_READY = ("FAILED", "NEEDS_ATTENTION", "DELETED", "DELETING")
# Work-request statuses (cloud_migrations WorkRequest.STATUS_*). The OCI CLI's `target-asset update
# --wait-for-state` waits on exactly these, which is how the update is known to be asynchronous.
WR_OK, WR_BAD = "SUCCEEDED", ("FAILED", "CANCELED", "NEEDS_ATTENTION")


def _headers(resp):
    return getattr(resp, "headers", None) or {}


def retry_token(plan_id, asset_id, details, etag):
    """opc-retry-token for one target-asset update: the SAME token for a re-send of the same change to the
    same version of the asset (so a lost response cannot apply it twice), a NEW token as soon as the
    asset's etag or the change differs (so a deliberate re-run is never answered from the 24 h token cache
    with a stale result). 64 hex characters, the documented maximum length."""
    import hashlib
    import json
    try:
        import oci
        body = oci.util.to_dict(details)
    except Exception:                             # noqa: BLE001 - non-SDK stand-ins in tests
        body = repr(details)
    raw = json.dumps([plan_id, asset_id, body, etag], sort_keys=True, default=str)
    return hashlib.sha256(raw.encode()).hexdigest()


class OCMDriver:
    """Applies one wave to an OCM migration plan. Order matters, because executing the plan launches every
    included asset:

      0 READ every in-wave target asset and BUILD its user_spec: ocio's fields laid over the asset's current
        user_spec (else OCM's recommended_spec), so fields ocio does not own, such as the replicated boot
        volume source or a kept private IP, survive (merge_spec). A bad input, or an asset OCM marks
        FAILED / NEEDS_ATTENTION / DELETED, stops the wave here, before anything is changed.
        The before-state of every asset that will be touched goes to `on_before` (the CLI journals it), so
        the plan's prior settings are on record before the first change.
      1 EXCLUDE every out-of-wave target asset first. Nothing outside the wave is ever newly included. If a
        call fails part-way, out-of-wave assets that were ALREADY included may still be, so the command stops,
        says not to execute the plan, and exits 1; re-running ocm-wave finishes the job.
      2 Update each in-wave target asset with the blueprint user_spec and include it.
      3 Re-read the plan and check that the included set is exactly the wave. Any difference is an error.

    Every update (steps 1 and 2) is:
      * CONDITIONAL: sent with If-Match = the etag of the GET just before it, so a change someone made in
        the console in between is not silently overwritten (HTTP 412 -> stop, re-run re-reads);
      * IDEMPOTENT: sent with an opc-retry-token derived from (plan, asset, change, etag), so a re-send after
        a timeout or lost response cannot apply it twice;
      * WAITED ON: OCM applies target-asset updates through a work request. When the response carries
        opc-work-request-id, the driver polls it; FAILED / CANCELED / NEEDS_ATTENTION stops the wave with
        Oracle's own error messages (list_work_request_errors). Step 3 still re-reads the plan regardless.

    Each call is retried on 409/429/5xx and transport errors, bounded. Model and method names checked
    against oci 2.189.0; NOT run against OCM: whether GET returns an etag and update returns a work-request
    id must be confirmed on a real plan. Both are used when present, and step 3 does not depend on them."""

    def __init__(self, client, migration_plan_id, models=None, attempts=5, sleep=None, clock=None,
                 work_request_timeout=1200.0):
        if models is None:
            import oci
            models = oci.cloud_migrations.models
        import time
        self.c, self.plan, self.m = client, migration_plan_id, models
        self.attempts, self.sleep = attempts, sleep or time.sleep
        self.clock = clock or time.monotonic
        self.wr_timeout = work_request_timeout       # the OCI CLI's own default --max-wait-seconds is 1200
        self.work_requests = []

    def _call(self, what, fn, *a, **kw):
        for i in range(1, self.attempts + 1):
            try:
                return fn(*a, **kw)
            except Exception as e:                 # noqa: BLE001 - classified below
                rid = getattr(e, "request_id", None)
                tail = f" (opc-request-id {rid})" if rid else ""
                if getattr(e, "status", None) == 412:
                    raise OCMError(f"{what}: the target asset was changed by someone else since it was read "
                                   f"(HTTP 412, If-Match){tail}. Nothing was overwritten. The plan may be part-way "
                                   f"updated: do not execute it; check who changed it, then re-run ocm-wave") from e
                if i == self.attempts or not _retryable(e):
                    from .errors import describe
                    text = describe(e) if hasattr(e, "code") and hasattr(e, "status") else f"{e!r}{tail}"
                    raise OCMError(f"{what}: {text} after {i} attempt(s). The plan may be part-way updated: do not "
                                   f"execute it; fix the cause and re-run ocm-wave") from e
                self.sleep(min(30.0, 2.0 ** (i - 1)))

    def _pages(self, what, fn, **kw):
        """All items of a paged list call. A page token the service has already returned would loop forever,
        so it is refused."""
        items, page, seen = [], None, set()
        while True:
            if page:
                kw["page"] = page
            resp = self._call(what, fn, **kw)
            data = resp.data
            items.extend(getattr(data, "items", data) or [])
            page = getattr(resp, "next_page", None) or _headers(resp).get("opc-next-page")
            if not page:
                return items
            if page in seen:
                raise OCMError(f"{what}: the service repeated page token {page!r}; stopping instead of looping")
            seen.add(page)

    def summaries(self):
        """Every target asset summary of the migration plan, all pages (repeated page tokens refused, see _pages).
        Each call is retried like any other (_call); an OCMError if it still fails.
        """
        return self._pages("list target assets", self.c.list_target_assets, migration_plan_id=self.plan)

    def _wait(self, what, resp):
        wid = _headers(resp).get("opc-work-request-id")
        if not wid:
            return None
        self.work_requests.append(wid)
        deadline, delay = self.clock() + self.wr_timeout, 1.0
        while True:
            status = getattr(self._call(f"work request {wid}", self.c.get_work_request, wid).data, "status", None)
            if status == WR_OK:
                return wid
            if status in WR_BAD:
                errs = self._pages(f"work request {wid} errors", self.c.list_work_request_errors, work_request_id=wid)
                why = "; ".join(f"{getattr(x, 'code', '')}: {getattr(x, 'message', x)}" for x in errs) or "no detail"
                raise OCMError(f"{what}: work request {wid} {status}: {why}. The plan may be part-way updated: do not "
                               f"execute it; fix the cause and re-run ocm-wave")
            if self.clock() > deadline:
                raise OCMError(f"{what}: work request {wid} still {status} after {self.wr_timeout:.0f} s. Do not execute "
                               f"the plan; check the work request in the console, then re-run ocm-wave")
            self.sleep(delay)
            delay = min(30.0, delay * 2)

    def _get(self, tid):
        return self._call(f"get {tid}", self.c.get_target_asset, tid)

    def _update(self, what, tid, details):
        """GET (for the etag) -> conditional, idempotent update -> wait for its work request.

        With an etag, the token is derived from it (retry_token). Without one, the asset's version is unknown, so
        a derived token would be the same for a deliberate re-apply after a restore, and a service honouring the
        24 h token cache would answer it from cache with nothing changed. Then the token carries a fresh nonce
        per call: resends inside this call (_call's retries) reuse it; a later call sends a new one. Sending a
        target-asset update twice sets the same fields twice, so a new token never duplicates anything."""
        etag = _headers(self._get(tid)).get("etag")
        kw = {"opc_retry_token": retry_token(self.plan, tid, details, etag or f"no-etag/{os.urandom(16).hex()}")}
        if etag:
            kw["if_match"] = etag
        return self._wait(what, self._call(what, self.c.update_target_asset, tid, details, **kw))

    def restore(self, snapshot):
        """Put target assets back to a journalled before-state ({asset id: {"is_excluded_from_execution",
        "user_spec"}}, as apply_wave's on_before produced it). Same safety order as apply_wave: assets to be
        EXCLUDED are restored first, then those to be included. Each update is conditional, idempotent and
        waited on (_update). An asset whose user_spec was empty before keeps its current one: the API has no
        way to clear it, and that is reported, not hidden. Returns what was restored and any differences
        found when the plan is read back."""
        order = sorted(snapshot.items(), key=lambda kv: (not kv[1]["is_excluded_from_execution"], kv[0]))
        restored, kept_spec = [], []
        for tid, st in order:
            spec = from_dict(self.m.LaunchInstanceDetails, st.get("user_spec"), self.m)
            if spec is None and st.get("user_spec") is None:
                kept_spec.append(tid)
            self._update(f"restore {tid}", tid, self.m.UpdateVmTargetAssetDetails(
                is_excluded_from_execution=st["is_excluded_from_execution"], user_spec=spec))
            restored.append(tid)
        import oci
        diffs = []
        for tid, st in snapshot.items():
            now = self._get(tid).data
            if bool(getattr(now, "is_excluded_from_execution", False)) != st["is_excluded_from_execution"]:
                diffs.append(f"{tid}: is_excluded_from_execution is {now.is_excluded_from_execution}")
            if st.get("user_spec") is not None and oci.util.to_dict(getattr(now, "user_spec", None)) != st["user_spec"]:
                diffs.append(f"{tid}: user_spec differs from the journalled one after restore")
        if diffs:
            raise OCMError(f"restore sent, but the plan does not read back as before: {diffs}. Do not execute it")
        return {"restored": restored, "user_spec_was_empty_kept_current": kept_spec, "work_requests": list(self.work_requests)}

    def not_migrated(self, vm_names, mapping=None):
        """VMs (of earlier waves this wave depends on) whose target asset in this plan shows no
        created_resource_id, i.e. no target instance yet; VMs with no target asset here are listed too.
        Reading created_resource_id as "migrated" follows the SDK's description ("Created resource
        identifier"); confirm it on a real plan."""
        mapping = dict(mapping or {})
        sums = self.summaries()
        by_id = {x.id: x for x in sums}
        by_name = {}
        for x in sums:
            by_name.setdefault(getattr(getattr(x, "migration_asset", None), "display_name", None), []).append(x)
        out = []
        for vm in vm_names:
            x = by_id.get(mapping[vm]) if vm in mapping else (by_name.get(vm, [None])[0] if len(by_name.get(vm, [])) == 1 else None)
            if x is None or not getattr(x, "created_resource_id", None):
                out.append(vm)
        return out

    def apply_wave(self, wave_placements, subnet_ids, compartment_id, availability_domain, mapping=None,
                   tags=None, fault_domains=None, capacity_reservation_id=None, defined_tags=None, nsg_map=None,
                   on_before=None):
        """fault_domains: {vm: FD}; None spreads each app tier over the three fault domains (F.fault_domains),
        {} leaves the choice to OCI. on_before(snapshot) is called once, before the first change, with
        {target asset id: {"is_excluded_from_execution": bool, "user_spec": dict | None}} for every asset
        this call may change."""
        import oci
        if fault_domains is None:
            fault_domains = F.fault_domains(wave_placements)
        sums = self.summaries()
        known = {x.id for x in sums}
        bad = sorted(v for v in (mapping or {}).values() if v not in known)
        if bad:
            raise OCMError(f"mapping names target assets that are not in migration plan {self.plan}: {bad}")
        names = [p.workload.name for p in wave_placements]
        ids = match_target_assets(sums, names, mapping)
        in_wave = set(ids.values())
        # 0 read and build everything first: a bad input or an asset in a bad state changes nothing
        before = [self._get(tid).data for tid in sorted(in_wave)]
        cur = {x.id: (getattr(x, "user_spec", None) or getattr(x, "recommended_spec", None)) for x in before}
        try:
            specs = {p.workload.name: target_asset_update(self.m, p, subnet_ids, compartment_id, availability_domain,
                                                          False, fault_domains.get(p.workload.name), tags,
                                                          capacity_reservation_id, defined_tags,
                                                          [nsg_map[k]] if (k := f"{p.workload.app}-{p.workload.tier}")
                                                          in (nsg_map or {}) else None,
                                                          base=cur.get(ids[p.workload.name]))
                     for p in wave_placements}
        except ValueError as e:                      # a spec that cannot be applied: refuse before any change
            raise OCMError(f"{e}; nothing was changed") from None
        not_ready = sorted(f"{x.id}: {x.lifecycle_state}" for x in before
                           if getattr(x, "lifecycle_state", None) in ASSET_NOT_READY)
        if not_ready:
            raise OCMError(f"target assets OCM marks as not ready: {not_ready}. Resolve them in OCM (a "
                           f"NEEDS_ATTENTION asset needs a person to look) and re-run; nothing was changed")
        to_exclude = [x for x in sums if x.id not in in_wave and not getattr(x, "is_excluded_from_execution", False)]
        if on_before is not None:
            # Every asset this call changes is read in full: a summary carries no user_spec, and a before-state
            # that recorded None for an asset that had a spec would make restore keep the wrong one (and say so).
            snap = {}
            for x in [self._get(y.id).data for y in to_exclude] + before:
                us = getattr(x, "user_spec", None)
                snap[x.id] = {"is_excluded_from_execution": bool(getattr(x, "is_excluded_from_execution", False)),
                              "user_spec": oci.util.to_dict(us) if us is not None else None}
            on_before(snap)
        excluded = []
        for x in to_exclude:                                # 1 exclude first
            self._update(f"exclude {x.id}", x.id, self.m.UpdateVmTargetAssetDetails(is_excluded_from_execution=True))
            excluded.append(x.id)
        updated = []
        for p in wave_placements:                           # 2 then include the wave
            self._update(f"update {ids[p.workload.name]}", ids[p.workload.name], specs[p.workload.name])
            updated.append(p.workload.name)
        # 3 verify. update_target_asset returns no body, so re-read until the plan shows the change.
        for i in range(self.attempts):
            after = self.summaries()
            included = {x.id for x in after if not getattr(x, "is_excluded_from_execution", False)}
            full = {tid: self._get(tid).data for tid in sorted(in_wave)}
            wrong = sorted(f"{name}: user_spec shape/size not applied" for name, tid in ids.items()
                           if not _spec_matches(getattr(full[tid], "user_spec", None), specs[name].user_spec))
            if included == in_wave and not wrong:
                break
            if i < self.attempts - 1:
                self.sleep(min(30.0, 2.0 ** i))
        else:
            raise OCMError(f"after the update, the plan includes {sorted(included)} (wave: {sorted(in_wave)}); "
                           f"{wrong}. Do not execute the plan")
        return {"updated": updated, "excluded": excluded, "verified_included": sorted(included),
                "work_requests": list(self.work_requests),
                "sizing_differences": sizing_differences(before, wave_placements)}
