"""Resolve symbolic blueprint images (IMAGE_OL8, ...) to a region's platform image OCIDs.

Platform image OCIDs differ per region and are refreshed regularly, so a hand-kept image map goes stale.
resolve() asks the region: ComputeClient.list_images(compartment_id, operating_system,
operating_system_version, shape, lifecycle_state="AVAILABLE", sort_by="TIMECREATED", sort_order="DESC"),
skips the compartment's own custom images (the listing returns platform AND custom images "in the specified
compartment", so a result whose compartment_id is the queried compartment is custom) and community listings,
then confirms each candidate with get_image_shape_compatibility_entry(image_id, shape) (404 = not
compatible) and takes the newest compatible one. Parameter names checked against oci 2.189.0; the
operating_system / operating_system_version strings come from the caller's spec file (the SDK's own
examples are "Oracle Linux" and "7.2"), because they must match the region's catalog exactly.
The resolved OCIDs become part of the plan id, so an approval covers the exact images.
"""
from __future__ import annotations


def resolve(compute, compartment_id, spec, shape):
    """spec: {symbol: {"operating_system": ..., "operating_system_version": ...}} -> {symbol: image OCID}."""
    import oci
    out = {}
    for symbol, want in sorted(spec.items()):
        images = oci.pagination.list_call_get_all_results(
            compute.list_images, compartment_id, operating_system=want["operating_system"],
            operating_system_version=want["operating_system_version"], shape=shape, lifecycle_state="AVAILABLE",
            sort_by="TIMECREATED", sort_order="DESC").data
        for img in images:
            # list_images(compartment) returns platform images AND the compartment's own custom images (SDK docs);
            # so a result whose compartment_id IS the queried compartment is a custom image, never a platform one.
            # Community listings are third-party images. Neither is what "the region's platform image" means.
            if getattr(img, "compartment_id", None) == compartment_id or getattr(img, "listing_type", None) == "COMMUNITY":
                continue
            try:
                compute.get_image_shape_compatibility_entry(img.id, shape)
            except oci.exceptions.ServiceError as e:
                if e.status == 404:
                    continue
                raise
            out[symbol] = img.id
            break
        else:
            raise ValueError(f"{symbol}: no AVAILABLE image for {want} compatible with {shape} in this region")
    return out

