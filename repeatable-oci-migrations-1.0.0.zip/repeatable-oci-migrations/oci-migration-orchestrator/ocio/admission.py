"""Admission: fresh, named, plan- and wave-bound readiness evidence before a wave may change anything.

WHY. Approval answers "may this change happen?". Admission answers "is the estate ready for it RIGHT NOW?":
capacity confirmed, the application healthy, the rollback rehearsed, and so on. Those facts go stale in
minutes and belong to one plan and one wave, so evidence is accepted only if it:

  * names THIS plan id and THIS wave number (evidence for another plan or wave cannot be reused);
  * was observed within the policy's max_age_seconds, and not in the future (beyond a small clock skew);
  * has exactly one row per required check, each passed is literally true, and each names who observed it
    (observer) and where the proof lives (source_ref: a ticket, a dashboard URL, a runbook record);
  * records no other check as failed (a row the policy does not require still counts if it says "not passed").

Exactly one evidence document per (plan, wave) is accepted; two are refused as conflicting rather than
picking one. Every decision, allowed or not, is journalled with the SHA-256 of the evidence document.

WHAT IT IS NOT. The evidence is supplied by the operator; this module checks its shape, binding and age.
It does not authenticate who wrote it, and a hash is integrity, not a signature. It is a gate that makes
the readiness claim explicit, specific and auditable, not proof that the claim is true.

Policy file: {"required_checks": ["capacity", ...], "max_age_seconds": 900}. The policy is part of the
plan id, so the gate a reviewer saw is the gate that runs. Merged from the annotated package's admission
module; this version adds ISO 8601 timestamps (timezone required), a bounded clock-skew allowance and
per-wave journalling inside the existing pipeline.
"""
from __future__ import annotations

import hashlib
import json
import math
from datetime import datetime

CLOCK_SKEW_SECONDS = 60


def check_policy(policy):
    """Validate a policy document; ValueError naming the problem."""
    if not isinstance(policy, dict):
        raise ValueError("admission policy must be a JSON object")
    req, age = policy.get("required_checks"), policy.get("max_age_seconds")
    if (not isinstance(req, list) or not req or any(not isinstance(x, str) or not x.strip() for x in req)
            or len(set(req)) != len(req)):
        raise ValueError("admission policy needs required_checks: a non-empty list of unique check names")
    spaced = [x for x in req if x != x.strip()]
    if spaced:                                   # "capacity " would never match an evidence row named capacity
        raise ValueError(f"admission policy check names have surrounding spaces: {spaced}; remove them")
    if isinstance(age, bool) or not isinstance(age, (int, float)) or not math.isfinite(age) or age <= 0:
        raise ValueError("admission policy needs max_age_seconds: a positive number")
    return policy


def _epoch(value):
    """Seconds since the epoch from a number or an ISO 8601 string WITH a timezone; None if neither."""
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value) if math.isfinite(value) else None
    if isinstance(value, str):
        try:
            t = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
        return t.timestamp() if t.tzinfo is not None else None      # naive time: which timezone? refuse
    return None


def digest(doc):
    """SHA-256 (hex) of a JSON document in canonical form (sorted keys, no whitespace), journalled with each
    admission decision so the exact evidence judged can be matched later. Integrity, not a signature."""
    return hashlib.sha256(json.dumps(doc, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def evaluate(plan_id, wave, documents, policy, now):
    """{"allowed": bool, "reasons": [...], "evidence_hash": str | None, "plan_id", "wave"} for one wave.
    documents: every evidence document supplied (any plan, any wave); only those naming this plan and wave
    are considered."""
    check_policy(policy)
    docs = [d for d in (documents or []) if isinstance(d, dict)]
    # The wave must be the integer itself: in Python True == 1 == 1.0, so JSON true or 1.0 would bind to wave 1.
    mine = [d for d in docs if d.get("plan_id") == plan_id and type(d.get("wave")) is int and d.get("wave") == wave]
    out = {"plan_id": plan_id, "wave": wave, "required": list(policy["required_checks"]), "evidence_hash": None}
    if len(mine) > 1:
        return dict(out, allowed=False, reasons=[f"more than one evidence document for plan {plan_id} wave {wave}; "
                                                  f"supply exactly one"])
    if not mine:
        other = sorted({(d.get("plan_id"), d.get("wave")) for d in docs}, key=str)
        return dict(out, allowed=False, reasons=[f"no evidence bound to plan {plan_id} wave {wave} (evidence is "
                                                  f"not bound to it; documents given are for {other})"])
    doc, reasons = mine[0], []
    at = _epoch(doc.get("observed_at"))
    if at is None:
        reasons.append("observed_at missing or not a time (epoch seconds, or ISO 8601 with a timezone)")
    elif at > now + CLOCK_SKEW_SECONDS:
        reasons.append(f"observed_at is in the future by {at - now:.0f} s; check the clocks")
    elif now - at > policy["max_age_seconds"]:
        reasons.append(f"evidence is stale: observed {now - at:.0f} s ago, policy allows "
                       f"{policy['max_age_seconds']} s; observe again")
    rows = doc.get("checks") if isinstance(doc.get("checks"), list) else []
    named = {}
    for r in rows:
        if isinstance(r, dict) and isinstance(r.get("name"), str):
            named.setdefault(r["name"], []).append(r)
        else:
            reasons.append("malformed check row (needs a name)")
    for name in policy["required_checks"]:
        got = named.get(name, [])
        if len(got) != 1:
            reasons.append(f"missing or conflicting check: {name} ({len(got)} rows)")
            continue
        r = got[0]
        if r.get("passed") is not True:
            reasons.append(f"check did not pass: {name} (passed must be true, got {r.get('passed')!r})")
        for k in ("observer", "source_ref"):
            if not isinstance(r.get(k), str) or not r[k].strip():
                reasons.append(f"check {name} has no {k}: say who observed it and where the proof is")
    # The evidence itself says something failed (a rollback rehearsal, say) that the policy does not require:
    # admitting the wave would ignore what the operator recorded, so it is refused too.
    for name in sorted(set(named) - set(policy["required_checks"])):
        if any(r.get("passed") is not True for r in named[name]):
            reasons.append(f"the evidence records check {name} as not passed; resolve it or remove the row")
    return dict(out, allowed=not reasons, reasons=reasons, evidence_hash=digest(doc))
