"""What to do about the OCI service errors an operator actually meets.

Codes, statuses and retry guidance from Oracle's "API Errors" reference
(docs.oracle.com/en-us/iaas/Content/API/References/apierrors.htm, read 2026-10-21):

  400 LimitExceeded            exceeds the ORACLE-defined limit for the tenancy        do not retry
  400 QuotaExceeded            exceeds an ADMINISTRATOR-defined compartment quota       do not retry
  401 NotAuthenticated         authentication missing or incorrect                      do not retry
  404 NotAuthorizedOrNotFound  not found, OR not authorized: OCI deliberately does not  do not retry
                               say which, so a missing IAM policy looks like a bad OCID
  409 IncorrectState           will be right "given some amount of time"                retry with backoff
  412 NoEtagMatch              If-Match etag differs                                     do not retry
  429 TooManyRequests                                                                   retry with backoff
  500 InternalServerError                                                               retry with backoff

hint() returns one actionable sentence for the do-not-retry codes; retryable ones are handled by the
callers' backoff and need no hint. Policy resource types: instance-family and virtual-network-family are
the Core Services families; ocm-migration-family is from Oracle's "Oracle Cloud Migrations User Policies"
page (read 2026-10-21). The family needed depends on the call.
"""

HINTS = {
    (400, "LimitExceeded"): "this is the tenancy's Oracle service limit, not a compartment quota: request a limit "
                            "increase (Console: Governance > Limits, Quotas and Usage) or use another shape or AD",
    (400, "QuotaExceeded"): "a compartment quota set by your administrators blocks this: ask them to raise the "
                            "quota policy, or use another compartment",
    (401, "NotAuthenticated"): "check the API key, fingerprint, user and tenancy OCIDs in the profile, or renew "
                               "the session token (--auth security_token)",
    (404, "NotAuthorizedOrNotFound"): "either an OCID in the request is wrong or the caller lacks an IAM policy; "
                                      "OCI does not say which. Check the OCIDs, then the policy, e.g. 'Allow group "
                                      "<group> to manage instance-family in compartment <name>' (virtual-network-"
                                      "family for networks; ocm-migration-family for Oracle Cloud Migrations)",
}


def hint(status, code):
    """One sentence on what to do, or None when there is nothing better than the message itself."""
    return HINTS.get((status, code))


def describe(e):
    """'<status> <code>: <message> (opc-request-id ...). What to do: ...' for an oci ServiceError."""
    status, code = getattr(e, "status", None), getattr(e, "code", None)
    msg = f"{status} {code}: {getattr(e, 'message', e)} (opc-request-id {getattr(e, 'request_id', None)})"
    h = hint(status, code)
    return f"{msg}. What to do: {h}" if h else msg
