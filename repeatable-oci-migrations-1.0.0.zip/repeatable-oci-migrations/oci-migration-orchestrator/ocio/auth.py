"""How the tools authenticate to OCI. Returns (config, signer) for any oci.*Client(config, signer=...).

  api_key             ~/.oci/config profile with a user API key (the default)
  security_token      a session from `oci session authenticate`: the profile's security_token_file plus
                      key_file (decrypted with the profile's pass_phrase, if any), signed with oci.auth.signers.SecurityTokenSigner(token, private_key)
  instance_principal  running on an OCI instance in a dynamic group:
                      oci.auth.signers.InstancePrincipalsSecurityTokenSigner(); no keys on disk
  resource_principal  running inside an OCI service that provides one (e.g. Functions):
                      oci.auth.signers.get_resource_principals_signer()

Signer class names and signatures checked against oci 2.189.0. For the principal modes, the region
and tenancy come from the signer, so no config file is needed. Not exercised against a tenancy.
"""
from __future__ import annotations

import os

MODES = ("api_key", "security_token", "instance_principal", "resource_principal")


def make(mode="api_key", profile="DEFAULT", config_file="~/.oci/config"):
    """(config, signer) for one of MODES; pass both to any oci client as Client(config, signer=signer).

    api_key: config read from config_file/profile, signer None (the SDK signs with the profile's key).
    security_token: same profile, plus a SecurityTokenSigner built from its security_token_file and key_file.
    instance_principal / resource_principal: a minimal config {"region", "tenancy"} taken from the signer
    (tenancy may be None for a resource principal whose signer does not expose it). Raises ValueError for an
    unknown mode; file, key and metadata-service errors from the SDK propagate unchanged. Imports oci lazily,
    so the rest of the package works without the SDK installed."""
    import oci
    if mode == "api_key":
        return oci.config.from_file(os.path.expanduser(config_file), profile), None
    if mode == "security_token":
        cfg = oci.config.from_file(os.path.expanduser(config_file), profile)
        with open(os.path.expanduser(cfg["security_token_file"])) as f:
            token = f.read().strip()
        key = oci.signer.load_private_key_from_file(os.path.expanduser(cfg["key_file"]),
                                                    pass_phrase=cfg.get("pass_phrase"))   # an encrypted key_file
        return cfg, oci.auth.signers.SecurityTokenSigner(token, key)
    if mode == "instance_principal":
        signer = oci.auth.signers.InstancePrincipalsSecurityTokenSigner()
        return {"region": signer.region, "tenancy": signer.tenancy_id}, signer
    if mode == "resource_principal":
        signer = oci.auth.signers.get_resource_principals_signer()
        return {"region": signer.region, "tenancy": getattr(signer, "tenancy_id", None)}, signer
    raise ValueError(f"unknown auth mode {mode!r}; use one of {MODES}")
