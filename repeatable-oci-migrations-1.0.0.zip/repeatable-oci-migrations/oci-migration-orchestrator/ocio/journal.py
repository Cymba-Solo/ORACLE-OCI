"""Append-only, hash-chained run journal (JSON Lines).

Every state change is written BEFORE the engine moves on, so a crashed run can be resumed: steps
journalled as created are not created again. The hash chain makes silent edits to the journal
detectable (verify()). It is tamper-EVIDENT, not tamper-proof: someone who can rewrite the whole
file can rewrite the chain; ship the head hash off-host if that matters.

Scale. A migration re-run opens the journal once per wave and asks it the same questions per step
(what exists, which runs are open, what happened to this step). Re-reading and re-scanning the whole
file for each of those was quadratic in the size of the estate. Instead, all handles on one file in a
process share one parsed state with indexes that are updated as entries arrive:

  * the shared state is reused only while the file is exactly as this process last saw it (same inode,
    size and modification time, which this process's own appends keep current). Any other change, an
    append by another process or an edit, forces a full reload, so tampering is still detected;
  * the indexes (per run, per run and step, runs started and ended, and what exists now) are kept
    incrementally, so views cost what they return, not the size of the journal.
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import os
import threading
from types import MappingProxyType

GENESIS = "0" * 64
_SHARED = {}                      # realpath -> _State
_SHARED_LOCK = threading.Lock()


def _h(prev, body):
    return hashlib.sha256((prev + json.dumps(body, sort_keys=True, separators=(",", ":"))).encode()).hexdigest()


def _stat(path):
    try:
        st = os.stat(path)
    except FileNotFoundError:
        return None
    return (st.st_ino, st.st_size, st.st_mtime_ns)


class _State:
    """Parsed entries of one journal file plus incremental indexes. Shared by every handle on the file."""

    def __init__(self, entries, numbers=None, stat=None):
        self.lock = threading.RLock()
        self.entries, self.stat = [], stat
        numbers = list(numbers) if numbers is not None else list(range(1, len(entries) + 2))
        self.line_of, self.next_line = numbers[:-1], numbers[-1]   # each entry's file line; the next append's
        self.by_run, self.by_run_step = {}, {}
        self.started, self.ended = [], {}           # run_started entries in order; run_id -> last end event
        self.live, self._pending = {}, {}           # what exists now (see existing_steps)
        self.view = MappingProxyType(self.live)
        for e in entries:
            self.add(e)

    def add(self, e):
        """Record one parsed entry and update every index from it.

        Indexes: by run, by (run, step), runs started, the last end event per run, and the live view of what
        exists: 'ready' makes a step exist (with the params hash journalled by its 'creating' entry);
        'rolled_back' or 'observed_gone' for the same resource id removes it; 'rollback_failed' keeps it but marks
        it uncertain. Called for every entry on load and for each new append, so views never rescan the file.
        """
        self.entries.append(e)
        rid, sid, ev = e.get("run_id"), e.get("step"), e.get("event")
        if rid is not None:
            self.by_run.setdefault(rid, []).append(e)
            if ev == "run_started":
                self.started.append(e)
            elif ev in ("run_succeeded", "run_failed", "run_torn_down"):
                self.ended[rid] = ev
        if sid is None:
            return
        self.by_run_step.setdefault((rid, sid), []).append(e)
        cur = self.live.get(sid)
        outputs = e.get("outputs") if isinstance(e.get("outputs"), dict) else {}
        same = cur is not None and cur["id"] == outputs.get("id")
        if ev == "creating":
            self._pending[(rid, sid)] = e.get("params_hash")
        elif ev == "ready":
            self.live[sid] = {"run_id": rid, "id": outputs.get("id"),
                              "params_hash": self._pending.get((rid, sid)), "uncertain": False}
        elif ev in ("rolled_back", "observed_gone") and same:
            del self.live[sid]
        elif ev == "rollback_failed" and same:
            self.live[sid] = dict(cur, uncertain=True)


class JournalError(Exception):
    """The journal cannot be used as it is: a line is not valid JSON (the message names the line and says what
    to do), or, as JournalBusy, another process holds it.
    """
    pass


class JournalBusy(JournalError):
    """Another ocio process holds the journal's lock (see exclusive()); the message names its pid."""
    pass


def _load(path):
    """Parsed entries. A line that is not JSON is refused with its number, never skipped: a line torn by a
    crash mid-write may record a request OCI had already accepted, so dropping it could lose an orphan."""
    entries, numbers = [], []
    if os.path.exists(path):
        with open(path) as f:
            lines = f.read().split("\n")
        last = max((i for i, x in enumerate(lines) if x.strip()), default=-1)
        for i, line in enumerate(lines):
            if not line.strip():
                continue
            try:
                e = json.loads(line)
            except ValueError:
                where = ("the LAST line, so most likely torn by a crash during a write" if i == last
                         else "a line in the middle, so the file was edited or damaged")
                raise JournalError(
                    f"{path} line {i + 1} is not valid JSON ({where}). It may record a request OCI accepted: "
                    f"read it, check OCI for what it names, then move the file aside and keep it; do not delete "
                    f"it or edit it in place") from None
            if not isinstance(e, dict):
                raise JournalError(
                    f"{path} line {i + 1} is valid JSON but not a journal entry (an object): the file was edited or "
                    f"damaged. Move it aside and keep it; do not delete it or edit it in place")
            entries.append(e)
            numbers.append(i + 1)                          # the entry's real line in the file (blank lines count)
        if lines and lines[-1] == "":
            lines.pop()                                    # the final newline does not start a line
        numbers.append(len(lines) + 1)                     # sentinel: the line the next append will occupy
    else:
        numbers.append(1)
    return entries, numbers


@contextlib.contextmanager
def exclusive(path):
    """Hold the journal for one process: an exclusive, non-blocking lock on '<journal>.lock'.

    Two orchestrators applying from one journal at once would each see the other's steps as missing and
    create them again. POSIX (Linux, macOS): flock, released by the kernel when the process exits, however it
    exits, so a crash never leaves a stale lock. Windows: msvcrt.locking on one byte far past the pid record (the
    region is locked, the pid stays readable), likewise released when the process exits. LIMIT: these are
    per-host locks; on a network file system shared between hosts they may not exclude a process on another
    host. Run one orchestrator per journal, on one host."""
    lock = path + ".lock"
    fd = os.open(lock, os.O_RDWR | os.O_CREAT, 0o600)
    try:
        release = _lock(fd)
        if release is None:
            os.lseek(fd, 0, os.SEEK_SET)
            holder = os.read(fd, 64).decode(errors="replace").strip() or "unknown"
            raise JournalBusy(f"journal {path} is in use by another ocio process (pid {holder}); wait for it to "
                              f"finish. Two writers would duplicate resources") from None
        try:
            os.ftruncate(fd, 0)
            os.lseek(fd, 0, os.SEEK_SET)
            os.write(fd, str(os.getpid()).encode())
            yield
        finally:
            release()
    finally:
        os.close(fd)                              # closing the descriptor also releases the lock


_WIN_LOCK_OFFSET = 1 << 20                        # the byte locked on Windows: far past the pid record


def _lock(fd):
    """Take an exclusive non-blocking lock on fd; a release function, or None if another process holds it."""
    try:
        import fcntl
    except ImportError:
        fcntl = None
    if fcntl is not None:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return None
        return lambda: None                       # closing the descriptor releases a flock
    import msvcrt                                 # Windows
    os.lseek(fd, _WIN_LOCK_OFFSET, os.SEEK_SET)
    try:
        msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
    except OSError:
        return None

    def release():
        os.lseek(fd, _WIN_LOCK_OFFSET, os.SEEK_SET)
        msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
    return release


class Journal:
    """Handle on one journal file: append hash-chained entries, verify the chain, and read indexed views.

    All handles on the same real path in one process share one parsed state (see the module docstring), which
    is reloaded whenever the file's inode, size or modification time differs from what this process last saw.
    Constructing a handle reads the file if needed; it raises JournalError if a line is not valid JSON. A
    missing file is an empty journal; the first append creates it.
    """
    def __init__(self, path):
        self.path = path
        key = os.path.realpath(path)
        with _SHARED_LOCK:
            st = _SHARED.get(key)
            now = _stat(path)
            if st is None or st.stat != now:          # a missing file is shared too (stat None), until created
                st = _State(*_load(path), stat=now)
                _SHARED[key] = st
        self._s = st
        self._lock = st.lock

    def _fresh(self):
        """The shared state, reloaded first if the file is not as this process last saw it (another process
        appended, or someone edited it). Every read goes through here, so an edit made after a handle was opened
        is seen (and verify() reports it). LIMIT: the check is inode, size and modification time; an edit that
        keeps all three is not noticed until one of them changes."""
        with self._lock:
            s = self._s
            now = _stat(self.path)
            if s.stat != now:
                fresh = _State(*_load(self.path), stat=now)
                s.__dict__.update({k: v for k, v in fresh.__dict__.items() if k != "lock"})
            return s

    @property
    def entries(self):
        """All entries in file order (the shared list: read it, do not modify it)."""
        return self._fresh().entries

    @property
    def head(self):
        """Hash of the last entry, or the genesis hash (64 zeros) for an empty journal. Keep it off-host to make
        later rewrites of the whole file detectable.
        """
        s = self._fresh()
        if not s.entries:
            return GENESIS
        h = s.entries[-1].get("hash")
        if not (isinstance(h, str) and len(h) == 64):
            raise JournalError(f"{self.path} line {s.line_of[-1]} has no hash (the entry was edited): a new entry "
                               f"cannot be chained to it. Move the file aside and keep it; do not edit it in place")
        return h

    def append(self, **body):
        """Append one entry and return it, chained to the current head (fields prev and hash added).

        If the file changed since this process last saw it (another process appended, or someone edited it), the
        state is reloaded first, so the new entry chains to the real last line. The line is written, flushed and
        fsync'ed before this returns: an entry that was returned is on disk. This does not take the cross-process
        lock; commands that write hold exclusive() around the whole operation.
        """
        with self._lock:
            s = self._fresh()                      # changed under us (another process, or an edit): reload
            e = dict(body, prev=self.head)
            e["hash"] = _h(e["prev"], {k: v for k, v in e.items() if k not in ("hash",)})
            with open(self.path, "a+b") as f:
                if f.seek(0, os.SEEK_END) and (f.seek(-1, os.SEEK_END), f.read(1))[1] != b"\n":
                    f.write(b"\n")                  # a file whose final newline was dropped: never glue two entries
                f.write((json.dumps(e, sort_keys=True) + "\n").encode())
                f.flush()
                os.fsync(f.fileno())
            s.add(e)
            s.line_of.append(s.next_line)
            s.next_line += 1
            s.stat = _stat(self.path)
            return e

    def verify(self) -> bool:
        """True if every entry's prev and hash match the chain from genesis; see verify_detail for where it breaks."""
        return self.verify_detail() is None

    def verify_detail(self):
        """None if the chain is intact, else {"line", "problem"} for the FIRST entry that breaks it (1-based
        line in the file). Everything before that line is still vouched for by the chain; that entry and
        everything after it are not."""
        s = self._fresh()
        prev = GENESIS
        for i, e in enumerate(s.entries, start=1):
            body = {k: v for k, v in e.items() if k != "hash"}
            line = s.line_of[i - 1]                   # the real line in the file (blank lines counted)
            if e.get("prev") != prev:
                return {"line": line, "problem": "prev does not match the hash of the entry before it "
                                              "(an entry was removed, inserted or reordered)"}
            if _h(prev, body) != e.get("hash"):
                return {"line": line, "problem": "hash does not match the entry's content (the entry was edited)"}
            prev = e["hash"]
        return None

    # ------------------------------------------------------------ indexed views
    def state(self, run_id):
        """Latest known status and outputs per step for one run."""
        st = {}
        for e in self._fresh().by_run.get(run_id, ()):
            if "step" not in e:
                continue
            cur = st.setdefault(e["step"], {})
            cur["status"] = e["event"]
            if "outputs" in e:
                cur["outputs"] = e["outputs"]
        return st

    def run_entries(self, run_id):
        """Copy of all entries of one run, in file order (from the index, not a scan)."""
        return list(self._fresh().by_run.get(run_id, ()))

    def step_entries(self, run_id, step_id):
        """Copy of all entries of one step within one run, in file order."""
        return list(self._fresh().by_run_step.get((run_id, step_id), ()))

    def runs_started(self):
        """Copy of every run_started entry, in the order the runs started."""
        return list(self._fresh().started)

    def run_end(self, run_id):
        """'run_succeeded' | 'run_failed' | 'run_torn_down' | None (the last end event of the run)."""
        return self._fresh().ended.get(run_id)

    def existing(self):
        """Read-only live view: {step_id: {run_id, id, params_hash, uncertain}} for resources that exist
        according to the journal (ready, and not rolled back, torn down or observed gone since)."""
        return self._fresh().view
