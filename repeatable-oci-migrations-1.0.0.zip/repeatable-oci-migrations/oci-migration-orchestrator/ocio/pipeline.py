"""The end-to-end migration pipeline: one function that wires the five parts together.

    discovery (optional) -> blueprint factory (+ optional agent behind the guard) -> wave planner
      -> target network -> per wave: quota preflight -> dry-run plan -> approval -> guarded execution

Every stop is explicit and recorded. Refused workloads block their whole app, and every app that depends
on a blocked app, with the reason named. Rejected proposals, change-cap breaches, quota shortfalls,
missing approvals, changed inputs and failed waves each appear in the report. Approvals are written to
the tamper-evident journal, bound to the exact content of the wave they approve.

Re-running is safe, and identity is by CONTENT, not by wave number:
  * a VM that exists from ANY earlier run (journalled ready, not rolled back) is never created again;
    if its settings have changed since, that is reported as drift, not silently applied or ignored;
  * an interrupted run is resumed only if the inputs for its steps are unchanged; otherwise the
    pipeline stops and says so (it never guesses);
  * a target network whose settings changed since it was created is refused, not reused.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field

from . import agent as A
from . import capacity as C
from . import factory as F
from . import policy as policy_mod
from .engine import Result, params_hash, workflow_hash
from .spec import Workflow


@dataclass
class Settings:
    """Everything about a run that is not the inventory: where it lands, how it is tagged, how waves are cut,
    and which reviewed plan it must match.

    environment ('dev', 'test', 'prod') selects policy gates and approval rules; compartment_id, tags,
    landing_name, vcn_cidr and tier_cidrs ({'web'|'app'|'db': CIDR}) define the target network;
    max_apps_per_wave / max_vms_per_wave (None = no VM cap) and solo_apps shape the waves;
    max_customized_share caps the share of placements that deviate from their blueprint (run blocked above it);
    quota_headroom is the fraction of available quota the preflight keeps in reserve; stop_on_wave_failure
    stops later waves after one fails; expected_plan_id, when set, blocks the run unless the computed plan id
    is exactly the reviewed one. The remaining fields (fault-domain spread, capacity reservation, defined tags,
    NSG map, bound_inputs) reach API calls and are therefore all part of the plan id.
    """
    environment: str
    compartment_id: str
    tags: dict
    landing_name: str                    # name prefix of the target network (VCN + tier subnets)
    vcn_cidr: str
    tier_cidrs: dict
    availability_domain: str = "AD-1"
    max_apps_per_wave: int = 3
    max_vms_per_wave: int = None
    solo_apps: tuple = ()
    max_customized_share: float = 0.3
    quota_headroom: float = 0.1
    stop_on_wave_failure: bool = True
    expected_plan_id: str = None         # set when approvals were given for a reviewed plan
    spread_fault_domains: bool = True    # spread each app tier over the AD's three fault domains
    capacity_reservation_id: str = None  # launch under this compute capacity reservation
    defined_tags: dict = field(default_factory=dict)   # {namespace: {key: value}}, on everything created
    nsg_map: dict = field(default_factory=dict)        # {"<app>-<tier>": NSG OCID}: VNIC membership
    bound_inputs: dict = field(default_factory=dict)   # other inputs that reach an API call (image map,
                                                       # OCM plan, subnet map, ...): part of the plan id

    def __post_init__(self):
        from .spec import ENVIRONMENTS
        if self.environment not in ENVIRONMENTS:       # "PROD" / "production" would silently get dev rules
            raise ValueError(f"environment {self.environment!r} must be one of {ENVIRONMENTS}")


@dataclass
class Report:
    """What run() decided and did: placements, refusals, blocked apps (with reasons), waves, the plan id,
    policy violations and run-level stops (which mean zero API calls), apps over the VM cap, and one result
    per executed wave (status, reason, drift, rollbacks, orphans, run ids, API calls).
    """
    placements: list = field(default_factory=list)
    refused: list = field(default_factory=list)          # [(vm, reason)]
    rejected_proposals: list = field(default_factory=list)
    blocked_apps: dict = field(default_factory=dict)     # app -> reason (refused VM, or depends on a blocked app)
    run_blocked: list = field(default_factory=list)      # run-level stops
    waves: list = field(default_factory=list)
    mutual_groups: list = field(default_factory=list)
    plan_id: str = ""
    policy_violations: list = field(default_factory=list)   # gate results on the planned workflows (dry run)
    target_network: str = ""
    over_cap: dict = field(default_factory=dict)          # app -> why it is in a wave above the VM cap
    wave_results: list = field(default_factory=list)

    @property
    def landing_zone(self):            # earlier name of target_network
        """Status of the target network build (same as target_network; kept for older callers)."""
        return self.target_network

    def summary(self):
        """Compact, JSON-ready overview of the report for printing: plan id, placement and deviation counts,
        refusals, blocked and over-cap apps, run-level stops, waves planned, policy violations, network status
        and each wave's status.
        """
        dev = F.deviation_report(self.placements)
        return {"plan_id": self.plan_id, "placed": dev["workloads"], "standard_pct": dev["standard_pct"],
                "customized": dev["customized"], "refused": len(self.refused),
                "rejected_proposals": len(self.rejected_proposals), "blocked_apps": self.blocked_apps,
                "over_cap": self.over_cap,
                "run_blocked": self.run_blocked, "waves_planned": len(self.waves),
                "mutual_groups": self.mutual_groups, "policy_violations": self.policy_violations,
                "target_network": self.target_network,
                "wave_status": [w["status"] for w in self.wave_results]}


def place_all(workloads, blueprints, overrides=None, proposer=None, bounds=A.Bounds()):
    """Placements via fixed overrides (reviewed by people) or via a proposer behind the guard."""
    placements, refused, rejected = [], [], []
    if proposer is None:
        for w in workloads:
            try:
                placements.append(F.place(w, blueprints, (overrides or {}).get(w.name, {})))
            except F.FactoryError as e:
                refused.append((w.name, str(e)))
        return placements, refused, rejected, []
    decisions = A.review(workloads, proposer, A.Guard(workloads, blueprints, bounds))
    for d in decisions:
        if d.accepted:
            placements.append(d.placement)
        else:
            rejected.append((d.workload, d.reasons))
    return placements, refused, rejected, decisions


def blocked_apps(workloads, not_placed) -> dict:
    """An app with any VM that could not be placed cannot move (it would move without that VM), and
    neither can any app that depends on it, directly or indirectly. Returns {app: reason}."""
    app_of = {w.name: w.app for w in workloads}
    deps = {}
    for w in workloads:
        deps.setdefault(w.app, set()).update(w.depends_on_apps)
    out = {}
    for vm in sorted(not_placed):
        out.setdefault(app_of[vm], f"VM {vm} could not be placed")
    for a, ds in sorted(deps.items()):
        for d in sorted(ds - set(deps)):
            out.setdefault(a, f"depends on {d}, which is not in the inventory")
    changed = True
    while changed:
        changed = False
        for a, ds in sorted(deps.items()):
            if a not in out:
                hit = sorted(d for d in ds if d in out)
                if hit:
                    out[a] = f"depends on blocked app {hit[0]}"
                    changed = True
    return out


def plan_id(placements, waves, settings) -> str:
    """Short digest of everything an approver reviews: placements, waves, target settings, and every other
    input that reaches an API call (Settings.bound_inputs)."""
    body = {"placements": sorted((p.workload.name, p.blueprint.id(), sorted(p.params.items())) for p in placements),
            "waves": waves, "env": settings.environment, "compartment": settings.compartment_id,
            "tags": sorted(settings.tags.items()), "ad": settings.availability_domain,
            "network": [settings.landing_name, settings.vcn_cidr, sorted(settings.tier_cidrs.items())],
            "fd": settings.spread_fault_domains, "capres": settings.capacity_reservation_id,
            "defined_tags": settings.defined_tags, "nsg": settings.nsg_map, "bound": settings.bound_inputs}
    return hashlib.sha256(json.dumps(body, sort_keys=True, default=str).encode()).hexdigest()[:12]


# ------------------------------------------------------------------ journal views


def _runs(journal, wf_name):
    """[(run_id, hash, steps, end)] for runs of wf_name, oldest first. end: succeeded|failed|None.
    (A torn-down run counts as failed: it is over, and is not resumed.)"""
    out = []
    for e in journal.runs_started():
        if e.get("workflow") == wf_name:
            end = journal.run_end(e["run_id"])
            end = None if end is None else ("succeeded" if end == "run_succeeded" else "failed")
            out.append((e["run_id"], e.get("workflow_hash"), e.get("steps"), end))
    return out


def unfinished_runs(journal):
    """[(run_id, workflow_name, hash, steps)] for runs with no end, of ANY workflow. A wave's identity is
    its content, so an interrupted run may belong to a wave that has since been renumbered or reshaped."""
    return [(e["run_id"], e.get("workflow"), e.get("workflow_hash"), e.get("steps") or [])
            for e in journal.runs_started() if journal.run_end(e["run_id"]) is None]


def existing_steps(journal):
    """{step_id: {"run_id", "id", "params_hash", "uncertain"}} for resources that exist according to the
    journal (journalled ready, and not rolled back, torn down or observed gone afterwards), across ALL runs.
    uncertain=True: a later rollback or teardown of it FAILED, so whether it still exists is unknown.
    A live, read-only view kept by the journal's index (Journal.existing), not a full scan."""
    return journal.existing()


def verify_existing(eng, wf, exist):
    """Check with OCI that every step of wf the journal says exists is really there and ready, before it
    is skipped. Confirmed gone -> journalled 'observed_gone' (it will be created again). Anything else
    that is not ready, or cannot be read, is returned as a problem: the wave stops rather than reporting
    success on the journal's word alone."""
    from .providers import GONE, READY
    problems = []
    for st in wf.steps:
        x = exist.get(st.id)
        if x is None:
            continue
        hint = (f"If it is gone and OCI can no longer show it, record that: migrate.py resolve --journal <journal> "
                f"--step {st.id} --id {x['id']} --by <name>")
        try:
            state = eng.observe(st.kind, x["id"])
        except Exception as e:                     # noqa: BLE001 - unreadable means unknown means stop
            problems.append(f"{st.id} ({x['id']}): cannot confirm its state: {e}. {hint}")
            continue
        if state == GONE:
            eng.j.append(run_id=x["run_id"], step=st.id, event="observed_gone", outputs={"id": x["id"]})
        elif x["uncertain"]:
            problems.append(f"{st.id} ({x['id']}) is {state}: an earlier rollback or teardown failed to delete it. "
                            f"Tear down run {x['run_id']} (migrate.py teardown --journal <journal> --run-id "
                            f"{x['run_id']} --apply), then re-run")
        elif state != READY[st.kind]:
            problems.append(f"{st.id} ({x['id']}) is {state}, not {READY[st.kind]}; investigate before re-running")
    return problems


def _restrict(wf, step_ids):
    ids = set(step_ids)
    return Workflow(wf.name, wf.environment, wf.compartment_id, tuple(s for s in wf.steps if s.id in ids), wf.tags)


def apply_network(eng, wf) -> Result:
    """The target network is created once. Same settings -> reuse (after checking with OCI that it is still
    there); changed settings -> refuse."""
    h = workflow_hash(wf)
    for rid, rh, _, end in reversed(_runs(eng.j, wf.name)):
        if end == "succeeded":
            if rh != h:
                return Result(run_id=rid, status="BLOCKED_CHANGED",
                              error=f"target network {wf.name} was created by run {rid} with different settings; "
                                    f"tear it down (migrate.py teardown --run-id {rid}) or restore the original settings")
            st = eng.j.state(rid)
            if all(st.get(s.id, {}).get("status") == "ready" for s in wf.steps):
                problems = verify_existing(eng, wf, existing_steps(eng.j))
                gone = [s.id for s in wf.steps if s.id not in existing_steps(eng.j)]
                if problems or gone:
                    return Result(run_id=rid, status="BLOCKED_STATE",
                                  error=f"target network {wf.name} from run {rid} is not intact: "
                                        f"{problems + [f'{g} no longer exists' for g in gone]}")
                return Result(run_id=rid, status="SUCCEEDED",
                              outputs={k: v["outputs"] for k, v in st.items() if v.get("status") == "ready"})
            # The run succeeded and was NOT torn down (a torn-down run counts as failed), yet not every step is
            # ready: part of the network is gone or its deletion failed. Building a second network beside what is
            # left would duplicate it and hide the uncertain part, so stop, every time, until it is torn down.
            states = {s.id: st.get(s.id, {}).get("status") for s in wf.steps if st.get(s.id, {}).get("status") != "ready"}
            return Result(run_id=rid, status="BLOCKED_STATE",
                          error=f"target network {wf.name} from run {rid} is only partly there: {states}; tear it "
                                f"down (teardown --run-id {rid}), then re-run to build it again")
        if end is None:
            if rh != h:
                return Result(run_id=rid, status="BLOCKED_CHANGED",
                              error=f"an interrupted run {rid} of {wf.name} used different settings; resume it with the "
                                    f"original settings, or tear it down first")
            return eng.apply(wf, run_id=rid)
        left = {sid: v.get("status") for sid, v in eng.j.state(rid).items() if v.get("status") in _MAY_EXIST}
        if left:                                    # failed run whose rollback / teardown left resources behind
            return Result(run_id=rid, status="BLOCKED_STATE",
                          error=f"run {rid} of {wf.name} ended but these may still exist: {left}; tear it down "
                                f"(teardown --run-id {rid}) or confirm they are gone (resolve), then re-run")
        break                                       # last run failed and was rolled back / torn down: start anew
    return eng.apply(wf)


_MAY_EXIST = ("creating", "create_unconfirmed", "created", "ready", "rollback_failed")


def _in_flight(journal, step_ids):
    """Steps of unfinished runs (of any workflow) that already exist in OCI: they hold quota already."""
    out = set()
    for rid, _, _, steps in unfinished_runs(journal):
        if set(steps) & step_ids:
            out |= {sid for sid, st in journal.state(rid).items() if st.get("status") in ("created", "ready")}
    return out & step_ids


def execute_wave(engine_factory, wf):
    """Run one wave by content. Returns (status, why, results, drift)."""
    eng = engine_factory()
    exist = existing_steps(eng.j)
    drift = sorted(s.id for s in wf.steps if s.id in exist and exist[s.id]["params_hash"] not in (None, params_hash(s.params)))
    results = []
    ids = {s.id for s in wf.steps}
    # Interrupted runs that touched any of these VMs, whatever wave they were in at the time.
    for rid, name, rh, steps in unfinished_runs(eng.j):
        if not set(steps) & ids:
            continue
        if not set(steps) <= ids or workflow_hash(_restrict(wf, steps)) != rh:
            return ("BLOCKED_CHANGED", f"an interrupted run {rid} ({name}) covered {sorted(steps)} with different "
                    f"inputs or a different wave split; restore the original inputs to resume it, or tear it down "
                    f"first (migrate.py teardown --journal <journal> --run-id {rid} --apply)", results, drift)
        results.append(engine_factory().apply(_restrict(wf, steps), run_id=rid))
        if results[-1].status != "SUCCEEDED":
            return results[-1].status, results[-1].error or results[-1].violations, results, drift
    exist = existing_steps(engine_factory().j)
    remaining = [s.id for s in wf.steps if s.id not in exist]
    if remaining:
        results.append(engine_factory().apply(_restrict(wf, remaining)))
        if results[-1].status != "SUCCEEDED":
            return results[-1].status, results[-1].error or results[-1].violations, results, drift
    if not results:
        return "SUCCEEDED", "already exists from earlier runs (checked in OCI)", results, drift
    return "SUCCEEDED", "", results, drift


def _wave_opts(s):
    return {"spread_fault_domains": s.spread_fault_domains, "capacity_reservation_id": s.capacity_reservation_id,
            "defined_tags": s.defined_tags or None, "nsg_map": s.nsg_map or None}


def _closure(apps, deps):
    seen, todo = set(), list(apps)
    while todo:
        for d in deps.get(todo.pop(), ()):
            if d not in seen:
                seen.add(d); todo.append(d)
    return seen


def run(workloads, blueprints, settings: Settings, engine_factory, quota: C.QuotaSource = None,
        approver=None, overrides=None, proposer=None, bounds=A.Bounds(), execute=True, admit=None) -> Report:
    """engine_factory() -> Engine. approver(wave_name, reasons, plan, wave_hash) -> (approved: bool, who: str).
    admit(wave_number, plan_id) -> ocio.admission.evaluate(...) result, or None for no admission gate. It is
    asked just before approval, for every wave that still has something to create; the decision is journalled
    and a refusal stops the run (BLOCKED_ADMISSION), since later waves may depend on this one.
    quota=None is allowed only when execute=False (planning); executing requires it."""
    s, rep = settings, Report()
    placements, rep.refused, rep.rejected_proposals, decisions = place_all(
        workloads, blueprints, overrides, proposer, bounds)
    if decisions:
        rep.run_blocked += A.change_cap(decisions, s.max_customized_share)
    not_placed = {vm for vm, _ in rep.refused} | {vm for vm, _ in rep.rejected_proposals}
    unknown_solo = sorted(set(s.solo_apps) - {w.app for w in workloads})
    if unknown_solo:                             # a typo here would silently batch an app meant to go alone
        rep.run_blocked.append(f"solo apps not in the inventory: {unknown_solo}; check the spelling")
    rep.blocked_apps = blocked_apps(workloads, not_placed)
    rep.placements = [p for p in placements if p.workload.app not in rep.blocked_apps]
    placed = [p.workload for p in rep.placements]
    rep.waves = F.plan_waves(placed, s.max_apps_per_wave, s.max_vms_per_wave,
                             [a for a in s.solo_apps if a in {w.app for w in placed}])
    rep.mutual_groups = F.mutual_groups(placed)
    if s.max_vms_per_wave is not None:                 # an app cannot be split, so it moves alone, and is named
        n_vms = {}
        for w in placed:
            n_vms[w.app] = n_vms.get(w.app, 0) + 1
        rep.over_cap = {a: f"{n} VMs, above the cap of {s.max_vms_per_wave} per wave; it moves alone in one wave"
                        for a, n in sorted(n_vms.items()) if n > s.max_vms_per_wave}
    if not rep.waves:
        rep.run_blocked.append(f"nothing to execute: no app can be placed ({len(rep.blocked_apps)} blocked, each "
                               f"named under blocked_apps)" if rep.blocked_apps else "nothing to execute: the inventory is empty")
    rep.plan_id = plan_id(rep.placements, rep.waves, s)
    # Policy gates on the PLAN, so a dry run shows what --apply would block (missing tags, bad CIDRs, ...)
    try:
        net_plan = F.target_network(s.landing_name, s.environment, s.compartment_id, s.tags, s.vcn_cidr, s.tier_cidrs,
                                    s.defined_tags)
        rep.policy_violations += [f"target network: {v}" for v in policy_mod.evaluate(net_plan)]
        planned = {k: {"id": f"planned-{k}"} for k in F.TIER_SUBNETS.values()}
        by_app0 = {}
        for p in rep.placements:
            by_app0.setdefault(p.workload.app, []).append(p)
        for i, apps in enumerate(rep.waves, start=1):
            wf0 = F.wave_workflow(i, apps, [p for a in apps for p in by_app0.get(a, ())], planned,
                                  s.environment, s.compartment_id, s.tags, all_placements=rep.placements,
                                  **_wave_opts(s))
            rep.policy_violations += [f"wave {i}: {v}" for v in policy_mod.evaluate(wf0)]
    except (F.FactoryError, ValueError) as e:
        rep.policy_violations.append(f"plan could not be built: {e}")
    if s.expected_plan_id and s.expected_plan_id != rep.plan_id:
        rep.run_blocked.append(f"plan {rep.plan_id} differs from the reviewed plan {s.expected_plan_id}; "
                               f"review the new plan before approving it")
    if not execute or rep.run_blocked or rep.policy_violations:
        return rep                               # policy is checked on the plan: violations mean zero API calls
    if quota is None:
        raise ValueError("executing requires a quota source; pass quota=StaticQuota(...) or OCILimitsQuota(...)")

    # One run journal, one target. Resources are identified in the journal by step id (vcn, subnet_app, the VM
    # name), so a second compartment, environment or landing network recorded in the same journal would find the
    # first one's resources and "skip" creating its own. The first run binds the journal to its target; any other
    # target is refused before any API call (use one --journal per target).
    target = {"compartment": s.compartment_id, "environment": s.environment, "landing": s.landing_name}
    j0 = engine_factory().j
    bound = [e for e in j0.entries if e.get("event") == "journal_target"]
    if bound and {k: bound[0].get(k) for k in target} != target:
        rep.run_blocked.append(f"this journal belongs to target {[bound[0].get(k) for k in target]} "
                               f"(compartment, environment, landing); this run's target is {list(target.values())}. "
                               f"Use a separate --journal for each target; nothing was created")
        return rep
    if not bound:
        j0.append(event="journal_target", **target)
    if admit is not None and rep.waves:
        # The first wave that still has something to create must be admitted before even the network is built (a
        # re-run whose earlier waves landed is not held back by their evidence going stale). Journalled like the
        # per-wave decisions, so a refusal here is on record too.
        done = existing_steps(j0)
        pending = [i for i, apps in enumerate(rep.waves, start=1)
                   if any(p.workload.name not in done for p in rep.placements if p.workload.app in apps)]
        if pending:
            w = pending[0]
            first = admit(w, rep.plan_id)
            j0.append(event="admission", workflow=f"wave-{w}", plan_id=rep.plan_id, wave=w,
                      allowed=bool(first.get("allowed")), reasons=first.get("reasons", []),
                      evidence_hash=first.get("evidence_hash"), phase="before_network")
            if not first.get("allowed"):
                rep.run_blocked.append(f"wave {w} is not admitted: {first.get('reasons', [])}; nothing was created")
                return rep
    net = F.target_network(s.landing_name, s.environment, s.compartment_id, s.tags, s.vcn_cidr, s.tier_cidrs,
                           s.defined_tags)
    z = apply_network(engine_factory(), net)
    rep.target_network = z.status
    if z.status != "SUCCEEDED":
        rep.wave_results.append({"wave": 0, "apps": [], "status": "NOT_RUN",
                                 "why": f"target network {z.status}: {z.error or z.violations}"})
        return rep
    by_app, deps = {}, {}
    for p in rep.placements:
        by_app.setdefault(p.workload.app, []).append(p)
        deps.setdefault(p.workload.app, set()).update(p.workload.depends_on_apps)
    not_done = set()                             # apps of waves that did not succeed
    for i, apps in enumerate(rep.waves, start=1):
        wave_placements = [p for a in apps for p in by_app.get(a, ())]
        wf = F.wave_workflow(i, apps, wave_placements, z.outputs, s.environment, s.compartment_id, s.tags,
                             all_placements=rep.placements, **_wave_opts(s))
        res = {"wave": i, "apps": apps, "vms": len(wf.steps)}

        def stop(status, why):
            res.update(status=status, why=why)
            rep.wave_results.append(res)
            not_done.update(apps)
            return s.stop_on_wave_failure

        missing = sorted(_closure(apps, deps) & not_done)
        if missing:                              # never launch an app before what it depends on is in place
            if stop("SKIPPED_DEPENDENCY", f"depends on {missing}, which did not complete"):
                break
            continue
        eng = engine_factory()
        problems = verify_existing(eng, wf, existing_steps(eng.j))
        if problems:
            if stop("BLOCKED_STATE", problems):
                break
            continue
        exist = existing_steps(eng.j)
        todo = _restrict(wf, [st.id for st in wf.steps if st.id not in exist])
        # VMs an interrupted run already created hold their quota: count only what is still to create
        in_flight = _in_flight(eng.j, {st.id for st in wf.steps})
        if not todo.steps:
            drift = sorted(st.id for st in wf.steps if exist[st.id]["params_hash"] not in (None, params_hash(st.params)))
            res.update(status="SUCCEEDED", why="already exists from earlier runs (checked in OCI)", drift=drift)
            rep.wave_results.append(res)
            continue
        new = _restrict(todo, [st.id for st in todo.steps if st.id not in in_flight])
        shortfall = C.preflight(new, quota, s.availability_domain, s.quota_headroom)
        if shortfall:
            if stop("BLOCKED_QUOTA", shortfall):
                break
            continue
        if admit is not None:
            adm = admit(i, rep.plan_id)
            eng.j.append(event="admission", workflow=wf.name, plan_id=rep.plan_id, wave=i,
                         allowed=bool(adm.get("allowed")), reasons=adm.get("reasons", []),
                         evidence_hash=adm.get("evidence_hash"), phase="wave")
            if not adm.get("allowed"):
                stop("BLOCKED_ADMISSION", adm.get("reasons", []))
                break
        plan = eng.plan(todo)
        todo_ids = {st.id for st in todo.steps}
        reasons = A.approval_reasons(s.environment, [p for p in wave_placements if p.workload.name in todo_ids])
        if reasons:
            wh = workflow_hash(todo)
            ok, who = approver(wf.name, reasons, plan, wh) if approver else (False, "")
            eng.j.append(event="approval", workflow=wf.name, wave_hash=wh, plan_id=rep.plan_id,
                         approved=bool(ok), by=who, reasons=reasons)
            if not ok:
                stop("BLOCKED_APPROVAL", reasons)
                break                          # later waves may depend on this one
        status, why, results, drift = execute_wave(engine_factory, wf)
        res.update(status=status, why=why, drift=drift,
                   rolled_back=[x for r in results for x in r.rolled_back],
                   orphans=[x for r in results for x in r.orphans],
                   run_ids=[r.run_id for r in results], api_calls=sum(r.api_calls for r in results))
        rep.wave_results.append(res)
        if status == "SUCCEEDED":
            use = getattr(quota, "record_use", None)       # a static quota snapshot must shrink as waves land
            if use:
                use(C.wave_demand(new), s.availability_domain)
        else:
            not_done.update(apps)
            if s.stop_on_wave_failure:
                break
    return rep
