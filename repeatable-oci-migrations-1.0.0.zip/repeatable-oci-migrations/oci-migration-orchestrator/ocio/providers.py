"""Provider interface, a simulated OCI for tests, and the real OCI SDK adapter.

The engine depends only on Provider. FakeOCI reproduces the behaviours the engine must handle:
asynchronous lifecycle states, HTTP 429 throttling and 5xx errors, idempotent retry tokens, and
failures mid-provision. OCISDKProvider maps the same four calls onto the OCI Python SDK.
"""
from __future__ import annotations

import hashlib
import re
import threading
import time

TRANSIENT = {429, 500, 502, 503, 504}
READY = {"vcn": "AVAILABLE", "subnet": "AVAILABLE", "instance": "RUNNING"}
GONE = "TERMINATED"


class ProviderError(Exception):
    """A cloud call failed. status is the HTTP status (0 for a transport error with none); retryable marks a
    normally permanent status known to be temporary here (409 on delete, timeouts); capacity marks "out of
    host capacity", which the engine retries at most a few times.
    """
    def __init__(self, status, message="", retryable=False, capacity=False):
        super().__init__(f"{status} {message}")
        self.status = status
        self.retryable = retryable          # set only where a normally-permanent status is known to be temporary
        self.capacity = capacity            # OCI has no host capacity for this shape here: retrying rarely helps

    @property
    def transient(self):
        """True if retrying can help: a status in TRANSIENT (throttling and server errors) or flagged retryable."""
        return self.status in TRANSIENT or self.retryable


class Crash(BaseException):
    """Simulates the orchestrator process dying. BaseException so the engine cannot catch it."""


class Provider:
    """What the engine needs from a cloud: four calls. FakeOCI and OCISDKProvider implement it; a provider
    signals failure with ProviderError (status, and whether retrying can help)."""

    def create(self, kind, compartment_id, params, tags, retry_token) -> str:
        """Start creating a resource of `kind` ('vcn', 'subnet', 'instance'); return its id. The same
        retry_token must yield the same resource, never a second one."""

    def state(self, kind, rid) -> str:
        """Current lifecycle state ('PROVISIONING', 'AVAILABLE', 'RUNNING', 'TERMINATED', ...)."""

    def outputs(self, kind, rid) -> dict:
        """What later steps may reference: at least {"id": ...}."""

    def delete(self, kind, rid) -> None:
        """Start deleting the resource; deleting something already gone is not an error."""


# ---------------------------------------------------------------- simulated OCI


class FakeOCI(Provider):
    """In-memory OCI. Thread-safe. Lifecycle advances one state per poll, deterministically.

    faults: {(op, kind): [status, status, ...]} — each matching call pops one status and raises it
            (use 0 for 'succeed this time'). op in {"create", "state", "delete"}.
    fail_provision: set of display_names whose launch fails: the resource goes to TERMINATED, as in OCI.
    crash_after_create: set of display_names; the process 'dies' right after OCI accepted the create.
    provision_polls: polls before a resource becomes ready.
    """

    def __init__(self, faults=None, fail_provision=(), crash_after_create=(), provision_polls=2,
                 latency=0.0, max_in_flight=None):
        """latency (seconds, real sleep, outside the lock) and max_in_flight model an API under load:
        a call arriving while max_in_flight calls are already being served gets HTTP 429."""
        self.lock = threading.Lock()
        self.latency, self.max_in_flight = latency, max_in_flight
        self.in_flight, self.peak_in_flight, self.throttled = 0, 0, 0
        self.res, self.tokens = {}, {}
        self.faults = {k: list(v) for k, v in (faults or {}).items()}
        self.fail_provision = set(fail_provision)
        self.crash_after_create = set(crash_after_create)
        self.provision_polls = provision_polls
        self.calls = []
        self._per_name = {}                              # (kind, compartment, display name) -> creates so far

    def _admit(self):
        if self.max_in_flight is None and not self.latency:
            return False
        with self.lock:
            if self.max_in_flight is not None and self.in_flight >= self.max_in_flight:
                self.throttled += 1
                raise ProviderError(429, "too many requests in flight")
            self.in_flight += 1
            self.peak_in_flight = max(self.peak_in_flight, self.in_flight)
        if self.latency:
            time.sleep(self.latency)
        return True

    def _leave(self, admitted):
        if admitted:
            with self.lock:
                self.in_flight -= 1

    def _fault(self, op, kind):
        q = self.faults.get((op, kind))
        if q:
            s = q.pop(0)
            if s == "capacity":
                raise ProviderError(500, "InternalError: Out of host capacity. (injected)", capacity=True)
            if s:
                raise ProviderError(s, f"injected on {op} {kind}")

    def create(self, kind, compartment_id, params, tags, retry_token):
        """Simulated create with OCI's retry-token semantics: the same (kind, compartment, token) returns the same
        resource. A subnet or instance whose parent (vcn_id / subnet_id) is missing or not ready gets a 404.
        Injected faults (including "capacity") raise before anything is created; a name in crash_after_create
        raises Crash AFTER the resource exists, as a process dying mid-call would.
        """
        admitted = self._admit()
        try:
            return self._create_impl(kind, compartment_id, params, tags, retry_token)
        finally:
            self._leave(admitted)

    def _create_impl(self, kind, compartment_id, params, tags, retry_token):
        with self.lock:
            self.calls.append(("create", kind, params.get("display_name")))
            self._fault("create", kind)
            key = (kind, compartment_id, retry_token)
            if key in self.tokens:                       # OCI semantics: same retry token -> same resource
                return self.tokens[key]
            for need in ("vcn_id",) if kind == "subnet" else ("subnet_id",) if kind == "instance" else ():
                parent = self.res.get(params.get(need))
                if not parent or parent["state"] != READY[parent["kind"]]:
                    raise ProviderError(404, f"{need} not found or not ready")
            # Derived from what is created, not from arrival order: parallel creates reach this lock in any
            # order, and one shared counter made the same run print different OCIDs under load. The n-th create
            # of a name gets the same id in every run (creates of one name are sequential: rollback, re-create).
            name = (kind, compartment_id, params.get("display_name"))
            self._per_name[name] = self._per_name.get(name, 0) + 1
            rid = f"ocid1.{kind}.oc1..fake{hashlib.sha256(repr((name, self._per_name[name])).encode()).hexdigest()[:10]}"
            while rid in self.res:                       # never reuse an id (e.g. two creates without a name)
                rid += "x"
            self.res[rid] = {"kind": kind, "state": "PROVISIONING", "polls": 0, "params": dict(params),
                             "tags": dict(tags), "compartment_id": compartment_id}
            self.tokens[key] = rid
        if params.get("display_name") in self.crash_after_create:
            self.crash_after_create.discard(params.get("display_name"))
            raise Crash(f"process died after create of {params.get('display_name')}")
        return rid

    def state(self, kind, rid):
        """Simulated lifecycle: a new resource is PROVISIONING for provision_polls reads, then ready (or TERMINATED,
        with a failure reason, for a name in fail_provision); a deleted one goes TERMINATING -> TERMINATED. 404
        for an unknown id.
        """
        admitted = self._admit()
        try:
            return self._state_impl(kind, rid)
        finally:
            self._leave(admitted)

    def _state_impl(self, kind, rid):
        with self.lock:
            self.calls.append(("state", kind, rid))
            self._fault("state", kind)
            r = self.res.get(rid)
            if r is None:
                raise ProviderError(404, "not found")
            if r["state"] == "PROVISIONING":
                r["polls"] += 1
                if r["polls"] >= self.provision_polls:
                    # A failed launch ends TERMINATED in OCI (instances have no FAILED lifecycle state).
                    failed = r["params"].get("display_name") in self.fail_provision
                    r["state"] = GONE if failed else READY[kind]
                    if failed:
                        r["failure"] = "simulated launch failure (work request error)"
            elif r["state"] == "TERMINATING":
                r["state"] = GONE
            return r["state"]

    def outputs(self, kind, rid):
        """{"id", "state", "display_name"} of a simulated resource."""
        with self.lock:
            r = self.res[rid]
            return {"id": rid, "state": r["state"], "display_name": r["params"].get("display_name")}

    def delete(self, kind, rid):
        """Simulated delete: idempotent for unknown or deleted ids; 409 while a VCN still has subnets or a subnet
        still has instances, as OCI refuses those.
        """
        admitted = self._admit()
        try:
            return self._delete_impl(kind, rid)
        finally:
            self._leave(admitted)

    def _delete_impl(self, kind, rid):
        with self.lock:
            self.calls.append(("delete", kind, rid))
            self._fault("delete", kind)
            r = self.res.get(rid)
            if r is None or r["state"] == GONE:
                return                                   # idempotent delete
            if kind == "vcn" and any(x["params"].get("vcn_id") == rid and x["state"] != GONE for x in self.res.values()):
                raise ProviderError(409, "VCN still has subnets")
            if kind == "subnet" and any(x["params"].get("subnet_id") == rid and x["state"] != GONE for x in self.res.values()):
                raise ProviderError(409, "subnet still has instances")
            r["state"] = "TERMINATING"

    def failure_reason(self, kind, rid):
        """The simulated work-request error of a failed launch, or None."""
        with self.lock:
            return (self.res.get(rid) or {}).get("failure")

    def live(self):
        """Resources that still exist (not TERMINATED or TERMINATING): what a test checks for leftovers."""
        with self.lock:
            return {rid: r for rid, r in self.res.items() if r["state"] not in (GONE, "TERMINATING")}


# ---------------------------------------------------------------- real OCI


class OCISDKProvider(Provider):
    """Adapter onto the OCI Python SDK (verified against oci 2.189.0 models and client methods).

    Construction of request models is exercised offline in tests; live calls need an OCI config and
    a tenancy, and were NOT run in this build. Five behaviours matter on a live tenancy and are
    handled here (each has an offline test):
      * SDK-level retries are OFF. oci 2.189.0 applies DEFAULT_RETRY_STRATEGY (8 attempts, 600 s) to
        every call unless told otherwise; stacked under the engine's own retries one stuck call could
        take hours, and the engine would lose control of pacing. The engine owns retries.
      * After a delete completes, OCI GETs return 404 for VCNs and subnets. But OCI also answers 404
        (NotAuthorizedOrNotFound) when the caller lacks permission. So 404 means "gone" ONLY for a
        resource this adapter's delete call was accepted for; any other 404 is an error, and rollback
        reports the resource as an orphan that could not be confirmed deleted.
      * Network timeouts and connection resets (no HTTP status) are retryable: the retry token makes a
        re-sent create safe.
      * Blueprint images are symbolic (e.g. "IMAGE_OL8"). image_map resolves them to real image OCIDs
        for the region; an unmapped symbol is refused, never sent to OCI.
      * 409 Conflict on delete (a subnet whose instance VNIC is still detaching) is retryable, but
        only on delete: a 409 on create means a real conflict and is not retried.
    """

    def __init__(self, config=None, signer=None, availability_domain=None, image_id=None, image_map=None,
                 timeout=(10, 60)):
        import oci
        self.oci = oci
        kw = {"signer": signer} if signer else {}
        kw["retry_strategy"] = oci.retry.NoneRetryStrategy()
        # Explicit (connect, read) timeouts in seconds; the SDK's documented defaults are 10 and 60. Set
        # here so a hung connection fails into the engine's bounded retries instead of stalling a wave.
        kw["timeout"] = timeout
        cfg = config if config is not None else oci.config.from_file()
        self._cfg, self._kw = cfg, kw
        self.net = oci.core.VirtualNetworkClient(cfg, **kw)
        self.compute = oci.core.ComputeClient(cfg, **kw)
        self.wr = None                         # WorkRequestClient, built on first use
        self._work_requests = {}               # instance OCID -> launch work request OCID
        self.ad, self.image_id = availability_domain, image_id
        self.image_map = dict(image_map or {})
        self._deleted = set()                  # OCIDs whose delete OCI accepted (2xx) in this process

    def _image(self, params):
        img = params.get("image_id", self.image_id)
        if img and img.startswith("ocid1.image."):
            return img
        per_shape = f"{img}@{params.get('shape')}"      # resolved per shape: x86 images do not boot Arm shapes
        if per_shape in self.image_map:
            return self.image_map[per_shape]
        from .factory import ARM_SHAPES
        if params.get("shape") in ARM_SHAPES:            # never fall back to the plain (x86) symbol on Arm
            raise ProviderError(400, f"{params.get('shape')} is an Arm shape: image {img!r} needs an Arm entry "
                                     f"{per_shape!r} in image_map (or --resolve-images); refusing the x86 image")
        if img in self.image_map:
            return self.image_map[img]
        raise ProviderError(400, f"image {img!r} is not an image OCID and has no entry in image_map; refusing to guess")

    @staticmethod
    def dns_label(value):
        """OCI DNS labels: letters and digits only, starting with a letter, at most 15 characters.
        Anything else is cleaned; if nothing usable remains, no label is sent (OCI then sets none)."""
        if not value:
            return None
        v = re.sub(r"[^a-z0-9]", "", str(value).lower())
        v = re.sub(r"^[0-9]+", "", v)[:15]
        return v or None

    # Request models are built in a separate, pure method so tests can check them without network.
    def build(self, kind, compartment_id, params, tags):
        """The SDK request model for one step, with no network call: CreateVcnDetails, CreateSubnetDetails or
        LaunchInstanceDetails, carrying display name, freeform and defined tags, and for instances the AD, fault
        domain, capacity reservation, Flex shape config (OCPUs, memory, baseline; omitted for fixed shapes),
        VNIC (subnet, public IP flag, hostname label, NSGs) and image source (resolved by _image, boot volume
        size and VPUs/GB). DNS labels are cleaned by dns_label. ValueError for an unknown kind.
        """
        m = self.oci.core.models
        common = dict(compartment_id=compartment_id, display_name=params.get("display_name"), freeform_tags=dict(tags),
                      defined_tags=params.get("defined_tags"))
        if kind == "vcn":
            return m.CreateVcnDetails(cidr_blocks=[params["cidr_block"]], dns_label=self.dns_label(params.get("dns_label")),
                                      **common)
        if kind == "subnet":
            return m.CreateSubnetDetails(vcn_id=params["vcn_id"], cidr_block=params["cidr_block"],
                                         prohibit_public_ip_on_vnic=bool(params.get("prohibit_public_ip_on_vnic")),
                                         dns_label=self.dns_label(params.get("dns_label")), **common)
        if kind == "instance":
            flex = ".Flex" in params["shape"]          # fixed shapes (e.g. VM.Standard.E2.1.Micro) reject a shape config
            return m.LaunchInstanceDetails(
                availability_domain=params.get("availability_domain", self.ad), shape=params["shape"],
                fault_domain=params.get("fault_domain"),
                capacity_reservation_id=params.get("capacity_reservation_id"),
                shape_config=m.LaunchInstanceShapeConfigDetails(
                    ocpus=params.get("ocpus", 1), memory_in_gbs=params.get("memory_gbs", 8),
                    baseline_ocpu_utilization=params.get("baseline_ocpu_utilization")) if flex else None,
                create_vnic_details=m.CreateVnicDetails(subnet_id=params["subnet_id"],
                                                        assign_public_ip=bool(params.get("assign_public_ip")),
                                                        hostname_label=params.get("hostname_label"),
                                                        nsg_ids=params.get("nsg_ids")),
                source_details=m.InstanceSourceViaImageDetails(
                    image_id=self._image(params), boot_volume_size_in_gbs=params.get("boot_volume_size_in_gbs"),
                    boot_volume_vpus_per_gb=params.get("boot_volume_vpus_per_gb")),
                **common)
        raise ValueError(kind)

    def _call(self, fn, *a, **kw):
        exc = self.oci.exceptions
        transport = tuple(t for t in (getattr(exc, "RequestException", None), getattr(exc, "ConnectTimeout", None),
                                      getattr(exc, "BaseRequestException", None),
                                      getattr(exc, "BaseConnectTimeout", None)) if t)
        try:
            import requests
            transport += (requests.exceptions.RequestException,)
        except ImportError:                       # pragma: no cover - requests ships with the oci SDK
            pass
        try:
            return fn(*a, **kw)
        except exc.ServiceError as e:
            # Keep Oracle's own message and the opc-request-id: it is what Oracle Support asks for first.
            from .errors import describe
            msg = describe(e)            # code, message, request id, and what to do for the non-retryable codes
            # "Out of host capacity." arrives as 500 InternalError on launch. Oracle's "Always Free Resources"
            # page (read 2026-10-21) names the error and its remedy (another AD, or wait and retry); earlier
            # this comment said only users reported it, which was wrong. The 500/InternalError pairing is
            # still from user reports, so the match stays on the text and stays loose.
            raise ProviderError(e.status, msg, capacity="out of host capacity" in str(e.message).lower()) from e
        except transport as e:                    # no HTTP status: timeout, reset, DNS
            raise ProviderError(0, f"transport error: {type(e).__name__}: {e}", retryable=True) from e

    def create(self, kind, compartment_id, params, tags, retry_token):
        """Send the create (create_vcn, create_subnet or launch_instance) with the engine's opc-retry-token and
        return the new OCID. For a launch, the opc-work-request-id header is kept so failure_reason can read why
        it failed. Errors become ProviderError via _call.
        """
        details = self.build(kind, compartment_id, params, tags)
        fn = {"vcn": self.net.create_vcn, "subnet": self.net.create_subnet, "instance": self.compute.launch_instance}[kind]
        resp = self._call(fn, details, opc_retry_token=retry_token)
        wr = (getattr(resp, "headers", None) or {}).get("opc-work-request-id")
        if wr:                                  # LaunchInstance returns the work request (Oracle SDK reference)
            self._work_requests[resp.data.id] = wr
        return resp.data.id

    def failure_reason(self, kind, rid):
        """Why a launch failed, from its work request's errors (an instance only says TERMINATED)."""
        wr = self._work_requests.get(rid)
        if not wr:
            return None
        if self.wr is None:
            self.wr = self.oci.work_requests.WorkRequestClient(self._cfg, **self._kw)
        try:
            errs = self._call(self.wr.list_work_request_errors, wr).data
        except ProviderError as e:
            return f"work request {wr}: errors could not be read ({e})"
        return "; ".join(f"{getattr(x, 'code', '')}: {getattr(x, 'message', '')}" for x in errs) or None

    def _get(self, kind, rid):
        fn = {"vcn": self.net.get_vcn, "subnet": self.net.get_subnet, "instance": self.compute.get_instance}[kind]
        return self._call(fn, rid).data

    def state(self, kind, rid):
        """The resource's lifecycle_state. A 404 counts as TERMINATED only for a resource this process deleted
        (deleted VCNs and subnets 404); any other 404 is raised, since OCI also answers 404 when not authorized.
        """
        try:
            return self._get(kind, rid).lifecycle_state
        except ProviderError as e:
            if e.status == 404 and rid in self._deleted:   # deleted VCNs/subnets 404 instead of TERMINATED
                return GONE
            if e.status == 404:
                raise ProviderError(404, f"{rid} not found or not authorized (NotAuthorizedOrNotFound)") from e
            raise

    def outputs(self, kind, rid):
        """{"id", "state", "display_name"} read from OCI."""
        d = self._get(kind, rid)
        return {"id": d.id, "state": d.lifecycle_state, "display_name": d.display_name}

    def delete(self, kind, rid):
        """Send delete_vcn, delete_subnet or terminate_instance and remember the id as deleted. A 404 is accepted
        only for an id already deleted here; 409 (e.g. a VNIC still detaching) is raised as retryable.
        """
        fn = {"vcn": self.net.delete_vcn, "subnet": self.net.delete_subnet, "instance": self.compute.terminate_instance}[kind]
        try:
            self._call(fn, rid)
            self._deleted.add(rid)
        except ProviderError as e:
            if e.status == 404 and rid in self._deleted:   # a re-sent delete for something already deleted
                return
            if e.status == 404:
                raise ProviderError(404, f"{rid} not found or not authorized; cannot confirm it is deleted") from e
            if e.status == 409:                       # e.g. VNIC still detaching: retry, bounded by the engine
                raise ProviderError(409, f"conflict on delete of {kind} (retryable): {e}", retryable=True) from e
            raise
