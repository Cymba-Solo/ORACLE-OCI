"""Execution engine: plan (dry run), apply with retries / waits / rollback, resume after a crash.

Guarantees, each covered by a test:
  * Policy gates run on the plan; any violation means zero API calls.
  * Idempotency: the OCI retry token for a step is derived from (run_id, step_id, generation), so
    re-sending a create after a timeout or a crash returns the SAME resource instead of creating a
    duplicate (generation counts earlier rollbacks of the step; see retry_token).
  * Throttling and 5xx are retried with capped exponential backoff and full jitter; 4xx are not.
  * A step is done only when its resource reaches its ready lifecycle state, within a timeout.
  * On failure (of any kind, expected or not), everything this run created is deleted in reverse
    completion order (saga rollback). Anything rollback could not delete is reported by OCID as an
    orphan, never hidden; a create that hit a server or network error and may exist without a confirmed
    OCID is reported too, with the tags to find it by.
  * Every transition is journalled (fsync) before the engine moves on; resume reuses the journal.
"""
from __future__ import annotations

import hashlib
import json
import random
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field

from . import policy as policy_mod
from .providers import GONE, READY, ProviderError
from .spec import SpecError, Workflow, resolve, waves


@dataclass(frozen=True)
class RetryPolicy:
    """How transient provider errors (throttling, 5xx, transport) are retried: at most max_attempts calls
    in total, sleeping a uniformly random time in [0, min(cap_seconds, base_seconds * 2**(attempt-1))]
    between them (capped exponential backoff with full jitter). Non-transient errors are never retried."""
    max_attempts: int = 6
    base_seconds: float = 1.0
    cap_seconds: float = 30.0


@dataclass
class Result:
    """Outcome of Engine.apply or Engine.teardown.

    status: SUCCEEDED | BLOCKED (policy violations, nothing sent) | FAILED_ROLLED_BACK | FAILED_ROLLBACK_INCOMPLETE
    (apply), TORN_DOWN | TEARDOWN_INCOMPLETE (teardown). outputs: {step id: provider outputs} on success.
    error: why the run failed. violations: policy gate messages. rolled_back: steps deleted. orphans: what may
    still exist ({"step", "id" (None if never confirmed), "error"}). api_calls: provider calls made by the engine."""
    run_id: str
    status: str
    outputs: dict = field(default_factory=dict)
    error: str = ""
    violations: list = field(default_factory=list)
    rolled_back: list = field(default_factory=list)
    orphans: list = field(default_factory=list)
    api_calls: int = 0


class StepFailed(Exception):
    """A step (or a wave of steps) could not complete: a non-retryable provider error, retries exhausted,
    a resource entering FAILED or disappearing, a wait timeout, or an expired retry-token window. The message
    says which and, where known, what to do; apply() turns it into a rollback."""


def retry_token(run_id, step_id, generation=0):
    """Same (run, step, generation) -> same token -> OCI returns the same resource on a re-send.
    generation counts prior rollbacks of this step: after a rollback the old resource is terminated,
    and reusing its token would hand back the terminated resource instead of a new one."""
    return hashlib.sha256(f"{run_id}/{step_id}/{generation}".encode()).hexdigest()[:64]


def params_hash(params) -> str:
    """Stable digest of a step's resolved parameters, journalled at create time (drift detection)."""
    return hashlib.sha256(json.dumps(params, sort_keys=True, default=str).encode()).hexdigest()[:16]


_OCIO_LABELS = ("migration_wave",)            # tags ocio derives itself; not part of what a run is bound to


def workflow_hash(wf) -> str:
    """SHA-256 over a workflow's steps, environment, compartment and tags. Journalled when a run starts; a resume
    is refused if the workflow handed to it hashes differently (the plan changed under the run). Tags are in it
    because they are stamped on every resource the run creates: finishing an interrupted run with other tags
    would leave half its resources under one cost centre and half under another. Excluded: the wave label
    (migration_wave), which ocio itself sets from the wave number. Waves are resumed by content, so a VM whose
    wave was renumbered (a dependency dropped) must still resume its interrupted run."""
    return hashlib.sha256(json.dumps(
        {"steps": [vars(s) for s in wf.steps], "env": wf.environment, "c": wf.compartment_id,
         "tags": {k: v for k, v in (wf.tags or {}).items() if k not in _OCIO_LABELS}},
        sort_keys=True, default=list).encode()).hexdigest()


class Engine:
    """Executes one Workflow against a provider, journalling every transition (see the module docstring for
    the guarantees). Steps run wave by wave in dependency order, up to max_workers in parallel within a wave.
    sleep, clock (monotonic), wall (epoch) and rng are injectable so tests and simulations need no real time."""

    def __init__(self, provider, journal, gates=policy_mod.DEFAULT_GATES, max_workers=4,
                 retry=RetryPolicy(), wait_timeout=1800.0, poll_seconds=5.0,
                 sleep=None, clock=None, rng=None, limiter=None, wall=None,
                 token_max_age=23 * 3600, capacity_attempts=2):
        """limiter: optional capacity.AdaptiveLimiter shared by all workers (and by several engines,
        if they run against the same region). With a limiter, max_workers can be set high: the limiter,
        not the pool size, decides how many calls are in flight."""
        self.p, self.j, self.gates = provider, journal, gates
        self.limiter = limiter
        # OCI retry tokens expire after 24 hours (OCI API reference, opc-retry-token). A create that was
        # sent but never confirmed is re-sent with the same token on resume only if it is younger than
        # token_max_age; otherwise the step stops and says which tagged resource to look for.
        # Resolved here, not as default arguments: a default is bound when the module is imported, so a clock
        # configured or patched later (a simulation, a test, a different time source) would be ignored.
        self.wall, self.token_max_age = wall or time.time, token_max_age
        self.max_workers, self.retry = max_workers, retry
        self.capacity_attempts = capacity_attempts
        self.wait_timeout, self.poll = wait_timeout, poll_seconds
        self.sleep, self.clock = sleep or time.sleep, clock or time.monotonic
        self.rng = rng or random.Random()
        self.calls = 0

    # ------------------------------------------------------------ plan
    def plan(self, wf: Workflow) -> dict:
        """Dry run: the workflow's waves, the policy-gate violations, and one "create" action per step with
        its unresolved parameters (references such as ${vcn.id} stay as written). No provider call, no journal
        write."""
        return {"workflow": wf.name, "environment": wf.environment, "waves": waves(wf),
                "violations": policy_mod.evaluate(wf, self.gates),
                "actions": [{"step": s.id, "kind": s.kind, "action": "create", "depends_on": list(s.depends_on),
                             "params": dict(s.params)} for s in wf.steps]}

    # ------------------------------------------------------------ helpers
    def _with_retry(self, what, fn, *a):
        attempt, ambiguous = 0, False
        while True:
            attempt += 1
            self.calls += 1
            try:
                return self._call(fn, *a)
            except ProviderError as e:
                # A timeout / reset (status 0) or a server error (5xx, other than a capacity refusal) may have
                # been ACCEPTED with the reply lost. Remember it for the whole call: if later attempts are then
                # refused (429, 4xx), the request may still have taken effect on an earlier attempt.
                st = getattr(e, "status", None)
                if not getattr(e, "capacity", False) and (st == 0 or (isinstance(st, int) and st >= 500)):
                    ambiguous = True
                if getattr(e, "capacity", False) and attempt >= self.capacity_attempts:
                    err = StepFailed(f"{what}: {e} after {attempt} attempt(s). OCI has no host capacity for this "
                                     f"shape here; retrying the same request rarely helps. Options: another fault "
                                     f"domain or availability domain, another shape, or a capacity reservation "
                                     f"(--capacity-reservation)")
                    err.maybe_accepted = ambiguous
                    raise err from e
                if not e.transient or attempt >= self.retry.max_attempts:
                    err = StepFailed(f"{what}: {e} after {attempt} attempt(s)")
                    err.maybe_accepted = ambiguous
                    raise err from e
                backoff = min(self.retry.cap_seconds, self.retry.base_seconds * 2 ** (attempt - 1))
                self.sleep(self.rng.uniform(0, backoff))          # full jitter

    def _call(self, fn, *a):
        if self.limiter is None:
            return fn(*a)
        self.limiter.acquire()
        throttled = False
        try:
            return fn(*a)
        except ProviderError as e:
            throttled = e.status == 429
            raise
        finally:
            self.limiter.release(throttled)

    def observe(self, kind, rid):
        """Current lifecycle state of a resource, with the usual retries (used to verify what the journal
        says exists before a wave is skipped)."""
        return self._with_retry(f"state {rid}", self.p.state, kind, rid)

    MAX_POLL_SECONDS = 30.0        # the oci SDK waiter's default max_interval_seconds (oci.waiter.wait_until)

    def _wait(self, kind, rid, target):
        """Poll until target, FAILED/gone, or wait_timeout. The interval starts at poll_seconds and doubles to
        30 s, as the SDK's own waiter does: a launch takes minutes, and polling every VM in flight at a fixed
        5 s spends the region's GET rate limit (and invites 429s) for no earlier answer. The last sleep is cut
        so the wait never runs past its deadline."""
        deadline = self.clock() + self.wait_timeout
        interval = self.poll
        while True:
            st = self._with_retry(f"state {rid}", self.p.state, kind, rid)
            if st == target:
                return
            if st in ("FAILED", GONE):
                why = None
                reason = getattr(self.p, "failure_reason", None)
                if callable(reason):
                    try:
                        why = reason(kind, rid)
                    except Exception as e:          # noqa: BLE001 - the reason is a courtesy, not a step
                        why = f"reason unavailable: {e!r}"
                raise StepFailed(f"{rid} entered {st} while waiting for {target}" + (f": {why}" if why else ""))
            now = self.clock()
            if now >= deadline:
                raise StepFailed(f"{rid} not {target} within {self.wait_timeout}s (last {st})")
            self.sleep(min(interval, deadline - now))
            interval = min(interval * 2, max(self.MAX_POLL_SECONDS, self.poll))

    # ------------------------------------------------------------ apply
    def apply(self, wf: Workflow, run_id=None) -> Result:
        """New run when run_id is None; otherwise resume that run from the journal."""
        violations = policy_mod.evaluate(wf, self.gates)
        rid = run_id or uuid.uuid4().hex
        res = Result(run_id=rid, status="BLOCKED", violations=violations)
        if violations:
            self.j.append(run_id=rid, event="blocked", violations=violations)
            return res
        wf_hash = workflow_hash(wf)
        prior = self.j.state(rid)
        if run_id is None:
            self.j.append(run_id=rid, event="run_started", workflow=wf.name, workflow_hash=wf_hash,
                          steps=[s.id for s in wf.steps])
        else:
            started = [e for e in self.j.run_entries(rid) if e.get("event") == "run_started"]
            if not started or started[0]["workflow_hash"] != wf_hash:
                raise SpecError("resume refused: workflow differs from the one this run started with")
            self.j.append(run_id=rid, event="run_resumed")

        outputs, created = {}, []           # created: (step_id, kind, ocid) in completion order
        for sid, st in prior.items():
            if st.get("status") == "ready":
                outputs[sid] = st["outputs"]
            if st.get("outputs", {}).get("id") and st.get("status") in ("created", "ready"):
                created.append((sid, wf.step(sid).kind, st["outputs"]["id"]))

        try:
            for wave in waves(wf):
                todo = [s for s in wave if s not in outputs]
                with ThreadPoolExecutor(max_workers=self.max_workers) as ex:
                    futs = {s: ex.submit(self._run_step, wf, rid, s, outputs, prior.get(s, {}), created) for s in todo}
                    errors = []
                    for s, f in futs.items():
                        try:
                            outputs[s] = f.result()
                        except StepFailed as e:
                            errors.append(f"{s}: {e}")
                    if errors:
                        raise StepFailed("; ".join(errors))
        except Exception as e:                  # noqa: BLE001 - any error: undo what this run created
            res.error = str(e) if isinstance(e, (StepFailed, SpecError)) else f"unexpected error: {e!r}"
            self._rollback(rid, created, res)
            for sid in self._unconfirmed(rid):
                res.orphans.append({"step": sid, "id": None,
                                    "error": f"create was sent but never confirmed (server or network error); it may exist. "
                                             f"Look for a resource tagged ocio_run={rid}, ocio_step={sid}"})
            res.status = "FAILED_ROLLED_BACK" if not res.orphans else "FAILED_ROLLBACK_INCOMPLETE"
            self.j.append(run_id=rid, event="run_failed", error=res.error, orphans=res.orphans)
            res.api_calls = self.calls
            return res
        self.j.append(run_id=rid, event="run_succeeded")
        res.status, res.outputs, res.api_calls = "SUCCEEDED", outputs, self.calls
        return res

    def _unconfirmed(self, rid):
        """Steps of this run whose create may have reached OCI without a confirmed OCID."""
        st = self.j.state(rid)
        flagged = {e["step"] for e in self.j.run_entries(rid) if e.get("event") == "create_unconfirmed"}
        return sorted(sid for sid in flagged if st.get(sid, {}).get("status") == "create_unconfirmed")

    def _run_step(self, wf, rid, sid, outputs, prior, created):
        step = wf.step(sid)
        params = resolve(step.params, outputs)
        ocid = prior.get("outputs", {}).get("id") if prior.get("status") == "created" else None
        if ocid is None:
            gen = sum(1 for e in self.j.step_entries(rid, sid)      # each earlier resource of this step that is gone
                      if e.get("event") in ("rolled_back", "observed_gone"))
            token = retry_token(rid, sid, gen)
            if prior.get("status") in ("creating", "create_unconfirmed"):     # sent, never confirmed either way
                sent = [e for e in self.j.step_entries(rid, sid) if e.get("event") == "creating"]
                age = self.wall() - sent[-1].get("ts", self.wall()) if sent else 0
                if age > self.token_max_age:
                    raise StepFailed(f"create of {sid} was sent {age / 3600:.1f} h ago and never confirmed; its "
                                     f"retry token may have expired, so re-sending could duplicate it. Look for a "
                                     f"resource tagged ocio_run={rid}, ocio_step={sid}; delete it or record it, then re-run")
            tags = dict(wf.tags, ocio_run=rid, ocio_step=sid)   # findable later, e.g. after a long outage
            self.j.append(run_id=rid, step=sid, event="creating", retry_token=token, ts=self.wall(),
                          params_hash=params_hash(params), kind=step.kind)
            try:
                ocid = self._with_retry(f"create {sid}", self.p.create, step.kind, wf.compartment_id,
                                        params, tags, token)
            except StepFailed as e:
                # May exist if ANY attempt may have been accepted (not only the last): a lost reply followed by
                # 429s is still a create that may have happened.
                if getattr(e, "maybe_accepted", False):
                    self.j.append(run_id=rid, step=sid, event="create_unconfirmed", error=str(e))
                raise
            created.append((sid, step.kind, ocid))
            self.j.append(run_id=rid, step=sid, event="created", outputs={"id": ocid})
        self._wait(step.kind, ocid, READY[step.kind])
        out = self._with_retry(f"outputs {sid}", self.p.outputs, step.kind, ocid)
        self.j.append(run_id=rid, step=sid, event="ready", outputs=out)
        return out

    def teardown(self, wf: Workflow, run_id) -> Result:
        """Delete everything a run created that may still exist, newest first, and wait until each is
        gone: resources it created, and resources whose earlier rollback or teardown FAILED. Used to undo a
        wave on purpose, to clear a BLOCKED_STATE or BLOCKED_CHANGED, or to clean up a smoke test. Same
        guarantees as rollback: failures are reported as orphans, never hidden; every deletion is
        journalled. A complete teardown closes the run, so it is no longer resumed. wf may be None: the
        resource kinds are then read from the journal."""
        st = self.j.state(run_id)
        kinds = {e["step"]: e.get("kind") for e in self.j.run_entries(run_id) if e.get("event") == "creating"}
        order = [e["step"] for e in self.j.run_entries(run_id) if e.get("event") == "created"]
        created, seen = [], set()
        for sid in order:
            if sid in seen or st.get(sid, {}).get("status") not in ("created", "ready", "rollback_failed"):
                continue
            seen.add(sid)
            kind = wf.step(sid).kind if wf is not None else kinds.get(sid)
            if kind is None:
                raise SpecError(f"cannot tell what kind of resource {sid} is; pass the workflow")
            created.append((sid, kind, st[sid]["outputs"]["id"]))
        res = Result(run_id=run_id, status="TORN_DOWN")
        self.j.append(run_id=run_id, event="teardown_started")
        self._rollback(run_id, created, res)
        for sid, v in sorted(st.items()):          # sent but never confirmed: may exist, cannot be deleted by OCID
            if v.get("status") in ("creating", "create_unconfirmed"):
                res.orphans.append({"step": sid, "id": None,
                                    "error": f"create was sent but never confirmed; it may exist. Look for a "
                                             f"resource tagged ocio_run={run_id}, ocio_step={sid}"})
        if res.orphans:
            res.status = "TEARDOWN_INCOMPLETE"
        self.j.append(run_id=run_id, event="teardown_finished", orphans=res.orphans)
        if not res.orphans:
            self.j.append(run_id=run_id, event="run_torn_down")
        res.api_calls = self.calls
        return res

    def _rollback(self, rid, created, res):
        for sid, kind, ocid in reversed(created):
            try:
                self._with_retry(f"delete {sid}", self.p.delete, kind, ocid)
                self._wait(kind, ocid, GONE)
                res.rolled_back.append(sid)
                self.j.append(run_id=rid, step=sid, event="rolled_back", outputs={"id": ocid})
            except StepFailed as e:
                res.orphans.append({"step": sid, "id": ocid, "error": str(e)})
                self.j.append(run_id=rid, step=sid, event="rollback_failed", outputs={"id": ocid}, error=str(e))
