"""Example blueprint catalog and inventory loader. Teams replace this file with their own standards."""
from __future__ import annotations

import csv

from .factory import Blueprint, Workload

E5 = "VM.Standard.E5.Flex"

BLUEPRINTS = (
    Blueprint("web-linux", 1, "web", "linux",
              {"shape": E5, "assign_public_ip": False, "image_id": "IMAGE_OL8"},
              frozenset({"ocpus", "memory_gbs"})),
    Blueprint("app-linux", 1, "app", "linux",
              {"shape": E5, "assign_public_ip": False, "image_id": "IMAGE_OL8"},
              frozenset({"ocpus", "memory_gbs", "shape"})),
    Blueprint("app-windows", 1, "app", "windows",
              {"shape": E5, "assign_public_ip": False, "image_id": "IMAGE_WIN2022"},
              frozenset({"ocpus", "memory_gbs"})),
    Blueprint("db-linux", 1, "db", "linux",
              {"shape": E5, "assign_public_ip": False, "image_id": "IMAGE_OL8"},
              frozenset({"ocpus", "memory_gbs", "subnet"})),
)


INVENTORY_COLUMNS = ("name", "app", "tier", "os", "vcpus", "memory_gb")      # + optional depends_on_apps
TIERS = ("web", "app", "db")


def _positive(value, what, kind):
    try:
        n = kind(value)
    except (TypeError, ValueError):
        raise ValueError(f"{what} {value!r} is not a number") from None
    if not (n > 0) or n != n or n == float("inf"):
        raise ValueError(f"{what} {value!r} must be greater than 0")
    return n


def load_inventory(path) -> list[Workload]:
    """CSV columns: name, app, tier, os, vcpus, memory_gb, depends_on_apps (semicolon-separated).

    Read as UTF-8 with or without a byte-order mark (Excel's "CSV UTF-8" adds one; without this the first
    column is called '\ufeffname' and every line fails). Every refusal names the line:
      * missing columns are named once, from the header;
      * name, app and os must be non-empty; tier must be web, app or db (lower case, as everywhere else);
      * vcpus is a whole number > 0; memory_gb a number > 0, fractions allowed (15.5 GB from an MB
        export), and sizing rounds it UP (factory.size);
      * dependencies are split on ';' and trimmed ("b; c" is b and c, not b and " c");
      * duplicate VM names are listed."""
    out = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        rd = csv.DictReader(f)
        missing = [c for c in INVENTORY_COLUMNS if c not in (rd.fieldnames or [])]
        if missing:
            raise ValueError(f"inventory {path}: missing columns {missing}; header is {rd.fieldnames}")
        for i, r in enumerate(rd, start=2):
            try:
                name, app, tier, os_ = (str(r[k] or "").strip() for k in ("name", "app", "tier", "os"))
                for k, v in (("name", name), ("app", app), ("os", os_)):
                    if not v:
                        raise ValueError(f"{k} is empty")
                if tier not in TIERS:
                    raise ValueError(f"tier {tier!r} must be one of {TIERS}")
                vc = _positive(r["vcpus"], "vcpus", int)
                mem = _positive(r["memory_gb"], "memory_gb", float)
                deps = tuple(x.strip() for x in (r.get("depends_on_apps") or "").split(";") if x.strip())
                out.append(Workload(name=name, app=app, tier=tier, os=os_, vcpus=vc,
                                    memory_gb=int(mem) if mem == int(mem) else mem, depends_on_apps=deps))
            except ValueError as e:
                raise ValueError(f"inventory line {i}: {e}") from None
    seen, dup = set(), []
    for w in out:
        (dup.append(w.name) if w.name in seen else seen.add(w.name))
    if dup:
        raise ValueError(f"inventory has duplicate VM names: {sorted(set(dup))}")
    return out
