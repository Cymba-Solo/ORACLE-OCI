"""Check every planned shape and size against what the availability domain actually offers, read live.

WHY. factory.SHAPE_SIZE holds Oracle's published per-shape maximums, which is right for planning. A real
tenancy can differ: a shape may not be offered in a given AD, or not to that compartment, and flexible-shape
limits (OCPU range, memory range, GB per OCPU) are what ComputeClient.list_shapes reports for that AD, not
what a table says. A mismatch otherwise fails only at LaunchInstance, part-way through a wave.

WHAT. check() calls list_shapes(compartment_id, availability_domain=AD), once, all pages, and for each
distinct (shape, OCPUs, memory) in the plan reports, in words an operator can act on:
  * the shape is not offered in the AD (to this compartment);
  * flexible shape: OCPUs outside ocpu_options.min..max, memory outside memory_options.min_in_g_bs..
    max_in_g_bs, GB per OCPU outside min_per_ocpu_in_gbs..max_per_ocpu_in_gbs (each bound used only when
    the service returns it);
  * fixed shape: planned OCPUs / memory differ from the shape's own.
Read-only. Field names checked against oci 2.189.0 (Shape, ShapeOcpuOptions, ShapeMemoryOptions);
not run against a tenancy. The idea and the per-OCPU checks come from the merged annotated package.
"""
from __future__ import annotations


def _all(compute, compartment_id, **kw):
    items, page, seen = [], None, set()
    while True:
        if page:
            kw["page"] = page
        resp = compute.list_shapes(compartment_id, **kw)
        items.extend(resp.data or [])
        page = getattr(resp, "next_page", None) or (getattr(resp, "headers", None) or {}).get("opc-next-page")
        if not page:
            return items
        if page in seen:
            raise ValueError(f"list_shapes repeated page token {page!r}; stopping instead of looping")
        seen.add(page)


def _outside(value, lo, hi):
    return (lo is not None and value < lo) or (hi is not None and value > hi)


def check(compute, compartment_id, availability_domain, placements):
    """[problem, ...] for the placements' shapes in this AD; [] when every one fits."""
    offered = {s.shape: s for s in _all(compute, compartment_id, availability_domain=availability_domain)}
    problems, seen = [], set()
    for p in placements:
        shape, ocpus, mem = p.params["shape"], p.params["ocpus"], p.params["memory_gbs"]
        if (shape, ocpus, mem) in seen:
            continue
        seen.add((shape, ocpus, mem))
        who = p.workload.name
        s = offered.get(shape)
        if s is None:
            problems.append(f"{who}: shape {shape} is not offered in {availability_domain} to this compartment "
                            f"(offered there: {len(offered)} shapes); choose another shape or AD")
            continue
        co, mo = getattr(s, "ocpu_options", None), getattr(s, "memory_options", None)
        if co is None and mo is None:                      # fixed shape
            if (s.ocpus is not None and ocpus != s.ocpus) or (s.memory_in_gbs is not None and mem != s.memory_in_gbs):
                problems.append(f"{who}: {shape} is fixed at {s.ocpus} OCPUs / {s.memory_in_gbs} GB; plan has "
                                f"{ocpus} / {mem}")
            continue
        if co is not None and _outside(ocpus, co.min, co.max):
            problems.append(f"{who}: {ocpus} OCPUs is outside {shape}'s {co.min}-{co.max} OCPUs in "
                            f"{availability_domain}")
        if mo is not None:
            if _outside(mem, mo.min_in_g_bs, mo.max_in_g_bs):
                problems.append(f"{who}: {mem} GB is outside {shape}'s {mo.min_in_g_bs}-{mo.max_in_g_bs} GB in "
                                f"{availability_domain}")
            per = mem / ocpus if ocpus else float("inf")
            if _outside(per, getattr(mo, "min_per_ocpu_in_gbs", None), getattr(mo, "max_per_ocpu_in_gbs", None)):
                problems.append(f"{who}: {per:g} GB per OCPU is outside {shape}'s {mo.min_per_ocpu_in_gbs}-"
                                f"{mo.max_per_ocpu_in_gbs} GB per OCPU in {availability_domain}")
    return problems
