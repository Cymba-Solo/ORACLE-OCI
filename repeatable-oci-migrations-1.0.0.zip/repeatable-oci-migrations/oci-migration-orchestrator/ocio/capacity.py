"""Capacity: quota preflight before a wave, and adaptive pacing of API calls during it.

Quota preflight
  A wave that would exceed a compartment's service limits fails at PLAN time, before any resource is
  created, instead of half-way through with a 400 LimitExceeded and a rollback. Demand is the sum of
  OCPUs and memory per shape family in the wave. Limit names come from Oracle's "Limits by Service"
  page (Compute rows; all scoped per availability domain), checked 2026-10-21:
      VM.Standard.E5.Flex -> standard-e5-core-count / standard-e5-memory-count
      VM.Standard.E4.Flex -> standard-e4-core-count / standard-e4-memory-count
      VM.Standard3.Flex   -> standard3-core-count   / standard3-memory-count
  A limit whose availability cannot be read is a violation ("unknown"), never assumed to be fine.

Adaptive pacing (AIMD, as in TCP congestion control)
  One limiter is shared by every worker of a run. It allows `limit` calls in flight. Each successful
  call nudges the limit up (+1 per `limit` successes); each 429 halves it. So the engine finds the rate
  OCI will accept instead of hammering it with a fixed worker count.
"""
from __future__ import annotations

import threading
from collections import defaultdict

SHAPE_LIMITS = {
    "VM.Standard.E5.Flex": ("standard-e5-core-count", "standard-e5-memory-count"),
    "VM.Standard.E4.Flex": ("standard-e4-core-count", "standard-e4-memory-count"),
    "VM.Standard3.Flex": ("standard3-core-count", "standard3-memory-count"),
    # Limits by Service, Compute (checked 2026-10-21): per availability domain, shared with Container Instances
    "VM.Standard.A1.Flex": ("standard-a1-core-count", "standard-a1-memory-count"),
}


def wave_demand(wf) -> dict:
    """{limit_name: amount} needed by the instance steps of a workflow."""
    need = defaultdict(float)
    for s in wf.steps:
        if s.kind != "instance":
            continue
        shape = s.params.get("shape")
        if shape not in SHAPE_LIMITS:
            need[f"unmapped-shape:{shape}"] += 1
            continue
        cores, mem = SHAPE_LIMITS[shape]
        need[cores] += float(s.params.get("ocpus", 1))
        need[mem] += float(s.params.get("memory_gbs", 1))
    return dict(need)


class QuotaSource:
    """Where preflight reads how much of a service limit is still available. Subclasses: StaticQuota (a
    snapshot from a file or a test) and OCILimitsQuota (read live from the tenancy)."""

    def available(self, limit_name: str, availability_domain: str):
        """Return the available amount, or None if it cannot be determined."""
        raise NotImplementedError


class StaticQuota(QuotaSource):
    """Known availability, e.g. for tests or a run planned from a file of limits (--quota-file). It is a
    snapshot taken before the run, so the pipeline calls record_use after each successful wave and later
    waves are checked against what is left. (OCILimitsQuota needs no such call: it reads live values.)"""

    def __init__(self, available: dict):
        self._a = dict(available)
        self._total = dict(available)          # the snapshot as given: the limit headroom is a share of

    def total(self, limit_name, availability_domain=None):
        """The limit's size as the snapshot gave it (before any record_use), or None if it is not listed."""
        return self._total.get(limit_name)

    def available(self, limit_name, availability_domain):
        """The snapshot's remaining amount for limit_name, or None (unknown) if the snapshot does not list it.
        The availability domain is ignored: a snapshot file describes the one AD the run targets."""
        return self._a.get(limit_name)

    def record_use(self, demand: dict, availability_domain=None):
        """Subtract a landed wave's demand ({limit name: amount}, as wave_demand returns) from the snapshot, so
        the next wave is checked against what is left. Limits not in the snapshot stay unknown."""
        for k, v in demand.items():
            if k in self._a:
                self._a[k] -= v


class OCILimitsQuota(QuotaSource):
    """Reads oci.limits.LimitsClient.get_resource_availability (response field `available`).

    service_name defaults to "compute"; Oracle's pages checked do not show the exact service name, so
    confirm it once with `oci limits service list --compartment-id <tenancy-ocid>` (see RUNBOOK.md).
    A 404/400 from the API returns None, which preflight reports as unknown. Not run against a tenancy.
    """

    def __init__(self, compartment_id, config=None, signer=None, service_name="compute", client=None, timeout=None):
        """timeout: (connect, read) seconds for the LimitsClient, as every other client gets (--sdk-timeout);
        None keeps the SDK default. client: an injected client (tests), used as is."""
        if client is None:
            import oci
            kw = {"signer": signer} if signer else {}
            kw["retry_strategy"] = oci.retry.NoneRetryStrategy()
            if timeout is not None:
                kw["timeout"] = timeout
            client = oci.limits.LimitsClient(config if config is not None else oci.config.from_file(), **kw)
        self.client, self.compartment_id, self.service_name = client, compartment_id, service_name
        self.errors = {}           # limit name -> why its availability could not be read
        self._totals = {}          # (limit, AD) -> used + available, from the last successful read

    def total(self, limit_name, availability_domain):
        """used + available from the last read of limit_name (the limit as it applies to this compartment), or
        None if it was not read or the response had no `used`."""
        return self._totals.get((limit_name, availability_domain))

    def available(self, limit_name, availability_domain):
        """Live `available` amount of limit_name in availability_domain for this compartment, or None when it
        cannot be read. Any exception (HTTP 404/400, authorization, network) returns None and records why in
        self.errors[limit_name]; preflight then refuses the wave as "unknown" instead of assuming it fits."""
        try:
            data = self.client.get_resource_availability(self.service_name, limit_name, self.compartment_id,
                                                         availability_domain=availability_domain).data
        except Exception as e:     # 404 (not supported / not authorized), 400 (wrong scope), network: all fail closed
            status = getattr(e, "status", None)
            self.errors[limit_name] = f"{type(e).__name__}{f' {status}' if status else ''}: {getattr(e, 'message', e)}"
            return None
        avail, used = getattr(data, "available", None), getattr(data, "used", None)
        if isinstance(avail, (int, float)) and isinstance(used, (int, float)):
            self._totals[(limit_name, availability_domain)] = used + avail
        return avail


def preflight(wf, quota: QuotaSource, availability_domain: str, headroom: float = 0.0) -> list[str]:
    """Violations if the wave would not fit. headroom keeps a fraction of each LIMIT free (0.1 = 10%).

    The fraction is of the limit's total (quota.total(): the snapshot as given, or used + available live),
    not of what is left: taken of what is left, the reserve shrinks with every wave (10, then 1, then 0.1 of
    a 100-OCPU limit) until nothing is kept free. A source that cannot say the total falls back to a share
    of what is available."""
    out = []
    for limit, amount in sorted(wave_demand(wf).items()):
        if limit.startswith("unmapped-shape:"):
            out.append(f"{wf.name}: shape {limit.split(':', 1)[1]!r} has no known service-limit mapping")
            continue
        avail = quota.available(limit, availability_domain)
        if avail is None:
            why = getattr(quota, "errors", {}).get(limit)
            out.append(f"{wf.name}: availability of {limit} in {availability_domain} is unknown"
                       f"{f' ({why})' if why else ''}; refusing to assume it fits")
        else:
            total = getattr(quota, "total", lambda *a: None)(limit, availability_domain)
            reserve = headroom * (total if isinstance(total, (int, float)) else avail)
            if amount > avail - reserve:
                of = f" of {total:g}" if isinstance(total, (int, float)) else ""
                out.append(f"{wf.name}: needs {amount:g} of {limit} in {availability_domain}, "
                           f"{avail:g} available, {reserve:g} kept free (headroom {headroom:.0%}{of})")
    return out


class AdaptiveLimiter:
    """Shared AIMD concurrency limit. Thread-safe.

    Usage (as engine.Engine does): limiter.acquire(); try: call() finally: limiter.release(throttled), where
    throttled is True when the call was answered with HTTP 429. `limit` starts at `initial` and stays within
    [minimum, maximum]; `throttles` counts 429s and `peak_limit` records the highest limit reached."""

    def __init__(self, initial=4, minimum=1, maximum=64):
        if not (1 <= minimum <= initial <= maximum):
            raise ValueError("need 1 <= minimum <= initial <= maximum")
        self.limit, self.minimum, self.maximum = initial, minimum, maximum
        self.in_flight, self._successes = 0, 0
        self.throttles, self.peak_limit = 0, initial
        self._cv = threading.Condition()

    def acquire(self):
        """Block until fewer than `limit` calls are in flight, then take a slot."""
        with self._cv:
            while self.in_flight >= self.limit:
                self._cv.wait()
            self.in_flight += 1

    def release(self, throttled: bool):
        """Give the slot back and adapt: a throttled call halves the limit (not below minimum) and resets the
        success count; otherwise, after `limit` consecutive successes the limit grows by 1 (not above maximum).
        Wakes any waiting acquire()."""
        with self._cv:
            self.in_flight -= 1
            if throttled:
                self.throttles += 1
                self.limit = max(self.minimum, self.limit // 2)
                self._successes = 0
            else:
                self._successes += 1
                if self._successes >= self.limit:
                    self.limit = min(self.maximum, self.limit + 1)
                    self._successes = 0
                    self.peak_limit = max(self.peak_limit, self.limit)
            self._cv.notify_all()
