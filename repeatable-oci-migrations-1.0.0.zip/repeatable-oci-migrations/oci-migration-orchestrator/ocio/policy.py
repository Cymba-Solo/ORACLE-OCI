"""Policy gates, evaluated on the PLAN before any API call. A violation stops the run (fail closed).

Gates are plain functions returning a list of violation strings, so a team can add its own.
"""
from __future__ import annotations

import ipaddress

from .spec import Workflow


def no_public_ip_in_prod(wf: Workflow):
    """In prod only: every subnet must set prohibit_public_ip_on_vnic=true and no instance may assign a public
    IP. Returns one violation string per offending step; [] outside prod.
    """
    if wf.environment != "prod":
        return []
    out = []
    for s in wf.steps:
        if s.kind == "subnet" and not s.params.get("prohibit_public_ip_on_vnic", False):
            out.append(f"{s.id}: prod subnets must set prohibit_public_ip_on_vnic=true")
        if s.kind == "instance" and s.params.get("assign_public_ip", False):
            out.append(f"{s.id}: prod instances must not assign a public IP")
    return out


def no_burstable_in_prod(wf: Workflow):
    """Burstable (subcore) instances run at a baseline of 1/8 or 1/2 OCPU and only burst above it: fine for
    dev and test, a latent outage for production load."""
    if wf.environment != "prod":
        return []
    return [f"{s.id}: burstable instance ({s.params['baseline_ocpu_utilization']}) in prod"
            for s in wf.steps if s.kind == "instance"
            and s.params.get("baseline_ocpu_utilization") not in (None, "BASELINE_1_1")]


def required_tags(keys=("cost_center", "owner")):
    """Gate factory: the returned gate reports a workflow whose tags lack a non-blank value for any of `keys`
    (default cost_center and owner). The gate is named 'required_tags' in reports.
    """
    def gate(wf: Workflow):
        missing = [k for k in keys if not str(wf.tags.get(k) or "").strip()]     # " " is no cost centre
        return [f"workflow missing required tag(s): {missing}"] if missing else []
    gate.__name__ = "required_tags"
    return gate


def allowed_shapes(shapes):
    """Gate factory: the returned gate reports every instance step whose shape is not in `shapes` (a set of
    shape names). The default gates allow the E5, E4 and Standard3 Flex shapes only.
    """
    def gate(wf: Workflow):
        return [f"{s.id}: shape {s.params.get('shape')!r} not in allowed list"
                for s in wf.steps if s.kind == "instance" and s.params.get("shape") not in shapes]
    gate.__name__ = "allowed_shapes"
    return gate


def cidr_sanity(wf: Workflow):
    """Subnets must be valid IPv4, inside a VCN CIDR they depend on, and must not overlap each other.

    IPv4 only: the VCN's cidr_blocks are "IPv4 CIDR blocks" and a subnet's cidr_block must lie within them;
    IPv6 prefixes go in separate fields (ipv6_private_cidr_blocks, ipv6_cidr_block) that ocio does not set
    (oci 2.189.0 model documentation). An IPv6 prefix here is reported, never passed on."""
    out, vcns, subnets = [], {}, []
    for s in wf.steps:
        if s.kind not in ("vcn", "subnet"):
            continue
        try:
            net = ipaddress.ip_network(s.params["cidr_block"])
        except (KeyError, ValueError) as e:
            out.append(f"{s.id}: invalid cidr_block ({e})")
            continue
        if net.version != 4:
            out.append(f"{s.id}: cidr_block {net} is IPv6; OCI takes IPv4 here (IPv6 prefixes are a separate "
                       f"setting ocio does not manage)")
            continue
        if s.kind == "vcn":
            vcns[s.id] = net
        else:
            subnets.append((s, net))
    for s, net in subnets:
        parents = [vcns[d] for d in s.depends_on if d in vcns]
        if not parents:
            out.append(f"{s.id}: subnet does not depend on a VCN step")
        elif not any(net.subnet_of(p) for p in parents):
            out.append(f"{s.id}: {net} is not inside its VCN")
    for i, (a, na) in enumerate(subnets):
        for b, nb in subnets[i + 1:]:
            if na.overlaps(nb):
                out.append(f"{a.id} and {b.id}: overlapping CIDRs {na} / {nb}")
    return out


def _verified_shapes():
    from .factory import SHAPE_SIZE                  # one list: the shapes whose limits were checked
    return set(SHAPE_SIZE)


DEFAULT_GATES = (no_public_ip_in_prod, no_burstable_in_prod, required_tags(), cidr_sanity,
                 allowed_shapes(_verified_shapes()))


def evaluate(wf: Workflow, gates=DEFAULT_GATES) -> list[str]:
    """All violations of all gates for one workflow, in gate order. An empty list means the plan may proceed;
    callers treat any violation as a stop before the first API call (fail closed).
    """
    return [v for g in gates for v in g(wf)]
