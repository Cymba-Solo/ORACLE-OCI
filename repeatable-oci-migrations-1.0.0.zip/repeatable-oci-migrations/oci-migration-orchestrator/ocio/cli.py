#!/usr/bin/env python3
"""Command line for the migration orchestrator. See RUNBOOK.md for the full procedure.

  discover   assets + flows (+ listeners) -> findings.json and a decisions template; with --decisions,
             also writes the reviewed inventory.csv for planning
  plan       inventory (+ overrides or --agent rule) -> deviation report, refusals, waves. No OCI calls.
  run        plan, then execute against OCI: quota preflight, approvals, adaptive pacing, journal.
             DRY RUN unless --apply. Re-run the same command after a crash: it resumes.
             (Builds the target network and launches instances from images: for rebuilds and pilots.)
  teardown   delete what one run created and may still exist, newest first (dry run unless --apply)
  ui         the one-click launch console: radio buttons -> previewed command -> run (127.0.0.1 only)
  status     read-only summary of a journal: integrity (and where it breaks), runs, resources, events
  resolve    record in the journal that an operator confirmed a resource is gone (when OCI cannot say)
  ocm-wave   the MIGRATION path: write the blueprint settings for one wave into an Oracle Cloud Migrations
             migration plan's target assets and exclude every other asset. OCM then replicates and launches
             from the replicated volumes when the operator executes the plan. DRY RUN unless --apply.
  ocm-restore  put OCM target assets back as ocm-wave journalled them before its first change.
             DRY RUN unless --apply --restore-id.
  netpolicy  observed flows -> one NSG per app tier with least-privilege rules, the default-security-list
             gap, hybrid flows per wave. DRY RUN unless --apply (then writes --nsg-map-out for run/ocm-wave).

Run as `ocio ...` (installed), `python -m ocio ...`, or `python scripts/migrate.py ...`; all three are this
module. Every command that writes a journal holds it exclusively (ocio.journal.exclusive).
"""
import argparse
import csv
import json
import os
import sys

from ocio import __version__
from ocio import agent as A, capacity as C, discovery as D, factory as F, ocm as O, pipeline as P
from ocio.catalog import BLUEPRINTS, load_inventory
from ocio.engine import Engine
from ocio.journal import Journal


def _person(v):
    """A name standing behind an approval or confirmation: non-empty after trimming, so `--approve-by " "`
    cannot pass for a person."""
    v = (v or "").strip()
    if not v:
        raise argparse.ArgumentTypeError("must name a person (it is recorded in the journal)")
    return v


class Refused(SystemExit):
    """A refusal made BEFORE anything was changed (bad option, wrong OCID type, unknown AD, wrong region, missing
    reviewed id, busy journal). Exit code 2, as documented ("stopped before any change"); 1 stays reserved for
    "something may have changed". The message is the exception's text; main() prints it to stderr."""

    def __init__(self, message):
        super().__init__(message)
        self.code = 2


def _positive_int(v):
    n = int(v)
    if n < 1:
        raise argparse.ArgumentTypeError(f"must be a whole number of at least 1, got {v}")
    return n


def _fraction(lo_open=False, hi_open=False):
    def check(v):
        x = float(v)
        if not ((x > 0 if lo_open else x >= 0) and (x < 1 if hi_open else x <= 1)):
            raise argparse.ArgumentTypeError(f"must be between 0 and 1, got {v}")
        return x
    return check


def _timeout(v):
    """--sdk-timeout CONNECT,READ in seconds (one number sets both), e.g. 10,60 (the SDK's own defaults)."""
    parts = [float(x) for x in str(v).split(",")]
    if len(parts) == 1:
        parts *= 2
    if len(parts) != 2 or min(parts) <= 0:
        raise argparse.ArgumentTypeError(f"expected CONNECT,READ seconds, got {v}")
    return tuple(parts)


def _defined_tags(pairs):
    """--defined-tag Namespace.Key=value (repeatable) -> {"Namespace": {"Key": "value"}} for OCI defined tags.
    The namespace and key must already exist in the tenancy; OCI rejects unknown ones at create time."""
    out = {}
    for p in pairs or ():
        k, sep, v = p.partition("=")
        ns, dot, key = k.partition(".")
        if not (sep and dot and ns and key):
            raise Refused(f"--defined-tag must be Namespace.Key=value, got {p!r}")
        out.setdefault(ns, {})[key] = v
    return out


def _check_ocid(value, types, what):
    from ocio.ocid import problem
    p = problem(value, types)
    if p:
        raise Refused(f"{what}: {p}")


def _auth(a):
    """(config, signer) for --auth, refused if the session's region is not the reviewed --region. The region
    comes from the config profile (api_key, security_token) or from the signer (instance and resource
    principals: the region the instance or service runs in), so a profile or host in another region would
    otherwise send a reviewed plan to the wrong region."""
    from ocio import auth
    cfg, signer = auth.make(a.auth, a.profile, a.config)
    want = getattr(a, "region", None)
    if want and cfg.get("region") != want:
        raise Refused(f"the OCI session is in region {cfg.get('region')!r} but the reviewed plan is for --region "
                         f"{want!r}; use a profile (or host) in {want}, or review a plan for the other region. "
                         f"Nothing was sent")
    return cfg, signer


def _oci_session(a):
    """(config, signer) for --auth; and a helper that builds any client with SDK retries off and explicit
    timeouts, the same way the provider does."""
    import oci
    cfg, signer = _auth(a)

    def client(cls):
        kw = {"retry_strategy": oci.retry.NoneRetryStrategy(), "timeout": a.sdk_timeout}
        if signer is not None:
            kw["signer"] = signer
        return cls(cfg, **kw)
    return cfg, signer, client


def _check_ad(identity, tenancy_id, ad, compartment=None):
    """Refuse (SystemExit) an availability domain the tenancy does not have, listing the real ones. The listing
    takes the tenancy OCID or any compartment OCID (IdentityClient.list_availability_domains, oci 2.189.0), so a
    resource principal whose signer exposes no tenancy uses --compartment instead of sending None."""
    from ocio import tenancy
    where = tenancy_id or compartment
    if not where:
        raise Refused("cannot check the availability domain: the session gives no tenancy OCID and no compartment "
                         "was given")
    try:
        tenancy.check_availability_domain(identity, where, ad)
    except ValueError as e:
        raise Refused(str(e)) from None


def _shapes_stop(compute, a, placements, plan_id, out):
    """Live shape check (ocio.shapes) when there is a compute client: the real tenancy, or one a test
    injects. True (and the reasons printed) when a planned shape/size is not available in the AD."""
    if compute is None:
        return False
    from ocio import shapes
    problems = shapes.check(compute, a.compartment, a.availability_domain, placements)
    if problems:
        out(json.dumps({"stopped": problems, "plan_id": plan_id,
                        "note": "read live from list_shapes for this AD; nothing was created or changed"}, indent=2))
    return bool(problems)


def _load_json(path, kinds=(dict,)):
    """A JSON file's content, which must be one of kinds (a JSON object unless the option takes a list); a
    malformed file or the wrong shape is a ValueError naming the file, reported by main() without a traceback."""
    with open(path) as f:
        try:
            value = json.load(f)
        except json.JSONDecodeError as e:
            raise ValueError(f"{path}: not valid JSON ({e.msg} at line {e.lineno}, column {e.colno})") from None
    if not isinstance(value, kinds):
        want = " or ".join({dict: "an object {...}", list: "a list [...]"}[k] for k in kinds)
        raise ValueError(f"{path}: expected {want}, got {type(value).__name__}")
    return value


def _tags(pairs):
    out = {}
    for p in pairs or ():
        if "=" not in p:
            raise Refused(f"--tag must be key=value, got {p!r}")
        k, v = p.split("=", 1)
        out[k] = v
    return out


def cmd_discover(a, out):
    """`discover`: assets + flows (+ listeners, VIPs) -> findings JSON and a decisions template beside it.

    Writes the findings report to --out and '<out>.decisions-template.json' (high-confidence dependencies
    pre-accepted, low-confidence ones listed for review, a reviewed_by field). With --decisions, applies the
    reviewed decisions and writes the planning inventory CSV to --inventory-out; refusals there (unresolved
    private addresses, unknown or unnamed decisions) raise ValueError from discovery. Makes no OCI calls.
    Returns 0.
    """
    res = D.discover(D.load_assets(a.assets), D.load_flows(a.flows),
                     D.load_listeners(a.listeners) if a.listeners else None,
                     vips=D.load_vips(a.vips) if a.vips else None)
    rep = res.report()
    with open(a.out, "w") as f:
        json.dump(rep, f, indent=2)
    template = {"dependencies": {d["dep"]: "accept" for d in rep["dependencies"] if d["confidence"] >= 0.6},
                "_review_these_low_confidence": {d["dep"]: "accept or reject" for d in rep["dependencies"]
                                                 if d["confidence"] < 0.6},
                "apps": {}, "tiers": {},
                "reviewed_by": "",
                "_reviewed_by": "required if you reject a dependency, move a VM to another app or tier, or list a "
                                "private address under external_ok",
                "external_ok": [], "_unresolved_private_destinations": sorted({u["dst_ip"] for u in rep["unresolved_private_destinations"]}),
                "_unresolved_private_sources": sorted({u["src_ip"] for u in rep["unresolved_private_sources"]})}
    tpl = os.path.splitext(a.out)[0] + ".decisions-template.json"
    with open(tpl, "w") as f:
        json.dump(template, f, indent=2)
    out(f"findings: {a.out}  ({rep['vms']} VMs, {len(rep['apps'])} apps, {len(rep['dependencies'])} dependencies, "
        f"{len(rep['low_confidence_vms'])} low-confidence VMs, {len(rep['silent_vms'])} silent VMs, {len(rep['infrastructure_only_vms'])} infrastructure-only VMs, "
        f"{len(rep['unresolved_private_destinations'])} unresolved private destinations, "
        f"{len(rep['unresolved_private_sources'])} unresolved private sources)")
    out(f"decisions template: {tpl}  (edit it; move reviewed items into 'dependencies')")
    if a.decisions:
        dec = D.load_decisions(a.decisions)
        dec["dependencies"] = {k: v for k, v in dec.get("dependencies", {}).items()}
        wls, summary = res.to_workloads(dec)
        with open(a.inventory_out, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["name", "app", "tier", "os", "vcpus", "memory_gb", "depends_on_apps"])
            for x in wls:
                w.writerow([x.name, x.app, x.tier, x.os, x.vcpus, x.memory_gb, ";".join(x.depends_on_apps)])
        out(f"inventory: {a.inventory_out}  dependencies {summary}")
    return 0


def _bound(a):
    """Every input besides the plan itself that reaches an API call or gates one. Hashed into the plan id, so
    an approval for one reviewed dry run cannot be used with, say, another migration plan, other subnet
    OCIDs or a weaker admission policy. (The admission policy is added only when given, so plan ids without
    one are unchanged.)"""
    out = {}
    if a.cmd == "run":
        out = {"image_map": _load_json(a.image_map) if a.image_map else None,
               "resolved_images": getattr(a, "_resolved_images", None)}
    elif a.cmd == "ocm-wave":
        out = {"migration_plan": a.migration_plan, "wave": a.wave, "subnet_map": _load_json(a.subnet_map),
               "mapping": _load_json(a.mapping) if a.mapping else None}
    pol = _admission_policy(a)
    if pol is not None:
        out["admission_policy"] = pol
    if getattr(a, "region", None):
        out["region"] = a.region
    return out


def _admission_policy(a):
    if not getattr(a, "admission_policy", None):
        return None
    from ocio import admission
    try:
        return admission.check_policy(_load_json(a.admission_policy))
    except ValueError as e:
        raise Refused(f"--admission-policy: {e}") from None


def _admitter(a):
    """admit(wave, plan_id) for the pipeline, reading --admission at decision time (so each wave is judged
    against the clock when it is about to start), or None when there is no --admission-policy."""
    pol = _admission_policy(a)
    if pol is None:
        if getattr(a, "admission", None):
            raise Refused("--admission needs --admission-policy (which checks are required, and how fresh)")
        return None
    import time
    from ocio import admission

    def admit(wave, plan_id):
        docs = _load_json(a.admission, (dict, list)) if a.admission else []
        return admission.evaluate(plan_id, wave, docs if isinstance(docs, list) else [docs], pol, time.time())
    return admit


def _settings(a):
    return P.Settings(a.env, a.compartment or "ocid1.compartment.oc1..plan-only", _tags(a.tag), a.landing_name,
                      a.vcn_cidr, {"web": a.web_cidr, "app": a.app_cidr, "db": a.db_cidr},
                      availability_domain=a.availability_domain or "AD-1", max_apps_per_wave=a.max_apps_per_wave,
                      max_vms_per_wave=a.max_vms_per_wave, solo_apps=tuple(a.solo or ()),
                      max_customized_share=a.max_customized_share, quota_headroom=a.quota_headroom,
                      expected_plan_id=getattr(a, "plan_id", None), bound_inputs=_bound(a),
                      spread_fault_domains=not a.no_fault_domain_spread,
                      capacity_reservation_id=a.capacity_reservation, defined_tags=_defined_tags(a.defined_tag),
                      nsg_map=_nsg_map(a))


def _nsg_map(a):
    m = _load_json(a.nsg_map) if getattr(a, "nsg_map", None) else {}
    for k, v in m.items():
        _check_ocid(v, None, f"--nsg-map {k}")
    return m


def _flow_view(a, rep):
    """(observed flows, NSG plan) when --flows is given, else (None, None)."""
    from ocio import netpolicy as N
    if not getattr(a, "flows", None):
        return None, None
    if not a.assets:
        raise Refused("--flows needs --assets (to map addresses to VMs)")
    fl = N.observed_flows(D.load_assets(a.assets), D.load_flows(a.flows), D.load_vips(a.vips) if a.vips else None)
    return fl, N.build(rep.placements, fl)


def _cutover(a, rep, waves=None):
    """Per wave: flows that would be BLOCKED at cutover with the NSGs in --nsg-map (none, if not given), and
    hybrid flows that cross the site boundary while partners are still on the source site. Waves earlier
    than the one checked are assumed done. Returns None when no --flows was given."""
    from ocio import netpolicy as N
    fl, plan = _flow_view(a, rep)
    if fl is None:
        return None
    nsg = _nsg_map(a)
    out, done = [], []
    for i, apps in enumerate(rep.waves, start=1):
        vms = [p.workload.name for p in rep.placements if p.workload.app in apps]
        if waves is None or i in waves:
            r = N.check(plan, rep.placements, fl, vms, done, nsg)
            out.append({"wave": i, "apps": apps, **r})
        done += vms
    return out


def _inputs(a):
    wls = load_inventory(a.inventory)
    overrides = None
    if a.overrides:
        raw = _load_json(a.overrides)
        overrides = {k: {f: v for f, v in o.items() if not f.startswith("_")} for k, o in raw.items()}
    proposer = A.RuleProposer(BLUEPRINTS, _load_json(a.metrics) if a.metrics else None) if a.agent == "rule" else None
    if overrides and proposer:
        raise Refused("use --overrides or --agent, not both")
    return wls, overrides, proposer


def _print_plan(rep, out):
    out(json.dumps({"plan_id": rep.plan_id, "summary": rep.summary(), "refused": rep.refused,
                    "rejected_proposals": rep.rejected_proposals, "waves": rep.waves,
                    "deviation": F.deviation_report(rep.placements)}, indent=2, default=str))


def cmd_plan(a, out):
    """`plan`: inventory -> placements, deviations, refusals, waves and the plan id. Makes no OCI calls.

    Prints the plan. With --assets and --flows it also runs the cutover check against --nsg-map, as `run`
    does. Returns 0, or 2 if the plan has run-level stops or policy violations, or a wave's observed traffic
    would be denied at cutover.
    """
    if a.compartment:                              # same check as run / ocm-wave: the id goes into the plan id
        _check_ocid(a.compartment, ("compartment", "tenancy"), "--compartment")
    wls, overrides, proposer = _inputs(a)
    rep = P.run(wls, BLUEPRINTS, _settings(a), engine_factory=None, overrides=overrides, proposer=proposer,
                execute=False)
    _print_plan(rep, out)
    cut = _cutover(a, rep)                      # --assets/--flows given: the same cutover check as run
    if cut and any(w["blocked"] for w in cut):
        out(json.dumps({"stopped": "cutover would break observed traffic: these flows are not allowed by the NSGs "
                                   "in --nsg-map (run `netpolicy` to create them)", "plan_id": rep.plan_id,
                        "cutover": cut}, indent=2))
        return 2
    return 0 if not (rep.run_blocked or rep.policy_violations) else 2


def _resolve_images(a, wls, overrides, compute=None):
    """Resolve the symbolic images of the blueprints this inventory uses, per shape (an x86 image does not
    boot an Arm A1 shape), to the region's newest compatible platform images. Returns {"SYMBOL@SHAPE": OCID}."""
    from ocio import images
    spec = _load_json(a.resolve_images)
    if compute is None:
        import oci
        _, _, client = _oci_session(a)
        compute = client(oci.core.ComputeClient)
    pairs = set()
    for w in wls:
        try:
            p = F.place(w, BLUEPRINTS, (overrides or {}).get(w.name, {})).params
        except F.FactoryError:
            continue
        if p.get("image_id") in spec:
            pairs.add((p["image_id"], p["shape"]))
    out = {}
    for sym, shape in sorted(pairs):
        try:
            out[f"{sym}@{shape}"] = images.resolve(compute, a.compartment, {sym: spec[sym]}, shape)[sym]
        except ValueError as e:
            raise Refused(str(e)) from None
    return out


def cmd_run(a, out, provider_factory=None, quota=None, approver=None, inject_compute=None, identity=None,
            shape_compute=None):
    """`run`: the rebuild path. Dry run prints the plan; --apply executes it wave by wave.

    Before anything is created: compartment, capacity reservation and image OCIDs are checked; --apply needs
    the reviewed --plan-id; on a real tenancy the AD is checked against the tenancy and every planned shape
    against list_shapes for that AD; the cutover check runs when flows are given. The pipeline then applies
    quota preflight, policy gates, admission (if a policy is given) and approval per wave, journalling each
    decision. The keyword arguments inject test doubles (provider, quota, approver, compute, identity) in place
    of the real OCI session. Exit codes: 0 every wave succeeded (or a clean dry run); 1 a wave did not
    succeed; 2 stopped before any API call (plan mismatch, policy, shapes, cutover, admission of wave 1).
    """
    if not (a.compartment and a.availability_domain):
        raise Refused("run needs --compartment and --availability-domain")
    _check_ocid(a.compartment, ("compartment", "tenancy"), "--compartment")
    if a.capacity_reservation:
        _check_ocid(a.capacity_reservation, None, "--capacity-reservation")
    for sym, img in (_load_json(a.image_map) if a.image_map else {}).items():
        _check_ocid(img, ("image",), f"--image-map {sym}")
    if a.apply and not a.plan_id:
        raise Refused("run --apply needs --plan-id (printed by the dry run of this same command), so it executes "
                         "only the reviewed plan")
    wls, overrides, proposer = _inputs(a)
    if a.resolve_images:                       # read-only lookups; the result is part of the plan id
        a._resolved_images = _resolve_images(a, wls, overrides, inject_compute)
    s = _settings(a)
    if not a.apply:
        rep = P.run(wls, BLUEPRINTS, s, engine_factory=None, overrides=overrides, proposer=proposer, execute=False)
        _print_plan(rep, out)
        cut = _cutover(a, rep)
        if cut and any(w["blocked"] for w in cut):
            out(json.dumps({"stopped": "cutover would break observed traffic: these flows are not allowed by the "
                                       "NSGs in --nsg-map (run `migrate.py netpolicy` to create them)",
                            "plan_id": rep.plan_id, "cutover": cut}, indent=2))
            return 2
        out("DRY RUN: nothing was created. Add --apply to execute (quota check and approvals still apply).")
        return 0 if not (rep.run_blocked or rep.policy_violations) else 2      # same rule as `plan`
    image_map = None
    if provider_factory is None:               # the real tenancy: check the AD before anything is created
        import oci
        cfg, signer, client = _oci_session(a)
        _check_ad(identity or client(oci.identity.IdentityClient), cfg.get("tenancy"), a.availability_domain, a.compartment)
        image_map = dict(_load_json(a.image_map) if a.image_map else {}, **(getattr(a, "_resolved_images", None) or {}))

        shape_compute = shape_compute or client(oci.core.ComputeClient)

        def provider_factory():
            from ocio.providers import OCISDKProvider
            return OCISDKProvider(config=cfg, signer=signer, availability_domain=a.availability_domain,
                                  image_map=image_map, timeout=a.sdk_timeout)
    if quota is None:
        if a.quota_file:
            quota = C.StaticQuota(_load_json(a.quota_file))
        else:
            cfg, signer = _auth(a)
            quota = C.OCILimitsQuota(a.compartment, config=cfg, signer=signer, service_name=a.limits_service,
                                     timeout=a.sdk_timeout)
    if approver is None:
        def approver(name, reasons, plan, wave_hash):
            if a.approve_by:                   # plan id already checked by the pipeline before any wave runs
                out(f"{name}: pre-approved by {a.approve_by} (plan {a.plan_id}) for: {reasons}")
                return True, a.approve_by
            out(f"\n{name} needs approval: {reasons}  (plan {a.plan_id})")
            for x in plan["actions"]:
                q = x["params"]
                out(f"  create {x['kind']} {x['step']}: {q.get('shape')} {q.get('ocpus')} OCPU {q.get('memory_gbs')} GB, "
                    f"subnet {q.get('subnet_id')}, public IP {q.get('assign_public_ip')}")
            try:
                who = input("Type your name to approve, or press Enter to stop: ").strip()
            except EOFError:                   # no terminal (cron, CI, piped input): not approved
                out(f"{name}: no terminal to ask for approval; not approved. Use --approve-by NAME to pre-approve.")
                return False, ""
            return bool(who), who
    dry = P.run(wls, BLUEPRINTS, s, None, overrides=overrides, proposer=proposer, execute=False)
    if _shapes_stop(shape_compute, a, dry.placements, dry.plan_id, out):
        return 2
    if image_map is not None:                    # every launch must have its image, and Arm an Arm one
        missing = F.image_problems(dry.placements, image_map)
        if missing:
            out(json.dumps({"stopped": missing, "plan_id": dry.plan_id, "note": "nothing was created"}, indent=2))
            return 2
    cut = _cutover(a, dry)
    if cut and any(w["blocked"] for w in cut):
        out(json.dumps({"stopped": "cutover would break observed traffic (see cutover); nothing was created",
                        "cutover": cut}, indent=2))
        return 2
    provider = provider_factory()
    limiter = C.AdaptiveLimiter(initial=4, maximum=a.max_in_flight)
    journal_path = a.journal

    def mk():
        return Engine(provider, Journal(journal_path), max_workers=a.max_in_flight, limiter=limiter)
    rep = P.run(wls, BLUEPRINTS, s, mk, quota=quota, approver=approver, overrides=overrides, proposer=proposer,
                admit=_admitter(a))
    if rep.run_blocked or rep.policy_violations:          # stopped before any API call
        out(json.dumps({"stopped": rep.run_blocked + rep.policy_violations, "plan_id": rep.plan_id}, indent=2))
        return 2
    out(json.dumps({"summary": rep.summary(), "waves": rep.wave_results, "journal": os.path.abspath(journal_path),
                    "journal_intact": Journal(journal_path).verify(), "journal_break": Journal(journal_path).verify_detail()}, indent=2, default=str))
    return 0 if rep.wave_results and all(w["status"] == "SUCCEEDED" for w in rep.wave_results) else 1


def cmd_ocm_wave(a, out, client=None, quota=None, identity=None, shape_compute=None):
    """`ocm-wave`: the migration path. Writes one wave's blueprint settings into an OCM migration plan.

    Dry run prints each target asset's planned update and the plan id; nothing is sent. --apply, in this order:
    reviewed --plan-id, quota preflight, AD and live shape checks (real tenancy), dependency gate (earlier
    waves' VMs must already have target instances, or be confirmed with --dependencies-done-by), approval
    (--approve-by when the wave needs it), admission evidence (if a policy is given); then OCMDriver.apply_wave
    with the before-state journalled first. Every decision and the outcome go to the journal. client, quota,
    identity and shape_compute inject test doubles. Executing the migration plan stays an OCM action. Exit
    codes: 0 applied and verified; 1 an OCM call or check failed (the plan may be part-way updated: do not
    execute it); 2 stopped before any change.
    """
    try:
        import oci
    except ImportError:
        raise Refused("ocm-wave needs the OCI Python SDK even for a dry run (it builds the real OCM request models): "
                      "pip install \"oci==2.189.0\"") from None
    _check_ocid(a.compartment, ("compartment", "tenancy"), "--compartment")
    _check_ocid(a.migration_plan, None, "--migration-plan")
    if a.capacity_reservation:
        _check_ocid(a.capacity_reservation, None, "--capacity-reservation")
    for key, sid in _load_json(a.subnet_map).items():
        if key not in F.TIER_SUBNETS.values():
            raise Refused(f"--subnet-map: unknown key {key!r}; use {sorted(F.TIER_SUBNETS.values())}")
        _check_ocid(sid, ("subnet",), f"--subnet-map {key}")
    for vm, tid in (_load_json(a.mapping) if a.mapping else {}).items():
        _check_ocid(tid, None, f"--mapping {vm}")
    wls, overrides, proposer = _inputs(a)
    rep = P.run(wls, BLUEPRINTS, _settings(a), engine_factory=None, overrides=overrides, proposer=proposer,
                execute=False)
    if rep.run_blocked or rep.policy_violations:
        out(json.dumps({"stopped": rep.run_blocked + rep.policy_violations, "plan_id": rep.plan_id}, indent=2))
        return 2
    if not 1 <= a.wave <= len(rep.waves):
        raise Refused(f"--wave {a.wave} does not exist: the plan has {len(rep.waves)} waves: "
                         + "; ".join(f"{i}: {w}" for i, w in enumerate(rep.waves, start=1)))
    apps = rep.waves[a.wave - 1]
    wave = [p for p in rep.placements if p.workload.app in apps]
    subnets = _load_json(a.subnet_map)
    mapping = _load_json(a.mapping) if a.mapping else None
    m = oci.cloud_migrations.models
    s = _settings(a)
    fds = F.fault_domains(wave) if s.spread_fault_domains else {}
    preview = {p.workload.name: oci.util.to_dict(O.target_asset_update(
        m, p, subnets, a.compartment, a.availability_domain, fault_domain=fds.get(p.workload.name), tags=_tags(a.tag),
        capacity_reservation_id=s.capacity_reservation_id, defined_tags=s.defined_tags or None,
        nsg_ids=[s.nsg_map[k]] if (k := f"{p.workload.app}-{p.workload.tier}") in s.nsg_map else None)) for p in wave}
    cut = _cutover(a, rep, waves={a.wave})
    if cut and cut[0]["blocked"]:
        out(json.dumps({"stopped": f"cutover of wave {a.wave} would break observed traffic: flows not allowed by the "
                                   f"NSGs in --nsg-map (run `migrate.py netpolicy`)", "plan_id": rep.plan_id,
                        "cutover": cut}, indent=2))
        return 2
    if not a.apply:
        out(json.dumps({"plan_id": rep.plan_id, "wave": a.wave, "apps": apps, "target_asset_updates": preview,
                        "cutover": cut,
                        "note": "DRY RUN: nothing sent to OCM. --apply --plan-id <this id> updates the migration "
                                "plan's target assets; executing the plan stays an OCM action."}, indent=2, default=str))
        return 0
    # Same rules as `run`: --apply changes a real migration plan, so it must name the reviewed plan, the
    # launch it prepares must fit the quota, and a wave that needs approval (prod, subnet move, >2x
    # growth) must name who approved it. Approval and result go to the hash-chained journal.
    if not a.plan_id:
        raise Refused("ocm-wave --apply needs --plan-id (from the dry run), so it changes only the reviewed plan")
    if quota is None:
        if a.quota_file:
            quota = C.StaticQuota(_load_json(a.quota_file))
        else:
            cfg, signer = _auth(a)
            quota = C.OCILimitsQuota(a.compartment, config=cfg, signer=signer, service_name=a.limits_service,
                                     timeout=a.sdk_timeout)
    planned = {k: {"id": v} for k, v in subnets.items()}
    wf = F.wave_workflow(a.wave, apps, wave, planned, a.env, a.compartment, _tags(a.tag), **P._wave_opts(s))
    shortfall = C.preflight(wf, quota, a.availability_domain, a.quota_headroom)
    if shortfall:
        out(json.dumps({"stopped": shortfall, "plan_id": rep.plan_id}, indent=2))
        return 2
    # Dependencies first: every VM of an app this wave depends on must already have its target instance.
    deps = {}
    for p in rep.placements:
        deps.setdefault(p.workload.app, set()).update(p.workload.depends_on_apps)
    dep_apps = sorted(P._closure(apps, deps) - set(apps))
    dep_vms = [p.workload.name for p in rep.placements if p.workload.app in dep_apps]
    if client is None:                         # the real tenancy: check the AD before changing the plan
        cfg, signer, mk_client = _oci_session(a)
        _check_ad(identity or mk_client(oci.identity.IdentityClient), cfg.get("tenancy"), a.availability_domain, a.compartment)
        client = mk_client(oci.cloud_migrations.MigrationClient)
        shape_compute = shape_compute or mk_client(oci.core.ComputeClient)
    if _shapes_stop(shape_compute, a, wave, rep.plan_id, out):
        return 2
    driver = O.OCMDriver(client, a.migration_plan, m)
    j = Journal(a.journal)
    pending = driver.not_migrated(dep_vms, mapping) if dep_vms else []
    if pending and not a.dependencies_done_by:
        out(json.dumps({"stopped": [f"wave {a.wave} depends on {dep_apps}; not yet migrated in this plan: {pending}. "
                                    f"Migrate them first, or, if they were migrated elsewhere, confirm with "
                                    f"--dependencies-done-by NAME"], "plan_id": rep.plan_id}, indent=2))
        return 2
    if pending:
        j.append(event="dependencies_confirmed", workflow=f"ocm-{a.migration_plan}-wave-{a.wave}", plan_id=rep.plan_id,
                 by=a.dependencies_done_by, vms=pending)
    reasons = A.approval_reasons(a.env, wave)
    if reasons and not a.approve_by:
        out(json.dumps({"stopped": [f"wave {a.wave} needs approval: {reasons}; re-run with --approve-by NAME"],
                        "plan_id": rep.plan_id}, indent=2))
        return 2
    if reasons:
        j.append(event="approval", workflow=f"ocm-{a.migration_plan}-wave-{a.wave}", plan_id=rep.plan_id,
                 approved=True, by=a.approve_by, reasons=reasons)
    admit = _admitter(a)                        # the same admission gate as `run`, for this one wave
    if admit is not None:
        adm = admit(a.wave, rep.plan_id)
        j.append(event="admission", workflow=f"ocm-{a.migration_plan}-wave-{a.wave}", plan_id=rep.plan_id, wave=a.wave,
                 allowed=bool(adm["allowed"]), reasons=adm["reasons"], evidence_hash=adm["evidence_hash"])
        if not adm["allowed"]:
            out(json.dumps({"stopped": [f"wave {a.wave} is not admitted: {adm['reasons']}"], "plan_id": rep.plan_id,
                            "admission": adm}, indent=2))
            return 2
    try:
        res = driver.apply_wave(wave, subnets, a.compartment, a.availability_domain, mapping, tags=_tags(a.tag),
                                fault_domains=fds, capacity_reservation_id=s.capacity_reservation_id,
                                defined_tags=s.defined_tags or None, nsg_map=s.nsg_map,
                                on_before=lambda snap: j.append(
                                    event="ocm_before_state", migration_plan=a.migration_plan, wave=a.wave,
                                    plan_id=rep.plan_id, assets=snap))
    except (O.OCMError, ValueError, F.FactoryError) as e:
        j.append(event="ocm_wave_failed", migration_plan=a.migration_plan, wave=a.wave, plan_id=rep.plan_id, error=str(e))
        out(json.dumps({"failed": str(e), "plan_id": rep.plan_id, "journal": os.path.abspath(a.journal)}, indent=2))
        return 1
    j.append(event="ocm_wave_applied", migration_plan=a.migration_plan, wave=a.wave, plan_id=rep.plan_id,
             updated=res["updated"], excluded=res["excluded"])
    out(json.dumps({"plan_id": rep.plan_id, "wave": a.wave, "apps": apps,
                    "approval": {"by": a.approve_by, "reasons": reasons} if reasons else None,
                    "journal": os.path.abspath(a.journal), **res}, indent=2, default=str))
    return 0


def parser():
    """The argparse parser for every command. Option abbreviations are disabled (see the end of this function),
    so a prefix can never silently select a different option.
    """
    ap = argparse.ArgumentParser(prog="ocio", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--version", action="version", version=f"ocio {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("discover")
    d.add_argument("--assets", required=True); d.add_argument("--flows", required=True)
    d.add_argument("--listeners"); d.add_argument("--vips", help="CSV vip,name: VIP / SCAN addresses -> VMs")
    d.add_argument("--out", default="findings.json")
    d.add_argument("--decisions"); d.add_argument("--inventory-out", default="inventory.csv")
    t = sub.add_parser("teardown", help="delete what one run created (dry run unless --apply)")
    t.add_argument("--journal", required=True); t.add_argument("--run-id", required=True)
    t.add_argument("--apply", action="store_true")
    t.add_argument("--profile", default="DEFAULT"); t.add_argument("--config", default="~/.oci/config")
    t.add_argument("--auth", choices=["api_key", "security_token", "instance_principal", "resource_principal"],
                   default="api_key")
    t.add_argument("--sdk-timeout", type=_timeout, default=(10.0, 60.0))
    o = sub.add_parser("ocm-restore", help="put OCM target assets back as journalled before an ocm-wave --apply")
    o.add_argument("--journal", required=True); o.add_argument("--migration-plan", required=True)
    o.add_argument("--wave", type=int, help="restore the before-state of this wave (default: the latest)")
    o.add_argument("--apply", action="store_true"); o.add_argument("--restore-id")
    o.add_argument("--profile", default="DEFAULT"); o.add_argument("--config", default="~/.oci/config")
    o.add_argument("--auth", choices=["api_key", "security_token", "instance_principal", "resource_principal"],
                   default="api_key")
    o.add_argument("--sdk-timeout", type=_timeout, default=(10.0, 60.0))
    u = sub.add_parser("ui", help="open the one-click launch console in the browser (local only)")
    u.add_argument("--workdir", default=".", help="folder commands run in; relative paths start here")
    u.add_argument("--port", type=int, default=0, help="default: any free port")
    u.add_argument("--no-browser", action="store_true", help="print the address instead of opening it")
    u.add_argument("--write", metavar="HTML", help="write the console (the wrapper, offline) as one HTML file and exit")
    u.add_argument("--inventory", help="inventory the console shows and plans (default: examples/inventory.csv)")
    u.add_argument("--env", default="dev", choices=["dev", "test", "prod"], help="environment the console plans for")
    u.add_argument("--assets", help="assets.csv for the console's Discovery page (default: examples/estate/)")
    u.add_argument("--flows", help="flows.csv for the console's Discovery page (default: examples/estate/)")
    st = sub.add_parser("status", help="read-only summary of a journal: integrity, runs, resources, events")
    st.add_argument("--journal", required=True)
    r = sub.add_parser("resolve", help="record that a resource the journal lists is confirmed gone")
    r.add_argument("--journal", required=True); r.add_argument("--step", required=True)
    r.add_argument("--id", required=True); r.add_argument("--by", required=True, type=_person)
    for name in ("plan", "run", "ocm-wave", "netpolicy"):
        p = sub.add_parser(name)
        p.add_argument("--inventory", required=True); p.add_argument("--overrides")
        p.add_argument("--agent", choices=["rule"]); p.add_argument("--metrics")
        p.add_argument("--env", default="prod", choices=["dev", "test", "prod"])
        p.add_argument("--compartment"); p.add_argument("--availability-domain")
        p.add_argument("--tag", action="append", default=[],
                       help="key=value, repeatable. No defaults: the required-tags policy decides what is missing")
        p.add_argument("--landing-name", default="mig"); p.add_argument("--vcn-cidr", default="10.20.0.0/16")
        p.add_argument("--web-cidr", default="10.20.1.0/24"); p.add_argument("--app-cidr", default="10.20.2.0/24")
        p.add_argument("--db-cidr", default="10.20.3.0/24")
        p.add_argument("--max-apps-per-wave", type=_positive_int, default=3)
        p.add_argument("--max-vms-per-wave", type=_positive_int)
        p.add_argument("--solo", action="append", help="app that must move in a wave of its own (repeatable)")
        p.add_argument("--max-customized-share", type=_fraction(), default=0.3)
        p.add_argument("--defined-tag", action="append", default=[],
                       help="Namespace.Key=value, repeatable: OCI defined tags on everything created")
        p.add_argument("--capacity-reservation", help="OCID of a compute capacity reservation to launch under")
        p.add_argument("--no-fault-domain-spread", action="store_true",
                       help="let OCI choose fault domains instead of spreading each app tier over all three")
        p.add_argument("--assets", help="assets.csv: with --flows, checks every wave's cutover against observed traffic")
        p.add_argument("--flows", help="flows.csv (as for discover)")
        p.add_argument("--vips", help="vips.csv (as for discover)")
        p.add_argument("--nsg-map", help="JSON {app-tier: NSG OCID} written by `netpolicy --apply`; VNICs join them")
        p.add_argument("--region", help="the region this plan is for, e.g. us-phoenix-1: part of the plan id, and "
                                        "--apply refuses an OCI session in any other region")
        if name != "netpolicy":
            p.add_argument("--admission-policy", help="JSON {required_checks: [...], max_age_seconds: N}: each wave "
                                                      "needs fresh, named evidence bound to the plan id (part of it)")
        if name in ("run", "ocm-wave"):            # evidence gates execution; `plan` changes nothing
            p.add_argument("--admission", help="JSON evidence document(s) {plan_id, wave, observed_at, checks: "
                                               "[{name, passed, observer, source_ref}]}; see examples/")
        if name == "netpolicy":
            p.add_argument("--apply", action="store_true")
            p.add_argument("--policy-id", help="policy id printed by the dry run; required with --apply")
            p.add_argument("--vcn", help="OCID of the target VCN the NSGs belong to")
            p.add_argument("--nsg-map-out", default="nsg-map.json")
            p.add_argument("--journal", default="ocio-netpolicy.jsonl")
            p.add_argument("--auth", choices=["api_key", "security_token", "instance_principal", "resource_principal"],
                           default="api_key")
            p.add_argument("--sdk-timeout", type=_timeout, default=(10.0, 60.0))
            p.add_argument("--profile", default="DEFAULT"); p.add_argument("--config", default="~/.oci/config")
        p.add_argument("--quota-headroom", type=_fraction(hi_open=True), default=0.1)
        if name == "ocm-wave":
            p.add_argument("--wave", type=int, required=True)
            p.add_argument("--migration-plan", required=True, help="OCID of the OCM migration plan")
            p.add_argument("--subnet-map", required=True, help="JSON: subnet_web/subnet_app/subnet_db -> subnet OCID")
            p.add_argument("--mapping", help="JSON: source VM name -> target asset OCID (else matched by name)")
            p.add_argument("--dependencies-done-by", type=_person, help="confirm, as this person, that the VMs this wave depends on "
                                                          "were migrated outside this plan (journalled)")
            p.add_argument("--profile", default="DEFAULT"); p.add_argument("--config", default="~/.oci/config")
        if name in ("run", "ocm-wave"):
            p.add_argument("--auth", choices=["api_key", "security_token", "instance_principal", "resource_principal"],
                           default="api_key", help="how to authenticate to OCI (see ocio/auth.py)")
            p.add_argument("--sdk-timeout", type=_timeout, default=(10.0, 60.0),
                           help="CONNECT,READ seconds for every OCI call (SDK defaults: 10,60)")
            p.add_argument("--quota-file", help="JSON: limit name -> available (instead of reading the Limits API)")
            p.add_argument("--limits-service", default="compute")
            p.add_argument("--journal", default="ocio-run.jsonl" if name == "run" else "ocio-ocm.jsonl")
            p.add_argument("--apply", action="store_true")
            p.add_argument("--approve-by", type=_person, help="pre-approve, as this person, the waves of the plan named by --plan-id")
            p.add_argument("--plan-id", help="plan id printed by the dry run; required with --approve-by (and with "
                                             "ocm-wave --apply). Stops if the plan has changed since it was reviewed")
        if name == "run":
            p.add_argument("--image-map", help="JSON: symbolic image name -> image OCID for this region")
            p.add_argument("--resolve-images", help="JSON: symbolic image -> {operating_system, operating_system_version}; "
                                                    "resolved to the region's newest compatible platform image per shape")
            p.add_argument("--max-in-flight", type=_positive_int, default=16)
            p.add_argument("--profile", default="DEFAULT"); p.add_argument("--config", default="~/.oci/config")
    # No abbreviations: argparse otherwise accepts any unambiguous prefix, so `--admission` would silently mean
    # `--admission-policy` on a command without the former, and `--appr` would mean `--approve-by`.
    ap.allow_abbrev = False
    for sp in sub.choices.values():
        sp.allow_abbrev = False
    return ap


def cmd_netpolicy(a, out, net_client=None):
    """Least-privilege NSGs from observed traffic (see ocio/netpolicy.py). Dry run: the NSGs, the rules, how
    much traffic the default security list would deny, and per wave the hybrid flows the network team must
    route. --apply --policy-id <id from the dry run> --vcn <VCN OCID> creates the NSGs and converges their
    rules, journals it, and writes --nsg-map-out for `run` / `ocm-wave --nsg-map`."""
    import hashlib
    from ocio import netpolicy as N
    wls, overrides, proposer = _inputs(a)
    rep = P.run(wls, BLUEPRINTS, _settings(a), None, overrides=overrides, proposer=proposer, execute=False)
    fl, plan = _flow_view(a, rep)
    if fl is None:
        raise Refused("netpolicy needs --assets and --flows")
    names = {n: n for n in plan.members}                  # as if every planned NSG exists
    waves = []
    done = []
    for i, apps in enumerate(rep.waves, start=1):
        vms = [p.workload.name for p in rep.placements if p.workload.app in apps]
        r = N.check(plan, rep.placements, fl, vms, done, names)
        waves.append({"wave": i, "apps": apps, "hybrid": r["hybrid"], "blocked_with_plan": r["blocked"]})
        done += vms
    report = dict(plan.report(), default_security_list=N.default_list_blocks(rep.placements, fl), waves=waves)
    pid = hashlib.sha256(json.dumps(plan.report(), sort_keys=True).encode()).hexdigest()[:12]
    if not a.apply:
        out(json.dumps(dict(report, policy_id=pid, note="DRY RUN: nothing created. --apply --policy-id <this id> "
                                                         "--vcn <VCN OCID> creates the NSGs and rules."), indent=2))
        return 0
    if a.policy_id != pid:
        raise Refused(f"--policy-id {a.policy_id} is not the reviewed policy {pid}; review the dry run again")
    _check_ocid(a.vcn, ("vcn",), "--vcn")
    _check_ocid(a.compartment, ("compartment", "tenancy"), "--compartment")
    import oci
    if net_client is None:
        _, _, client = _oci_session(a)
        net_client = client(oci.core.VirtualNetworkClient)
    j = Journal(a.journal)
    existing = _load_json(a.nsg_map_out) if os.path.exists(a.nsg_map_out) else {}
    known = dict(existing)

    def save(name=None, nsg_id=None):                   # after every create, before the next call can fail
        if name is not None:
            known[name] = nsg_id
        tmp = a.nsg_map_out + ".tmp"
        with open(tmp, "w") as f:
            json.dump(known, f, indent=2)
        os.replace(tmp, a.nsg_map_out)
    ids = N.apply(net_client, oci.core.models, plan, a.compartment, a.vcn, tags=_tags(a.tag),
                  defined_tags=_defined_tags(a.defined_tag) or None, existing=existing, journal=j, on_created=save)
    known = dict(ids)
    save()
    out(json.dumps({"policy_id": pid, "nsg_map": os.path.abspath(a.nsg_map_out), "nsgs": ids,
                    "journal_intact": j.verify(), "journal_break": j.verify_detail()}, indent=2))
    return 0


def cmd_teardown(a, out, provider_factory=None):
    """Delete what one run created and may still exist (including resources whose rollback failed),
    newest first. Dry run unless --apply. The remedy for BLOCKED_STATE and BLOCKED_CHANGED."""
    j = Journal(a.journal)
    st = j.state(a.run_id)
    if not any(e.get("run_id") == a.run_id and e.get("event") == "run_started" for e in j.entries):
        raise Refused(f"run {a.run_id} is not in {a.journal}")
    todo = [{"step": sid, "id": v.get("outputs", {}).get("id"), "status": v["status"]} for sid, v in sorted(st.items())
            if v.get("status") in ("created", "ready", "rollback_failed", "creating", "create_unconfirmed")]
    if not a.apply:
        out(json.dumps({"run_id": a.run_id, "would_delete_or_report": todo,
                        "note": "DRY RUN. Add --apply to delete; unconfirmed creates are reported with their tags."},
                       indent=2))
        return 0
    if provider_factory is None:
        def provider_factory():
            import oci
            from ocio.providers import OCISDKProvider
            cfg, signer = _auth(a)
            return OCISDKProvider(config=cfg, signer=signer, timeout=a.sdk_timeout)
    res = Engine(provider_factory(), j).teardown(None, a.run_id)
    out(json.dumps({"run_id": a.run_id, "status": res.status, "deleted": res.rolled_back, "orphans": res.orphans},
                   indent=2, default=str))
    return 0 if res.status == "TORN_DOWN" else 1


def cmd_ocm_restore(a, out, client=None):
    """Put an OCM migration plan's target assets back as they were before an `ocm-wave --apply`, from the
    before-state that command journalled first (event ocm_before_state). Dry run shows what would be sent
    and prints a restore_id; --apply needs that id, so only the reviewed restore runs. Journalled."""
    import hashlib
    _check_ocid(a.migration_plan, None, "--migration-plan")
    j = Journal(a.journal)
    snaps = [e for e in j.entries if e.get("event") == "ocm_before_state" and e.get("migration_plan") == a.migration_plan
             and (a.wave is None or e.get("wave") == a.wave)]
    if not snaps:
        raise Refused(f"{a.journal} has no before-state for migration plan {a.migration_plan}"
                         + (f" wave {a.wave}" if a.wave is not None else ""))
    e = snaps[-1]
    rid = hashlib.sha256(e["hash"].encode()).hexdigest()[:12]
    summary = {"restore_id": rid, "from_entry": e["hash"], "wave": e.get("wave"), "plan_id": e.get("plan_id"),
               "assets": {tid: {"is_excluded_from_execution": st["is_excluded_from_execution"],
                                "user_spec": "as journalled" if st.get("user_spec") is not None else
                                "was empty: current one kept (the API cannot clear it)"}
                          for tid, st in sorted(e["assets"].items())}}
    if not a.apply:
        out(json.dumps(dict(summary, note="DRY RUN: nothing sent. --apply --restore-id <this id> restores these "
                                           "assets, exclusions first"), indent=2))
        return 0
    if a.restore_id != rid:
        raise Refused("ocm-restore --apply needs --restore-id from the dry run of this same command (the latest "
                         "before-state may have changed since)")
    if client is None:
        import oci
        _, _, mk_client = _oci_session(a)
        client = mk_client(oci.cloud_migrations.MigrationClient)
    try:
        res = O.OCMDriver(client, a.migration_plan).restore(e["assets"])
    except (O.OCMError, ValueError) as ex:
        j.append(event="ocm_restore_failed", migration_plan=a.migration_plan, from_entry=e["hash"], error=str(ex))
        out(json.dumps({"failed": str(ex), "journal": os.path.abspath(a.journal)}, indent=2))
        return 1
    j.append(event="ocm_restored", migration_plan=a.migration_plan, from_entry=e["hash"], restored=res["restored"])
    out(json.dumps(dict(summary, **res), indent=2))
    return 0


def cmd_status(a, out):
    """Read-only summary of a journal: integrity (and where it breaks), runs, what exists, approvals and
    admissions, OCM changes. Safe to run while another process holds the journal: it takes no lock."""
    if not os.path.exists(a.journal):
        raise Refused(f"no journal at {a.journal}")
    j = Journal(a.journal)
    events = {}
    for e in j.entries:
        events[e.get("event")] = events.get(e.get("event"), 0) + 1
    started = j.runs_started()
    ended = {e["run_id"]: j.run_end(e["run_id"]) for e in started}
    exist = j.existing()
    out(json.dumps({
        "journal": os.path.abspath(a.journal), "entries": len(j.entries), "head": j.head,
        "chain_intact": j.verify(), "chain_break": j.verify_detail(),
        "runs": {"started": len(started), "open": sum(1 for v in ended.values() if v is None),
                 "ended": {k: sum(1 for v in ended.values() if v == k)
                           for k in ("run_succeeded", "run_failed", "run_torn_down")},
                 "open_run_ids": [e["run_id"] for e in started if ended[e["run_id"]] is None]},
        "resources_existing": len(exist),
        "resources_uncertain": sorted(k for k, v in exist.items() if v.get("uncertain")),
        "events": dict(sorted(events.items(), key=lambda kv: str(kv[0]))),
        "note": "head is the hash of the last entry: record it somewhere else to make later edits detectable",
    }, indent=2))
    return 0


def cmd_resolve(a, out):
    """Record, in the journal, that an operator confirmed a resource is gone (for when OCI no longer shows
    it, e.g. a 404 that could also mean 'not authorized'). Audited: who, when, which OCID."""
    j = Journal(a.journal)
    live = P.existing_steps(j).get(a.step)
    if not live or live["id"] != a.id:
        raise Refused(f"the journal does not show {a.step} as existing with id {a.id}; nothing to resolve")
    j.append(run_id=live["run_id"], step=a.step, event="observed_gone", outputs={"id": a.id}, by=a.by,
             note="confirmed gone by operator")
    out(f"recorded: {a.step} ({a.id}) confirmed gone by {a.by}")
    return 0


def main(argv=None, out=print, **inject):
    """Entry point: parse argv, run the command, return its exit code. `out` receives each line of output.

    Commands that write a journal (--apply, and resolve) hold it exclusively for their whole run, so a second
    orchestrator on the same journal is refused. A busy or damaged journal ends with SystemExit carrying the
    reason (no traceback). `inject` passes test doubles through to the command handlers.
    """
    from ocio.journal import exclusive, JournalError
    a = parser().parse_args(argv)
    try:
        if a.cmd == "resolve" or getattr(a, "apply", False):     # anything that writes the journal: one writer
            with exclusive(a.journal):
                return _dispatch(a, out, inject)
        return _dispatch(a, out, inject)
    except JournalError as e:              # busy (another writer) or damaged (says which line): no traceback
        print(f"ocio {a.cmd}: {e}", file=sys.stderr)
        raise Refused(str(e)) from None
    except Refused as e:                   # SystemExit with an int code prints nothing: say why, then exit 2
        print(f"ocio {a.cmd}: {e}", file=sys.stderr)
        raise
    except _INPUT_ERRORS as e:             # a missing or malformed input, a bad OCI profile: one line, exit 2
        if os.environ.get("OCIO_DEBUG"):
            raise
        print(f"ocio {a.cmd}: {_describe(e)}", file=sys.stderr)
        return 2


def _oci_client_error():
    try:
        import oci
        return (oci.exceptions.ClientError,)
    except ImportError:
        return ()


_INPUT_ERRORS = (OSError, ValueError) + _oci_client_error()


def _describe(e):
    """One line for an input error: the file for file errors, otherwise the message (OCIO_DEBUG=1 shows the
    traceback instead)."""
    if isinstance(e, FileNotFoundError):
        return f"no such file: {e.filename}"
    if isinstance(e, PermissionError):
        return f"not allowed to read or write {e.filename}"
    return str(e) or type(e).__name__


def _dispatch(a, out, inject):
    if a.cmd == "resolve":
        return cmd_resolve(a, out)
    if a.cmd == "status":
        return cmd_status(a, out)
    if a.cmd == "ui":
        from ocio.ui import launch
        state = launch.wrapper_state(a.workdir, a.inventory, a.env, a.assets, a.flows)
        if a.write:
            with open(a.write, "w", encoding="utf-8") as f:
                f.write(launch.wrapper_page(state))
            out(f"wrote {a.write}: the console, offline (inspect, review, export; the launcher builds commands to copy)")
            return 0
        return launch.serve(a.workdir, a.port, not a.no_browser, out, state=state)
    if a.cmd == "ocm-restore":
        return cmd_ocm_restore(a, out, client=inject.get("ocm_client"))
    if a.cmd == "netpolicy":
        return cmd_netpolicy(a, out, net_client=inject.get("net_client"))
    if a.cmd == "teardown":
        return cmd_teardown(a, out, provider_factory=inject.get("provider_factory"))
    if a.cmd == "discover":
        return cmd_discover(a, out)
    if a.cmd == "plan":
        return cmd_plan(a, out)
    if a.cmd == "ocm-wave":
        if not (a.compartment and a.availability_domain):
            raise Refused("ocm-wave needs --compartment and --availability-domain")
        return cmd_ocm_wave(a, out, client=inject.get("ocm_client"), quota=inject.get("quota"),
                            shape_compute=inject.get("shape_compute"))
    return cmd_run(a, out, **inject)


if __name__ == "__main__":
    sys.exit(main())
