"""Migration factory: the "cookie cutter with customization as needed" layer.

  inventory (one row per source VM)          e.g. exported from vCenter / Hyper-V
      + blueprints (the cookie cutter)       one per workload archetype, versioned
      + overrides (customization)            only at points the blueprint declares customizable
      -> deviation report                    how far each workload is from standard, and why
      -> waves                               apps move no earlier than the apps they depend on
      -> one Workflow per wave               executed by the engine with gates, retries, rollback

Rules that make the factory trustworthy:
  * A workload with no matching blueprint is REFUSED, not given a default.
  * An override to a locked field is REFUSED, with the field named.
  * Every override is reported, so "standard" is measurable rather than claimed.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

from .spec import Step, Workflow, validate


class FactoryError(ValueError):
    """A workload cannot be placed or a wave cannot be built: no or several matching blueprints, an override
    of a locked field, a size or setting outside the shape's limits, bad wave caps, or a dependency on an app
    that is not in the inventory. The message names the workload or app and the reason."""


@dataclass(frozen=True)
class Blueprint:
    """A versioned standard for one archetype (tier x OS family): the instance defaults every matching
    workload gets, and the only fields an override may change (customizable). Frozen: a change is a new
    version, so a placement always names exactly the standard it came from."""
    name: str
    version: int
    match_tier: str                     # web | app | db
    match_os: str                       # linux | windows
    defaults: dict                      # instance params
    customizable: frozenset             # fields an override may change

    def id(self):
        """"<name>@v<version>", the identifier used in reports, proposals and journalled tags."""
        return f"{self.name}@v{self.version}"


@dataclass(frozen=True)
class Workload:
    """One source VM as the factory sees it: name, app, tier (web | app | db), free-text OS, source vCPUs and
    memory in GB, and the apps it depends on (which must move no later than this one)."""
    name: str
    app: str
    tier: str
    os: str                              # free text from inventory, e.g. "Red Hat Enterprise Linux 8 (64-bit)"
    vcpus: int
    memory_gb: float                 # GB; fractional values (15.5) come from hypervisor MB exports
    depends_on_apps: tuple = ()


@dataclass
class Placement:
    """A workload matched to its blueprint: params are the final instance parameters (defaults, source-derived
    size, then overrides, then display_name), and overrides records exactly what deviates from the standard."""
    workload: Workload
    blueprint: Blueprint
    params: dict
    overrides: dict = field(default_factory=dict)

    @property
    def standard(self):
        """True when no override was applied (the workload runs on the blueprint as published)."""
        return not self.overrides


_WINDOWS = re.compile(r"\bwindows\b|\bwin\s?(?:20\d\d|2k\d*)\b|\bw2k\d*\b")      # Win2016, win 2019, W2K19
_LINUX = re.compile(r"linux|\bred hat\b|\brhel\b|\bcentos\b|\bubuntu\b|\bsuse\b|\bdebian\b|\brocky\b")


def os_family(os_text: str) -> str:
    """"windows", "linux" or "unknown" from a free-text OS string (case-insensitive, whole-word match, with the
    usual Windows abbreviations: Win2016, W2K19). A string naming both families ("Linux (Windows Subsystem
    image builder)") is "unknown", as is anything else (Solaris, AIX): "unknown" matches no blueprint, so
    such a workload is refused for review rather than guessed."""
    t = os_text.lower()
    win, lin = bool(_WINDOWS.search(t)), bool(_LINUX.search(t))
    if win != lin:
        return "windows" if win else "linux"
    return "unknown"


# Flex shape limits, from Oracle's "Compute Shapes" page (Flexible Shapes table), checked 2026-10-21:
# memory per instance is at least max(1 GB, number of OCPUs) and at most 64 GB per OCPU.
# E5.Flex total memory is 1024 GB in that table but 1049 GB in another table on the same page;
# the lower value is used. Shapes not listed here are not size-checked (ListShapes would be needed).
SHAPE_SIZE = {"VM.Standard.E5.Flex": (126, 1024), "VM.Standard.E4.Flex": (64, 1024), "VM.Standard3.Flex": (32, 512),
              "VM.Standard.A1.Flex": (76, 472)}
MAX_GB_PER_OCPU = 64
# Oracle's Compute Shapes page (checked 2026-10-21): "1 OCPU on x86 (AMD and Intel) = 2 vCPUs";
# "1 OCPU on Arm A1 (Compute) = 1 core ... or 1 vCPU". A1.Flex: 76 OCPUs, 64 GB per OCPU up to 472 GB.
VCPUS_PER_OCPU = {"VM.Standard.A1.Flex": 1}          # every other shape here is x86: 2
ARM_SHAPES = frozenset(s for s, n in VCPUS_PER_OCPU.items() if n == 1)   # need Arm (aarch64) images


def image_problems(placements, image_map):
    """Images each placement would launch with, checked BEFORE anything is created: a symbolic image (e.g.
    IMAGE_OL8) needs an entry in image_map, and on an Arm shape it needs the per-shape entry SYMBOL@SHAPE,
    because an x86 image does not boot an Arm shape and LaunchInstance would fail part-way through a wave.
    `--resolve-images` writes exactly those per-shape entries. Explicit image OCIDs in a blueprint are taken
    as given (their architecture cannot be told from the OCID). Returns [problem, ...]."""
    out = []
    for p in placements:
        img, shape = p.params.get("image_id"), p.params.get("shape")
        if not img or str(img).startswith("ocid1.image."):
            continue
        if shape in ARM_SHAPES:
            if f"{img}@{shape}" not in image_map:
                out.append(f"{p.workload.name}: {shape} is Arm and needs an Arm image: add {img}@{shape} to the image "
                           f"map, or use --resolve-images")
        elif f"{img}@{shape}" not in image_map and img not in image_map:
            out.append(f"{p.workload.name}: image {img} has no entry in the image map")
    return out


def size(w: Workload, shape=None) -> dict:
    """OCPUs for the target SHAPE: x86 1 OCPU = 2 vCPUs, Arm A1 1 OCPU = 1 vCPU. Round up so the target is
    never smaller than the source. The two Flex memory rules then hold both ways: memory is raised to at
    least 1 GB per OCPU (16 vCPU / 4 GB sources), and OCPUs are raised until the source's memory fits at
    MAX_GB_PER_OCPU (a 4 vCPU / 192 GB database needs 3 OCPUs, not 2; memory is never cut to fit). Without
    a shape, x86 is assumed."""
    memory = max(1, math.ceil(w.memory_gb))                                            # 15.5 GB -> 16, never 15
    ocpus = max(1, math.ceil(w.vcpus / VCPUS_PER_OCPU.get(shape, 2)), math.ceil(memory / MAX_GB_PER_OCPU))
    return {"ocpus": ocpus, "memory_gbs": max(memory, ocpus)}


# Instance settings a blueprint or override may carry, validated here (oci 2.189.0 model documentation):
# boot volume 50 GB to 32,768 GB; VPUs per GB 10 (Balanced), 20 (Higher Performance) or 30-120 (Ultra
# High Performance); baseline OCPU utilization BASELINE_1_8 / BASELINE_1_2 (burstable) or BASELINE_1_1.
BASELINES = ("BASELINE_1_8", "BASELINE_1_2", "BASELINE_1_1")


def setting_problems(params) -> list[str]:
    """Why optional instance settings are out of range (empty list = all fine or absent): boot volume size
    50..32768 GB (whole number), boot volume VPUs per GB 10, 20 or 30..120, baseline OCPU utilization one of
    BASELINES. Ranges as in the comment above (oci 2.189.0 model documentation)."""
    out = []
    b = params.get("boot_volume_size_in_gbs")
    if b is not None and not (type(b) is int and 50 <= b <= 32768):
        out.append(f"boot_volume_size_in_gbs {b!r} outside 50..32768")
    v = params.get("boot_volume_vpus_per_gb")
    if v is not None and not (type(v) is int and (v in (10, 20) or 30 <= v <= 120)):
        out.append(f"boot_volume_vpus_per_gb {v!r} must be 10, 20 or 30..120")
    bl = params.get("baseline_ocpu_utilization")
    if bl is not None and bl not in BASELINES:
        out.append(f"baseline_ocpu_utilization {bl!r} must be one of {BASELINES}")
    return out


def shape_problems(shape, ocpus, memory_gbs) -> list[str]:
    """Why a size does not fit a Flex shape (empty list = fits, or the shape is not size-checked)."""
    if shape not in SHAPE_SIZE:
        return []
    max_ocpus, max_mem = SHAPE_SIZE[shape]
    out = []
    if not 1 <= ocpus <= max_ocpus:
        out.append(f"{ocpus} OCPUs outside 1..{max_ocpus} for {shape}")
    if memory_gbs < max(1, ocpus):
        out.append(f"{memory_gbs} GB below the minimum of {max(1, ocpus)} GB for {ocpus} OCPUs on {shape}")
    if memory_gbs > min(max_mem, ocpus * MAX_GB_PER_OCPU):
        out.append(f"{memory_gbs} GB above the maximum of {min(max_mem, ocpus * MAX_GB_PER_OCPU)} GB for "
                   f"{ocpus} OCPUs on {shape}")
    return out


def place(w: Workload, blueprints, overrides: dict) -> Placement:
    """Match w to exactly one blueprint (same tier and OS family) and build its parameters.

    Order: blueprint defaults, then OCPUs and memory sized from the source for the shape the VM will run on
    (an overridden shape counts), then the overrides, then display_name = the VM name. Raises FactoryError,
    naming the VM, when no blueprint or more than one matches, when an override touches a locked field, or
    when the result does not fit the shape (shape_problems) or has an out-of-range setting
    (setting_problems). Never falls back to a default blueprint."""
    fam = os_family(w.os)
    matches = [b for b in blueprints if b.match_tier == w.tier and b.match_os == fam]
    if not matches:
        raise FactoryError(f"{w.name}: no blueprint for tier={w.tier!r} os={fam!r} ({w.os!r}); refusing to guess")
    if len(matches) > 1:
        raise FactoryError(f"{w.name}: ambiguous blueprints {[b.id() for b in matches]}")
    bp = matches[0]
    params = dict(bp.defaults)
    params.update(size(w, overrides.get("shape", params.get("shape"))))   # size for the shape it will run on
    locked = sorted(set(overrides) - bp.customizable)
    if locked:
        raise FactoryError(f"{w.name}: override of locked field(s) {locked} in {bp.id()} "
                           f"(customizable: {sorted(bp.customizable)})")
    params.update(overrides)
    params["display_name"] = w.name
    problems = shape_problems(params.get("shape"), params.get("ocpus", 1), params.get("memory_gbs", 1)) + \
        setting_problems(params)
    if problems:
        raise FactoryError(f"{w.name}: does not fit {params.get('shape')}: {'; '.join(problems)}")
    return Placement(w, bp, params, dict(overrides))


def _move_groups(apps: dict) -> list[frozenset]:
    """Strongly connected components (Tarjan, iterative). Apps that depend on each other, directly or
    through a loop, must move in the SAME wave: neither can go first without breaking the other."""
    index, low, on, stack, out, counter = {}, {}, set(), [], [], [0]
    for root in sorted(apps):
        if root in index:
            continue
        work = [(root, iter(sorted(apps[root])))]
        index[root] = low[root] = counter[0]; counter[0] += 1; stack.append(root); on.add(root)
        while work:
            node, it = work[-1]
            nxt = next(it, None)
            if nxt is not None:
                if nxt not in index:
                    index[nxt] = low[nxt] = counter[0]; counter[0] += 1; stack.append(nxt); on.add(nxt)
                    work.append((nxt, iter(sorted(apps[nxt]))))
                elif nxt in on:
                    low[node] = min(low[node], index[nxt])
                continue
            work.pop()
            if work:
                low[work[-1][0]] = min(low[work[-1][0]], low[node])
            if low[node] == index[node]:
                comp = set()
                while True:
                    x = stack.pop(); on.discard(x); comp.add(x)
                    if x == node:
                        break
                out.append(frozenset(comp))
    return out


def plan_waves(workloads, max_apps_per_wave=3, max_vms_per_wave=None, solo_apps=()) -> list[list[str]]:
    """Group apps into waves; an app is placed no earlier than any app it depends on.

    * Mutually dependent apps (a dependency loop) move together in one wave, as one unit; they are
      reported by mutual_groups(). A loop is not an error: discovery finds them in real estates.
    * Waves are capped by app count and, optionally, by VM count. A unit larger than a cap still moves
      as one wave on its own (it cannot be split), and it is never merged with anything else.
    * solo_apps (e.g. business-critical apps) always get a wave of their own.
    """
    if not isinstance(max_apps_per_wave, int) or max_apps_per_wave < 1:
        raise FactoryError(f"max_apps_per_wave must be a whole number of at least 1, got {max_apps_per_wave!r}")
    if max_vms_per_wave is not None and (not isinstance(max_vms_per_wave, int) or max_vms_per_wave < 1):
        raise FactoryError(f"max_vms_per_wave must be a whole number of at least 1, got {max_vms_per_wave!r}")
    apps, vms = {}, {}
    for w in workloads:
        apps.setdefault(w.app, set()).update(w.depends_on_apps)
        vms[w.app] = vms.get(w.app, 0) + 1
    known = set(apps)                           # built once (was rebuilt per app: quadratic at 10k+ apps)
    for a, deps in apps.items():
        missing = deps - known
        if missing:
            raise FactoryError(f"app {a} depends on {sorted(missing)}, which is not in the inventory")
    unknown_solo = set(solo_apps) - set(apps)
    if unknown_solo:
        raise FactoryError(f"solo_apps not in the inventory: {sorted(unknown_solo)}")
    groups = _move_groups(apps)
    group_of = {a: g for g in groups for a in g}
    gdeps = {g: {group_of[d] for a in g for d in apps[a]} - {g} for g in groups}
    level = {}
    for g in groups:                       # Tarjan emits a group only after every group it depends on
        level[g] = 1 + max((level[d] for d in gdeps[g]), default=-1)
    by_level = {}
    for g, l in level.items():                  # bucket once: O(groups), not O(levels x groups)
        by_level.setdefault(l, []).append(sorted(g))
    out = []
    for L in sorted(by_level):
        units = sorted(by_level[L], key=lambda u: u[0])
        cur, cur_vms = [], 0
        for u in units:
            n_vms = sum(vms[a] for a in u)
            solo = any(a in solo_apps for a in u)
            too_many_apps = len(cur) + len(u) > max_apps_per_wave
            too_many_vms = max_vms_per_wave is not None and cur_vms + n_vms > max_vms_per_wave
            if cur and (solo or too_many_apps or too_many_vms):
                out.append(cur); cur, cur_vms = [], 0
            cur = cur + u; cur_vms += n_vms
            if solo:
                out.append(cur); cur, cur_vms = [], 0
        if cur:
            out.append(cur)
    return out


def mutual_groups(workloads) -> list[list[str]]:
    """App sets that must move together because they depend on each other (size > 1 only)."""
    apps = {}
    for w in workloads:
        apps.setdefault(w.app, set()).update(d for d in w.depends_on_apps)
    apps = {a: {d for d in ds if d in apps} for a, ds in apps.items()}
    return sorted(sorted(g) for g in _move_groups(apps) if len(g) > 1)


TIER_SUBNETS = {"web": "subnet_web", "app": "subnet_app", "db": "subnet_db"}


def target_network(name, environment, compartment_id, tags, vcn_cidr, tier_cidrs, defined_tags=None) -> Workflow:
    """The minimal target network the waves land in: one VCN and one subnet per tier. It is NOT a landing
    zone in Oracle's sense (no compartments, IAM, logging or security services), and on purpose it adds no
    gateways (internet, NAT, service, DRG), no route rules and no security rules: subnets get the VCN's
    default route table and default security list. Per Oracle's Security Lists page (checked 2026-10-21),
    that list allows stateful ingress TCP 22 (SSH) and ICMP 3/4 "from authorized source IP addresses", ICMP 3
    from the VCN CIDR, and all egress. Web subnets block public IPs in prod. Connectivity back to the source site
    and any tightening of the default security list are the network team's, before the first wave."""
    dt = {"defined_tags": defined_tags} if defined_tags else {}
    steps = [Step("vcn", "vcn", {"display_name": f"{name}-vcn", "cidr_block": vcn_cidr, "dns_label": name[:15], **dt})]
    for tier, cidr in tier_cidrs.items():
        # A subnet DNS label (alphanumeric, starting with a letter, unique in the VCN, set only when the VCN
        # has one, and never changeable) is what lets instance hostnames resolve through the VCN resolver.
        steps.append(Step(TIER_SUBNETS[tier], "subnet",
                          {"display_name": f"{name}-{tier}", "cidr_block": cidr, "vcn_id": "${vcn.id}",
                           "prohibit_public_ip_on_vnic": tier != "web" or environment == "prod", "dns_label": tier, **dt},
                          ("vcn",)))
    wf = Workflow(f"{name}-target-network", environment, compartment_id, tuple(steps), dict(tags))
    validate(wf)
    return wf


landing_zone = target_network          # earlier name, kept so existing callers keep working


FAULT_DOMAINS = ("FAULT-DOMAIN-1", "FAULT-DOMAIN-2", "FAULT-DOMAIN-3")   # three per AD (SDK documentation)


def fault_domains(placements) -> dict:
    """{vm: fault domain}: the VMs of each app tier, in name order, round-robin over the three fault domains
    of the AD, so one hardware fault or maintenance event cannot take a whole tier down. In a single-AD
    region this is the only anti-affinity there is. (Without it, OCI picks a fault domain itself.)"""
    out, groups = {}, {}
    for p in placements:
        groups.setdefault((p.workload.app, p.workload.tier), []).append(p.workload.name)
    for names in groups.values():
        for i, n in enumerate(sorted(names)):
            out[n] = FAULT_DOMAINS[i % 3]
    return out


def hostnames(placements) -> dict:
    """{vm: hostname label}: RFC 952/1123 (letters, digits, hyphens; starts with a letter, ends with a letter
    or digit; at most 63 characters) and unique across the placements given (pass the whole plan: OCI requires
    uniqueness within a subnet, and all waves share the tier subnets)."""
    out, used = {}, set()
    for p in sorted(placements, key=lambda p: p.workload.name):
        h = re.sub(r"[^a-z0-9-]+", "-", p.workload.name.lower()).strip("-")
        h = re.sub(r"^[^a-z]+", "", h) or "vm"
        h = h[:63].rstrip("-")
        base, k = h, 1
        while h in used:
            k += 1
            suffix = f"-{k}"
            h = base[:63 - len(suffix)].rstrip("-") + suffix
        used.add(h)
        out[p.workload.name] = h
    return out


def wave_workflow(wave_no, apps, placements, landing_outputs, environment, compartment_id, tags,
                  spread_fault_domains=True, capacity_reservation_id=None, defined_tags=None, nsg_map=None,
                  all_placements=None) -> Workflow:
    """The Workflow for one wave: one "instance" step per VM of the wave's apps, named after the VM.

    Each step gets the placement's parameters (copied, never mutated), the subnet id from landing_outputs
    for its tier or overridden subnet key (FactoryError if the target network has no such subnet), a unique
    RFC 952/1123 hostname label, and, when asked for, a fault domain (round-robin per app tier), a capacity
    reservation, defined tags and NSG membership. The workflow is tagged migration_wave=<n> and validated.

    nsg_map: {"<app>-<tier>": NSG OCID} from `netpolicy --apply`; each VM's VNIC joins its app tier's NSG,
    which is what lets the flows discovery observed through once both ends are in OCI."""
    steps = []
    in_wave = [p for p in placements if p.workload.app in apps]
    fds = fault_domains(in_wave) if spread_fault_domains else {}
    # Hostname labels must be unique within a SUBNET, and every wave uses the same tier subnets: so labels are
    # assigned over the whole plan (all_placements), not wave by wave.
    hosts = hostnames(all_placements if all_placements is not None else in_wave)
    for p in placements:
        if p.workload.app not in apps:
            continue
        params = dict(p.params)                       # copy: never mutate the placement itself
        sub_key = params.pop("subnet", None) or TIER_SUBNETS[p.workload.tier]
        if sub_key not in landing_outputs:
            raise FactoryError(f"{p.workload.name}: target network has no {sub_key}")
        params["subnet_id"] = landing_outputs[sub_key]["id"]
        params["hostname_label"] = hosts[p.workload.name]
        if p.workload.name in fds:
            params["fault_domain"] = fds[p.workload.name]
        if capacity_reservation_id:
            params["capacity_reservation_id"] = capacity_reservation_id
        if defined_tags:
            params["defined_tags"] = defined_tags
        nsg = (nsg_map or {}).get(f"{p.workload.app}-{p.workload.tier}")
        if nsg:
            params["nsg_ids"] = [nsg]
        steps.append(Step(p.workload.name, "instance", params))
    wf = Workflow(f"wave-{wave_no}", environment, compartment_id, tuple(steps),
                  dict(tags, migration_wave=str(wave_no)))
    validate(wf)
    return wf


def deviation_report(placements) -> dict:
    """How standard the plan is: workload count, how many run on a blueprint unchanged and how many are
    customized, the standard share in percent (None for no workloads), the count per blueprint id, and every
    customization with its overrides. Measures "standard by default" instead of claiming it."""
    n = len(placements)
    std = sum(p.standard for p in placements)
    return {"workloads": n, "standard": std, "customized": n - std,
            "standard_pct": round(100 * std / n, 1) if n else None,
            "by_blueprint": {bp: sum(1 for p in placements if p.blueprint.id() == bp)
                             for bp in sorted({p.blueprint.id() for p in placements})},
            "customizations": [{"workload": p.workload.name, "blueprint": p.blueprint.id(), "overrides": p.overrides}
                               for p in placements if p.overrides]}
