# Repeatable OCI Migrations: a working orchestrator

*J.C. Glover · October 2026 · version 2*

In our conversation you mentioned the goal of getting OCI migrations to a place where they are cookie-cutter, with customization only where a workload truly needs it. This is the orchestration layer I would build toward that, built far enough to test under failure and at scale. It sits **on top of** Oracle Cloud Migrations, not beside it.

**The idea in one line:** standardize by default, customize by exception, and make every exception visible.

## Where it fits

Oracle Cloud Migrations discovers VMs, recommends sizes, builds migration plans and replicates data. Its published material leaves several things to the team:

- which VMs form an application, and what depends on what;
- a library of target templates;
- wave orchestration;
- rollback beyond terminate-and-rerun;
- validation.

That remaining layer is what makes a migration repeatable. It is what this covers.

## Five parts, in pipeline order

| Part | What it does | Status |
|---|---|---|
| **1. Discovery** | Proposes app groups, tiers and dependencies from the VM inventory plus network flows, listening ports and VIP/SCAN addresses. Every finding has a confidence and its evidence; a person reviews. | Built, tested on synthetic estates |
| **2. Blueprint factory** | Versioned blueprints per archetype. Only declared fields may be customized; anything else is refused and the field named. Sizes are checked against Oracle's published Flex shape limits. A deviation report measures how standard the estate is. | Built, tested |
| **3. Wave planner & scale** | Dependency-ordered waves; mutually dependent apps move together; waves capped by app count, VM count and criticality. An app that cannot be fully placed is held back, with every app that depends on it. Quota preflight before every wave; adaptive pacing of API calls. | Built; planning measured to 51,779 VMs |
| **4. Execution, two paths** | **Migration:** `ocm-wave` excludes every out-of-wave target asset in an Oracle Cloud Migrations plan, then writes the wave's blueprint settings into its assets, then re-reads the plan to verify both; OCM replicates and launches from the replicated disks. **Rebuild or pilot:** `run` builds the target network and launches new instances, with policy gates, dry run, idempotent creates (`opc-retry-token`), ready-state waits, rollback in reverse order and a hash-chained journal. Re-running after a crash resumes. | Built, tested offline; not yet run against OCI or OCM |
| **5. Agent assist** | An AI agent may only propose a blueprint and field values for one VM. Deterministic code (the guard) accepts or rejects, and approvals and a change cap stay with people. | Built and fuzz-tested; real model not yet called |

## How the safety works

- **Unknown means stop.** A VM with no blueprint, a quota that cannot be read, a private address discovery cannot place, or a missing approval stops that step. Nothing is ever filled in by default.
- **Discovery errs toward caution.**
  - An unreviewed dependency is *kept*, because it can only make a wave later.
  - Only a reviewer can drop one.
  - Apps that depend on each other move together.
- **The agent never touches OCI.** Its proposal must:
  - be for the VM it was asked about;
  - use the blueprint the factory itself would pick;
  - change only customizable fields;
  - never size below the source and stay within bounds.
- **Approvals are bound to the reviewed plan.** Production waves, subnet moves, more-than-2× growth and any size below the source need a named approver. Every `--apply` must name the plan id printed by its dry run, which covers placements, waves, environment, compartment, tags, network, availability domain and every other input that reaches an API call (image map; OCM plan, wave, subnet map and asset mapping). A changed input means a new plan id, and the run stops. Approvals are written to the hash-chained journal on both paths.
- **Policy is checked on the plan.** Missing tags, overlapping CIDRs or public IPs in prod stop `--apply` before any API call.
- **Resume is by content, checked against OCI.** Re-running finds what exists from the journal VM by VM, whichever wave or run created it, then confirms each one with OCI before skipping it. A VM deleted by hand is created again; one in an unexpected state, or whose earlier rollback failed, stops the wave. An interrupted run is resumed only with unchanged inputs; otherwise it is refused. A create that was never confirmed is not re-sent after 23 hours, because OCI keeps retry tokens for 24, and one that hit a server or network error is reported with the tags to find it by.
- **A wave never runs before what it depends on.** On `run`, if a wave fails, every later wave that depends on it is skipped, even when the run is told to continue. On `ocm-wave`, a wave is refused until every VM it depends on shows a target instance in the migration plan (or a named person confirms they were migrated elsewhere, which is journalled).

## What I verified

Every figure names how it was produced. **Measured** means our own code timed or counted in a 2-CPU cloud container. **Simulated** means run against an in-memory OCI with injected faults, or against synthetic estates whose ground truth is known. No live tenancy was used. Discovery and guard figures come from `scripts/evidence.py`, scale figures from `scripts/scale_test.py`, recovery from `demo_v2.py`, tests and planted defects from the test suite and `mutate.py`. All outputs are saved in `examples/`.

| Check | Result | Tier |
|---|---|---|
| Unit and end-to-end tests, cache cleared | **344 / 344 pass** | Measured |
| Planted defects caught by the tests (one at a time, unmodified control passes) | **206 / 206 caught** on the code as delivered. Its one full run caught 204 of 207; the two gaps got tests and those mutants were re-run and caught, and one equivalent mutant was removed (`examples/mutate_results.txt` says how). Earlier full passes caught 128 / 131 and 160 / 161, and each gap got a test | Measured |
| Randomised scenarios with independent oracles (`scripts/montecarlo.py`, 14 scenarios × 500 trials, plus the whole suite in shuffled order × 20, about 17 s each) | Every safety check held in **500 / 500** trials of every scenario, and the suite passed in 20 / 20 runs. Two scenarios complete fewer by design, because their random inputs must be refused: OCM driver 248 / 500, console 150 / 500 | Simulated |
| Planning time for synthetic inventories of 1,034 / 10,451 / 51,779 VMs (placement, waves, deviation report) | 0.009 s / 0.09 s / 0.55 s | Measured |
| Discovery time: 1,034 / 10,451 VMs | 0.08 s / 1.0 s (container timings vary from day to day; see `TUNEUP_LOG.md`) | Measured |
| Discovery on synthetic estates with known truth (5 seeds × 100 apps, 412–486 VMs) | High-confidence dependencies 100% correct in all five; 97.9–100% of real dependencies found; tiers 100% | Simulated |
| Discovery with 25% / 50% of untagged hosts renamed to generic names (`srv10042`) | VMs in groupings that mix two apps: 9.7% / 28.0% on average, **all flagged** | Simulated |
| Discovery with 25% / 50% renamed to misleading names shared across apps (`prod-app-0042`) | VMs in mixed groupings: 3.2% / 11.8%, **all flagged** | Simulated |
| Guard against 17,100 hostile agent proposals | 186 valid ones accepted, **0 unsafe accepted**, 0 guard errors | Simulated |
| ~1,000-VM inventory against a server allowing 4 calls in flight; all arms use the production retry policy, 100× faster | Fixed pool of 32: **0 of 8 waves** (failed, and the waves depending on them skipped). Fixed pool of 4 (tuned to the known limit): 8 of 8. Adaptive pacing with 32 workers: **8 of 8**, without being told the limit. 0 duplicate resources in every arm | Simulated |
| Same seeds, any Python hash seed | Identical discovery reports, waves and plan ids | Measured |
| Crash, then re-run the same command | Finished waves skipped, unfinished resumed, 0 duplicates, journal intact | Simulated |

Across all 25 discovery runs with renamed hosts (including 5 with none renamed), 20 contained groupings that mix apps, and none of those VMs went unflagged. Generic names are flagged by rule; the misleading-name runs exercise the traffic check, but only on the traffic patterns these synthetic estates contain. Two harder patterns have their own tests: unrelated apps sharing one database, and one caller (a scheduler or health checker) in front of unrelated apps. Both are flagged. One residual case is not: a caller in front of VMs that share a misleading name and make no calls of their own looks exactly like load-balanced replicas.

About the ~1,000-VM run: half the inventory was held back on purpose. 54 VMs have no blueprint in the example catalog, which blocks 24 apps, and 96 more apps depend on those. The report names each one and why.

Independent reviews of the code reproduced defects in four rounds; each was fixed with a test that fails without the fix. The second review's findings included a duplicate VM when waves are renumbered between a crash and a re-run, a wave reported successful while its VM was gone, an approval that did not cover the OCM plan or subnets, an OCM update order that could leave extra assets included, and unrelated apps that share one database being merged under a misleading host name. The third round checked those fixes and found that the advertised remedy for a blocked wave, a teardown, did nothing for a resource whose rollback had failed; teardown now handles it, closes the run, and is a command. The fourth round, after the console was added, reproduced about 45 more, from an NSG created twice after a partial failure to readiness evidence that took `true` as wave 1; all are fixed test-first and listed in `TUNEUP_LOG.md` (119 tune-ups in all; the last two were found by the final mutation and Monte Carlo runs).

Building v2 also surfaced ten behaviours that only a **live tenancy** would otherwise have shown. All are handled and tested offline:

1. **Doubled retries.** The OCI SDK's default retries (8 attempts, 600 s) stacked under the engine's own; they are off.
2. **Ambiguous 404s.** OCI answers 404 both for "deleted" and for "not authorized". A 404 now means "gone" only for something this run deleted.
3. **Transport errors.** Timeouts and connection resets carry no HTTP status; they are now retried within limits.
4. **Retry-token expiry.** Tokens last 24 hours; an unconfirmed create older than 23 hours is not re-sent, and every resource is tagged with its run and step so it can be found.
5. **Delete conflicts.** A 409 on delete while a VNIC detaches is temporary, and gets a bounded retry.
6. **Placeholder images.** Image names reached OCI unresolved; now they map to OCIDs or are refused.
7. **Fixed shapes.** A shape configuration was sent for fixed shapes such as `VM.Standard.E2.1.Micro`.
8. **Flex limits.** OCPU and memory limits per shape (for example at most 64 GB per OCPU) are checked before anything is sent.
9. **DNS labels.** Labels with hyphens are invalid in OCI; they are cleaned.
10. **Default network security.** The target network adds no gateways or security rules; the runbook states what the VCN's default security list allows, per Oracle's documentation.

## How to try it

`RUNBOOK.md` has the full procedure:

- **Commands:** `discover`, `plan`, `ocm-wave` (migration) and `ocm-restore` (put an OCM plan back), `run` (rebuild or pilot), `netpolicy` (least-privilege NSGs from observed traffic), `status`, `teardown` (undo one run) and `resolve` (record an operator-confirmed deletion);
- **The console:** double-click `Launch` for OCI Migration Control, a local page with radio-button choices for every command;
- **Readiness evidence:** fresh, plan- and wave-bound proof per wave before it may change anything;
- **Inputs:** the inventory, flows, VIP map and review files;
- **Approvals, plan ids and resume;**
- **IAM:** Oracle's published policy statements, verbatim, with what is still unconfirmed marked as such;
- **A first live test:** `scripts/live_smoke.py` creates one VCN, a private subnet and optionally one Always Free instance, verifies them and deletes them again. It is a dry run unless `--apply` is given.

## Path to adoption

1. **Learn the estate.** Discovery plus report-only planning. Nothing is created; the output is a dependency map and a deviation report.
2. **Codify the standard.** Blueprints with the team; refusals from stage 1 become the backlog.
3. **Pilot one low-risk wave** with `ocm-wave`, first in a non-production compartment, then in production.
4. **Scale wave by wave.** The share of standard workloads over time shows the process converging.

## What it is not (yet)

- **It has not run against a live tenancy or against Oracle Cloud Migrations.** The SDK and OCM request models and method signatures are checked offline against oci 2.189.0, and the OCM path against a stateful stand-in. `live_smoke.py` is the first live test; the first `ocm-wave --apply` on a sandbox plan is the second. How quickly OCM reflects a target-asset update is unknown; the verification step re-reads with backoff and refuses if the plan does not match.
- **It does not move data or execute migration plans.** Replication, launch from replicated disks and cutover stay with OCM. Matching target assets to VMs by source name needs confirming on a real plan; a mapping file is the fallback.
- **Re-runs cost one read per finished VM.** Before skipping anything, a re-run confirms it with OCI: about 50,000 state reads for a 50,000-VM estate. That is the price of never reporting success on the journal's word alone.
- **The OCM dependency gate reads `created_resource_id`** on target assets as "migrated", following the SDK's description; confirm on a real plan.
- **No language model has been called.** The OCI Generative AI request is built and checked offline; whatever a model proposes goes through the same guard.
- **Resource types are VCN, subnet and instance** on the `run` path, and NSGs via `netpolicy`. Block volumes and load balancers are next.
- **Discovery quality depends on the evidence.** With non-standard host names and no tags there are more findings to review. The synthetic estates follow patterns I chose; real estates will differ.
- **Limits.** The quota check uses Oracle's documented compute limit names. The Limits API service name and the read-limits policy need a one-time confirmation in a real tenancy (see `RUNBOOK.md`).

Happy to walk through any part, or to adapt it to how your team runs migrations today.
