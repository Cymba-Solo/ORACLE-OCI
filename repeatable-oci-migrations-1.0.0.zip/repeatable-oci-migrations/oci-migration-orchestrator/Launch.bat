@echo off
rem OCIO one-click launch (Windows): double-click. Opens the launch console in your browser.
rem Needs Python 3.10 or newer. Live OCI commands also need the SDK: py -m pip install "oci==2.189.0"
cd /d "%~dp0"
set PY=
where py >nul 2>nul && (set PY=py -3)
if not defined PY (where python >nul 2>nul && (set PY=python))
if not defined PY goto nopython
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" || goto nopython
%PY% -c "import oci" 2>nul || echo Note: the OCI SDK is not installed; plan, discover and run dry runs work; ocm-wave and live OCI calls need: %PY% -m pip install "oci==2.189.0"
%PY% -m ocio ui --workdir . %*
if errorlevel 1 pause
goto end
:nopython
echo Python 3.10 or newer was not found. Install it from https://www.python.org/downloads/ and try again.
pause
:end
