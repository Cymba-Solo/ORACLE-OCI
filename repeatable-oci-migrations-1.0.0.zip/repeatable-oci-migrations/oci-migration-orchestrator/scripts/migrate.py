#!/usr/bin/env python3
"""Compatibility wrapper: the command line now lives in ocio/cli.py (installed as `ocio`, or `python -m ocio`).
`python scripts/migrate.py ...` keeps working exactly as before, from a checkout without installing."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ocio.cli import *                    # noqa: E402,F401,F403 - the same module, for `import migrate`
from ocio.cli import _defined_tags, main, parser   # noqa: E402,F401 - private helpers tests use

if __name__ == "__main__":
    sys.exit(main())
