#!/usr/bin/env python3
"""Writes a small SIMULATED estate (assets, flows, listeners) to examples/estate/ for trying discovery.

  python3 -B scripts/make_example_estate.py

The estate comes from ocio/synth.py (12 apps, seed 2), so it is deterministic: re-running rewrites the same three
files. They are the inputs `ocio discover` (and the launch console's Discover defaults) are shown with:
  assets.csv     name, ip, os, vcpus, memory_gb, tags ("k=v;k=v")
  flows.csv      src_ip, dst_ip, dst_port, connections   (observed traffic, as a flow-log export would give)
  listeners.csv  name, port                               (listening ports per VM, used for tier evidence)
Prints one line: counts of VMs, flows and listeners, and the folder written.
"""
import csv, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ocio import synth  # noqa: E402

def main(out="examples/estate", n_apps=12, seed=2):
    """Generate the estate (n_apps apps, fixed seed) and write the three CSVs into `out` (created if missing).
    The ground truth synth returns is not written: discovery should be judged without it."""
    os.makedirs(out, exist_ok=True)
    assets, flows, listeners, truth = synth.estate(n_apps, seed=seed)
    with open(os.path.join(out, "assets.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(["name", "ip", "os", "vcpus", "memory_gb", "tags"])
        for a in assets:
            w.writerow([a.name, a.ip, a.os, a.vcpus, a.memory_gb, ";".join(f"{k}={v}" for k, v in a.tags.items())])
    with open(os.path.join(out, "flows.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(["src_ip", "dst_ip", "dst_port", "connections"]); w.writerows(flows)
    with open(os.path.join(out, "listeners.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(["name", "port"])
        for n, ports in sorted(listeners.items()):
            for p in sorted(ports):
                w.writerow([n, p])
    print(f"{len(assets)} VMs, {len(flows)} flows, {sum(len(v) for v in listeners.values())} listeners -> {out}")

if __name__ == "__main__":
    main()
