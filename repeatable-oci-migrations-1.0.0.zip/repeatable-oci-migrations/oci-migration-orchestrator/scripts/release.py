#!/usr/bin/env python3
"""Release integrity manifest: SHA256SUMS over every file of the package.

  python scripts/release.py write  [ROOT]   write ROOT/SHA256SUMS
  python scripts/release.py verify [ROOT]   exit 0 if every listed file matches and nothing is unlisted

The format is the one coreutils writes ("<sha256>  <path>"), so a recipient can check a copy with nothing
but `sha256sum -c SHA256SUMS`. verify() goes further than sha256sum -c: it also reports files that are
present but NOT listed (something added after release), which -c cannot see.

What this is: a check that the files are the ones released (integrity). What it is not: proof of who
released them (a manifest sent alongside the files can be replaced with them; send its own hash, or sign
it, through a separate channel when that matters).

Skipped: version-control and build leftovers (.git, __pycache__, *.pyc, build/, *.egg-info, virtual
environments) and run-time files (*.lock).
"""
import hashlib
import os
import sys

NAME = "SHA256SUMS"
SKIP_DIRS = {".git", "__pycache__", "build", "dist", ".pytest_cache", "venv", ".venv"}
SKIP_SUFFIX = (".pyc", ".lock")


def files(root):
    """Every file under root that belongs in the manifest, as sorted '/'-separated relative paths: SHA256SUMS
    itself, SKIP_DIRS, *.egg-info folders and SKIP_SUFFIX files are left out."""
    out = []
    for d, dirs, names in os.walk(root):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS and not x.endswith(".egg-info"))
        for n in sorted(names):
            rel = os.path.relpath(os.path.join(d, n), root).replace(os.sep, "/")
            if rel != NAME and not n.endswith(SKIP_SUFFIX):
                out.append(rel)
    return sorted(out)


def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def write(root):
    """Write root/SHA256SUMS ("<sha256>  <path>" per file, '\\n' line ends) and return the number of files."""
    lines = [f"{_sha(os.path.join(root, r))}  {r}\n" for r in files(root)]
    with open(os.path.join(root, NAME), "w", newline="\n") as f:
        f.writelines(lines)
    return len(lines)


def verify(root):
    """[problem, ...]; [] when the tree is exactly what the manifest lists."""
    listed = {}
    with open(os.path.join(root, NAME)) as f:
        for line in f:
            if not line.strip():
                continue
            digest, rel = line.rstrip("\n").split("  ", 1)
            listed[rel] = digest
    present = set(files(root))
    problems = [f"missing: {r}" for r in sorted(set(listed) - present)]
    problems += [f"changed: {r}" for r in sorted(set(listed) & present) if _sha(os.path.join(root, r)) != listed[r]]
    problems += [f"not listed: {r}" for r in sorted(present - set(listed))]
    return problems


def main(argv=None):
    """`write [ROOT]` or `verify [ROOT]` (ROOT defaults to the package folder). Exit codes: 0 written / every file
    matches; 1 verify found problems (each printed: missing, changed, not listed); 2 usage (prints this help)."""
    argv = sys.argv[1:] if argv is None else argv
    if not argv or argv[0] not in ("write", "verify"):
        print(__doc__)
        return 2
    root = argv[1] if len(argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if argv[0] == "write":
        print(f"{NAME}: {write(root)} files")
        return 0
    try:
        problems = verify(root)
    except FileNotFoundError:
        print(f"no {NAME} in {root}: nothing to verify against")
        return 2
    except ValueError:
        print(f"{NAME} in {root} is damaged (a line is not '<sha256>  <path>')")
        return 2
    print("\n".join(problems) if problems else f"{NAME}: every file matches, nothing unlisted")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
