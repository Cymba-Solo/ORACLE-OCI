#!/usr/bin/env python3
"""Scale test.  python3 -B scripts/scale_test.py [out.json]

Part A, MEASURED in this container (CPU time of our own code, no OCI involved):
  planning (placement + waves + deviation report) and discovery at 1,000 / 10,000 / 50,000 VMs.
Part B, SIMULATED execution of a ~1,000-VM estate against an in-memory OCI that serves each call in
  5 ms and answers HTTP 429 when more than 4 calls are in flight (a strict server, on purpose). Both arms
  use the engine's PRODUCTION retry policy (6 attempts, 1 s base, 30 s cap) scaled down 100x in time
  (0.01-0.3 s backoff against 5 ms calls). Duplicates are counted as live resources sharing a display
  name, so a re-sent create that got a new token would show up here. Compares a fixed pool of 32 workers
  with the adaptive limiter, and adds a fixed pool of 4 workers, i.e. a pool tuned by someone who already
  knows the server's limit (the limiter's value is not having to know it). Counts: waves succeeded, 429s, duplicates, wall time of the simulation.
  About half the inventory is held back on purpose: VMs with no blueprint (e.g. Windows, by design of the
  example catalog) block their app, and every app that depends on a blocked app is blocked too.
Part C, MODELED: how long the API calls of a real migration would take at a given request rate. This is
  arithmetic on Part B's call counts, labelled as such, not a measurement of OCI.

Output. Progress lines "A {...}" (one per size), "B {...}" (one per arm) and "C {...}" on stdout; with a path
argument, the whole result as JSON with keys A_measured, B_simulated (fixed 32, fixed 4, adaptive limiter, in that
order) and C_modeled. examples/scale_results.json is that file; the document's planning and pacing charts are
generated from it. Timings depend on the machine; the 2-CPU container figures are the ones quoted.
"""
import json
import os
import random
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ocio import capacity as C, discovery as D, factory as F, pipeline as P, synth   # noqa: E402
from ocio.catalog import BLUEPRINTS                                                  # noqa: E402
from ocio.engine import Engine, RetryPolicy                                          # noqa: E402
from ocio.journal import Journal                                                     # noqa: E402
from ocio.providers import FakeOCI                                                   # noqa: E402

TAGS = {"cost_center": "cc-1", "owner": "scale-test"}


def part_a():
    """Part A, MEASURED (our code's run time on this machine, no OCI). For ~1k / ~10k / ~50k-VM synthetic
    inventories: time placement + wave planning + mutual-dependency groups + deviation report together
    (planning_seconds), and discovery on its own (discovery_seconds, skipped for the 50k estate). Also reports how
    many VMs were placed, refused and how many waves resulted. Returns one dict per size."""
    rows = []
    for n_apps in (230, 2300, 11500):                     # ~1k, ~10k, ~50k VMs (about 4.4 VMs per app)
        wls, _ = synth.inventory(n_apps, seed=1)
        t = time.perf_counter()
        placed, refused, _, _ = P.place_all(wls, BLUEPRINTS)
        waves = F.plan_waves([p.workload for p in placed], max_apps_per_wave=25, max_vms_per_wave=200)
        mutual = F.mutual_groups([p.workload for p in placed])
        dev = F.deviation_report(placed)
        plan_s = time.perf_counter() - t
        disc_s = None
        if n_apps <= 2300:
            assets, flows, listeners, _ = synth.estate(n_apps, seed=1)
            t = time.perf_counter()
            D.discover(assets, flows, listeners)
            disc_s = time.perf_counter() - t
        rows.append({"vms": len(wls), "apps": n_apps, "placed": dev["workloads"], "refused": len(refused),
                     "waves": len(waves), "mutual_groups": len(mutual), "planning_seconds": round(plan_s, 3),
                     "discovery_seconds": None if disc_s is None else round(disc_s, 3)})
        print("A", rows[-1], flush=True)
    return rows


def part_b(limiter_on, seed=3, workers=32):
    """Part B, SIMULATED. Execute a ~1,000-VM synthetic inventory end to end through the real pipeline and engine
    against FakeOCI (5 ms per call; HTTP 429 above 4 calls in flight). The retry policy is the production one with
    its times divided by 100. limiter_on adds the adaptive limiter (start 4, max 32) to a 32-worker engine;
    otherwise `workers` is a fixed pool. Returns: waves and waves succeeded, failed wave numbers, calls served,
    429s, peak calls in flight, duplicates (live resources sharing a display name: must be 0), live instances,
    journal_intact, simulated wall time, and the limiter's peak when used."""
    wls, _ = synth.inventory(230, seed=seed)
    fake = FakeOCI(latency=0.005, max_in_flight=4, provision_polls=2)
    jp = os.path.join(tempfile.mkdtemp(), "journal.jsonl")
    lim = C.AdaptiveLimiter(initial=4, maximum=32) if limiter_on else None
    scale = 0.01                                   # production policy, 100x faster in time
    d = RetryPolicy()
    retry = RetryPolicy(max_attempts=d.max_attempts, base_seconds=d.base_seconds * scale, cap_seconds=d.cap_seconds * scale)

    def mk():
        return Engine(fake, Journal(jp), max_workers=workers, retry=retry, poll_seconds=0.002,
                      rng=random.Random(seed), limiter=lim)
    s = P.Settings("dev", "ocid1.compartment.oc1..scale", TAGS, "scale", "10.0.0.0/16",
                   {"web": "10.0.0.0/20", "app": "10.0.16.0/20", "db": "10.0.32.0/20"},
                   max_apps_per_wave=25, max_vms_per_wave=200, stop_on_wave_failure=False)
    quota = C.StaticQuota({name: 1e9 for pair in C.SHAPE_LIMITS.values() for name in pair})
    t = time.perf_counter()
    rep = P.run(wls, BLUEPRINTS, s, mk, quota=quota)
    wall = time.perf_counter() - t
    calls = sum(1 for _ in fake.calls)
    out = {"mode": "adaptive limiter (32 workers)" if limiter_on else f"fixed {workers} workers", "vms_in_inventory": len(wls),
           "apps_blocked": len(rep.blocked_apps), "vms_moved_by_plan": len(rep.placements),
           "waves": len(rep.wave_results),
           "waves_succeeded": sum(w["status"] == "SUCCEEDED" for w in rep.wave_results),
           "waves_failed": [w["wave"] for w in rep.wave_results if w["status"] != "SUCCEEDED"],
           "api_calls_served": calls, "http_429": fake.throttled, "peak_in_flight": fake.peak_in_flight,
           "duplicates": (lambda n: len(n) - len(set(n)))([r["params"].get("display_name") for r in fake.live().values()]),
           "live_instances": sum(1 for r in fake.live().values() if r["kind"] == "instance"),
           "journal_intact": Journal(jp).verify(), "wall_seconds": round(wall, 2)}
    if lim:
        out["limiter_peak"] = lim.peak_limit
    print("B", out, flush=True)
    return out


def part_c(b):
    """Part C, MODELED: API calls per migrated VM from one Part B result, and the hours 10,000 VMs' calls would
    take at 5, 10 and 20 requests per second. Arithmetic only; real provisioning time usually dominates."""
    per_vm = b["api_calls_served"] / max(1, b["vms_moved_by_plan"])
    return {"api_calls_per_vm": round(per_vm, 2),
            "hours_for_10k_vms_at_requests_per_second": {rps: round(10_000 * per_vm / rps / 3600, 2) for rps in (5, 10, 20)},
            "note": "MODELED: call count from Part B divided by an assumed sustained request rate; "
                    "real OCI provisioning time per instance, not request rate, will often dominate."}


if __name__ == "__main__":
    res = {"A_measured": part_a()}
    res["B_simulated"] = [part_b(False), part_b(False, workers=4), part_b(True)]
    res["C_modeled"] = part_c(res["B_simulated"][2])
    print("C", res["C_modeled"])
    if len(sys.argv) > 1:
        json.dump(res, open(sys.argv[1], "w"), indent=1)
