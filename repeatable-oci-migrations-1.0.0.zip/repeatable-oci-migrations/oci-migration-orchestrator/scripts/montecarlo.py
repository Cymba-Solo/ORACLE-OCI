#!/usr/bin/env python3
"""Monte Carlo: every script, 100 randomized trials each, checking real behaviour, not just exit codes.

  python3 -B scripts/montecarlo.py [--trials 100] [--only name,name] [--out examples/montecarlo_results.json]

Each trial draws its own seed and randomizes what that script is given: estate size and shape, which VM
crashes or fails, injected 429 / 5xx / transport faults, environment (dev or prod), server limits, plan
sizes, Python's hash seed. Two kinds of checks are reported separately, and never averaged together:

  SAFETY      must hold in every trial (no duplicate VM, nothing unsafe accepted, journal intact, the OCM
              plan never newly includes a VM outside the wave, mixed app groups always flagged, ...).
              One violation is a defect.
  COMPLETION  how often the work finished, which depends on how hostile the draw was (MEASURED, reported
              as a rate; a failed completion with safety intact is correct behaviour, e.g. a rollback).

SIMULATED: in-memory OCI and OCM stand-ins; no tenancy. Scripts that are deterministic by design (the
demos, evidence.py, make_example_estate.py) are run 100 times as separate processes under different
hash seeds, and must reproduce their saved outputs byte for byte.

Not repeated: mutate.py. It is deterministic (a fixed list of planted defects, each run once on the final
code); 100 repeats would re-measure the same thing. The unit-test suite is run by `--only unittest` 100 times
in a shuffled order under random hash seeds, which is the Monte Carlo that applies to it.

How to read the output
  One line per scenario: "<name> safety S/N completed C/N (seconds)". S must equal N; C below N is
  acceptable only when the failures are refusals with safety intact. --out (default
  examples/montecarlo_results.json) is updated in place, scenario by scenario, with for each one: the script
  it exercises, trials, safety_pass, per_check_pass (every SAFETY check by name), completed, up to 10
  failures (seed, failed checks, metrics, traceback tail), a metrics sample, and total seconds. Re-run one
  failing trial with --only <name> --trials 1 --first-seed <seed>. Exit code 0 when every selected scenario
  passed every safety check in every trial, else 1.
"""
import argparse
import contextlib
import csv
import io
import json
import os
import random
import subprocess
import sys
import tempfile
import time
from collections import Counter
from types import SimpleNamespace as NS
from unittest import mock

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "scripts"))

from ocio import agent as A, capacity as C, discovery as D, factory as F, ocm as O, pipeline as P, synth  # noqa: E402
from ocio.catalog import BLUEPRINTS                                                                     # noqa: E402
from ocio.engine import Engine, RetryPolicy                                                             # noqa: E402
from ocio.journal import Journal                                                                        # noqa: E402
from ocio.providers import GONE, Crash, FakeOCI                                                         # noqa: E402

TAGS = {"cost_center": "cc-mc", "owner": "montecarlo"}
COMP = "ocid1.compartment.oc1..mc"
QUOTA = C.StaticQuota({n: 1e9 for pair in C.SHAPE_LIMITS.values() for n in pair})


class Clock:
    """A virtual clock for the engine: calling it returns the current simulated time, and sleep() advances it
    instantly. Backoffs and readiness waits therefore cost no real time and stay deterministic per seed."""
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t

    def sleep(self, s):
        """Advance simulated time by s seconds, without waiting."""
        self.t += s


def faults(r, n_max=10, codes=(429, 503, 500)):
    """A random fault queue with no run of 5 or more errors in a row: the engine's 6 attempts can always
    get through it, so a failure to complete would be a real defect, not an unlucky draw."""
    q, run = [], 0
    for _ in range(r.randint(0, n_max)):
        if run < 4 and r.random() < 0.5:
            q.append(r.choice(codes)); run += 1
        else:
            q.append(0); run = 0
    return q


def settings(env, **kw):
    """pipeline.Settings for a Monte Carlo run in `env` (dev or prod), with fixed tags, compartment and CIDRs;
    keyword arguments (wave caps, stop_on_wave_failure, ...) are passed through."""
    return P.Settings(env, COMP, TAGS, "mc", "10.0.0.0/16",
                      {"web": "10.0.1.0/24", "app": "10.0.2.0/24", "db": "10.0.3.0/24"}, **kw)


def instance_names(fake):
    """Counter of display names of the instances that are LIVE in the fake OCI. A count above 1 is a duplicate
    VM, the defect the retry-token and resume logic exist to prevent."""
    return Counter(x["params"]["display_name"] for x in fake.live().values() if x["kind"] == "instance")


# --------------------------------------------------------------------------- scenarios
# Each returns (safety: {check: bool}, completed: bool, metrics: dict)

def sc_pipeline(seed):
    """ocio/pipeline.py (the engine behind `migrate.py run`): crash, failed launch, faults, hand deletion."""
    r = random.Random(seed)
    wls, _ = synth.inventory(r.randint(4, 30), seed=seed)
    env = r.choice(["dev", "prod"])
    s = settings(env, max_apps_per_wave=r.randint(1, 4))
    placed = [p.workload.name for p in P.run(wls, BLUEPRINTS, s, None, execute=False).placements]
    if not placed:
        return {"no_work": True}, True, {"vms": 0}
    fake = FakeOCI(faults={("create", "instance"): faults(r), ("state", "instance"): faults(r),
                           ("create", "subnet"): faults(r, 4)},
                   crash_after_create={r.choice(placed)} if r.random() < 0.5 else set(),
                   fail_provision={r.choice(placed)} if r.random() < 0.5 else set())
    jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")
    clock, asked = Clock(), []
    mk = lambda: Engine(fake, Journal(jp), sleep=clock.sleep, clock=clock, wall=clock,  # noqa: E731
                        rng=random.Random(seed), max_workers=8, limiter=C.AdaptiveLimiter(4, 1, 16))
    approver = lambda name, reasons, plan, wh: (asked.append(name) or True, "mc")  # noqa: E731
    deleted_by_hand, runs, rep = 0, 0, None
    for runs in range(1, 8):
        try:
            rep = P.run(wls, BLUEPRINTS, s, mk, quota=QUOTA, approver=approver)
        except Crash:
            continue
        if rep.wave_results and all(w["status"] == "SUCCEEDED" for w in rep.wave_results):
            if deleted_by_hand == 0 and r.random() < 0.4:          # someone deletes a VM by hand; re-run
                live = [k for k, x in fake.live().items() if x["kind"] == "instance"]
                fake.res[r.choice(live)]["state"] = GONE
                deleted_by_hand = 1
                continue
            break
        fake.fail_provision.clear()
        fake.faults.clear()
    names = instance_names(fake)
    j = Journal(jp)
    wave_runs = {e["workflow"] for e in j.entries if e.get("event") == "run_started" and "network" not in e["workflow"]}
    approved = {e["workflow"] for e in j.entries if e.get("event") == "approval" and e.get("approved")}
    completed = bool(rep and rep.wave_results and all(w["status"] == "SUCCEEDED" for w in rep.wave_results))
    safety = {
        "no_duplicate_vm": all(v == 1 for v in names.values()),
        "only_planned_vms_exist": set(names) <= set(placed),
        "journal_intact": j.verify(),
        "prod_waves_approved_before_running": env != "prod" or wave_runs <= approved,
        "no_orphans_reported": not any(w.get("orphans") for w in (rep.wave_results if rep else [])),
    }
    if completed:
        safety["every_planned_vm_running"] = set(names) == set(placed)
    return safety, completed, {"vms": len(placed), "runs": runs, "env": env, "hand_deleted": deleted_by_hand}


def sc_discovery(seed):
    """ocio/discovery.py (`migrate.py discover`, evidence.py part 1-2) on a random estate."""
    r = random.Random(seed)
    kw = dict(p_observe=r.uniform(0.6, 1.0), p_tagged=r.uniform(0.0, 0.4), p_mutual=r.uniform(0, 0.1),
              noise_flows=r.randint(0, 60))
    assets, flows, listeners, truth = synth.estate(r.randint(20, 120), seed=seed, **kw)
    true_app = {a.ip: truth["app"][a.name] for a in assets}
    share, kind = r.choice([0.0, 0.25, 0.5, 0.7]), r.choice(["generic", "misleading"])
    renamed = {}
    for i, a in enumerate(assets):
        if not a.tags and r.random() < share:
            old = a.name
            a.name = (f"srv{10000 + i}" if kind == "generic"
                      else f"{r.choice(['prod', 'core', 'main', 'apps'])}-{truth['tier'][a.name]}-{i:04d}")
            renamed[old] = a.name
    # the listener export names the same hosts: rename it too (stale names are refused since tune-up 109)
    listeners = {renamed.get(n, n): ports for n, ports in listeners.items()}
    res = D.discover(assets, flows, listeners)
    flagged = set(res.report()["low_confidence_vms"])
    groups = {}
    for a in assets:
        groups.setdefault(res.app[a.name].value, set()).add(true_app[a.ip])
    mixed = [a.name for a in assets if len(groups[res.app[a.name].value]) > 1]
    hi = {(d.from_app, d.to_app) for d in res.deps if d.confidence >= 0.6}
    ack = {"external_ok": sorted({u["dst_ip"] for u in res.unresolved} | {u["src_ip"] for u in res.unresolved_sources}),
           "reviewed_by": "monte-carlo harness"}                # declaring private addresses external needs a name
    wls, _ = res.to_workloads(ack)
    safety = {"mixed_groups_always_flagged": all(m in flagged for m in mixed),
              "every_vm_in_inventory_once": sorted(w.name for w in wls) == sorted(a.name for a in assets)}
    return safety, True, {"vms": len(assets), "renamed": share, "names": kind, "mixed": len(mixed),
                          "flagged_share": round(len(flagged) / len(assets), 3),
                          "hi_precision": (round(len(hi & truth["deps"]) / len(hi), 3) if hi and share == 0 else None)}


def sc_guard(seed):
    """ocio/agent.py guard against adversarial and rule-based proposers on a random inventory."""
    import evidence as E
    r = random.Random(seed)
    wls, _ = synth.inventory(r.randint(10, 60), seed=seed)
    g = A.Guard(wls, BLUEPRINTS)
    unsafe = errors = accepted = 0
    for proposer in (A.HostileProposer(BLUEPRINTS, seed), A.RuleProposer(BLUEPRINTS, {w.name: {"mem_peak_pct": r.randint(0, 100)} for w in wls})):
        for d in A.review(wls, proposer, g):
            if d.accepted:
                accepted += 1
                unsafe += bool(E._unsafe(d))
            elif any("guard error" in x for x in d.reasons):
                errors += 1
    return {"no_unsafe_accepted": unsafe == 0, "no_guard_errors": errors == 0}, True, {"accepted": accepted, "vms": len(wls)}


class FakeOCM:
    """Stateful stand-in for the OCM MigrationClient, modelling what the driver relies on (oci 2.189.0 method
    names): paged list, get with an etag header, update with If-Match (412 on mismatch) and an opc-retry-token
    cache, an asynchronous work request per update (status scripted), and target-asset lifecycle states.
    Injected per trial: failing updates (status or transport, N times), lost responses (the change is applied,
    then the call fails), concurrent console edits between GET and PUT, failed work requests, assets in
    NEEDS_ATTENTION, and an "ignore" mode that accepts updates and changes nothing. SIMULATED."""

    def __init__(self, r, assets, page):
        self.r, self.page = r, page
        self.assets = {k: NS(id=k, migration_asset=NS(display_name=n), is_excluded_from_execution=x,
                             recommended_spec=None, user_spec=None, created_resource_id=None, lifecycle_state="ACTIVE")
                       for k, (n, x) in assets.items()}
        self.etag = {k: "e0" for k in assets}
        self.fail, self.lost, self.race, self.wr_fail = {}, set(), set(), set()
        self.ignore = False
        self.tokens, self.applied, self.wr, self.edited = {}, [], {}, {}

    def list_target_assets(self, migration_plan_id, page=None):
        """One page (size self.page) of target assets sorted by id; next_page is the offset of the next page."""
        items = sorted(self.assets.values(), key=lambda a: a.id)
        i = int(page or 0)
        nxt = i + self.page
        return NS(data=NS(items=items[i:nxt]), next_page=str(nxt) if nxt < len(items) else None, headers={})

    def get_target_asset(self, target_asset_id):
        """The live asset with its current etag. For an asset in self.race, a 'console user' edits it right after
        this read (once), so the driver's next PUT must fail If-Match instead of overwriting the edit."""
        resp = NS(data=self.assets[target_asset_id], headers={"etag": self.etag[target_asset_id]})
        if target_asset_id in self.race:
            self.race.discard(target_asset_id)
            self.etag[target_asset_id] += "+console"
            self.edited[target_asset_id] = True
            self.assets[target_asset_id].created_resource_id = "edited-in-console"    # a field ocio never writes
        return resp

    def update_target_asset(self, target_asset_id, details, if_match=None, opc_retry_token=None):
        """Apply an UpdateVmTargetAssetDetails (inclusion flag, deep copy of user_spec) with the real API's
        conditional and idempotent semantics; return a response carrying an opc-work-request-id."""
        import copy
        import oci
        if opc_retry_token in self.tokens:
            return self.tokens[opc_retry_token]
        left = self.fail.get(target_asset_id)
        if left and left[1] > 0:
            left[1] -= 1
            if left[0] == "transport":
                raise oci.exceptions.RequestException("injected connection reset")
            raise oci.exceptions.ServiceError(left[0], "Injected", {}, "injected")
        if if_match is not None and if_match != self.etag[target_asset_id]:
            raise oci.exceptions.ServiceError(412, "NoEtagMatch", {}, "etag mismatch")
        wid = f"wr-{len(self.wr)}"
        self.wr[wid] = "FAILED" if target_asset_id in self.wr_fail else "SUCCEEDED"
        resp = NS(data=None, headers={"opc-work-request-id": wid})
        if not self.ignore and self.wr[wid] == "SUCCEEDED":
            a = self.assets[target_asset_id]
            if details.is_excluded_from_execution is not None:
                a.is_excluded_from_execution = details.is_excluded_from_execution
            if details.user_spec is not None:
                a.user_spec = copy.deepcopy(details.user_spec)
            self.etag[target_asset_id] = f"e{len(self.applied) + 1}"
            self.applied.append((target_asset_id, opc_retry_token))
        if opc_retry_token:
            self.tokens[opc_retry_token] = resp
        if target_asset_id in self.lost:                 # applied, then the response is lost
            self.lost.discard(target_asset_id)
            raise oci.exceptions.ServiceError(503, "ServiceUnavailable", {}, "response lost")
        return resp

    def get_work_request(self, work_request_id):
        """Status of one update's work request: SUCCEEDED, or FAILED for assets in self.wr_fail."""
        return NS(data=NS(status=self.wr[work_request_id]), headers={})

    def list_work_request_errors(self, work_request_id, page=None):
        """The error of a FAILED work request, as OCM returns them."""
        return NS(data=NS(items=[NS(code="InvalidParameter", message="injected work-request failure")]),
                  next_page=None, headers={})


def sc_ocm(seed):
    """ocio/ocm.py OCMDriver (`ocm-wave --apply`, then `ocm-restore`): random plans and paging, with failing,
    lost, raced and work-request-failed updates, assets OCM marks NEEDS_ATTENTION, and existing specs carrying
    fields ocio does not own. SIMULATED."""
    import copy
    import oci
    r = random.Random(seed)
    m = oci.cloud_migrations.models
    n = r.randint(3, 30)
    vms = [f"vm{i:03d}" for i in range(n)]
    wave = r.sample(vms, r.randint(1, max(1, n // 2)))
    placements = [F.place(F.Workload(v, "app", "app", "Oracle Linux 8", r.choice([2, 4, 8]), r.choice([8, 16, 32])),
                          BLUEPRINTS, {}) for v in wave]
    before = {f"ta-{v}": (v, r.random() < 0.5) for v in vms}
    c = FakeOCM(r, before, page=r.randint(1, 10))
    kept_ip = {}
    for tid in r.sample(sorted(c.assets), r.randint(0, n // 2)):        # specs with fields ocio does not own
        ip = f"10.9.{r.randint(0, 255)}.{r.randint(1, 254)}"
        c.assets[tid].user_spec = m.LaunchInstanceDetails(shape="VM.Standard2.1", is_pv_encryption_in_transit_enabled=True,
                                                          create_vnic_details=m.CreateVnicDetails(subnet_id="ocid1.subnet.oc1.phx.app", private_ip=ip))
        kept_ip[tid] = ip
    for tid in r.sample(sorted(c.assets), r.randint(0, 3)):
        c.fail[tid] = [r.choice([400, 409, 429, 500, 503, "transport"]), r.randint(1, 6)]
    c.lost = set(r.sample(sorted(c.assets), r.randint(0, 2)))
    c.race = set(r.sample(sorted(c.assets), r.choice([0, 0, 0, 1])))
    c.wr_fail = set(r.sample(sorted(c.assets), r.choice([0, 0, 0, 1])))
    attention = set(r.sample(sorted(c.assets), r.choice([0, 0, 0, 0, 1])))
    for tid in attention:
        c.assets[tid].lifecycle_state = "NEEDS_ATTENTION"
    c.ignore = r.random() < 0.05
    included_before = {k for k, (_, x) in before.items() if not x}
    in_wave = {f"ta-{v}" for v in wave}
    subnets = {"subnet_web": "ocid1.subnet.oc1.phx.web", "subnet_app": "ocid1.subnet.oc1.phx.app", "subnet_db": "ocid1.subnet.oc1.phx.db"}
    snapshots = []
    ok, err = True, ""
    try:
        res = O.OCMDriver(c, "ocid1.ocmmigrationplan.oc1.phx.plan1", m, attempts=5, sleep=lambda s: None).apply_wave(
            placements, subnets, COMP, "AD-1", on_before=lambda snap: snapshots.append(copy.deepcopy(snap)))
    except O.OCMError as e:
        ok, err = False, str(e)[:80]
    included = {k for k, a in c.assets.items() if not a.is_excluded_from_execution}
    tokens = [t for _, t in c.applied if t]
    safety = {"never_newly_includes_outside_wave": included - in_wave <= included_before - in_wave,
              "no_change_applied_twice": len(tokens) == len(set(tokens)),
              "not_ready_asset_never_newly_included": not ((attention & in_wave) - included_before) & included
              if attention else True,
              "before_state_recorded_before_any_change": bool(snapshots) or not c.applied}
    if attention & in_wave:
        safety["not_ready_asset_stops_before_any_change"] = not ok and c.applied == []
    if ok:
        safety["success_means_exactly_the_wave"] = included == in_wave and set(res["verified_included"]) == in_wave
        safety["success_means_specs_applied"] = all(getattr(c.assets[t].user_spec, "shape", None) for t in in_wave)
        safety["fields_ocio_does_not_own_kept"] = all(
            c.assets[t].user_spec.create_vnic_details.private_ip == kept_ip[t] for t in in_wave if t in kept_ip)
    if ok and snapshots and r.random() < 0.5:                              # restore what the journal recorded
        c.fail, c.lost, c.race, c.wr_fail, c.ignore = {}, set(), set(), set(), False
        O.OCMDriver(c, "ocid1.ocmmigrationplan.oc1.phx.plan1", m, attempts=5, sleep=lambda s: None).restore(snapshots[0])
        safety["restore_returns_the_recorded_state"] = all(
            c.assets[t].is_excluded_from_execution == st["is_excluded_from_execution"]
            and (st["user_spec"] is None or oci.util.to_dict(c.assets[t].user_spec) == st["user_spec"])
            for t, st in snapshots[0].items())
    return safety, ok, {"assets": n, "wave": len(wave), "error": err, "outside_still_included": len(included - in_wave)}


def sc_admission(seed):
    """ocio/admission.py: random evidence documents, each mutated in zero or more ways; the gate must admit a
    document exactly when an independent check of the policy says it should. SIMULATED (no clock waits)."""
    from ocio import admission as AD
    r = random.Random(seed)
    checks = r.sample(["capacity", "application_health", "rollback_rehearsal", "backup", "dns", "change_ticket"],
                      r.randint(1, 4))
    policy = {"required_checks": checks, "max_age_seconds": r.choice([60, 300, 900, 3600])}
    now = 1_800_000_000.0
    pid, wave = f"{r.getrandbits(48):012x}", r.randint(1, 9)
    rows = [{"name": c, "passed": True, "observer": "ops", "source_ref": f"ticket/{c}"} for c in checks]
    doc = {"plan_id": pid, "wave": wave, "observed_at": now - r.uniform(0, policy["max_age_seconds"] * 0.9), "checks": rows}
    valid = True
    for _ in range(r.choice([0, 0, 1, 1, 2])):
        kinds = ["plan", "wave", "wave_type", "extra_fail", "extra_ok", "stale", "future", "naive"] + (
            ["fail", "observer", "ref", "drop", "dup"] if rows else [])
        kind = r.choice(kinds)                     # row mutations only while there is a row to mutate
        valid = False
        if kind == "plan": doc["plan_id"] = "f" * 12
        elif kind == "wave": doc["wave"] = wave + 1
        elif kind == "wave_type": doc["wave"] = r.choice([float(wave), str(wave)] + ([True] if wave == 1 else []))
        elif kind == "extra_fail": rows.append({"name": "extra_check", "passed": r.choice([False, None, "no"]),
                                                "observer": "ops", "source_ref": "ticket/x"})
        elif kind == "extra_ok": rows.append({"name": "extra_check", "passed": True, "observer": "ops",
                                              "source_ref": "ticket/x"})
        elif kind == "stale": doc["observed_at"] = now - policy["max_age_seconds"] - 1
        elif kind == "future": doc["observed_at"] = now + AD.CLOCK_SKEW_SECONDS + 5
        elif kind == "fail": r.choice(rows)["passed"] = r.choice([False, "yes", 1, None])
        elif kind == "observer": r.choice(rows)["observer"] = r.choice(["", "  ", None])
        elif kind == "ref": r.choice(rows)["source_ref"] = r.choice(["", None])
        elif kind == "drop": rows.remove(r.choice(rows)) if rows else None
        elif kind == "dup": rows.append(dict(r.choice(rows))) if rows else None
        elif kind == "naive": doc["observed_at"] = "2027-01-15T08:00:00"
    docs = [doc] + ([dict(doc)] if r.random() < 0.05 else [])          # two documents for one wave: conflict
    # The oracle judges the FINAL document from the policy's rules, written here independently of the module
    # (a "dup" then "drop" can remove the very duplicate it added, leaving a valid document).
    at = doc["observed_at"]
    fresh = isinstance(at, (int, float)) and not isinstance(at, bool) and \
        now - policy["max_age_seconds"] <= at <= now + AD.CLOCK_SKEW_SECONDS
    rows_ok = all(sum(1 for x in rows if x.get("name") == c) == 1 for c in checks) and all(
        x.get("passed") is True and isinstance(x.get("observer"), str) and x["observer"].strip()
        and isinstance(x.get("source_ref"), str) and x["source_ref"].strip() for x in rows if x.get("name") in checks)
    extra_ok = all(x.get("passed") is True for x in rows if x.get("name") not in checks)   # recorded failures count
    valid = (len(docs) == 1 and doc["plan_id"] == pid and type(doc["wave"]) is int and doc["wave"] == wave
             and fresh and rows_ok and extra_ok)
    res = AD.evaluate(pid, wave, docs, policy, now)
    return ({"admits_exactly_the_valid_documents": res["allowed"] == valid,
             "every_refusal_has_a_reason": res["allowed"] or bool(res["reasons"])}, True,
            {"valid": valid, "reasons": len(res["reasons"])})


def sc_console(seed):
    """ocio/ui/launch.py build_argv: random radio choices and field values (including hostile ones); what the
    server would run must parse with the real CLI parser, carry no field value that could act as a flag, and
    keep apply gated by the reviewed id. SIMULATED (no server, no subprocess)."""
    import argparse
    from ocio import cli as CLI
    from ocio.ui import launch as LA
    r = random.Random(seed)
    d = tempfile.mkdtemp()
    for f in ("inv.csv", "a.csv", "f.csv", "s.json", "j.jsonl", "m.json"):
        open(f"{d}/{f}", "w").close()
    cmd = r.choice([c[0] for c in LA.COMMANDS])
    radios = {k: r.choice([v for v, *_ in opts] + (["evil; rm -rf /"] if r.random() < 0.05 else []))
              for k, _, cmds, opts, _ in LA.RADIOS if cmd in cmds and r.random() < 0.8}
    good = {"path_in": ["inv.csv", "a.csv", "f.csv", "s.json", "j.jsonl", "m.json"], "path_out": ["out.json", "j.jsonl"],
            "ocid:compartment,tenancy": [COMP], "ocid:vcn": ["ocid1.vcn.oc1.phx.v"],
            "ocid:": ["ocid1.ocmmigrationplan.oc1.phx.p"], "text": ["AD-1", "abc123def456", "cc"], "int": ["3", "1"],
            "region": ["us-phoenix-1"], "person": ["J. Doe"]}
    hostile = ["--apply", "-x", "$(id)", "a\nb", "nope.csv", "", "x" * 600, "; rm -rf /", "ocid1.vcn.oc1.phx.v"]
    fields = {k: (r.choice(good[kind]) if r.random() < 0.85 else r.choice(hostile))
              for k, _, kind, *_ in LA.FIELDS if r.random() < 0.9}
    argv, probs = LA.build_argv({"command": cmd, "radios": radios, "fields": fields}, d)
    safety = {}
    if not probs:
        try:
            a = CLI.parser().parse_args(argv)
            safety["argv_parses_with_the_real_cli"] = True
        except SystemExit:
            safety["argv_parses_with_the_real_cli"] = False
            a = None
        values = [argv[i + 1] for i, x in enumerate(argv[:-1]) if x.startswith("--") and not argv[i + 1].startswith("--")]
        safety["no_value_starts_with_dash"] = all(not v.startswith("-") for v in values)
        if a is not None and getattr(a, "apply", False) and cmd in ("run", "ocm-wave"):
            safety["apply_carries_the_reviewed_plan_id"] = bool(a.plan_id)
    else:
        safety["refusal_is_explained"] = all(isinstance(p, str) and p for p in probs)
    return safety, not probs, {"command": cmd, "problems": len(probs)}


def sc_journal(seed):
    """ocio/journal.py: random appends, then one random kind of damage (edit, removal, reorder, torn last line)
    or none; verify_detail must flag damage at the first damaged entry and stay silent otherwise; a second
    writer is refused while the first holds the lock. SIMULATED."""
    from ocio.journal import Journal as J, exclusive, JournalBusy, JournalError
    r = random.Random(seed)
    d = tempfile.mkdtemp()
    p = f"{d}/j.jsonl"
    n = r.randint(3, 40)
    with exclusive(p):
        busy = False
        try:
            with exclusive(p):
                pass
        except JournalBusy:
            busy = True
        j = J(p)
        for i in range(n):
            j.append(event=r.choice(["a", "b", "c"]), n=i, x=r.random())
    lines = open(p).read().splitlines()
    kind = r.choice(["none", "edit", "remove", "swap", "torn"])
    k = r.randrange(1, n - 1)
    if kind == "edit":
        lines[k] = lines[k].replace(f'"n": {k},', f'"n": {k + 1000},')
    elif kind == "remove":
        del lines[k]
    elif kind == "swap":
        lines[k], lines[k + 1] = lines[k + 1], lines[k]
    with open(p, "w") as f:
        f.write("\n".join(lines) + "\n" + ('{"event": "creat' if kind == "torn" else ""))
    safety = {"second_writer_refused": busy}
    try:
        det = J(p).verify_detail()
        safety["damage_located_exactly"] = (det is None) if kind == "none" else (det is not None and det["line"] == k + 1)
    except JournalError:
        safety["damage_located_exactly"] = kind == "torn"
    return safety, True, {"entries": n, "damage": kind}


def _write_estate(d, assets, flows, listeners):
    with open(f"{d}/assets.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["name", "ip", "os", "vcpus", "memory_gb", "tags"])
        for a in assets:
            w.writerow([a.name, a.ip, a.os, a.vcpus, a.memory_gb, ";".join(f"{k}={v}" for k, v in a.tags.items())])
    with open(f"{d}/flows.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["src_ip", "dst_ip", "dst_port", "connections"]); w.writerows(flows)
    with open(f"{d}/listeners.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["name", "port"])
        for n, ports in sorted(listeners.items()):
            for p in sorted(ports):
                w.writerow([n, p])


def sc_cli(seed):
    """scripts/migrate.py end to end: discover -> review -> plan -> run (dry, apply) -> teardown, and
    ocm-wave (dry, apply) for wave 1."""
    import migrate as M
    r = random.Random(seed)
    d = tempfile.mkdtemp()
    assets, flows, listeners, _ = synth.estate(r.randint(4, 14), seed=seed)
    _write_estate(d, assets, flows, listeners)
    out = []
    say = out.append
    rc = {}
    rc["discover"] = M.main(["discover", "--assets", f"{d}/assets.csv", "--flows", f"{d}/flows.csv",
                             "--listeners", f"{d}/listeners.csv", "--out", f"{d}/f.json"], out=say)
    tpl = json.load(open(f"{d}/f.decisions-template.json"))
    dec = {"dependencies": dict(tpl["dependencies"], **{k: "accept" for k in tpl["_review_these_low_confidence"]}),
           "external_ok": tpl["_unresolved_private_destinations"] + tpl["_unresolved_private_sources"],
           "reviewed_by": "monte-carlo harness"}
    json.dump(dec, open(f"{d}/dec.json", "w"))
    rc["review"] = M.main(["discover", "--assets", f"{d}/assets.csv", "--flows", f"{d}/flows.csv",
                           "--listeners", f"{d}/listeners.csv", "--out", f"{d}/f.json", "--decisions", f"{d}/dec.json",
                           "--inventory-out", f"{d}/inv.csv"], out=say)
    env = r.choice(["dev", "prod"])
    common = ["--inventory", f"{d}/inv.csv", "--env", env, "--tag", "cost_center=cc", "--tag", "owner=mc",
              "--compartment", COMP, "--availability-domain", "AD-1"]
    rc["plan"] = M.main(["plan", *common], out=say)
    base = ["run", *common, "--journal", f"{d}/run.jsonl"]
    rc["run_dry"] = M.main(base, out=say)
    pid = json.loads(out[-2])["plan_id"]
    placed = json.loads(out[-2])["summary"]["placed"]
    fake = FakeOCI(faults={("create", "instance"): faults(r), ("state", "instance"): faults(r)})
    extra = ["--apply", "--plan-id", pid] + (["--approve-by", "mc"] if env == "prod" else [])
    rc["run_apply"] = M.main(base + extra, out=say, provider_factory=lambda: fake, quota=QUOTA)
    names = instance_names(fake)
    j = Journal(f"{d}/run.jsonl")
    # Nothing placeable (every app blocked): plan and run must stop with exit 2 and touch nothing.
    want = {k: (0 if placed or k in ("discover", "review") else 2) for k in rc}
    safety = {"steps_exit_as_designed": rc == want,
              "nothing_called_when_nothing_placeable": placed > 0 or fake.calls == [],
              "no_duplicate_vm": all(v == 1 for v in names.values()),
              "every_planned_vm_running": sum(names.values()) == placed,
              "journal_intact": j.verify()}
    # teardown every run, newest first: everything goes, the journal stays intact
    runs = [e["run_id"] for e in j.entries if e.get("event") == "run_started"]
    tds = [M.main(["teardown", "--journal", f"{d}/run.jsonl", "--run-id", rid, "--apply"], out=say,
                  provider_factory=lambda: fake) for rid in reversed(runs)]
    safety["teardown_leaves_nothing"] = all(t == 0 for t in tds) and fake.live() == {}
    safety["journal_intact_after_teardown"] = Journal(f"{d}/run.jsonl").verify()
    # the migration path, wave 1 (when the plan has a wave at all: every app may be blocked)
    if placed == 0:
        return safety, safety["steps_exit_as_designed"], {"vms": len(assets), "env": env, "placed": 0}
    rows = list(csv.DictReader(open(f"{d}/inv.csv")))
    json.dump({"subnet_web": "ocid1.subnet.oc1.phx.web", "subnet_app": "ocid1.subnet.oc1.phx.app", "subnet_db": "ocid1.subnet.oc1.phx.db"},
              open(f"{d}/sub.json", "w"))
    ocm = ["ocm-wave", *common, "--wave", "1", "--migration-plan", "ocid1.ocmmigrationplan.oc1.phx.plan1", "--subnet-map", f"{d}/sub.json",
           "--journal", f"{d}/ocm.jsonl"]
    rc_dry = M.main(ocm, out=say, ocm_client=mock.Mock())
    od = json.loads(out[-1])
    c = FakeOCM(r, {f"ta-{x['name']}": (x["name"], r.random() < 0.5) for x in rows}, page=r.randint(1, 8))
    rc_apply = M.main(ocm + ["--apply", "--plan-id", od["plan_id"]] + (["--approve-by", "mc"] if env == "prod" else []),
                      out=say, ocm_client=c, quota=QUOTA)
    wave_vms = {f"ta-{n}" for n in od["target_asset_updates"]}
    included = {k for k, a in c.assets.items() if not a.is_excluded_from_execution}
    safety["ocm_dry_run_exit_0"] = rc_dry == 0
    safety["ocm_apply_exit_0_and_exactly_wave_1"] = rc_apply == 0 and included == wave_vms
    safety["ocm_journal_intact"] = Journal(f"{d}/ocm.jsonl").verify()
    return safety, safety["steps_exit_as_designed"] and rc_apply == 0, {"vms": len(assets), "env": env, "placed": placed}


def sc_live_smoke(seed):
    """scripts/live_smoke.py: dry run must touch nothing; apply must create, verify and remove everything."""
    import live_smoke as L
    r = random.Random(seed)
    d = tempfile.mkdtemp()
    argv = ["--compartment", COMP, "--availability-domain", "AD-1", "--journal", f"{d}/j.jsonl"]
    if r.random() < 0.5:
        argv += ["--with-instance", "--image-ocid", "ocid1.image.oc1..mc"]
    out = []
    dry = L.main(argv, provider_factory=lambda: (_ for _ in ()).throw(AssertionError("dry run built a provider")),
                 out=out.append)
    fake = FakeOCI(faults={("create", k): faults(r, 6) for k in ("vcn", "subnet", "instance")} |
                   {("state", k): faults(r, 6) for k in ("vcn", "subnet", "instance")} |
                   {("delete", k): faults(r, 4) for k in ("vcn", "subnet", "instance")})
    rc = L.main(argv + ["--apply"], provider_factory=lambda: fake, out=out.append)
    rep = json.loads(out[-1])
    safety = {"dry_run_creates_nothing": dry == 0, "pass_reported": rc == 0 and rep["result"] == "PASS",
              "nothing_left_behind": fake.live() == {}, "journal_intact": rep["journal_intact"]}
    return safety, rc == 0, {"with_instance": "--with-instance" in argv, "calls": len(fake.calls)}


def sc_scale_pacing(seed):
    """scripts/scale_test.py Part B, adaptive arm, against a server whose limit the client is not told."""
    r = random.Random(seed)
    wls, _ = synth.inventory(r.randint(10, 40), seed=seed)
    limit = r.randint(2, 8)
    fake = FakeOCI(latency=r.uniform(0.0005, 0.002), max_in_flight=limit, provision_polls=2)
    jp = os.path.join(tempfile.mkdtemp(), "j.jsonl")
    lim = C.AdaptiveLimiter(initial=4, maximum=32)
    d, k = RetryPolicy(), 0.01
    retry = RetryPolicy(d.max_attempts, d.base_seconds * k, d.cap_seconds * k)
    mk = lambda: Engine(fake, Journal(jp), max_workers=32, retry=retry, poll_seconds=0.001,  # noqa: E731
                        rng=random.Random(seed), limiter=lim)
    s = settings("dev", max_apps_per_wave=r.randint(2, 8), stop_on_wave_failure=False)
    rep = P.run(wls, BLUEPRINTS, s, mk, quota=QUOTA)
    names = instance_names(fake)
    done = [w for w in rep.wave_results if w["status"] == "SUCCEEDED"]
    safety = {"no_duplicate_vm": all(v == 1 for v in names.values()), "journal_intact": Journal(jp).verify(),
              "never_above_server_limit": fake.peak_in_flight <= limit,
              "failed_waves_left_nothing": sum(names.values()) == sum(w["vms"] for w in done)}
    return safety, len(done) == len(rep.wave_results), {"server_limit": limit, "http_429": fake.throttled,
                                                       "waves": len(rep.wave_results), "succeeded": len(done)}


def _proc(args, hashseed, cwd=HERE):
    """Run `python -B <args>` as a separate process under PYTHONHASHSEED=hashseed; (returncode, stdout, stderr)."""
    p = subprocess.run([sys.executable, "-B", *args], cwd=cwd, capture_output=True, text=True, timeout=600,
                       env=dict(os.environ, PYTHONHASHSEED=str(hashseed), PYTHONDONTWRITEBYTECODE="1"))
    return p.returncode, p.stdout, p.stderr


def sc_demo(seed):
    """demo.py in a fresh process under hash seed `seed`: must exit 0 and print exactly examples/demo_output.txt."""
    rc, outp, err = _proc(["demo.py"], seed)
    ref = open(os.path.join(HERE, "examples", "demo_output.txt")).read()
    return {"exit_0": rc == 0, "reproduces_saved_output": outp == ref}, rc == 0, {}


def sc_demo_v2(seed):
    """demo_v2.py in a fresh process: must exit 0, print exactly examples/demo_v2_output.txt, and end with every
    placed instance live and no two live resources sharing a name."""
    rc, outp, err = _proc(["demo_v2.py"], seed)
    ref = open(os.path.join(HERE, "examples", "demo_v2_output.txt")).read()
    return {"exit_0": rc == 0, "reproduces_saved_output": outp == ref,
            "end_state_line": "instances live: 24 of 24 placed | live resources sharing a name: 0" in outp}, rc == 0, {}


def sc_evidence(seed):
    """scripts/evidence.py in a fresh process: its JSON must be byte-identical to examples/evidence.json."""
    f = os.path.join(tempfile.mkdtemp(), "e.json")
    rc, _, _ = _proc(["scripts/evidence.py", f], seed)
    same = rc == 0 and open(f).read() == open(os.path.join(HERE, "examples", "evidence.json")).read()
    return {"exit_0": rc == 0, "reproduces_saved_output": same}, rc == 0, {}


def sc_make_estate(seed):
    """make_example_estate.main() into a temporary folder: the three CSVs must equal examples/estate/."""
    d = tempfile.mkdtemp()
    rc, _, _ = _proc(["-c", f"import sys; sys.path.insert(0, {HERE!r}); sys.path.insert(0, {os.path.join(HERE, 'scripts')!r});"
                      f"import make_example_estate as m; m.main(out={d!r})"], seed)
    same = all(open(f"{d}/{n}").read() == open(os.path.join(HERE, "examples", "estate", n)).read()
               for n in ("assets.csv", "flows.csv", "listeners.csv"))
    return {"exit_0": rc == 0, "reproduces_saved_estate": same}, rc == 0, {}


def sc_unittest(seed):
    """The whole suite, in a shuffled order, under a random hash seed."""
    code = ("import random, sys, unittest\n"
            f"sys.path.insert(0, {HERE!r})\n"
            f"s = unittest.defaultTestLoader.discover({HERE!r}, top_level_dir={HERE!r})\n"
            "flat = []\n"
            "def walk(t):\n"
            "    for x in t:\n"
            "        (walk(x) if isinstance(x, unittest.TestSuite) else flat.append(x))\n"
            "walk(s)\n"
            f"random.Random({seed}).shuffle(flat)\n"
            "r = unittest.TextTestRunner(stream=open('/dev/null', 'w'), verbosity=0).run(unittest.TestSuite(flat))\n"
            "print(r.testsRun, len(r.failures), len(r.errors))\n"
            "sys.exit(0 if r.wasSuccessful() else 1)\n")
    rc, outp, err = _proc(["-c", code], seed)
    last = (outp.strip().splitlines() or [""])[-1].split()        # tests may print; the counts are the last line
    ran = int(last[0]) if last and last[0].isdigit() else 0
    return {"all_tests_pass": rc == 0, "suite_ran": ran > 0}, rc == 0, {"ran": ran, "detail": outp.strip()[-60:]}


SCENARIOS = {"pipeline": sc_pipeline, "discovery": sc_discovery, "guard": sc_guard, "ocm_driver": sc_ocm,
             "cli_migrate": sc_cli, "live_smoke": sc_live_smoke, "scale_pacing": sc_scale_pacing,
             "demo": sc_demo, "demo_v2": sc_demo_v2, "evidence": sc_evidence, "make_example_estate": sc_make_estate,
             "unittest": sc_unittest, "admission": sc_admission, "console": sc_console, "journal": sc_journal}
SCRIPT_OF = {"pipeline": "ocio/pipeline.py (migrate.py run)", "discovery": "ocio/discovery.py (migrate.py discover)",
             "guard": "ocio/agent.py", "ocm_driver": "ocio/ocm.py (migrate.py ocm-wave)",
             "cli_migrate": "ocio/cli.py (ocio / scripts/migrate.py)", "live_smoke": "scripts/live_smoke.py",
             "scale_pacing": "scripts/scale_test.py (Part B)", "demo": "demo.py", "demo_v2": "demo_v2.py",
             "evidence": "scripts/evidence.py", "make_example_estate": "scripts/make_example_estate.py",
             "unittest": "tests/ (whole suite)", "admission": "ocio/admission.py",
             "console": "ocio/ui/launch.py (build_argv)", "journal": "ocio/journal.py"}


def run_one(name, seed):
    """Run scenario `name` once with `seed`, with its stdout captured. Returns {seed, safety, completed, metrics,
    error, seconds}. An exception or SystemExit inside the scenario is recorded as safety {"no_crash": False}
    with the end of its traceback, never raised: a crash is a finding, not the end of the run."""
    t = time.perf_counter()
    try:
        # The CLI and smoke test build their engines with the real clock (5 s polls); skip the waiting there
        # only. Elsewhere sleeps are injected or are part of the simulation (server latency).
        no_wait = mock.patch("time.sleep", lambda s: None) if name in ("cli_migrate", "live_smoke") else contextlib.nullcontext()
        with contextlib.redirect_stdout(io.StringIO()), no_wait:
            safety, completed, metrics = SCENARIOS[name](seed)
        err = None
    except (Exception, SystemExit) as e:                      # noqa: BLE001 - a crash or exit is a recorded failure
        import traceback
        safety, completed, metrics, err = {"no_crash": False}, False, {}, traceback.format_exc()[-600:]
    return {"seed": seed, "safety": safety, "completed": completed, "metrics": metrics, "error": err,
            "seconds": round(time.perf_counter() - t, 3)}


def main(argv=None):
    """Run --trials trials (seeds --first-seed, +1, ...) of each scenario in --only (default: all), print one
    summary line per scenario and merge the results into --out after each one. Exit 0 if every selected
    scenario passed every safety check in every trial, else 1."""
    ap = argparse.ArgumentParser()
    ap.add_argument("--trials", type=int, default=100)
    ap.add_argument("--only", default="")
    ap.add_argument("--out", default=os.path.join(HERE, "examples", "montecarlo_results.json"))
    ap.add_argument("--first-seed", type=int, default=1000)
    a = ap.parse_args(argv)
    names = [n for n in SCENARIOS if not a.only or n in a.only.split(",")]
    results = json.load(open(a.out)) if os.path.exists(a.out) else {}
    for name in names:
        trials = [run_one(name, a.first_seed + i) for i in range(a.trials)]
        bad = [t for t in trials if not all(t["safety"].values())]
        checks = sorted({k for t in trials for k in t["safety"]})
        results[name] = {
            "script": SCRIPT_OF[name], "trials": len(trials),
            "safety_pass": len(trials) - len(bad),
            "per_check_pass": {k: sum(1 for t in trials if t["safety"].get(k, True)) for k in checks},
            "completed": sum(t["completed"] for t in trials),
            "failures": [{"seed": t["seed"], "failed": [k for k, v in t["safety"].items() if not v],
                          "metrics": t["metrics"], "error": t["error"]} for t in bad][:10],
            "metrics_sample": [t["metrics"] for t in trials[:5]],
            "seconds_total": round(sum(t["seconds"] for t in trials), 1)}
        if name == "discovery":
            p = [t["metrics"]["hi_precision"] for t in trials if t["metrics"].get("hi_precision") is not None]
            results[name]["hi_precision_unrenamed"] = {"n": len(p), "min": min(p, default=None),
                                                       "mean": round(sum(p) / len(p), 4) if p else None}
        if name == "scale_pacing":
            results[name]["by_server_limit"] = {
                str(k): {"trials": sum(1 for t in trials if t["metrics"].get("server_limit") == k),
                         "completed": sum(1 for t in trials if t["metrics"].get("server_limit") == k and t["completed"])}
                for k in range(2, 9)}
        print(f"{name:22s} safety {results[name]['safety_pass']}/{len(trials)}  completed {results[name]['completed']}/{len(trials)}"
              f"  ({results[name]['seconds_total']} s)", flush=True)
        json.dump(results, open(a.out, "w"), indent=1, default=str)
    return 0 if all(r["safety_pass"] == r["trials"] for k, r in results.items() if k in names) else 1


if __name__ == "__main__":
    sys.exit(main())
