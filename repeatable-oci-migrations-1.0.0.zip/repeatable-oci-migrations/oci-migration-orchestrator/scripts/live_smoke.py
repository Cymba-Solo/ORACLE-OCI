#!/usr/bin/env python3
"""Live smoke test against a real OCI tenancy. DRY RUN unless --apply is given.

NOT RUN in the build environment (no tenancy there). Its dry-run path and its apply-and-teardown path
are tested against the simulated OCI (tests/test_v2.py); the first live run is the real test.

What it does with --apply, in a compartment you choose:
  1. creates one VCN and one private subnet (no public IPs), waits until both are AVAILABLE;
  2. with --with-instance, launches one small instance in that subnet and waits until RUNNING;
  3. tears everything down again, newest first, and waits until each resource is gone
     (unless --keep), then verifies the run journal's hash chain.

Cost: VCNs and subnets are free. The default instance shape VM.Standard.E2.1.Micro is Always Free with
conditions (Oracle "Always Free Resources" page, read 2026-10-21): up to two per tenancy, created in the
tenancy's HOME region, and only in one availability domain there. Elsewhere it is billed normally. Omit
--with-instance to create no compute at all.

Same checks as the main command line before anything is created: compartment and image OCIDs, the
availability domain against the tenancy's real ones, the session's region against --region, any of the
four auth modes, explicit SDK timeouts, and one writer per journal.

Example
  python3 scripts/live_smoke.py --compartment ocid1.compartment.oc1..xxx --availability-domain "Uocm:PHX-AD-1"
  python3 scripts/live_smoke.py --compartment ... --availability-domain ... --apply
  python3 scripts/live_smoke.py --compartment ... --availability-domain ... --apply \
      --with-instance --image-ocid ocid1.image.oc1.phx.xxx

Output and exit codes
  Prints the planned workflow as JSON ("mode": "DRY RUN" or "APPLY"). With --apply it then prints a report:
  network (and instance) status and OCIDs, each teardown result (with any orphans: resources it could not
  confirm deleted), journal_intact, and result PASS or FAIL.
    0  dry run printed, or apply PASSED (created, verified, torn down with no orphans, journal intact)
    1  apply ran but FAILED: read the report; orphans name resources to delete by hand
    2  stopped before anything was created: a policy gate, or a bad OCID / AD / region / argument
  The journal (--journal, default ocio-live-smoke.jsonl) records every step and is held exclusively while
  --apply runs; `ocio status --journal ...` summarises it afterwards.
"""
import argparse
import json
import os
import sys
import uuid

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ocio import cli, policy                                  # noqa: E402
from ocio.engine import Engine                                # noqa: E402
from ocio.journal import Journal                              # noqa: E402
from ocio.spec import Step, Workflow, validate                # noqa: E402


def workflows(a, suffix):
    """(network workflow, instance workflow or None) for this smoke run. Names carry a random suffix so two runs
    never collide. The network is one VCN and one subnet with prohibit_public_ip_on_vnic=True; the instance
    (only with --with-instance) is launched without a public IP, its subnet filled in after the network exists.
    Tags: cost_center, owner (from the arguments) and purpose=ocio-live-smoke, so the resources are easy to find."""
    tags = {"cost_center": a.cost_center, "owner": a.owner, "purpose": "ocio-live-smoke"}
    name = f"ocio-smoke-{suffix}"
    lz = Workflow(f"{name}-network", "dev", a.compartment, (
        Step("vcn", "vcn", {"display_name": f"{name}-vcn", "cidr_block": a.vcn_cidr, "dns_label": "ociosmoke"}),
        Step("subnet", "subnet", {"display_name": f"{name}-subnet", "cidr_block": a.subnet_cidr,
                                  "vcn_id": "${vcn.id}", "prohibit_public_ip_on_vnic": True,
                                  "dns_label": "smoke"}, ("vcn",)),
    ), tags)
    validate(lz)
    inst = None
    if a.with_instance:
        inst = Workflow(f"{name}-instance", "dev", a.compartment, (
            Step("vm", "instance", {"display_name": f"{name}-vm", "shape": a.shape, "ocpus": a.ocpus,
                                    "memory_gbs": a.memory_gbs, "assign_public_ip": False,
                                    "image_id": a.image_ocid, "availability_domain": a.availability_domain,
                                    "subnet_id": "__SUBNET__"}),), tags)
    return lz, inst


def gates(shape):
    """The policy gates this run must pass before any call: required tags, sane CIDRs, no public IP in prod, and
    only the one shape asked for (so a typo cannot launch something larger)."""
    return (policy.required_tags(), policy.cidr_sanity, policy.no_public_ip_in_prod, policy.allowed_shapes({shape}))


def parser():
    """Command-line options. Abbreviations are refused (allow_abbrev=False), as in the main command line."""
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0], allow_abbrev=False)
    ap.add_argument("--compartment", required=True)
    ap.add_argument("--availability-domain", required=True)
    ap.add_argument("--apply", action="store_true", help="actually create resources (default: dry run)")
    ap.add_argument("--keep", action="store_true", help="do not tear down after verifying")
    ap.add_argument("--with-instance", action="store_true")
    ap.add_argument("--image-ocid", default=None)
    ap.add_argument("--shape", default="VM.Standard.E2.1.Micro")
    ap.add_argument("--ocpus", type=int, default=1)
    ap.add_argument("--memory-gbs", type=int, default=1)
    ap.add_argument("--vcn-cidr", default="10.231.0.0/24")
    ap.add_argument("--subnet-cidr", default="10.231.0.0/26")
    ap.add_argument("--profile", default="DEFAULT")
    ap.add_argument("--config", default="~/.oci/config")
    ap.add_argument("--cost-center", default="smoke-test")
    ap.add_argument("--owner", default=os.environ.get("USER", "operator"))
    ap.add_argument("--journal", default="ocio-live-smoke.jsonl")
    ap.add_argument("--auth", choices=["api_key", "security_token", "instance_principal", "resource_principal"],
                    default="api_key")
    ap.add_argument("--sdk-timeout", type=cli._timeout, default=(10.0, 60.0), help="connect,read seconds")
    ap.add_argument("--region", help="refuse an OCI session in any other region")
    return ap


def main(argv=None, provider_factory=None, out=print, identity=None, tenancy=None):
    """Check the arguments, then run (see _run). The OCIDs are checked first, in every mode. A dry run stops
    there. --apply holds the journal exclusively, opens an OCI session with the chosen auth mode (refused if its
    region differs from --region), checks the availability domain against the tenancy's real ones, and only then
    creates anything. provider_factory / identity / tenancy / out are injection points for the tests (simulated
    OCI); left as None, the real SDK is used. Returns the exit code. A refusal before anything is created
    (bad OCID, unknown AD, wrong region, busy journal) prints its reason and exits 2."""
    try:
        return _main(argv, provider_factory, out, identity, tenancy)
    except cli.Refused as e:
        print(f"live_smoke: {e}", file=sys.stderr)
        raise


def _main(argv, provider_factory, out, identity, tenancy):
    """main() without the refusal reporting."""
    ap = parser()
    a = ap.parse_args(argv)
    cli._check_ocid(a.compartment, ("compartment", "tenancy"), "--compartment")
    if a.with_instance:
        if not a.image_ocid:
            ap.error("--with-instance needs --image-ocid ocid1.image... for your region")
        cli._check_ocid(a.image_ocid, ("image",), "--image-ocid")
    if not a.apply:
        return _run(a, None, out)
    from ocio.journal import exclusive, JournalError
    try:
        with exclusive(a.journal):
            if provider_factory is None:                 # the real tenancy, as the main command line does it
                import oci
                cfg, signer, mk = cli._oci_session(a)
                identity, tenancy = identity or mk(oci.identity.IdentityClient), cfg.get("tenancy")

                def provider_factory():
                    from ocio.providers import OCISDKProvider
                    return OCISDKProvider(config=cfg, signer=signer, availability_domain=a.availability_domain,
                                          timeout=a.sdk_timeout)
            if identity is not None:
                cli._check_ad(identity, tenancy, a.availability_domain, a.compartment)
            return _run(a, provider_factory(), out)
    except JournalError as e:
        raise cli.Refused(str(e)) from None


def _run(a, provider, out):
    """Plan the workflows (policy gates), print the plan, and with a provider: create the network, then the
    instance, verify each reached its ready state, tear both down newest first (unless --keep), verify the
    journal's hash chain, and print the report. Returns 0 PASS, 1 FAIL, 2 blocked by policy."""

    suffix = uuid.uuid4().hex[:6]
    lz, inst = workflows(a, suffix)
    eng = Engine(provider, Journal(a.journal), gates=gates(a.shape))

    plan = eng.plan(lz)
    out(json.dumps({"mode": "APPLY" if a.apply else "DRY RUN", "plan": plan,
                    "instance": None if inst is None else {"shape": a.shape, "ocpus": a.ocpus,
                                                            "memory_gbs": a.memory_gbs}}, indent=2))
    if plan["violations"]:
        out("BLOCKED by policy: " + "; ".join(plan["violations"])); return 2
    if not a.apply:
        out("Dry run only: nothing was created. Re-run with --apply to create and then tear down."); return 0

    report = {"journal": os.path.abspath(a.journal)}
    net = eng.apply(lz)
    report["network"] = {"status": net.status, "error": net.error, "ids": {k: v["id"] for k, v in net.outputs.items()}}
    vm = None
    if net.status == "SUCCEEDED" and inst is not None:
        steps = tuple(Step(s.id, s.kind, dict(s.params, subnet_id=net.outputs["subnet"]["id"]), s.depends_on)
                      for s in inst.steps)
        inst = Workflow(inst.name, inst.environment, inst.compartment_id, steps, inst.tags)
        vm = eng.apply(inst)
        report["instance"] = {"status": vm.status, "error": vm.error,
                              "ids": {k: v["id"] for k, v in vm.outputs.items()}}
    ok = net.status == "SUCCEEDED" and (vm is None or vm.status == "SUCCEEDED")
    if not a.keep:
        if vm is not None:
            report["instance_teardown"] = vars(eng.teardown(inst, vm.run_id))
        report["network_teardown"] = vars(eng.teardown(lz, net.run_id))
    report["journal_intact"] = Journal(a.journal).verify()
    report["result"] = "PASS" if ok and report["journal_intact"] and not any(
        report.get(k, {}).get("orphans") for k in ("instance_teardown", "network_teardown")) else "FAIL"
    out(json.dumps(report, indent=2, default=str))
    return 0 if report["result"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
