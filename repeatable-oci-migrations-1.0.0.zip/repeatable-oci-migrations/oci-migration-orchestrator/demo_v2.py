"""SIMULATED end-to-end run of all five parts. No OCI tenancy involved.

  python -B demo_v2.py

1 Discovery on examples/estate (54 VMs): app groups, tiers, dependencies, with confidence and evidence.
  A stand-in reviewer accepts high-confidence dependencies and rejects low-confidence ones.
2 Blueprint factory, with the rule-based agent proposing values behind the guard.
3 Wave planner: dependency order, mutual groups, VM cap.
  Windows VMs have no blueprint in the example catalog, so their apps are blocked, and so is every app
  that depends on them (the report names each one and why).
4 Guarded execution in prod against a simulated OCI that throttles (429), kills the process during
  wave 2, and fails one instance in the last wave. Quota preflight and approvals apply; the journal
  records every approval.
5 The same command, run again after the crash: wave 1 is skipped, wave 2 resumes, the last wave fails and
  is rolled back. 6 The cause is fixed and the same command runs a third time: the finished waves are
  skipped, the last wave starts fresh, and the migration of the unblocked apps completes.

How to read the last line: instances live / placed (must be equal), live resources sharing a name (duplicates:
must be 0), approvals journalled (prod waves need one each), journal intact (hash chain verified) and the 429
responses the adaptive limiter saw. Output is deterministic and saved as examples/demo_v2_output.txt; the Monte
Carlo script re-runs it and requires a byte-identical result. The reviewer and approver here are stand-ins
written into the script, marked as such; in real use they are people, named in the decisions file and on the
command line.
"""
import json
import os
import random
import tempfile

from ocio import agent as A, capacity as C, discovery as D, pipeline as P
from ocio.catalog import BLUEPRINTS
from ocio.engine import Engine, RetryPolicy
from ocio.journal import Journal
from ocio.providers import Crash, FakeOCI

HERE = os.path.dirname(os.path.abspath(__file__))
EST = os.path.join(HERE, "examples", "estate")


class Clock:
    """Virtual clock handed to the engine: calling it returns simulated time, sleep() adds to it instantly, so
    backoffs and readiness polls cost no real time and the printed output is identical on every run."""
    t = 0.0
    def __call__(self): return self.t
    def sleep(self, s): self.t += s


def main():
    """Run the six steps in order and print each one's result (see the module docstring)."""
    # 1 Discovery and review
    res = D.discover(D.load_assets(f"{EST}/assets.csv"), D.load_flows(f"{EST}/flows.csv"),
                     D.load_listeners(f"{EST}/listeners.csv"))
    rep = res.report()
    hi = [d for d in rep["dependencies"] if d["confidence"] >= 0.6]
    lo = [d for d in rep["dependencies"] if d["confidence"] < 0.6]
    print("== 1 Discovery ==")
    print(f"{rep['vms']} VMs -> {len(rep['apps'])} apps; app evidence {rep['app_sources']}; tier evidence {rep['tier_sources']}")
    print(f"dependencies: {len(hi)} high-confidence, {len(lo)} low-confidence; "
          f"external {len(rep['external_dependencies'])}; infrastructure traffic excluded {list(rep['excluded_infrastructure_traffic'])}")
    print(f"flagged for review: {len(rep['low_confidence_vms'])} VMs")
    # Stand-in reviewer: accepts high-confidence dependencies, rejects low-confidence ones, and merges
    # name groups that traffic split (flagged "name+traffic") back into one app after checking them.
    merges = {n: D.name_app(n) for n, f in res.app.items() if f.source == "name+traffic"}
    decisions = {"dependencies": {**{d["dep"]: "accept" for d in hi}, **{d["dep"]: "reject" for d in lo}},
                 "apps": merges, "reviewed_by": "demo reviewer (stand-in)"}
    print(f"reviewer merged {len(merges)} VMs back into their named app")
    wls, summary = res.to_workloads(decisions)
    print("review:", summary)

    # 2-3 Factory + agent + waves (plan only)
    s = P.Settings("prod", "ocid1.compartment.oc1..acme-prod", {"cost_center": "cc-4410", "owner": "migration-factory"},
                   "acme", "10.20.0.0/16", {"web": "10.20.1.0/24", "app": "10.20.2.0/24", "db": "10.20.3.0/24"},
                   max_apps_per_wave=4, max_vms_per_wave=20)
    metrics = {wls[1].name: {"mem_peak_pct": 93}}
    proposer = A.RuleProposer(BLUEPRINTS, metrics)
    plan = P.run(wls, BLUEPRINTS, s, None, proposer=proposer, execute=False)
    print("\n== 2 Factory + agent ==")
    print(json.dumps(plan.summary(), indent=1))
    print("rejected proposals:", [(w, r[0]) for w, r in plan.rejected_proposals])
    print("\n== 3 Waves ==", plan.waves)

    # 4 Execute with faults: a crash in wave 2, a failed instance in wave 4
    in_wave = lambda k: sorted(p.workload.name for p in plan.placements if p.workload.app in plan.waves[k - 1])
    last = len(plan.waves)
    assert last >= 3, "the demo story needs at least three waves"
    crash_vm, fail_vm = in_wave(2)[-1], in_wave(last)[0]
    fake = FakeOCI(faults={("create", "instance"): [429, 0, 503, 0, 429]},
                   crash_after_create={crash_vm}, fail_provision={fail_vm})
    print(f"faults: process dies after creating {crash_vm} (wave 2); {fail_vm} fails to provision (wave {last})")
    jp = os.path.join(tempfile.mkdtemp(), "journal.jsonl")
    clock, lim = Clock(), C.AdaptiveLimiter(initial=4, maximum=16)
    mk = lambda: Engine(fake, Journal(jp), sleep=clock.sleep, clock=clock, rng=random.Random(7),
                        max_workers=16, limiter=lim, retry=RetryPolicy())
    quota = C.StaticQuota({"standard-e5-core-count": 400, "standard-e5-memory-count": 4000})
    approver = lambda name, reasons, plan_, wave_hash: (True, "J.C. Glover")
    print("\n== 4 Execute (prod, faults injected) ==")
    try:
        P.run(wls, BLUEPRINTS, s, mk, quota=quota, approver=approver, proposer=proposer)
    except Crash as c:
        print(f"PROCESS CRASHED: {c}")

    def show(out):
        for w in out.wave_results:
            why = w.get("why")
            print(f"wave {w['wave']} {w['apps']}: {w['status']}" + (f"  [{why}]" if isinstance(why, str) and why else ""))

    # 5 Same command again after the crash
    out = P.run(wls, BLUEPRINTS, s, mk, quota=quota, approver=approver, proposer=proposer)
    print("\n== 5 Same command, run again after the crash ==")
    show(out)
    # 6 Cause of the failed instance fixed; same command a third time
    fake.fail_provision.clear()
    out = P.run(wls, BLUEPRINTS, s, mk, quota=quota, approver=approver, proposer=proposer)
    print("\n== 6 Cause fixed; same command a third time ==")
    show(out)
    inst = sorted(r["params"]["display_name"] for r in fake.live().values() if r["kind"] == "instance")
    j = Journal(jp)
    print("\n== Result in (simulated) OCI ==")
    names = [r["params"].get("display_name") for r in fake.live().values()]
    print(f"instances live: {len(inst)} of {len(out.placements)} placed | live resources sharing a name: "
          f"{len(names) - len(set(names))} | approvals journalled: "
          f"{sum(1 for e in j.entries if e.get('event') == 'approval')} | journal intact: {j.verify()} | "
          f"429s seen by limiter: {lim.throttles}")


if __name__ == "__main__":
    main()
