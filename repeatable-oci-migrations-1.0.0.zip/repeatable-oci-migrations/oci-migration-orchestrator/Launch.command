#!/bin/bash
# OCIO one-click launch (macOS): double-click in Finder. Opens the launch console in your browser.
# The first time, macOS may ask you to allow it: right-click > Open, or System Settings > Privacy & Security.
cd "$(dirname "$0")" || exit 1
exec ./launch.sh "$@"
